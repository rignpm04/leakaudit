# verify.py -- checks this release against the SHA-256 commitment published on Zenodo before it.
# Run: python timestamp/verify.py   (Python 3, no packages needed)
import hashlib
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST_FILE = "MANIFEST_2026-10-23_2314.txt"
COMMITMENT_FILE = "COMMITMENT_2026-10-23_2314.txt"
CHECK_FOLDER = os.path.join(HERE, "..", "exploratory")


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    mpath = os.path.join(HERE, MANIFEST_FILE)
    committed = re.findall(r"^\s*([0-9a-f]{64})\s+MANIFEST_\S+\.txt\s*$",
                           open(os.path.join(HERE, COMMITMENT_FILE), encoding="utf-8").read(), re.M)
    mhash = sha256_file(mpath)
    if mhash not in committed:
        raise SystemExit("FAIL: the manifest's SHA-256 (%s) is not the one in the commitment." % mhash)
    print("Manifest matches the commitment (sha256 %s)." % mhash)
    known = {}
    for line in open(mpath, encoding="utf-8"):
        if line.startswith("#") or not line.strip():
            continue
        parts = line.rstrip("\n").split("  ", 3)
        if len(parts) == 4:
            known[parts[3]] = parts[0]
    ok, bad = 0, []
    for root, dirs, files in os.walk(CHECK_FOLDER):
        dirs.sort()
        for fn in sorted(files):
            if fn == ".DS_Store" or fn.startswith("._"):
                continue
            p = os.path.join(root, fn)
            rel = os.path.relpath(p, CHECK_FOLDER).replace(os.sep, "/")
            if known.get(rel) == sha256_file(p):
                ok += 1
            else:
                bad.append(rel)
    print("%d file(s) match the manifest exactly (same path, same SHA-256); %d do not." % (ok, len(bad)))
    for rel in bad[:30]:
        print("  not as timestamped: %s" % rel)
    if not bad:
        print("Every file under exploratory/ is exactly as timestamped.")


if __name__ == "__main__":
    main()
