# step4_evaluate.py -- step 4 of the leakage-auditor quick test: score the column check (step 2) and the LLM audit
# (step 3) against the documented leaks in cases.json and apply the kill rules. Python 3.9; press Run in PyCharm.
#
# Truth per column: a leak column = 1, every other column = 0; probable columns are left out of the scoring and
# listed separately. Thresholds are tuned for the best macro recall while the total number of false flags (over all
# datasets, leak and clean) stays within BUDGET_FF_PER_DATASET x number of datasets; ties go to fewer false flags.
# Methods: column check at a fixed 0.80 (H2O-like) and 0.925 (about DataRobot's normalized Gini 0.85), column check
# tuned, each LLM x condition tuned, and combined (flag if score >= t1 OR leak_risk >= t2) for each LLM x condition.
# "Column check strongest" tunes separate thresholds for binary and regression cases and tries every regression score
# step 2 wrote (Gini, concordance, R^2); it is the baseline for the kill rules, so the LLM has to beat the best
# version of the vendor check, not a weak one.
# Recognition: probes.csv (step 3) holds each model's guesses of which public dataset the real and the disguised table
# come from. A model whose disguised recognition@3 exceeds RECOG_MAX fails the gate: its disguised result is not a
# clean memorization control. K3 compares the disguised gain with the real gain (reworded if there is no disguised
# condition); GO needs a model that passes the gate and whose disguised combined method recovers GO_RECOVER of the
# baseline's misses.
# Output: results.txt (also printed).

import os
import sys
from typing import Any, Dict, List, Optional, Tuple

# ============================================================ settings (edit here)
BUDGET_FF_PER_DATASET = 1.0   # allowed false flags = this x number of datasets (leak and clean)
K1_RECALL = 0.90              # KILL if the tuned column check alone reaches this macro recall
THIN_GAP = 0.75               # warn if the tuned column check is between this and K1_RECALL
K2_GAIN = 0.15                # KILL if the best combined method (real names) adds less macro recall than this
K3_RETAIN = 0.5               # KILL if the disguised (else reworded) gain is below this share of the real gain
GO_RECOVER = 0.5              # GO needs a gate-passing model whose disguised combined method recovers this share
RECOG_MAX = 0.15              # gate: a model's disguised recognition@3 must not exceed this
H2O_LIKE = 0.80               # fixed column-check thresholds (AUC / concordance)
DATAROBOT_LIKE = 0.925

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

CC_FILE = "scores_column_check.csv"
LLM_FILE = "scores_llm.csv"
PROBE_FILE = "probes.csv"
OUT_FILE = "results.txt"
T1_GRID: List[Optional[float]] = [None] + [round(1.0 - 0.01 * i, 2) for i in range(46)]   # off, 1.00 ... 0.55
T2_GRID: List[Optional[float]] = [None] + [float(x) for x in range(100, -1, -5)]          # off, 100 ... 0
R2_GRID: List[Optional[float]] = [None] + [round(1.0 - 0.02 * i, 2) for i in range(51)]  # off, 1.00 ... 0.00
REG_METRICS = ["gini", "concordance", "r2"]
COND_ORDER = ["real", "reworded", "scrambled", "disguised"]


def read_scores(name: str) -> Optional[pd.DataFrame]:
    p = common.path(name)
    if not os.path.exists(p):
        return None
    return pd.read_csv(p, dtype=str, keep_default_na=False)


def nz(x: float) -> float:
    return 0.0 if x is None or not np.isfinite(x) else float(x)


def fmt_t(t: Optional[float], llm: bool = False) -> str:
    if t is None:
        return "off"
    if llm:
        return "%d" % t
    s = "%.3f" % t
    return s[:-1] if s.endswith("0") else s   # 0.80, 0.925, 1.00


def fmt_r(x: float) -> str:
    return "n/a" if x is None or not np.isfinite(x) else "%.2f" % x


def recognized(guess: str, case: Dict[str, Any]) -> bool:
    return common.guess_matches(guess, case)  # name, id or any alias (see common.py)


class Scorer:
    """Flags -> macro / micro recall over leak datasets and false flags over all datasets."""

    def __init__(self, df: pd.DataFrame, datasets: List[str], by_id: Dict[str, Dict[str, Any]], budget: float):
        self.truth = df["is_leak"].to_numpy(dtype=bool)
        self.score = np.nan_to_num(df["score"].to_numpy(dtype=float), nan=-1.0)
        self.ds = df["case_id"].map({d: i for i, d in enumerate(datasets)}).to_numpy(dtype=int)
        self.n_ds = len(datasets)
        self.leak_total = np.bincount(self.ds, weights=self.truth.astype(float), minlength=self.n_ds)
        kind_leak = np.array([by_id[d]["kind"] == "leak" for d in datasets], dtype=bool)
        self.recall_ds = kind_leak & (self.leak_total > 0)
        self.in_recall = self.recall_ds[self.ds]
        self.budget = budget

    def evaluate(self, flags: np.ndarray) -> Dict[str, Any]:
        caught = np.bincount(self.ds, weights=(flags & self.truth).astype(float), minlength=self.n_ds)
        ff = np.bincount(self.ds, weights=(flags & ~self.truth).astype(float), minlength=self.n_ds)
        if self.recall_ds.any():
            macro = float(np.mean(caught[self.recall_ds] / self.leak_total[self.recall_ds]))
            micro = float(caught[self.recall_ds].sum() / self.leak_total[self.recall_ds].sum())
        else:
            macro = micro = float("nan")
        n_flags = int(flags.sum())
        precision = float((flags & self.truth).sum()) / n_flags if n_flags else float("nan")
        return {"macro": macro, "micro": micro, "ff": int(round(ff.sum())), "ff_ds": int((ff > 0).sum()),
                "precision": precision, "flags": flags, "caught": caught, "ff_per": ff}

    def flags(self, t1: Optional[float], risk: Optional[np.ndarray], t2: Optional[float]) -> np.ndarray:
        f = np.zeros(len(self.truth), dtype=bool)
        if t1 is not None:
            f |= self.score >= t1 - 1e-9
        if t2 is not None and risk is not None:
            f |= np.nan_to_num(risk, nan=-1.0) >= t2 - 1e-9
        return f

    def tune(self, risk: Optional[np.ndarray], t1_grid: List[Optional[float]],
             t2_grid: List[Optional[float]]) -> Tuple[Optional[float], Optional[float], Dict[str, Any]]:
        """Best macro recall within the false-flag budget; ties: fewer false flags, then stricter thresholds."""
        best = None
        for t1 in t1_grid:
            for t2 in t2_grid:
                res = self.evaluate(self.flags(t1, risk, t2))
                if res["ff"] > self.budget + 1e-9:
                    continue
                key = (nz(res["macro"]), -res["ff"])
                if best is None or key > best[0]:
                    best = (key, t1, t2, res)
        return best[1], best[2], best[3]  # "off/off" flags nothing, so something always fits the budget


def main() -> None:
    lines: List[str] = []

    def out(s: str = "") -> None:
        print(s)
        lines.append(s)

    cases = common.load_cases(quiet=True)
    by_id = {c["id"]: c for c in cases}
    cc = read_scores(CC_FILE)
    if cc is None or cc.empty:
        print("No %s -- run step2_column_check.py first." % CC_FILE)
        return
    cc["score"] = pd.to_numeric(cc["score"], errors="coerce")
    for m in REG_METRICS:
        col_name = "score_" + m
        cc[col_name] = pd.to_numeric(cc[col_name], errors="coerce") if col_name in cc.columns else np.nan
    gone = sorted(set(cc["case_id"]) - set(by_id))
    cc = cc[cc["case_id"].isin(by_id)].reset_index(drop=True)
    if cc.empty:
        print("None of the scored cases are in cases.json any more -- run steps 1 and 2 again.")
        return
    datasets = [c["id"] for c in cases if c["id"] in set(cc["case_id"])]
    cc["kind"] = cc["case_id"].map(lambda c: by_id[c]["kind"])
    cc["is_leak"] = [col in by_id[cid]["leak_columns"] for cid, col in zip(cc["case_id"], cc["column"])]
    cc["is_probable"] = [col in by_id[cid]["probable_leak_columns"] for cid, col in zip(cc["case_id"], cc["column"])]

    llm = read_scores(LLM_FILE)
    if llm is not None:
        llm["leak_risk"] = pd.to_numeric(llm["leak_risk"], errors="coerce")
        llm = llm[llm["case_id"].isin(datasets)]
        if llm.empty:
            llm = None
    pairs: List[Tuple[str, str]] = []
    conds: List[str] = []
    if llm is not None:
        conds = [c for c in COND_ORDER if c in set(llm["condition"])]
        conds += sorted(set(llm["condition"]) - set(conds))
        for m in dict.fromkeys(llm["model"]):
            for c in conds:
                if ((llm["model"] == m) & (llm["condition"] == c)).any():
                    pairs.append((m, c))

    # recognition probes: (model, condition) -> {case_id: one of the guesses names the case}
    recog: Dict[Tuple[str, str], Dict[str, bool]] = {}
    probes = read_scores(PROBE_FILE)
    if probes is not None:
        for _, r in probes[probes["case_id"].isin(by_id)].iterrows():
            hit = any(common.guess_matches(r.get("guess%d" % k, ""), by_id[r["case_id"]]) for k in (1, 2, 3))
            recog.setdefault((r["model"], r["condition"]), {})[r["case_id"]] = hit

    out("Leakage-auditor quick test -- results (%s)" % common.stamp())
    if any(m.startswith("mock-") for m, _ in pairs):
        out("WARNING: the LLM scores come from MOCK mode (a fake offline LLM). The verdict below is meaningless; "
            "run step 3 with MOCK = False.")
    if gone:
        out("note: ignoring scored cases that are no longer in cases.json: %s" % ", ".join(gone))
    for cid in datasets:
        have = set(cc.loc[cc["case_id"] == cid, "column"])
        absent = [c for c in by_id[cid]["leak_columns"] + by_id[cid]["probable_leak_columns"] if c not in have]
        if absent:
            out("note: %s lists %s, not among its scored columns (run steps 1-2 again) -- ignored" % (cid, absent))
    not_scored = [c["id"] for c in cases if c["id"] not in set(datasets)]
    if not_scored:
        out("note: cases in cases.json without column-check scores (failed or not run): %s" % ", ".join(not_scored))

    probable = cc[cc["is_probable"]].reset_index(drop=True)
    sc = cc[~cc["is_probable"]].reset_index(drop=True)
    budget = BUDGET_FF_PER_DATASET * len(datasets)
    S = Scorer(sc, datasets, by_id, budget)
    keys = list(zip(sc["case_id"], sc["column"]))
    risk: Dict[Tuple[str, str], np.ndarray] = {}
    detail: Dict[Tuple[str, str], Dict[Tuple[str, str], Tuple[float, str, str]]] = {}
    guesses: Dict[Tuple[str, str], Dict[str, str]] = {}
    for m, c in pairs:
        sub = llm[(llm["model"] == m) & (llm["condition"] == c)]
        d = {(a, b): (r, cat, why) for a, b, r, cat, why in
             zip(sub["case_id"], sub["column"], sub["leak_risk"], sub["category"], sub["reason"])}
        detail[(m, c)] = d
        risk[(m, c)] = np.array([d[k][0] if k in d else np.nan for k in keys], dtype=float)
        guesses[(m, c)] = dict(zip(sub["case_id"], sub["dataset_guess"]))

    n_leak_ds = int(S.recall_ds.sum())
    out("Datasets: %d (%d leak, %d clean); leak columns scored: %d; probable columns (left out): %d; "
        "false-flag budget: %.0f in total"
        % (len(datasets), sum(by_id[d]["kind"] == "leak" for d in datasets),
           sum(by_id[d]["kind"] == "clean" for d in datasets), int(S.truth.sum()), len(probable), budget))
    for m, c in pairs:
        covered = len(guesses[(m, c)])
        blank = int(np.isnan(risk[(m, c)]).sum())
        if covered < len(datasets) or blank:
            out("note: LLM %s / %s covers %d of %d datasets; %d scored columns have no risk (count as not flagged)"
                % (m, c, covered, len(datasets), blank))
    if n_leak_ds == 0:
        out("\nNo kind 'leak' dataset with a scored leak column -- recall cannot be computed.")

    # ---------------------------------------------------------------- methods
    methods: List[Dict[str, Any]] = []
    for name, t in (("column check @0.80 (H2O-like)", H2O_LIKE), ("column check @0.925 (DataRobot-like)",
                                                                  DATAROBOT_LIKE)):
        methods.append({"name": name, "family": "fixed", "t1": t, "t2": None, "res": S.evaluate(S.flags(t, None, None))})
    t1, _, res = S.tune(None, T1_GRID, [None])
    col_single = {"name": "column check tuned", "family": "column", "t1": t1, "t2": None, "res": res}
    methods.append(col_single)

    # strongest column check: separate binary / regression thresholds, every regression score step 2 wrote
    is_bin = (sc["task"] == "binary").to_numpy()
    bin_vals = np.where(np.isfinite(sc["score_gini"].to_numpy(dtype=float)), sc["score_gini"].to_numpy(dtype=float),
                        sc["score"].to_numpy(dtype=float))
    bin_vals = np.nan_to_num(bin_vals, nan=-1.0)
    variants = []
    for m in REG_METRICS:
        reg_vals = sc["score_" + m].to_numpy(dtype=float)
        if not np.isfinite(reg_vals[~is_bin]).any() and (~is_bin).any():
            continue
        reg_vals = np.nan_to_num(reg_vals, nan=-1.0)
        grid_reg = R2_GRID if m == "r2" else T1_GRID
        best_v = None
        for tb in T1_GRID:
            fb = is_bin & (bin_vals >= (tb if tb is not None else 9.0) - 1e-9)
            for tr in grid_reg:
                f = fb | ((~is_bin) & (reg_vals >= (tr if tr is not None else 9.0) - 1e-9))
                r = S.evaluate(f)
                if r["ff"] > S.budget + 1e-9:
                    continue
                key = (nz(r["macro"]), -r["ff"])
                if best_v is None or key > best_v[0]:
                    best_v = (key, tb, tr, r)
        if best_v is not None:
            variants.append({"name": "column check strongest (regression: %s)" % m, "family": "column", "metric": m,
                             "t1": best_v[1], "t1_reg": best_v[2], "t2": None, "res": best_v[3]})
    for v in variants:
        methods.append(v)
    col = max(variants, key=lambda x: (nz(x["res"]["macro"]), -x["res"]["ff"])) if variants else col_single
    if nz(col_single["res"]["macro"]) > nz(col["res"]["macro"]):
        col = col_single
    llm_m, comb = [], []
    for m, c in pairs:
        _, t2, res = S.tune(risk[(m, c)], [None], T2_GRID)
        llm_m.append({"name": "LLM %s / %s tuned" % (m, c), "family": "llm", "model": m, "cond": c, "t1": None,
                      "t2": t2, "res": res})
    for m, c in pairs:
        t1, t2, res = S.tune(risk[(m, c)], T1_GRID, T2_GRID)
        comb.append({"name": "combined %s / %s" % (m, c), "family": "combined", "model": m, "cond": c, "t1": t1,
                     "t2": t2, "res": res})
    methods += llm_m + comb

    def best_of(ms: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        return max(ms, key=lambda x: (nz(x["res"]["macro"]), -x["res"]["ff"])) if ms else None

    best_llm_real = best_of([x for x in llm_m if x["cond"] == "real"])
    best_real = best_of([x for x in comb if x["cond"] == "real"])
    best_rew = best_of([x for x in comb if x["cond"] == "reworded"])
    best_scr = best_of([x for x in comb if x["cond"] == "scrambled"])
    best_dis = best_of([x for x in comb if x["cond"] == "disguised"])

    def find(ms: List[Dict[str, Any]], m: str, c: str) -> Optional[Dict[str, Any]]:
        return next((x for x in ms if x["model"] == m and x["cond"] == c), None)

    def macro_on(x: Optional[Dict[str, Any]], subset: List[int]) -> str:
        if x is None or not subset:
            return "n/a"
        return "%.2f" % float(np.mean([x["res"]["caught"][i] / S.leak_total[i] for i in subset]))

    # gate: each model's disguised recognition@3 must not exceed RECOG_MAX
    gate: Dict[str, bool] = {}
    for (m, c), d in recog.items():
        if c == "disguised" and d:
            gate[m] = sum(d.values()) / float(len(d)) <= RECOG_MAX + 1e-12

    out("\nMETHODS (macro recall = mean per-dataset recall over leak datasets; false flags and precision over all "
        "datasets)")
    def t1_text(x: Dict[str, Any]) -> str:
        if "t1_reg" in x:
            return "bin %s / reg %s" % (fmt_t(x["t1"]), fmt_t(x["t1_reg"]))
        return fmt_t(x["t1"])

    rows = [[x["name"], t1_text(x), fmt_t(x["t2"], llm=True), fmt_r(x["res"]["macro"]), fmt_r(x["res"]["micro"]),
             x["res"]["ff"], x["res"]["ff_ds"], fmt_r(x["res"]["precision"])] for x in methods]
    out(common.format_table(["method", "t1 (score)", "t2 (risk)", "macro recall", "micro recall", "false flags",
                             "datasets with a false flag", "precision"], rows))

    out("\nPER DATASET (leak columns caught / false flags)")
    rows = []
    for i, d in enumerate(datasets):
        r = [d, by_id[d]["kind"], int(S.leak_total[i]),
             "%d / %d" % (col["res"]["caught"][i], col["res"]["ff_per"][i])]
        if best_real:
            r.append("%d / %d" % (best_real["res"]["caught"][i], best_real["res"]["ff_per"][i]))
        rows.append(r)
    out(common.format_table(["dataset", "kind", "leak columns", "column check (baseline)"]
                            + (["best combined (real): " + best_real["name"]] if best_real else []), rows))

    # ---------------------------------------------------------------- breakdown by the leak's own score
    out("\nLEAK COLUMNS BY THEIR OWN COLUMN-CHECK SCORE (leak datasets only)")
    leak_idx = np.flatnonzero(S.truth & S.in_recall)
    rows = []
    for name, lo, hi in (("< 0.70", -np.inf, 0.70), ("0.70 - 0.85", 0.70, 0.85), (">= 0.85", 0.85, np.inf)):
        idx = [i for i in leak_idx if lo <= S.score[i] < hi]
        r = [name, len(idx), sum(bool(col["res"]["flags"][i]) for i in idx)]
        r.append(sum(bool(best_llm_real["res"]["flags"][i]) for i in idx) if best_llm_real else "-")
        r.append(sum(bool(best_real["res"]["flags"][i]) for i in idx) if best_real else "-")
        rows.append(r)
    out(common.format_table(["score bucket", "leak columns", "column check (baseline)",
                             "best LLM (real)" + (": " + best_llm_real["name"] if best_llm_real else ""),
                             "best combined (real)" + (": " + best_real["name"] if best_real else "")], rows))

    # ---------------------------------------------------------------- lists for manual review
    def llm_notes(cid: str, column: str) -> List[str]:
        notes = []
        for m in dict.fromkeys(p[0] for p in pairs):
            parts = []
            for c in [p[1] for p in pairs if p[0] == m]:
                v = detail[(m, c)].get((cid, column))
                parts.append("%s %s" % (c, "-" if v is None or not np.isfinite(v[0]) else "%.0f" % v[0]))
            real = detail.get((m, "real"), {}).get((cid, column))
            why = (" | real: [%s] %s" % (real[1], real[2])) if real else ""
            notes.append("      %s: %s%s" % (m, ", ".join(parts), why))
        return notes

    out("\nLEAK COLUMNS MISSED BY THE BASELINE COLUMN CHECK (%s, thresholds %s)" % (col["name"], t1_text(col)))
    missed = [i for i in leak_idx if not col["res"]["flags"][i]]
    if not missed:
        out("  none")
    for i in missed:
        cid, column = keys[i]
        out("  %s / %s  (score %.3f)" % (cid, column, S.score[i]))
        for n in llm_notes(cid, column):
            out(n)

    if best_real:
        out("\nFALSE FLAGS OF THE BEST COMBINED METHOD (%s: t1 %s, t2 %s) -- for manual review"
            % (best_real["name"], fmt_t(best_real["t1"]), fmt_t(best_real["t2"], llm=True)))
        r = risk[(best_real["model"], best_real["cond"])]
        ff_idx = np.flatnonzero(best_real["res"]["flags"] & ~S.truth)
        if len(ff_idx) == 0:
            out("  none")
        for i in ff_idx:
            cid, column = keys[i]
            by_score = best_real["t1"] is not None and S.score[i] >= best_real["t1"] - 1e-9
            by_llm = best_real["t2"] is not None and np.isfinite(r[i]) and r[i] >= best_real["t2"] - 1e-9
            v = detail[(best_real["model"], "real")].get((cid, column))
            out("  %s / %s (%s): score %.3f, risk %s, flagged by %s%s"
                % (cid, column, by_id[cid]["kind"], S.score[i], "-" if not np.isfinite(r[i]) else "%.0f" % r[i],
                   "both" if by_score and by_llm else ("column check" if by_score else "LLM"),
                   (" -- [%s] %s" % (v[1], v[2])) if v else ""))

    out("\nPROBABLE LEAK COLUMNS (not scored)")
    if probable.empty:
        out("  none")
    for _, p in probable.iterrows():
        out("  %s / %s  (score %.3f)" % (p["case_id"], p["column"], p["score"]))
        for n in llm_notes(p["case_id"], p["column"]):
            out(n)

    if pairs:
        out("\nDATASET RECOGNITION (dataset_guess matches the case name or id)")
        rows = []
        for m, c in pairs:
            g = guesses[(m, c)]
            hits = [cid for cid, v in g.items() if recognized(v, by_id[cid])]
            named = sorted(set(v for v in g.values() if v))
            rows.append([m, c, "%d / %d" % (len(hits), len(g)), "; ".join(named)[:90]])
        out(common.format_table(["model", "condition", "recognized", "guesses"], rows))

    if recog:
        out("\nRECOGNITION PROBES (recognition@3: one of up to 3 guesses names the case, its id or an alias)")
        rows = []
        p_models = list(dict.fromkeys(m for m, _ in recog))
        p_conds = [c for c in COND_ORDER if any(k[1] == c for k in recog)]
        p_conds += sorted(set(k[1] for k in recog) - set(p_conds))
        for m in p_models:
            for c in p_conds:
                d = recog.get((m, c))
                if not d:
                    continue
                k = sum(d.values())
                g = ("PASS" if gate[m] else "FAIL") if c == "disguised" else ""
                rows.append([m, c, "%d / %d" % (k, len(d)), "%.0f%%" % (100.0 * k / len(d)), g])
        out(common.format_table(["model", "condition", "recognized", "recognition@3",
                                 "gate (disguised <= %.0f%%)" % (100 * RECOG_MAX)], rows))
        for m, ok in gate.items():
            if not ok:
                d = recog[(m, "disguised")]
                out("WARNING: %s recognizes %.0f%% of the disguised tables (more than RECOG_MAX = %.0f%%): its "
                    "disguised result is not a clean memorization control."
                    % (m, 100.0 * sum(d.values()) / len(d), 100 * RECOG_MAX))

    llm_models = list(dict.fromkeys(m for m, _ in pairs))
    if llm_models:
        out("\nPER MODEL (macro recall: LLM only, tuned / combined with the column check)")
        rows = []
        for m in llm_models:
            for fam, ms in (("LLM only", llm_m), ("combined", comb)):
                rows.append([m, fam] + [fmt_r(find(ms, m, c)["res"]["macro"]) if find(ms, m, c) else "-"
                                        for c in conds])
        out(common.format_table(["model", "method"] + conds, rows))
        if any(c == "disguised" for _, c in pairs):
            out("\nDISGUISED, UNRECOGNIZED ONLY (macro recall over the leak datasets the model did not recognize in "
                "its disguised probe; the baseline column check on the same datasets)")
            rows = []
            for m in llm_models:
                cd, ld = find(comb, m, "disguised"), find(llm_m, m, "disguised")
                if cd is None:
                    continue
                d = recog.get((m, "disguised"))
                if not d:
                    rows.append([m, "no probes", "-", "-", "-", "-"])
                    continue
                subset = [i for i, ds in enumerate(datasets) if S.recall_ds[i] and ds in d and not d[ds]]
                rows.append([m, "PASS" if gate.get(m) else "FAIL", len(subset), macro_on(cd, subset),
                             macro_on(ld, subset), macro_on(col, subset)])
            out(common.format_table(["model", "gate", "leak datasets", "combined (disguised)", "LLM only (disguised)",
                                     "baseline column check"], rows))

    # ---------------------------------------------------------------- verdict
    out("\nVERDICT (computed on kind 'leak' cases)")
    ct = col["res"]["macro"]
    kills: List[str] = []
    verdict = ""
    if n_leak_ds == 0:
        verdict = "NOT EVALUATED (no leak dataset with scored leak columns)"
    else:
        out("  baseline = %s: macro recall %.2f (thresholds %s)" % (col["name"], ct, t1_text(col)))
        if ct >= K1_RECALL:
            kills.append("K1: the column check alone reaches %.2f >= %.2f" % (ct, K1_RECALL))
        elif ct >= THIN_GAP:
            out("  WARNING (thin gap): the column check already reaches %.2f; at most %.2f of recall is left "
                "to gain" % (ct, 1 - ct))
        if not pairs:
            out("  LLM scores missing (run step 3) -- K2, K3 and GO not evaluated.")
            verdict = "KILL (%s)" % kills[0][:2] if kills else "INCOMPLETE (no LLM scores; K1 passed)"
        else:
            gain_real = None
            if best_real is None:
                out("  K2 not evaluated: no 'real' condition in %s" % LLM_FILE)
            else:
                gain_real = best_real["res"]["macro"] - ct
                out("  best combined (real): %s, macro recall %.2f, gain %+.2f (K2 needs >= %.2f)"
                    % (best_real["name"], best_real["res"]["macro"], gain_real, K2_GAIN))
                if gain_real < K2_GAIN:
                    kills.append("K2: the best combined method (real) adds %+.2f < %.2f" % (gain_real, K2_GAIN))
            # K3 compares the disguised gain with the real gain; without a disguised condition, the reworded one
            k3 = best_dis if best_dis is not None else best_rew
            if best_rew is not None and k3 is not best_rew:
                out("  best combined (reworded): %s, macro recall %.2f, gain %+.2f (information only)"
                    % (best_rew["name"], best_rew["res"]["macro"], best_rew["res"]["macro"] - ct))
            if best_scr is not None:
                out("  best combined (scrambled): %s, macro recall %.2f, gain %+.2f (information only)"
                    % (best_scr["name"], best_scr["res"]["macro"], best_scr["res"]["macro"] - ct))
            if k3 is None:
                out("  K3 not evaluated: no 'disguised' or 'reworded' condition in %s" % LLM_FILE)
            else:
                k3_cond = k3["cond"]
                gain_k3 = k3["res"]["macro"] - ct
                out("  best combined (%s): %s, macro recall %.2f, gain %+.2f (K3 needs >= %.1f x the real gain)"
                    % (k3_cond, k3["name"], k3["res"]["macro"], gain_k3, K3_RETAIN))
                if gain_real is not None and gain_k3 < K3_RETAIN * gain_real:
                    kills.append("K3: the %s gain %+.2f is below %.1f x the real gain %+.2f -- the edge comes from "
                                 "recognizing datasets" % (k3_cond, gain_k3, K3_RETAIN, gain_real))
            if kills:
                verdict = "KILL (%s)" % ", ".join(k[:2] for k in kills)
            elif best_real is None:
                verdict = "INCOMPLETE (no 'real' condition)"
            elif best_dis is None:
                verdict = "INCOMPLETE (GO needs the disguised condition: run step 3 with it)"
            elif not gate:
                verdict = "INCOMPLETE (GO needs the recognition probes: run step 3 with PROBES = True)"
            else:
                miss = [i for i in leak_idx if not col["res"]["flags"][i]]
                cands = []
                for m in dict.fromkeys(x["model"] for x in comb if x["cond"] == "disguised"):
                    x = find(comb, m, "disguised")
                    if m not in gate:
                        out("  %s: no disguised probe -- cannot pass the recognition gate" % m)
                        continue
                    back = sum(bool(x["res"]["flags"][i]) for i in miss)
                    share = back / float(len(miss)) if miss else 0.0
                    out("  %s: recognition gate %s; its disguised combined method recovers %d of the baseline's %d "
                        "missed leak columns (%.0f%%; GO needs %.0f%%)"
                        % (m, "PASS" if gate[m] else "FAIL", back, len(miss), 100 * share, 100 * GO_RECOVER))
                    if gate[m]:
                        cands.append((share, m))
                if not cands:
                    verdict = "NO GO (no model passes the recognition gate)"
                else:
                    share, m = max(cands)
                    verdict = ("GO (model: %s)" % m if share >= GO_RECOVER else
                               "NO GO (no kill rule fired, but the best model passing the gate, %s, recovers only "
                               "%.0f%% of the misses)" % (m, 100 * share))
    for k in kills:
        out("  " + k)
    out("\nVERDICT: " + verdict)
    out("Caveat: thresholds are tuned on the same data, which is optimistic for every method equally; the sample is "
        "small, so read the results as directional.")

    with open(common.path(OUT_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n(written to %s)" % OUT_FILE)


if __name__ == "__main__":
    main()
