# Leak real test 2: 47 new real datasets

- **What's here:** 35 public tables with documented leaks and 12 clean tables. None of them is one of the first test's 27.
- **Download:** every table downloads from GitHub.
- **Leak sources:** every definite leak has a source quoted word for word.
- **Independent check:** a second pass reviewed every column of every table against its prediction moment.
- **`catalog.csv`:** lists each table's target, prediction moment, leak columns, debatable columns and source.

## Run it (PyCharm, Python 3.9)

1. Put this folder in your PyCharm project. It must be its own folder, not your `leaktest` folder.
2. **`step1_get_data.py`:** downloads and prepares the 47 tables, about 85 MB. It must print `47 of 47 cases ready`.
3. **`step2_column_check.py`:** the no-AI column check.
4. **Optional, about $5:** the frontier models' scores on the new set, for reference.
   - In `step3_llm_audit.py`, paste your keys on your Mac only and set `DRY_RUN = False`. Run it, then run `step4_evaluate.py`.
   - Never send `step3_llm_audit.py` with keys in it.

## Task sentences (rewritten 2026-10-20, before any model was scored on this set)

- **What changed:** the unit, target and prediction-moment sentences every model sees no longer list the table's columns, say which values are or aren't known, or define the target through other columns. The first version of these sentences gave many answers away.
- **Key:** an independent reviewer checked each rewrite against the answer key. Three columns became debatable, so they count neither way: `islr_smarket` Volume, `aer_psid1976_labor_participation` unemp and `himalayan_expedition_members_died` solo.
- **Record:** `task_text_changes.json` lists every old and new sentence and the rules used.
- **The data didn't change.** You don't need to rerun `step1_get_data.py`. Rerun `step2_column_check.py` so its scores use the updated key.

## Human labeling (20 of the 47 tables)

- **`leak_labeling_20_tables_v2.xlsx`** (sent separately) goes to the labeler. Don't use the first version, which had the old sentences. It holds no answers. Tabs T01–T20 are 15 leak tables and 5 clean ones, in a fixed random order.
- **`label_codes.json`** maps T01–T20 to the case ids. Never send it, `cases.json` or `catalog.csv` to the labeler.
- **When the workbook comes back:** put it in this folder, set `LABELS_FILE` in `step5_score_labels.py` if the name changed, and press Run. It prints agreement and Cohen's kappa against the key, and lists every disagreement with the labeler's reason. It also writes `label_review.csv`.
- **Key fixes:** decide them from that review before anyone reads model results on this set. After that, the key is frozen.

## Rules (fixed now, before fine-tune run 2)

- **This set is the clean test for run 2.** Model results on it must not change anything in run 2. They are read once, for the verdict.
- **The first 27 (`leaktest`) are now development data,** since we studied the trained model's mistakes on them. Run 2 may train on them.

## Things to know

- **Kickstarter:** it uses `target_values`, which keeps only finished projects. It needs this folder's `step1_get_data.py`.
- **Wide tables:** `communities_crime_unnormalized` (145 columns), `openml_speed_dating` (122), `nhefs_smokers_mortality` (66) and `rossi_recidivism_arrest` (61) need long answers. Raise the 9B model's answer cap for run 2.
- **Medium confidence:**
  - `campus_recruitment_placed`: a Kaggle upload from an unnamed campus.
  - `clean_scat_species`: the documentation describes its columns only as a group.
- **Left out:**
  - AI4I 2020 predictive maintenance: synthetic.
  - Higgs ML challenge: simulated events.
  - Kaggle loan payments: unclear origin.
  - Two duplicate copies and one trivial log transform of the target (ISLR Wage).
