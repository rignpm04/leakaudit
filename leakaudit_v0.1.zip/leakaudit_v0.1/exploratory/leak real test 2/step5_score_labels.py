"""Step 5: score a person's labels on the 20-table labeling workbook against this folder's answer key.

Put the returned workbook in this folder, set LABELS_FILE below, and press Run. Python 3.9, standard library only.

Prints: how much was labeled, agreement with the key and Cohen's kappa (with a range from resampling tables),
how the person labeled the leaks, the columns they flagged that the key calls fine, the debatable columns, and
every disagreement with the person's reason. Writes label_review.csv with one row per column.

Settle any fixes to the key from this review BEFORE you look at model results on this test set.
"""
import csv
import json
import os
import random
import re
import zipfile
import xml.etree.ElementTree as ET

LABELS_FILE = "leak_labeling_20_tables_v2.xlsx"   # the workbook as it came back (rename here if the name changed)
CODES_FILE = "label_codes.json"                  # T01..T20 -> case id (keep this file away from the labeler)
CASES_FILE = "cases.json"                        # this folder's answer key
REVIEW_FILE = "label_review.csv"
RESAMPLES = 2000                                 # table-level resamples for the kappa range
SEED = 7
SHOW_MODELS = False   # True: also score scores_llm.csv (step 3) on the same columns. Only after the key is settled.
MODEL_FLAG_AT = 50    # a model's leak_risk at or above this counts as a flag

HERE = os.path.dirname(os.path.abspath(__file__))
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
R_ID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
PKG = "{http://schemas.openxmlformats.org/package/2006/relationships}"


# ------------------------------------------------------------ reading the workbook (no extra packages)
def _text(el):
    return "".join(t.text or "" for t in el.iter("{%s}t" % NS["m"]))


def _col_index(ref):
    letters = re.match(r"[A-Z]+", ref).group(0)
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n


def read_xlsx(path):
    """{sheet name: {row number: {column number: text}}} for every worksheet."""
    out = {}
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            shared = [_text(si) for si in root.findall("m:si", NS)]
        rels = {}
        rel_root = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        for rel in rel_root.iter(PKG + "Relationship"):
            target = rel.get("Target")
            target = target.lstrip("/") if target.startswith("/") else "xl/" + target
            rels[rel.get("Id")] = target
        wb_root = ET.fromstring(z.read("xl/workbook.xml"))
        for sh in wb_root.find("m:sheets", NS).findall("m:sheet", NS):
            target = rels.get(sh.get(R_ID))
            if not target or target not in names:
                continue
            rows = {}
            root = ET.fromstring(z.read(target))
            data = root.find("m:sheetData", NS)
            if data is None:
                continue
            for row in data.findall("m:row", NS):
                for c in row.findall("m:c", NS):
                    ref = c.get("r")
                    if not ref:
                        continue
                    t = c.get("t")
                    v = c.find("m:v", NS)
                    if t == "s" and v is not None:
                        val = shared[int(v.text)]
                    elif t == "inlineStr":
                        is_ = c.find("m:is", NS)
                        val = _text(is_) if is_ is not None else ""
                    elif v is not None:
                        val = v.text or ""
                    else:
                        val = ""
                    r = int(re.search(r"\d+", ref).group(0))
                    rows.setdefault(r, {})[_col_index(ref)] = val
            out[sh.get("name")] = rows
    return out


# ------------------------------------------------------------ labels
def norm_label(s):
    s = (s or "").strip().lower().replace("’", "'")
    if not s:
        return None
    if s.startswith("known"):
        return "known"
    if s.startswith("not known") or "leak" in s:
        return "leak"
    if s.startswith("can't") or s.startswith("cant") or s.startswith("can not") or s.startswith("cannot"):
        return "unsure"
    return "other"


def norm_conf(s):
    s = (s or "").strip().lower()
    if not s or s.startswith("sure"):
        return "sure"
    if s.startswith("fair"):
        return "fairly sure"
    if s.startswith("guess"):
        return "guess"
    return s


def read_tab(rows, expected):
    """The labeled rows of one T tab: list of (index, column name, label, confidence, reason)."""
    head = None
    for r in sorted(rows):
        b = (rows[r].get(2) or "").strip()
        g = (rows[r].get(7) or "").strip().lower()
        if b == "Column" and g.startswith("known at"):
            head = r
            break
    if head is None:
        return None, "header row not found"
    got = []
    r = head + 1
    while r in rows and (rows[r].get(2) or "").strip():
        cells = rows[r]
        got.append(((cells.get(1) or "").strip(), cells[2].strip(), cells.get(7, ""), cells.get(8, ""),
                    (cells.get(9) or "").strip()))
        r += 1
    problem = ""
    names = [g[1] for g in got]
    if names != expected:
        problem = "column list differs from the original (%d vs %d rows)" % (len(names), len(expected))
    return got, problem


# ------------------------------------------------------------ statistics
def kappa(pairs):
    """Cohen's kappa for (a, b) pairs of 0/1."""
    n = len(pairs)
    if n == 0:
        return float("nan")
    po = sum(1 for a, b in pairs if a == b) / float(n)
    pa = sum(a for a, _ in pairs) / float(n)
    pb = sum(b for _, b in pairs) / float(n)
    pe = pa * pb + (1 - pa) * (1 - pb)
    if pe >= 1.0:
        return float("nan")
    return (po - pe) / (1 - pe)


def kappa_range(by_table, resamples, seed):
    tables = [t for t in by_table if by_table[t]]
    if len(tables) < 2:
        return float("nan"), float("nan")
    rng = random.Random(seed)
    vals = []
    for _ in range(resamples):
        pick = [rng.choice(tables) for _ in tables]
        pairs = [p for t in pick for p in by_table[t]]
        k = kappa(pairs)
        if k == k:
            vals.append(k)
    if not vals:
        return float("nan"), float("nan")
    vals.sort()
    return vals[int(0.025 * len(vals))], vals[min(len(vals) - 1, int(0.975 * len(vals)))]


def fmt(x, nd=2):
    return "n/a" if x != x else ("%.*f" % (nd, x))


def main():
    path = os.path.join(HERE, LABELS_FILE)
    if not os.path.exists(path):
        raise SystemExit("Put the returned workbook in this folder and set LABELS_FILE (looked for %s)." % LABELS_FILE)
    meta = json.load(open(os.path.join(HERE, CODES_FILE), encoding="utf-8"))
    cases = {c["id"]: c for c in json.load(open(os.path.join(HERE, CASES_FILE), encoding="utf-8"))}
    book = read_xlsx(path)

    records = []
    problems = []
    for code in sorted(meta["codes"]):
        cid = meta["codes"][code]
        case = cases[cid]
        leak = set(case.get("leak_columns") or [])
        prob = set(case.get("probable_leak_columns") or [])
        if code not in book:
            problems.append("%s: tab missing" % code)
            continue
        got, problem = read_tab(book[code], meta["columns"][code])
        if got is None:
            problems.append("%s: %s" % (code, problem))
            continue
        if problem:
            problems.append("%s: %s; matching by column name" % (code, problem))
        for idx, name, lab, conf, reason in got:
            key = "leak" if name in leak else "probable" if name in prob else "fine"
            if name not in meta["columns"][code]:
                key = "unknown"
            records.append({"code": code, "case_id": cid, "kind": case.get("kind"), "column": name, "key": key,
                            "label": norm_label(lab), "label_text": lab, "confidence": norm_conf(conf),
                            "reason": reason})

    total = sum(len(v) for v in meta["columns"].values())
    labeled = [r for r in records if r["label"] is not None]
    tabs_done = sorted(set(r["code"] for r in records if r["label"] is not None))
    full_tabs = [c for c in tabs_done
                 if all(r["label"] is not None for r in records if r["code"] == c)]
    print("Labeled %d of %d columns; %d of 20 tabs complete." % (len(labeled), total, len(full_tabs)))
    for p in problems:
        print("  note: " + p)
    other = [r for r in labeled if r["label"] == "other"]
    if other:
        print("  %d labels were not one of the three choices (left out): %s" % (
            len(other), "; ".join("%s %s=%r" % (r["code"], r["column"], r["label_text"]) for r in other[:8])))

    # agreement on the columns the key is sure about
    sure_key = [r for r in labeled if r["key"] in ("leak", "fine") and r["label"] in ("known", "leak")]
    pairs = [(1 if r["label"] == "leak" else 0, 1 if r["key"] == "leak" else 0) for r in sure_key]
    by_table = {}
    for r, p in zip(sure_key, pairs):
        by_table.setdefault(r["code"], []).append(p)
    k = kappa(pairs)
    lo, hi = kappa_range(by_table, RESAMPLES, SEED)
    agree = sum(1 for a, b in pairs if a == b)
    tp = sum(1 for a, b in pairs if a == 1 and b == 1)
    fp = sum(1 for a, b in pairs if a == 1 and b == 0)
    fn = sum(1 for a, b in pairs if a == 0 and b == 1)
    tn = sum(1 for a, b in pairs if a == 0 and b == 0)
    print("")
    print("Agreement with the key (key leak or fine; person said Known or Not known yet): %d columns" % len(pairs))
    print("  agree %d of %d (%.1f%%)   Cohen's kappa %s   (95%% range from resampling tables: %s to %s)" % (
        agree, len(pairs), 100.0 * agree / max(1, len(pairs)), fmt(k), fmt(lo), fmt(hi)))
    print("                      key: leak   key: fine")
    print("  person: leak        %8d   %9d" % (tp, fp))
    print("  person: known       %8d   %9d" % (fn, tn))
    unsure_pairs = [(1 if r["label"] in ("leak", "unsure") else 0, 1 if r["key"] == "leak" else 0)
                    for r in labeled if r["key"] in ("leak", "fine") and r["label"] in ("known", "leak", "unsure")]
    print("  kappa if Can't tell counts as a leak: %s (%d columns)" % (fmt(kappa(unsure_pairs)), len(unsure_pairs)))

    key_leaks = [r for r in labeled if r["key"] == "leak"]
    print("")
    print("The key's %d leaks (labeled so far): person said leak %d, Can't tell %d, Known %d." % (
        len(key_leaks), sum(r["label"] == "leak" for r in key_leaks), sum(r["label"] == "unsure" for r in key_leaks),
        sum(r["label"] == "known" for r in key_leaks)))
    fine = [r for r in labeled if r["key"] == "fine"]
    flagged_fine = [r for r in fine if r["label"] == "leak"]
    clean_flags = [r for r in flagged_fine if r["kind"] == "clean"]
    print("Columns the key calls fine: %d labeled; person flagged %d (%d of them in the clean tables), Can't tell %d." % (
        len(fine), len(flagged_fine), len(clean_flags), sum(r["label"] == "unsure" for r in fine)))
    prob = [r for r in labeled if r["key"] == "probable"]
    if prob:
        print("Debatable columns (not scored): %d; person said leak %d, Can't tell %d, Known %d." % (
            len(prob), sum(r["label"] == "leak" for r in prob), sum(r["label"] == "unsure" for r in prob),
            sum(r["label"] == "known" for r in prob)))

    review = [r for r in labeled if (r["key"] == "leak" and r["label"] != "leak")
              or (r["key"] == "fine" and r["label"] in ("leak", "unsure"))]
    print("")
    print("To review (%d): each one is either a slip by the person or a mistake in the key." % len(review))
    for r in review:
        print("  %s %-34s %-24s key %-5s person %-7s (%s) %s" % (
            r["code"], r["case_id"][:34], r["column"][:24], r["key"], r["label"], r["confidence"],
            ("- " + r["reason"]) if r["reason"] else ""))

    with open(os.path.join(HERE, REVIEW_FILE), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["code", "case_id", "kind", "column", "key", "person", "confidence", "reason", "agrees"])
        for r in records:
            ag = ""
            if r["label"] in ("known", "leak") and r["key"] in ("leak", "fine"):
                ag = "yes" if (r["label"] == "leak") == (r["key"] == "leak") else "no"
            w.writerow([r["code"], r["case_id"], r["kind"], r["column"], r["key"], r["label"] or "",
                        r["confidence"] if r["label"] else "", r["reason"], ag])
    print("")
    print("Wrote %s (one row per column)." % REVIEW_FILE)

    if SHOW_MODELS:
        score_models(records)


def score_models(records):
    path = os.path.join(HERE, "scores_llm.csv")
    if not os.path.exists(path):
        print("SHOW_MODELS: scores_llm.csv not found (run step 3 first).")
        return
    risk = {}
    with open(path, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("condition") != "real":
                continue
            try:
                v = float(row.get("leak_risk"))
            except (TypeError, ValueError):
                continue
            risk[(row["model"], row["case_id"], row["column"])] = v
    models = sorted(set(m for m, _, _ in risk))
    rows = [r for r in records if r["key"] in ("leak", "fine") and r["label"] in ("known", "leak")]
    print("")
    print("Models on the same %d columns (leak_risk >= %d counts as a flag):" % (len(rows), MODEL_FLAG_AT))
    print("  %-12s %10s %16s %8s" % ("model", "vs key", "vs the person", "columns"))
    for m in models:
        vk, vp = [], []
        for r in rows:
            v = risk.get((m, r["case_id"], r["column"]))
            if v is None:
                continue
            flag = 1 if v >= MODEL_FLAG_AT else 0
            vk.append((flag, 1 if r["key"] == "leak" else 0))
            vp.append((flag, 1 if r["label"] == "leak" else 0))
        print("  %-12s %10s %16s %8d" % (m, fmt(kappa(vk)), fmt(kappa(vp)), len(vk)))


if __name__ == "__main__":
    main()
