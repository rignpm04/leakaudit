# train1_make_data.py -- makes the training file for the leak-auditor fine-tune (pilot). Python 3.9; press Run in
# PyCharm. No keys, no downloads. Needs step1_generate.py, step3_llm_audit.py and common.py in this folder.
#
# It builds new tables with the same generator as the fresh test, for the TRAIN_DOMAINS only, under new table ids
# (so new random draws): none of the 42 test tables is ever produced here, and the held-out domains are never used.
# Each table becomes one training example:
#   system + user  the exact prompt step 3 sends (same summaries, same wording, same instruction)
#   answer         the correct rating of every column, from the generator's answer key, in the json form step 3
#                  asks for, after a short reasoning note (the model learns to say briefly which columns are late,
#                  then answer)
# Output: train.jsonl and val.jsonl (one example per line, chat format) and train_manifest.json (what is in them).
#
# How the answer key becomes ratings:
#   leaks                          risk 95, category by leak type (final status, dates after the moment and values
#                                  "as of" the data pull -> post_outcome; totals that build after the moment ->
#                                  future_aggregate; computed from the outcome -> target_derived; row ids -> identifier)
#   silently overwritten fields    rated like legitimate columns: by design nothing in the table shows the overwrite,
#                                  so a "leak" label would only teach the model to memorize column names
#   decoys and trap columns        risk 10, fine (they look late but are known at the moment)
#   every other column             risk 5, fine

import csv
import gzip
import hashlib
import io
import json
import os
import sys
import time
import zlib
from typing import Any, Dict, List, Tuple

# ============================================================ settings (edit here)
TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]   # tables are generated for these domains only
HOLDOUT_DOMAINS = ["lending", "hospital"]                   # never used here: the test of whether training carries over
TABLES_PER_DOMAIN = 500       # 4 x 500 = 2,000 examples
TRAP_SHARE = 0.15             # share of tables built as trap tables (legitimate columns that look late)
VAL_SHARE = 0.05              # share kept apart for the validation loss during training
SEED = 20261019               # picks each table's kind; the tables' own draws come from their ids

TRAIN_FILE = "train.jsonl"
VAL_FILE = "val.jsonl"
MANIFEST_FILE = "train_manifest.json"

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_generate as s1  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

CATEGORY = {"outcome_status": "post_outcome", "post_event_date": "post_outcome", "snapshot_state": "post_outcome",
            "outcome_only_sparse": "post_outcome", "post_aggregate": "future_aggregate",
            "target_derived": "target_derived", "identifier": "identifier"}
REASON = {"outcome_status": "Final status, set only after the outcome is known.",
          "post_event_date": "Date of an event after the prediction moment.",
          "post_aggregate": "Total that keeps building after the prediction moment.",
          "snapshot_state": "Current value as of the data pull, after the moment.",
          "outcome_only_sparse": "Filled only when the outcome happens.",
          "target_derived": "Computed from the outcome itself.",
          "identifier": "Row identifier; repeats let a model memorize outcomes."}
PHRASE = {"outcome_status": "final status", "post_event_date": "date after the moment",
          "post_aggregate": "total that grows after the moment", "snapshot_state": "value as of the data pull",
          "outcome_only_sparse": "filled only when the outcome happens"}
TRAP_REASON = {"planned_future_date": "Planned date, already set at the prediction moment.",
               "legit_time_trend": "Known at the moment; it only trends over time.",
               "legit_sparse_signal": "Rarely filled, but recorded before the moment.",
               "legit_high_card_signal": "Code known at the prediction moment."}
RISK_LEAK, RISK_LOOKS_LATE, RISK_FINE = 95, 10, 5


def csv_text(header: List[str], rows: List[List[str]]) -> str:
    """The table exactly as step 1's write_table stores it."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def info_from_text(case: Dict[str, Any], text: str) -> Dict[str, Any]:
    """What step 3's prepare_case builds, from the CSV text instead of data/<id>.csv.gz (same parse, same seed)."""
    df = pd.read_csv(io.StringIO(text), low_memory=False)
    cols = [c for c in df.columns if c != common.TARGET]
    rng = np.random.RandomState((s3.SEED * 1000003 + zlib.crc32(case["id"].encode("utf-8"))) % (2 ** 32))
    summaries = {c: common.column_summary(df[c], s3.N_EXAMPLES, rng) for c in cols}
    return {"case": case, "id": case["id"], "task": case["task"], "columns": cols, "summaries": summaries,
            "n_rows": len(df), "real_text": {k: case.get(k) or "" for k in s3.TEXT_KEYS}}


def rate(case: Dict[str, Any], col: str) -> Tuple[int, str, str]:
    """(risk, category, reason) for one column, from the answer key."""
    ltype = (case.get("leak_types") or {}).get(col)
    if ltype and ltype in CATEGORY:
        return RISK_LEAK, CATEGORY[ltype], REASON[ltype]
    trap = (case.get("trap_columns") or {}).get(col)
    if trap:
        return RISK_LOOKS_LATE, "fine", TRAP_REASON.get(trap, "Known at the prediction moment.")
    if col in case.get("decoy_columns", []):
        return RISK_LOOKS_LATE, "fine", "Sounds late but describes history known at the moment."
    if col == case.get("moment_column"):
        return RISK_FINE, "fine", "The prediction moment itself."
    if col in case.get("strong_legit_columns", []):
        return RISK_FINE, "fine", "Strong predictor, known at the prediction moment."
    return RISK_FINE, "fine", "Known at the prediction moment."   # also silently overwritten fields (see the top)


def reasoning(case: Dict[str, Any], cols: List[str]) -> str:
    lt = case.get("leak_types") or {}
    late = ["%s (%s)" % (c, PHRASE[lt[c]]) for c in cols if lt.get(c) in PHRASE]
    derived = [c for c in cols if lt.get(c) == "target_derived"]
    ids = [c for c in cols if lt.get(c) == "identifier"]
    looks = [c for c in cols if c in case.get("decoy_columns", []) or c in (case.get("trap_columns") or {})]
    lines = ["Prediction moment: %s" % case.get("prediction_time", "")]
    if late:
        lines.append("Not yet known at that moment: " + ", ".join(late) + ".")
    if derived:
        lines.append("Built from the outcome: " + ", ".join(derived) + ".")
    if ids:
        lines.append("Row identifiers: " + ", ".join(ids) + ".")
    if not (late or derived or ids):
        lines.append("No column is recorded after the moment or built from the outcome.")
    if looks:
        lines.append("Look suspicious but are known at the moment: " + ", ".join(looks) + ".")
    lines.append("Everything else is known at the moment.")
    return "\n".join(lines)


def answer(case: Dict[str, Any], cols: List[str]) -> str:
    entries = []
    for c in cols:
        risk, category, why = rate(case, c)
        entries.append({"column": c, "leak_risk": risk, "category": category, "reason": why})
    return json.dumps({"dataset_guess": None, "columns": entries}, ensure_ascii=False)


def example(case: Dict[str, Any], info: Dict[str, Any]) -> Dict[str, Any]:
    p = s3.condition_prompt(info, "real", None, None)
    return {"id": case["id"], "domain": case["domain"], "style": case["naming_style"], "kind": case["kind"],
            "trap_table": bool(case.get("trap_columns")),
            "messages": [{"role": "system", "content": s3.SYSTEM_PROMPT},
                         {"role": "user", "content": p["user"]},
                         {"role": "assistant", "content": answer(case, info["columns"]),
                          "reasoning_content": reasoning(case, info["columns"])}]}


def file_sha256(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def test_table_hashes() -> Dict[str, str]:
    """sha256 of the CSV text of every test table in data/ (cases.json), to prove none is reproduced."""
    out = {}
    for case in common.load_cases(quiet=True):
        if common.has_data(case["id"]):
            with gzip.open(common.data_file(case["id"]), "rb") as f:
                out[hashlib.sha256(f.read()).hexdigest()] = case["id"]
    return out


def same_prompt_check() -> str:
    """Builds one test table in memory, the way this script builds training tables, and compares its prompt with the
    one step 3 builds from data/ -- they must be identical, or training would not match testing."""
    cases = {c["id"]: c for c in common.load_cases(quiet=True)}
    for cid, dom, k in (("claims_01", "claims", 1), ("orders_03", "orders", 3)):
        if cid not in cases or not common.has_data(cid):
            continue
        case, rows, header = s1.build(cid, dom, k)
        mine = s3.condition_prompt(info_from_text(case, csv_text(header, rows)), "real", None, None)["user"]
        theirs = s3.condition_prompt(s3.prepare_case(cases[cid]), "real", None, None)["user"]
        if mine != theirs:
            raise SystemExit("STOP: the prompt built here for %s differs from step 3's. Tell Claude." % cid)
        return "ok (%s: the prompt built here is identical to step 3's)" % cid
    return "skipped (no test tables in data/ yet -- run eval0_import.py first to include this check)"


def main() -> None:
    t0 = time.time()
    bad = [d for d in TRAIN_DOMAINS if d not in s1.DOMAINS] + [d for d in TRAIN_DOMAINS if d in HOLDOUT_DOMAINS]
    if bad:
        raise SystemExit("Fix TRAIN_DOMAINS / HOLDOUT_DOMAINS: %s" % bad)
    print("Training data for the leak-auditor fine-tune: %d domains x %d tables (held out: %s)"
          % (len(TRAIN_DOMAINS), TABLES_PER_DOMAIN, ", ".join(HOLDOUT_DOMAINS)))
    print("Same-prompt check: " + same_prompt_check())
    test_hashes = test_table_hashes()
    rng = np.random.RandomState(SEED)
    plan = []
    for dom in TRAIN_DOMAINS:
        for i in range(TABLES_PER_DOMAIN):
            traps = bool(rng.uniform() < TRAP_SHARE)
            k = 0 if traps else int(rng.randint(1, 7))      # 1-2 clear, 3-4 abbreviated, 5 cryptic, 6 clean
            plan.append(("trn_%s_%04d" % (dom, i + 1), dom, k, traps, bool(rng.uniform() < VAL_SHARE)))
    counts: Dict[str, Any] = {"tables": 0, "train": 0, "val": 0, "by_domain": {}, "by_style": {}, "by_kind": {},
                              "trap_tables": 0, "leaks_by_type": {}, "columns": 0, "chars": 0}
    seen_ids = set()
    with open(common.path(TRAIN_FILE), "w", encoding="utf-8") as ftr, \
            open(common.path(VAL_FILE), "w", encoding="utf-8") as fva:
        for n, (tid, dom, k, traps, val) in enumerate(plan, 1):
            case, rows, header = s1.build(tid, dom, k, traps)
            text = csv_text(header, rows)
            h = hashlib.sha256(text.encode("utf-8")).hexdigest()
            if h in test_hashes:
                raise SystemExit("STOP: %s reproduces test table %s. Tell Claude." % (tid, test_hashes[h]))
            if tid in seen_ids:
                raise SystemExit("STOP: duplicate training id %s" % tid)
            seen_ids.add(tid)
            ex = example(case, info_from_text(case, text))
            line = json.dumps(ex, ensure_ascii=False)
            (fva if val else ftr).write(line + "\n")
            counts["tables"] += 1
            counts["val" if val else "train"] += 1
            counts["by_domain"][dom] = counts["by_domain"].get(dom, 0) + 1
            counts["by_style"][case["naming_style"]] = counts["by_style"].get(case["naming_style"], 0) + 1
            counts["by_kind"][case["kind"]] = counts["by_kind"].get(case["kind"], 0) + 1
            counts["trap_tables"] += int(traps)
            for t in (case.get("leak_types") or {}).values():
                counts["leaks_by_type"][t] = counts["leaks_by_type"].get(t, 0) + 1
            counts["columns"] += len(header) - 1
            counts["chars"] += sum(len(m["content"]) + len(m.get("reasoning_content", "")) for m in ex["messages"])
            if n % 100 == 0 or n == len(plan):
                el = time.time() - t0
                print("  %4d / %d tables  (%.0f s, about %.0f s left)" % (n, len(plan), el, el / n * (len(plan) - n)))
    est_tokens = counts["chars"] / s3.CHARS_PER_TOKEN
    manifest = dict(counts, settings={"train_domains": TRAIN_DOMAINS, "holdout_domains": HOLDOUT_DOMAINS,
                                      "tables_per_domain": TABLES_PER_DOMAIN, "trap_share": TRAP_SHARE,
                                      "val_share": VAL_SHARE, "seed": SEED, "generator_seed": s1.SEED},
                    est_tokens=int(est_tokens), created=common.stamp(),
                    files={TRAIN_FILE: file_sha256(common.path(TRAIN_FILE)),
                           VAL_FILE: file_sha256(common.path(VAL_FILE))})
    common.write_json(common.path(MANIFEST_FILE), manifest)
    print("\n%d tables -> %s (%d) and %s (%d); %d columns rated" % (counts["tables"], TRAIN_FILE, counts["train"],
                                                                   VAL_FILE, counts["val"], counts["columns"]))
    print("By domain: %s" % counts["by_domain"])
    print("By naming style: %s; trap tables: %d; clean tables: %d"
          % (counts["by_style"], counts["trap_tables"], counts["by_kind"].get("clean", 0)))
    print("Leak columns by type: %s" % dict(sorted(counts["leaks_by_type"].items())))
    print("About %.1f million tokens per pass (characters / %.1f); the notebook prints the exact count."
          % (est_tokens / 1e6, s3.CHARS_PER_TOKEN))
    print("None of the %d test tables in data/ was reproduced. %.0f s in all." % (len(test_hashes), time.time() - t0))
    print("Next: eval1_make_prompts.py, then RunPod (GUIDE.md, part B).")


if __name__ == "__main__":
    main()
