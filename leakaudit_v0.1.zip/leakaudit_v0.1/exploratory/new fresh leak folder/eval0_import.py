# eval0_import.py -- brings what the before/after comparison needs into this folder from your earlier test folders.
# Python 3.9; press Run in PyCharm. No keys, no calls. Run it after the Qwen3.5 9B run in your fresh-test folder has
# finished; running it again later is safe (it only adds what is new).
#
# From FRESH_TEST_FOLDER:  cases.json and data/ for the 42 generated tables (byte for byte the tables every model saw),
#                          and every cached answer for them in llm_cache/ -- DeepSeek, Claude, GPT, and the local
#                          model's, which land here in llm_cache/local-<model>/ (e.g. llm_cache/local-qwen3.5-9b/).
# From OPEN_TEST_FOLDER:   (optional) the open models' cached answers (open-...), shown for reference.
# From QUICK_TEST_FOLDER:  cases.json (saved here as cases_real.json) and data/ for the 27 public datasets of the
#                          first test, and DeepSeek's, Claude's and GPT's cached answers for them.
# Nothing in those folders is changed. A file already here is kept, unless the one there is newer and different.
#
# Paths: in PyCharm, right-click the folder > Copy Path/Reference > Absolute Path, and paste it between the quotes.

FRESH_TEST_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/fresh test"
OPEN_TEST_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/fresh test open"
QUICK_TEST_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leaktest"

# ============================================================ internals
import filecmp
import json
import os
import re
import shutil
import sys
from typing import Any, Dict, List, Optional, Set

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

REAL_CASES_FILE = "cases_real.json"
STATS: Dict[str, int] = {"copied": 0, "updated": 0, "kept": 0}


def folder(p: str, name: str, optional: bool = False) -> Optional[str]:
    p = os.path.expanduser(str(p or "").strip().strip("'\""))
    if not p or p.startswith("PASTE_"):
        if optional:
            print("%s: not set -- skipped" % name)
            return None
        raise SystemExit("Paste the full path of your %s at the top of eval0_import.py (%s)." % (name.lower(), name))
    p = os.path.normpath(p)
    if not os.path.isdir(p):
        raise SystemExit("%s does not exist: %s" % (name, p))
    if os.path.samefile(p, HERE):
        raise SystemExit("%s points at this folder -- it must be your earlier test folder." % name)
    return p


def local_key(model: str) -> str:
    """Same rule as step 3 here: qwen/qwen3.5-9b -> local-qwen3.5-9b."""
    name = str(model).split("/")[-1].strip().lower()
    return "local-" + (re.sub(r"[^a-z0-9._-]+", "-", name).strip("-") or "model")


def put(src: str, dst: str) -> None:
    """Copy src to dst unless dst exists; replace dst only if src is newer and different."""
    if os.path.exists(dst):
        if filecmp.cmp(src, dst, shallow=False) or os.path.getmtime(src) <= os.path.getmtime(dst):
            STATS["kept"] += 1
            return
        STATS["updated"] += 1
    else:
        STATS["copied"] += 1
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def read_cases(p: str) -> List[Dict[str, Any]]:
    with open(p, encoding="utf-8-sig") as f:
        raw = json.load(f)
    return raw.get("cases", []) if isinstance(raw, dict) else raw


def copy_data(src_dir: str, ids: List[str], what: str) -> List[str]:
    missing = []
    for cid in ids:
        f = os.path.join(src_dir, "data", cid + ".csv.gz")
        if not os.path.exists(f):
            missing.append(cid)
            continue
        put(f, common.data_file(cid))
        m = os.path.join(src_dir, "data", cid + ".meta.json")
        if os.path.exists(m):
            put(m, common.meta_file(cid))
    if missing:
        print("  %s: no data for %d table(s): %s" % (what, len(missing), ", ".join(missing)))
    return missing


def copy_answers(src_dir: str, ids: Set[str], labels: Optional[List[str]] = None) -> Dict[str, int]:
    """Cached 'real' answers for these tables, for every model label (or only labels), local ones relabeled by id."""
    got: Dict[str, int] = {}
    root = os.path.join(src_dir, "llm_cache")
    if not os.path.isdir(root):
        return got
    for lab in sorted(os.listdir(root)):
        if lab.startswith("mock-") or (labels is not None and lab not in labels and not
                                       (lab.startswith("open-") and "open-" in labels)):
            continue
        d = os.path.join(root, lab, "real")
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            cid = fn[:-5] if fn.endswith(".json") else None
            if cid not in ids:
                continue
            src = os.path.join(d, fn)
            dest_lab = lab
            if lab == "local":
                rec = common.load_json(src)
                mid = (rec or {}).get("model_id") if isinstance(rec, dict) else None
                if not mid or not (rec or {}).get("parsed"):
                    continue
                dest_lab = local_key(mid)
            put(src, common.path("llm_cache", dest_lab, "real", fn))
            got[dest_lab] = got.get(dest_lab, 0) + 1
    return got


def main() -> None:
    fresh = folder(FRESH_TEST_FOLDER, "FRESH_TEST_FOLDER")
    opened = folder(OPEN_TEST_FOLDER, "OPEN_TEST_FOLDER", optional=True)
    quick = folder(QUICK_TEST_FOLDER, "QUICK_TEST_FOLDER")

    print("\n1. Generated tables, from %s" % fresh)
    gen = [c for c in read_cases(os.path.join(fresh, "cases.json")) if c.get("url") == "generated"]
    if len(gen) != 42:
        print("  note: found %d generated tables in its cases.json (expected 42)" % len(gen))
    put(os.path.join(fresh, "cases.json"), common.path("cases.json"))
    if os.path.exists(os.path.join(fresh, "generated_checksums.txt")):
        put(os.path.join(fresh, "generated_checksums.txt"), common.path("generated_checksums.txt"))
    gen_ids = [c["id"] for c in gen]
    copy_data(fresh, gen_ids, "generated")
    answers = {"generated": copy_answers(fresh, set(gen_ids))}
    if opened:
        print("2. Open-model answers, from %s" % opened)
        for k, v in copy_answers(opened, set(gen_ids), labels=["deepseek", "claude", "gpt", "open-"]).items():
            answers["generated"][k] = max(answers["generated"].get(k, 0), v)

    print("3. Public datasets, from %s" % quick)
    qc = os.path.join(quick, "cases.json")
    if os.path.exists(common.path(REAL_CASES_FILE)) and not filecmp.cmp(qc, common.path(REAL_CASES_FILE), shallow=False):
        print("  note: its cases.json differs from the cases_real.json shipped here -- using yours")
    shutil.copy2(qc, common.path(REAL_CASES_FILE))
    real_ids = [c["id"] for c in read_cases(qc)]
    copy_data(quick, real_ids, "public datasets")
    answers["real"] = copy_answers(quick, set(real_ids))

    print("\nFiles: %d copied, %d updated, %d already here." % (STATS["copied"], STATS["updated"], STATS["kept"]))
    have = {}
    for lab in sorted(os.listdir(common.path("llm_cache"))) if os.path.isdir(common.path("llm_cache")) else []:
        d = common.path("llm_cache", lab, "real")
        if os.path.isdir(d) and not lab.startswith("mock-"):
            names = {fn[:-5] for fn in os.listdir(d) if fn.endswith(".json")}
            have[lab] = (len(names & set(gen_ids)), len(names & set(real_ids)))
    rows = [[lab, "%d / %d" % (g, len(gen_ids)), "%d / %d" % (r, len(real_ids))] for lab, (g, r) in have.items()]
    print(common.format_table(["answers held here", "generated tables", "public datasets"], rows))
    if not any(lab.startswith("local-") for lab in have):
        print("No local-model answers yet: check that the Qwen3.5 9B run finished in %s." % fresh)
    print("Next: train1_make_data.py (GUIDE.md, part A).")


if __name__ == "__main__":
    main()
