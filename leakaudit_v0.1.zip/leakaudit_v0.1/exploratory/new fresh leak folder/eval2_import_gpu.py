# eval2_import_gpu.py -- stores the answers the RunPod notebook wrote (answers_base.jsonl, answers_trained.jsonl, both
# downloaded into this folder) the way step 3 stores its own, so train4_compare.py scores them like every other model.
# Python 3.9; press Run in PyCharm. No calls, no keys. Needs test_prompts.jsonl (made by eval1_make_prompts.py).
#
#   answers_base.jsonl     -> llm_cache/gpu-qwen3.5-9b/real/<table>.json            (untrained, thinking off)
#   answers_trained.jsonl  -> llm_cache/gpu-leakaudit-qwen3.5-9b/real/<table>.json  (trained, its short note first)
# Each answer is read with step 3's own reader (the same handling of <think> blocks, names and missing columns), and
# stamped with the hash of the exact prompt it answers, so train4_compare.py can check it belongs to today's tables.

FILES = {"answers_base.jsonl": ("gpu-qwen3.5-9b", "runpod/qwen3.5-9b (untrained, thinking off)"),
         "answers_trained.jsonl": ("gpu-leakaudit-qwen3.5-9b", "runpod/leakaudit-qwen3.5-9b (trained)")}
TEST_FILE = "test_prompts.jsonl"

# ============================================================ internals
import json
import os
import sys
from typing import Any, Dict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402


def main() -> None:
    if not os.path.exists(common.path(TEST_FILE)):
        raise SystemExit("%s is missing: run eval1_make_prompts.py first." % TEST_FILE)
    with open(common.path(TEST_FILE), encoding="utf-8") as f:
        tests: Dict[str, Dict[str, Any]] = {r["id"]: r for r in (json.loads(x) for x in f if x.strip())}
    found_any = False
    for fn, (label, model_id) in FILES.items():
        p = common.path(fn)
        if not os.path.exists(p):
            print("%s: not here yet -- download it from RunPod into this folder" % fn)
            continue
        found_any = True
        n, unreadable, missing_cols, unknown_ids = 0, [], 0, []
        with open(p, encoding="utf-8") as f:
            rows = [json.loads(x) for x in f if x.strip()]
        for r in rows:
            t = tests.get(r.get("id"))
            if t is None:
                unknown_ids.append(str(r.get("id")))
                continue
            parsed = s3.parse_answer(s3.strip_think(r.get("text") or ""), t["columns"])
            if not parsed:
                unreadable.append(t["id"])
                continue
            left_out = [c for c in t["columns"] if c not in parsed["entries"]]
            missing_cols += len(left_out)
            rec = {"case_id": t["id"], "model": label, "model_id": model_id, "condition": "real",
                   "prompt_hash": common.text_hash(model_id, t["system"], t["user"]), "timestamp": common.stamp(),
                   "prompt": t["user"], "raw": r.get("text"), "names": {c: c for c in t["columns"]},
                   "parsed": {"dataset_guess": parsed["dataset_guess"], "columns": parsed["entries"],
                              "missing": left_out, "unknown_names": parsed["unknown"]},
                   "usage": {"out": r.get("tokens")}, "cost": 0.0, "seconds": r.get("seconds"),
                   "source": "RunPod notebook (%s)" % fn}
            common.write_json(common.path("llm_cache", label, "real", t["id"] + ".json"), rec)
            n += 1
        print("%s -> llm_cache/%s/: %d of %d tables stored; %d unreadable%s; %d columns left unanswered"
              % (fn, label, n, len(tests), len(unreadable), (" (%s)" % ", ".join(unreadable)) if unreadable else "",
                 missing_cols))
        if unknown_ids:
            print("  note: %d answer(s) are for tables not in %s (left out): %s"
                  % (len(unknown_ids), TEST_FILE, ", ".join(unknown_ids[:10])))
    if found_any:
        print("Next: train4_compare.py")


if __name__ == "__main__":
    main()
