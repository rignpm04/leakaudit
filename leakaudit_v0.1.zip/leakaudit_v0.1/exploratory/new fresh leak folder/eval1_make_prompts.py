# eval1_make_prompts.py -- writes test_prompts.jsonl: the exact prompts step 3 sends for the 69 test tables (the 42
# generated tables and the quick test's 27 public datasets), for the RunPod notebook to answer with the untrained and
# the trained model. Python 3.9; press Run in PyCharm after eval0_import.py. No calls, no keys.
#
# Each line also carries the table's group and its answer key (leak columns, and the debatable columns that count
# neither way), only so the notebook can print a first preview; the official numbers come from train4_compare.py.

TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]   # must match train1_make_data.py
HOLDOUT_DOMAINS = ["lending", "hospital"]
TEST_FILE = "test_prompts.jsonl"

# ============================================================ internals
import hashlib
import json
import os
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

REAL_CASES_FILE = "cases_real.json"


def group_of(case: Dict[str, Any]) -> str:
    if case.get("url") != "generated":
        return "public datasets"
    if case.get("trap_columns"):
        return "trap tables"
    if case.get("domain") in TRAIN_DOMAINS:
        return "training domains"
    if case.get("domain") in HOLDOUT_DOMAINS:
        return "held-out domains"
    return "other"


def main() -> None:
    gen = common.load_cases(quiet=True)
    real = common.load_cases(quiet=True, file=REAL_CASES_FILE) if os.path.exists(common.path(REAL_CASES_FILE)) else []
    cases: List[Dict[str, Any]] = gen + [c for c in real if c["id"] not in {g["id"] for g in gen}]
    missing = [c["id"] for c in cases if not common.has_data(c["id"])]
    if missing:
        raise SystemExit("No data for %d table(s): %s -- run eval0_import.py first." % (len(missing), ", ".join(missing)))
    counts: Dict[str, int] = {}
    with open(common.path(TEST_FILE), "w", encoding="utf-8") as f:
        for c in cases:
            info = s3.prepare_case(c)
            p = s3.condition_prompt(info, "real", None, None)
            g = group_of(c)
            counts[g] = counts.get(g, 0) + 1
            row = {"id": c["id"], "group": g, "system": s3.SYSTEM_PROMPT, "user": p["user"],
                   "columns": info["columns"],
                   "leak_columns": [x for x in c.get("leak_columns", []) if x in info["columns"]],
                   "probable_leak_columns": [x for x in c.get("probable_leak_columns", []) if x in info["columns"]]}
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    with open(common.path(TEST_FILE), "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()
    print("%d test tables -> %s (sha256 %s...)" % (len(cases), TEST_FILE, digest[:16]))
    print("By group: %s" % counts)
    print("Next: upload %s with train.jsonl, val.jsonl and train2_runpod.ipynb to RunPod (GUIDE.md, part B)." % TEST_FILE)


if __name__ == "__main__":
    main()
