# step1_get_data.py -- step 1 of the leakage-auditor quick test: download every case in cases.json and write one
# standardized table per case. Python 3.9; press Run in PyCharm. No keys needed.
#
# For each case:
#  1. download its url into data/raw/<id>/ (skipped if the file is already there, unless FORCE)
#  2. read it with the case's format (sep, encoding, compression null/"gzip"/"zip", zip_member)
#  3. keep sample_rows rows, or DEFAULT_MAX_ROWS if the file is bigger (binary targets keep their positive share)
#  4. drop drop_columns
#  5. rename the target to "target": binary = 1 if the value is in positive_values, else 0; regression = a number
#  6. check that every leak and probable column exists (if not: error, case skipped)
#  7. write data/<id>.csv.gz and data/<id>.meta.json
# A case that fails is reported and skipped; the others carry on.

import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from difflib import get_close_matches
from typing import Any, Dict, List, Tuple

# ============================================================ settings (edit here)
FORCE = False              # True: download again even if the file is already in data/raw/<id>/
SEED = 7                   # for the row sample
DEFAULT_MAX_ROWS = 50000   # cases without sample_rows are cut to this many rows when the file is bigger
DOWNLOAD_TIMEOUT_S = 60
DOWNLOAD_TRIES = 3

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402


class CaseError(Exception):
    """A problem with this case's data or its entry in cases.json: reported, and the case is skipped."""


def suggest(name: str, columns: List[str]) -> str:
    close = get_close_matches(name, [str(c) for c in columns], n=3, cutoff=0.6)
    return " (did you mean %s?)" % " / ".join(repr(c) for c in close) if close else ""


# ============================================================ download
def file_name(url: str) -> str:
    name = os.path.basename(urllib.parse.unquote(urllib.parse.urlparse(url).path)) or "download.dat"
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)


def download(case: Dict[str, Any]) -> Tuple[str, str]:
    folder = common.raw_dir(case["id"])
    os.makedirs(folder, exist_ok=True)
    dest = os.path.join(folder, file_name(case["url"]))
    if os.path.exists(dest) and os.path.getsize(dest) > 0 and not FORCE:
        return dest, "already downloaded"
    tmp = dest + ".part"
    last = ""
    for attempt in range(DOWNLOAD_TRIES):
        try:
            req = urllib.request.Request(case["url"], headers={"User-Agent": "Mozilla/5.0 (leakaudit-quicktest)"})
            with urllib.request.urlopen(req, timeout=DOWNLOAD_TIMEOUT_S) as r, open(tmp, "wb") as f:
                shutil.copyfileobj(r, f, 1 << 20)
            os.replace(tmp, dest)
            return dest, "downloaded %.1f MB" % (os.path.getsize(dest) / 1e6)
        except urllib.error.HTTPError as e:
            last = "HTTP %d" % e.code
            if e.code in (400, 401, 403, 404, 410):
                break  # retrying will not help
        except Exception as e:  # timeouts, resets, missing local file
            if "CERTIFICATE_VERIFY_FAILED" in str(e):
                raise CaseError(common.CERT_HINT)
            last = str(e) or e.__class__.__name__
        if attempt + 1 < DOWNLOAD_TRIES:
            print("    download failed (%s) -- retrying" % last)
            time.sleep(3 * (attempt + 1))
    if os.path.exists(tmp):
        os.remove(tmp)
    raise CaseError("download failed (%s): %s" % (last, case["url"]))


# ============================================================ read
def pick_member(z: zipfile.ZipFile, wanted: Any) -> str:
    names = [n for n in z.namelist() if not n.endswith("/")]
    if wanted:
        if wanted in names:
            return wanted
        same = [n for n in names if os.path.basename(n) == wanted]
        if len(same) == 1:
            return same[0]
        raise CaseError("zip_member %r is not in the zip, which holds: %s" % (wanted, ", ".join(names[:15])))
    if len(names) == 1:
        return names[0]
    data = [n for n in names if n.lower().endswith((".csv", ".tsv", ".txt", ".data", ".dat"))]
    if len(data) == 1:
        return data[0]
    raise CaseError("the zip holds several files; set format.zip_member to one of: %s" % ", ".join(names[:15]))


def _read(fname: str, comp: Any, member: Any, enc: str, kwargs: Dict[str, Any]) -> pd.DataFrame:
    if comp == "zip":
        with zipfile.ZipFile(fname) as z:
            with z.open(pick_member(z, member)) as fh:
                return pd.read_csv(fh, encoding=enc, **kwargs)
    return pd.read_csv(fname, encoding=enc, compression=comp, **kwargs)


def read_table(fname: str, fmt: Dict[str, Any]) -> pd.DataFrame:
    """Reads delimited text, or an Excel sheet when format.excel is true (needs openpyxl).
    Optional extra format keys: header (null = no header row), names, na_values, sheet (Excel only)."""
    if fmt.get("excel"):
        try:
            return pd.read_excel(fname, sheet_name=fmt.get("sheet") or 0)
        except ImportError:
            raise CaseError("this case is an Excel file: run  pip install openpyxl  once, then run step 1 again")
        except (ValueError, OSError, zipfile.BadZipFile) as e:
            raise CaseError("cannot read the Excel file: %s" % str(e).strip()[:300])
    sep = fmt.get("sep", ",")
    if sep == "\\t":
        sep = "\t"
    kwargs: Dict[str, Any] = {}
    if sep in (None, "", "auto"):
        kwargs.update(sep=None, engine="python")  # sniff the separator
    elif len(sep) > 1:
        kwargs.update(sep=sep, engine="python")  # a regex such as "\\s+"
    else:
        kwargs.update(sep=sep, low_memory=False, skipinitialspace=True)
    if "header" in fmt:
        kwargs["header"] = fmt["header"]
    if fmt.get("names"):
        kwargs["names"] = list(fmt["names"])
    if fmt.get("na_values") is not None:
        kwargs["na_values"] = fmt["na_values"]
    comp = fmt.get("compression")
    comp = None if comp in (None, "", "none", "None") else str(comp).lower()
    enc = fmt.get("encoding") or "utf-8"
    try:
        return _read(fname, comp, fmt.get("zip_member"), enc, kwargs)
    except UnicodeDecodeError:
        print("    not valid %s text -- reading it as latin-1" % enc)
        return _read(fname, comp, fmt.get("zip_member"), "latin-1", kwargs)
    except (zipfile.BadZipFile, OSError, pd.errors.ParserError, ValueError) as e:
        raise CaseError("cannot read the file with this format: %s" % str(e).strip()[:300])


# ============================================================ standardize
def remove_outputs(case_id: str) -> None:
    """A failed case must not leave an older table behind for steps 2-4."""
    for p in (common.data_file(case_id), common.meta_file(case_id)):
        if os.path.exists(p):
            os.remove(p)


def make_target(y_raw: pd.Series, case: Dict[str, Any]) -> pd.Series:
    if case["task"] == "binary":
        seen = y_raw.map(common.norm_value)
        pv = case.get("positive_values")
        if not pv:
            values = set(seen.unique())
            if values <= {"0", "1"}:
                pv = [1]
            else:
                raise CaseError("set positive_values; the target's values include %s" % sorted(values)[:8])
        pos = set(common.norm_value(v) for v in pv)
        y = seen.isin(pos).astype(int)
        if y.sum() == 0 or y.sum() == len(y):
            top = ", ".join(repr(v) for v in y_raw.value_counts().index[:8])
            raise CaseError("positive_values %s match %s rows; the target's values are %s"
                            % (pv, "no" if y.sum() == 0 else "all", top))
        return y
    y, share = common.as_float(y_raw)
    if share < 0.5:
        raise CaseError("the regression target %r is not numeric" % case["target"])
    return y


def process(case: Dict[str, Any]) -> Dict[str, Any]:
    cid, tgt = case["id"], case["target"]
    fname, how = download(case)
    print("    %s: %s" % (how, os.path.relpath(fname, HERE)))
    df = read_table(fname, case["format"])
    df.columns = [str(c).strip() for c in df.columns]
    n_file = len(df)

    if tgt not in df.columns:
        raise CaseError("target column %r is not in the file%s" % (tgt, suggest(tgt, list(df.columns))))
    drop = case["drop_columns"]
    labeled = case["leak_columns"] + case["probable_leak_columns"]
    if tgt in drop:
        raise CaseError("the target %r is in drop_columns" % tgt)
    if tgt in labeled:
        raise CaseError("the target %r is listed as a leak/probable column" % tgt)
    clash = [c for c in labeled if c in drop]
    if clash:
        raise CaseError("listed as leak/probable and also in drop_columns: %s" % clash)
    absent = [c for c in drop if c not in df.columns]
    if absent:
        print("    note: drop_columns not in the file (ignored): %s" % absent)
    df = df.drop(columns=[c for c in drop if c in df.columns])
    missing = [c for c in labeled if c not in df.columns]
    if missing:
        raise CaseError("leak/probable columns not in the table: %s"
                        % "; ".join(repr(c) + suggest(c, list(df.columns)) for c in missing))

    y_raw = df[tgt]
    if y_raw.dtype == object:
        y_raw = y_raw.where(y_raw.isna(), y_raw.astype(str).str.strip()).replace("", np.nan)
    keep = y_raw.notna()
    df, y_raw = df[keep], y_raw[keep]
    y = make_target(y_raw, case)
    keep = y.notna()
    n_no_target = n_file - int(keep.sum())
    df, y = df[keep], y[keep]
    if n_no_target:
        print("    note: %d rows without a target value were dropped" % n_no_target)

    cap = case.get("sample_rows")
    try:
        cap = int(cap) if cap is not None else None
    except (TypeError, ValueError):
        raise CaseError("sample_rows must be a whole number or null")
    if cap is None and len(df) > DEFAULT_MAX_ROWS:
        cap = DEFAULT_MAX_ROWS
    sampled = cap is not None and cap < len(df)
    if sampled:
        idx = common.sample_index(y, cap, SEED, stratify=(case["task"] == "binary"))
        df, y = df.loc[idx], y.loc[idx]

    if common.TARGET in df.columns and tgt != common.TARGET:
        print("    note: the file already has a column named 'target'; it is renamed 'target_original'")
        df = df.rename(columns={common.TARGET: "target_original"})
    df = df.drop(columns=[tgt])
    df[common.TARGET] = y.values

    os.makedirs(common.path("data"), exist_ok=True)
    tmp = common.data_file(cid) + ".tmp"
    df.to_csv(tmp, index=False, compression="gzip")
    os.replace(tmp, common.data_file(cid))
    back = common.read_data(cid)  # infer types from the file the next steps read
    types = {c: common.infer_type(back[c]) for c in back.columns if c != common.TARGET}
    binary = case["task"] == "binary"
    meta = {"id": cid, "name": case["name"], "kind": case["kind"], "task": case["task"], "target_original": tgt,
            "rows": int(len(back)), "rows_in_file": int(n_file), "rows_without_target": int(n_no_target),
            "sampled": bool(sampled), "positive_rate": float(back[common.TARGET].mean()) if binary else None,
            "target_mean": None if binary else float(back[common.TARGET].mean()),
            "columns": types, "leak_columns": case["leak_columns"],
            "probable_leak_columns": case["probable_leak_columns"], "url": case["url"], "created": common.stamp()}
    common.write_json(common.meta_file(cid), meta)
    return meta


def main() -> None:
    print("Step 1 -- download and standardize the cases in %s" % common.CASES_FILE)
    cases = common.load_cases()
    if not cases:
        print("No usable cases in cases.json.")
        return
    rows = []
    for case in cases:
        print("\n%s (%s, %s)" % (case["id"], case["kind"], case["task"]))
        t0 = time.time()
        try:
            m = process(case)
            rate = "%.3f" % m["positive_rate"] if m["positive_rate"] is not None else "mean %.3g" % m["target_mean"]
            print("    ok: %d of %d rows, %d columns, target %s (%.0f s)"
                  % (m["rows"], m["rows_in_file"], len(m["columns"]), rate, time.time() - t0))
            rows.append([case["id"], case["kind"], case["task"], "ok", m["rows_in_file"], m["rows"], len(m["columns"]),
                         rate, len(m["leak_columns"]), len(m["probable_leak_columns"]), ""])
        except Exception as e:  # CaseError or anything unexpected: report, skip, carry on
            remove_outputs(case["id"])
            msg = " ".join(str(e).split()) or e.__class__.__name__
            if not isinstance(e, CaseError):
                msg = "%s: %s" % (e.__class__.__name__, msg)
            print("    ERROR: %s -- case skipped" % msg)
            rows.append([case["id"], case["kind"], case["task"], "SKIPPED", "", "", "", "", len(case["leak_columns"]),
                         len(case["probable_leak_columns"]), msg[:70]])
    print("\nSummary")
    print(common.format_table(["case", "kind", "task", "status", "rows in file", "rows kept", "columns",
                               "positive rate", "leaks", "probable", "problem"], rows))
    ok = sum(1 for r in rows if r[3] == "ok")
    print("\n%d of %d cases ready in data/.%s" % (ok, len(rows), " Next: step2_column_check.py" if ok else ""))


if __name__ == "__main__":
    main()
