# Leakage-auditor quick test

This is an informal viability check, not the paper. There is no GitHub repo or pre-registration yet.

> **Updating an existing folder:** copy the new files over the old ones, and keep `data/`, `llm_cache/` and `reworded/`. Your cached calls then stay free.

It asks one question: **do the standard leak checks miss real leaks, and can an LLM catch the misses without just recognizing famous datasets?**

## What's in it

- **16 public datasets with documented leaks**, 63 leak columns in all. A leak column is one that would not be known at the moment the prediction is made, or is computed from the outcome. Examples: call duration in bank marketing, lifeboat and body number in Titanic, payment totals in Lending Club, reservation status in hotel bookings.
- **11 clean datasets**, used to count false flags.
- **31 debatable columns**, listed as `probable_leak_columns` and left out of the scoring. These columns neither count for nor against any method.
- **The labels were frozen before any method was run.** Every label, with its documentation link, is in `cases.json`.

## Run order (PyCharm: open each file, press Run)

1. **`step1_get_data.py`** downloads the 27 datasets from GitHub into `data/`. It takes about a minute.
   - The Telco case is an Excel file. It needs `pip install openpyxl`; without it, step 1 skips that one case.
2. **`step2_column_check.py`** runs the vendor-style check: each column scored on its own, out of fold. It takes 5–10 minutes.
3. **`step3_llm_audit.py`** runs the LLM audit.
   - Run it once as shipped (`DRY_RUN = True`). This prints the prompts and a cost estimate, and makes no calls.
   - Then paste your keys at the top, set `DRY_RUN = False`, and run it again.
   - **Models:** DeepSeek, Claude and GPT. A model whose key isn't pasted is skipped.
   - **Conditions:** each model sees each dataset four ways:
     - **real:** the real column names;
     - **reworded:** names reworded, with the dataset's identity removed;
     - **scrambled:** names replaced by `col_01`…;
     - **disguised:** built so the models cannot recognize the dataset. GPT rewrites the task text, every column name and every category label it will show (cached in `disguised/`). The columns are then shuffled, counts and numbers rounded, and dates shifted by 7–15 years.
   - **Recognition probes:** each model is also asked, in a separate short call, which public dataset the real table and the disguised table come from. The answers go to `probes.csv`.
   - **Time and cost:** about 10–20 minutes. If your earlier calls are cached, the new calls cost roughly $1.60 plus GPT's reasoning tokens. The dry run prints the estimate.
   - **Caching:** every call is cached, so a rerun only pays for what failed or changed.
4. **`step4_evaluate.py`** prints the verdict and writes `results.txt`. Send me that file.

**Check:** if you run step 4 before step 3, it should show the baseline at a macro recall of 0.77, with 20 false flags. That's what I got here.

## How it's scored

- **Recall:** the share of each dataset's leak columns that a method flags, averaged over the leak datasets ("macro recall").
- **False-flag budget:** at most 1 false flag per dataset on average, counting the clean datasets.
- **Thresholds:** each method's threshold is tuned to its best setting within that budget.
- **The baseline is the strongest version of the vendor check.** It gets separate thresholds for classification and regression, and the best of three regression scores. The LLM has to beat the vendor check at its best.
- **Combined method:** a column is flagged if the vendor check flags it OR the LLM's risk is above its threshold.

## Kill rules

- **K1 – KILL** if the vendor check alone reaches a macro recall of 0.90 or more. Between 0.75 and 0.90, step 4 warns that the gap is thin.
- **K2 – KILL** if the best combined method (real names) adds less than 0.15 to the baseline.
- **K3 – KILL** if the gain in the disguised condition is below half the gain with real names. That would mean the LLM is recognizing datasets, not reasoning. If there is no disguised condition, the reworded one is used instead.
- **Recognition gate:** a model fails the gate if it names more than 15% of the disguised datasets in its probe (`RECOG_MAX`). Step 4 warns when that happens, because that model's disguised result is then not a clean memorization control.
- **GO** needs all three:
  - no kill rule fires;
  - at least one model passes the recognition gate;
  - that model's disguised combined method catches at least half of the leaks the vendor check missed.

  Step 4 names the model.
- **Per-model table:** step 4 also shows each model per condition, and its disguised recall on only the datasets it did not recognize, next to the vendor check on the same datasets.

These are directional results on a small sample. All methods are tuned on the same data, which flatters each of them equally.

## Files it creates

| File | What it is |
|---|---|
| `data/` | The downloads and the standardized tables. |
| `scores_column_check.csv` | Step 2: one row per dataset and column. |
| `reworded/`, `disguised/`, `llm_cache/` | Step 3: the reworded and disguised rewrites, and every LLM call (prompt, answer, tokens, cost). |
| `scores_llm.csv` | Step 3: the LLM's leak risk (0–100) and its reason, for every column, model and condition. |
| `probes.csv` | Step 3: each model's up to 3 guesses (with confidence) of which public dataset the real and the disguised table come from. |
| `step3_log.txt` | Step 3: retries and failures. |
| `results.txt` | Step 4: the method table, the misses, the false flags to review, and the verdict. |

## If something fails

- **Certificate error on the Mac:** double-click "Install Certificates.command" in Applications > Python 3.9.
- **DeepSeek rejects the model name:** set `DEEPSEEK_MODEL` to the name shown in your DeepSeek console.
- **GPT answers get cut off:** `step3_log.txt` will say so. Raise `MAX_TOKENS`, or `WRITER_MAX_TOKENS` for the disguise writer.
- **The disguise writer fails for a case:** step 3 retries once, listing the problems. If the answer is still unusable, it skips the disguised condition for that case and logs why. Running step 3 again retries it.
- **Testing without spending:** `MOCK = True` in step 3 runs the whole pipeline with a fake LLM. Its verdict means nothing.
