# t0_import.py -- brings what fine-tune run 4 needs from your run 3 folder ("leak training 3") into this folder.
# Python 3.9; press Run in PyCharm. No keys, no calls. Running it again is safe (it only adds what is new).
#
# From RUN3_FOLDER:
#   cases.json and data/ for the 42 generated test tables, and every earlier whole-table answer for them in
#   llm_cache/<label>/real/ (DeepSeek, Claude, GPT, open and local models, run 1's and run 2's RunPod models), for
#   reference rows;
#   run 3's own RunPod answers to the 42 generated tables (llm_cache/gpu3-.../chunks/), renamed run3-gpu-... so they
#   never mix with run 4's;
#   the development tables, with data/: cases_dev.json (the first 27 public datasets), cases_dev2.json (leak real test
#   2's 47) and cases_test3.json, saved here as cases_dev3.json (real test 3's 55: its results were read for run 3's
#   verdict, so from run 4 on they are training data, never test data);
#   cases_distill.json (run 3's 268 public training tables) with data/;
#   the teachers' saved answers (llm_cache/claude/chunks/ and llm_cache/gpt/chunks/), so t2_teachers.py only asks what
#   is new -- run 3's answers cost nothing again.
# Nothing in RUN3_FOLDER is changed. A file already here is kept, unless the one there is newer and different.
#
# Path: in PyCharm, right-click the folder > Copy Path/Reference > Absolute Path, and paste it between the quotes.

RUN3_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leak training 3"

# ============================================================ internals
import filecmp
import json
import os
import shutil
import sys
from typing import Any, Dict, List, Set

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

DEV_FILES = {"cases_dev.json": "cases_dev.json", "cases_dev2.json": "cases_dev2.json", "cases_test3.json": "cases_dev3.json"}
DISTILL_FILE = "cases_distill.json"
RUN3_RENAME = {"gpu3-qwen3.5-9b": "run3-gpu-qwen3.5-9b", "gpu3-leakaudit3-qwen3.5-9b": "run3-gpu-leakaudit3-qwen3.5-9b"}
TEACHER_LABELS = ["claude", "gpt", "mock-claude", "mock-gpt"]   # the mock labels exist only in a pipeline test
STATS: Dict[str, int] = {"copied": 0, "updated": 0, "kept": 0}


def folder(p: str) -> str:
    p = os.path.expanduser(str(p or "").strip().strip("'\""))
    if not p or p.startswith("PASTE_"):
        raise SystemExit("Paste the full path of your leak training 3 folder at the top of t0_import.py (RUN3_FOLDER).")
    p = os.path.normpath(p)
    if not os.path.isdir(p):
        raise SystemExit("RUN3_FOLDER does not exist: %s" % p)
    if os.path.samefile(p, HERE):
        raise SystemExit("RUN3_FOLDER points at this folder -- it must be your leak training 3 folder.")
    return p


def put(src: str, dst: str) -> None:
    """Copy src to dst unless dst exists; replace dst only if src is newer and different."""
    if os.path.exists(dst):
        if filecmp.cmp(src, dst, shallow=False) or os.path.getmtime(src) <= os.path.getmtime(dst):
            STATS["kept"] += 1
            return
        STATS["updated"] += 1
    else:
        STATS["copied"] += 1
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def read_cases(p: str) -> List[Dict[str, Any]]:
    if not os.path.exists(p):
        raise SystemExit("Not found: %s" % p)
    with open(p, encoding="utf-8-sig") as f:
        raw = json.load(f)
    return raw.get("cases", []) if isinstance(raw, dict) else raw


def copy_data(src_dir: str, ids: List[str], what: str) -> List[str]:
    """data/<id>.csv.gz and .meta.json for these tables, and their downloaded source files (data/raw/<id>/) when the
    folder has them (t3 compares those with real test 4's, so no copy of a test table can get into training)."""
    missing = []
    for cid in ids:
        f = os.path.join(src_dir, "data", cid + ".csv.gz")
        if not os.path.exists(f):
            missing.append(cid)
            continue
        put(f, common.data_file(cid))
        m = os.path.join(src_dir, "data", cid + ".meta.json")
        if os.path.exists(m):
            put(m, common.meta_file(cid))
        rd = os.path.join(src_dir, "data", "raw", cid)
        if os.path.isdir(rd):
            for fn in sorted(os.listdir(rd)):
                if os.path.isfile(os.path.join(rd, fn)) and not fn.endswith(".part"):
                    put(os.path.join(rd, fn), os.path.join(common.raw_dir(cid), fn))
    if missing:
        print("  %s: no data for %d table(s) there: %s" % (what, len(missing), ", ".join(missing[:15])))
    return missing


def copy_whole_answers(src_dir: str, ids: Set[str]) -> Dict[str, int]:
    """Earlier whole-table answers ('real') for the generated test tables, every label as it is there."""
    got: Dict[str, int] = {}
    root = os.path.join(src_dir, "llm_cache")
    if not os.path.isdir(root):
        return got
    for lab in sorted(os.listdir(root)):
        d = os.path.join(root, lab, "real")
        if lab.startswith("mock-") or not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            cid = fn[:-5] if fn.endswith(".json") else None
            if cid not in ids:
                continue
            put(os.path.join(d, fn), common.path("llm_cache", lab, "real", fn))
            got[lab] = got.get(lab, 0) + 1
    return got


def chunk_table(fn: str) -> str:
    """The table id of a chunk answer file name (<table>__c<j>of<k>.json)."""
    return fn[:-5].rsplit("__c", 1)[0] if fn.endswith(".json") else ""


def copy_run3_gpu(src_dir: str, ids: Set[str]) -> Dict[str, int]:
    """Run 3's RunPod answers to the generated test tables' prompts, renamed run3-gpu-..."""
    got: Dict[str, int] = {}
    for lab, new in RUN3_RENAME.items():
        d = os.path.join(src_dir, "llm_cache", lab, "chunks")
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if chunk_table(fn) in ids:
                put(os.path.join(d, fn), common.path("llm_cache", new, "chunks", fn))
                got[new] = got.get(new, 0) + 1
    return got


def copy_teachers(src_dir: str) -> Dict[str, int]:
    """Every saved teacher answer (run 3's tables, and real test 3's prompts if TEST3_REFERENCE was used)."""
    got: Dict[str, int] = {}
    for lab in TEACHER_LABELS:
        d = os.path.join(src_dir, "llm_cache", lab, "chunks")
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if fn.endswith(".json"):
                put(os.path.join(d, fn), common.path("llm_cache", lab, "chunks", fn))
                got[lab] = got.get(lab, 0) + 1
    return got


def main() -> None:
    src = folder(RUN3_FOLDER)
    print("From %s" % src)

    print("1. The 42 generated test tables")
    gen = [c for c in read_cases(os.path.join(src, "cases.json")) if c.get("url") == "generated"]
    if len(gen) != 42:
        print("  note: found %d generated tables in its cases.json (expected 42)" % len(gen))
    put(os.path.join(src, "cases.json"), common.path("cases.json"))
    if os.path.exists(os.path.join(src, "generated_checksums.txt")):
        put(os.path.join(src, "generated_checksums.txt"), common.path("generated_checksums.txt"))
    gen_ids = [c["id"] for c in gen]
    missing = copy_data(src, gen_ids, "generated")
    whole = copy_whole_answers(src, set(gen_ids))
    run3 = copy_run3_gpu(src, set(gen_ids))

    print("2. Development tables (documented keys): the 27, the 47 and real test 3's 55")
    sets: Dict[str, List[str]] = {"generated test": gen_ids}
    for src_name, dst_name in DEV_FILES.items():
        p = os.path.join(src, src_name)
        cases = read_cases(p)
        sets[dst_name] = [c["id"] for c in cases]
        put(p, common.path(dst_name))
        missing += copy_data(src, sets[dst_name], dst_name)

    print("3. Run 3's public training tables (%s)" % DISTILL_FILE)
    p = os.path.join(src, DISTILL_FILE)
    distill = read_cases(p)
    sets[DISTILL_FILE] = [c["id"] for c in distill]
    put(p, common.path(DISTILL_FILE))
    no_distill = copy_data(src, sets[DISTILL_FILE], DISTILL_FILE)   # left out of training (t3 says so), no stop

    seen: Dict[str, str] = {}
    for name, ids in sets.items():
        for cid in ids:
            if cid in seen:
                raise SystemExit("STOP: table %s is in both %s and %s. Tell Claude." % (cid, seen[cid], name))
            seen[cid] = name

    print("4. The teachers' saved answers")
    teachers = copy_teachers(src)

    print("\nFiles: %d copied, %d updated, %d already here." % (STATS["copied"], STATS["updated"], STATS["kept"]))
    rows = [[lab, n] for lab, n in sorted(teachers.items())] + [[lab, n] for lab, n in sorted(run3.items())]
    rows += [[lab + " (whole-table)", n] for lab, n in sorted(whole.items())]
    if rows:
        print(common.format_table(["saved answers brought in", "files"], rows))
    if not any(lab in teachers for lab in TEACHER_LABELS):
        print("note: no saved teacher answers in %s -- t2_teachers.py will ask for all of them" % RUN3_FOLDER)
    if missing:
        print("STOP: %d generated or development table(s) have no data in RUN3_FOLDER (listed above). Tell Claude."
              % len(missing))
        return
    print("Tables here: %d generated test, %d + %d + %d development (the 27, the 47, real test 3), %d public training "
          "(run 3%s). Next: t1_get_data.py"
          % (len(gen_ids), len(sets["cases_dev.json"]), len(sets["cases_dev2.json"]), len(sets["cases_dev3.json"]),
             len(sets[DISTILL_FILE]) - len(no_distill),
             "; %d without data left out" % len(no_distill) if no_distill else ""))


if __name__ == "__main__":
    main()
