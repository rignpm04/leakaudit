# Fine-tune run 4 ("leak training 4") -- design, fixed before any run-4 result

## Goal and the rule
Make Qwen3.5 9B a useful leak finder on real tables, without losing what the generator teaches. Run 3 (teachers on 268
real tables + 74 development tables, 240 generated tables, chunked prompts) gained +0.13 on real test 3 but lost 0.07 on
the held-out generated domains: it forgot generator patterns (e.g. "last_payment_date" called "Known at application").
Run 4 = run 3's recipe + much more real teacher data + the generated tables back (with real reasons) + more training +
batched, 3-sample answering.

Rule (fixed now, before any run-4 result; it puts real data first, as Patrick asked): within budget (best threshold on
0..100 step 5, <= 1 false flag per table on average, per group), scores = the mean of each column's 3 sampled ratings:
- PASS: trained - untrained >= +0.10 macro recall on REAL TEST 4, AND trained - untrained >= -0.05 on the held-out
  generated domains (lending, hospital).
- PARTIAL: real test 4 gain >= +0.10, but the held-out domains lose more than 0.05.
- FAIL: real test 4 gain < +0.10.
Debatable columns count neither way; unreadable = nothing flagged. Also reported (not the verdict): first-sample-only
scores (comparable with runs 1-3), the fixed setting (risk >= 50), false flags per table, run 3's trained model on the
generated groups, and -- only after the verdict -- the teachers on real test 4.

## Folder on Patrick's Mac: `leak training 4`
Same conventions as runs 2-3 (Python 3.9, pandas/numpy/stdlib only, PyCharm Run button, constants at the top, no CLI
args, no env vars, files in the script's own folder, terse prints, a "Next:" line). Keys only in t2_teachers.py as
PASTE_..._HERE placeholders; DRY_RUN = True and every MOCK flag False as shipped.

Files:
- `common.py`, `step1_generate.py`, `step1_get_data.py`, `step3_llm_audit.py`: byte-identical copies of run 3's kit
  (/home/claude/run3/kit3/). The chunk prompts must stay exactly run 3's, so run 3's cached teacher answers are reused.
- `t0_import.py`: from RUN3_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leak training 3" (copy rule as
  run 3's t0 put(): copy if absent, replace only if newer and different):
  - cases.json + data/ for the 42 generated test tables; every whole-table answer in llm_cache/<label>/real/ for them
    (labels kept as they are there: run1-gpu-..., run2-gpu-..., deepseek, claude, gpt, open-..., local-...);
  - run 3's GPU chunk answers for the 42 generated tables: llm_cache/gpu3-qwen3.5-9b/chunks/<chunk>.json and
    llm_cache/gpu3-leakaudit3-qwen3.5-9b/chunks/<chunk>.json -> renamed run3-gpu-qwen3.5-9b and
    run3-gpu-leakaudit3-qwen3.5-9b (only chunks of the 42 generated tables);
  - development tables: cases_dev.json (27), cases_dev2.json (47), and cases_test3.json saved here as cases_dev3.json
    (55; real test 3 is development data from run 4 on), each with its data/;
  - cases_distill.json (268) with data/;
  - the teachers' cached chunk answers llm_cache/claude/chunks/*.json and llm_cache/gpt/chunks/*.json (all of them:
    the 268 + 74 tables, and test 3's chunks from the TEST3_REFERENCE run), so t2 asks only what is new.
  - STOP if an id is in two sets. Prints counts per set and "Next: t1_get_data.py".
- `t1_get_data.py`: run 3's patched t1 with CASES_FILES = ["cases_distill2.json", "cases_test4.json"]; its "Next:" says
  t2a_make_generated.py when test 4 is not there yet, t3_make_training.py when it is.
- `t2a_make_generated.py` (new): builds the generated TRAINING tables and saves them like any table, so the teachers can
  rate them: GEN_TABLES_PER_DOMAIN = 200 for claims, orders, saas, shipments (800); step1_generate.build(tid, dom, k,
  traps, v2=True); ids trn4_<domain>_NNNN; its own random plan (SEED 20261022): TRAP_SHARE 0.15, k drawn as run 2/3.
  Writes data/<id>.csv.gz + data/<id>.meta.json exactly as the 42 generated test tables are stored (so
  step3.chunk_info gives the same prompt t3 would build in memory -- check this for 2 tables), and cases_gen.json (the
  case dicts: id, domain, naming_style, kind, task, target, unit, prediction_time, target_description, url "generated",
  leak_columns, leak_types, decoy_columns, trap_columns, ...). STOP if any table's CSV equals a generated test table
  (sha256) or an id repeats. Skips tables already built (rerun-safe). Prints counts by domain / style / leak type.
- `t2_teachers.py`: run 3's t2 extended:
  - BOTH teachers (claude-sonnet-5-5, gpt-6.1-sol) on cases_distill.json, cases_distill2.json, cases_dev.json,
    cases_dev2.json, cases_dev3.json;
  - GPT ONLY on cases_gen.json (REASON_TEACHERS = ["gpt"]; only its reasons are used, the key sets the scores);
  - TEST4_REFERENCE = False (True only after the run-4 verdict: both teachers on cases_test4.json);
  - every cached answer whose prompt hash matches is reused; DRY_RUN shows per file and teacher: tables, prompts,
    prompts still to ask, cost and time; WORKERS 4 per teacher; retry on unreadable or ANY missing column; MOCK;
  - summary (teacher_summary.txt): run 3's tables + GPT on the generated tables against the generator key (recall and
    false flags at risk >= 50) as a sanity check; the "Next:" line says send Claude teacher_summary.txt.
- `t3_make_training.py`: run 3's patched t3, extended (see Training data).
- `t4_make_test_prompts.py`: run 3's patched t4 with real test 4: the 42 generated tables + cases_test4.json, group names
  "training domains", "held-out domains", "trap tables", "real test 4". Refuses any table of cases_distill*.json,
  cases_dev*.json or cases_gen.json.
- `train2_runpod_run4.ipynb`: see Notebook.
- `t5_import_gpu.py`, `t6_compare.py`: see Import and Compare.
- `GUIDE.md` is written by the main session, not the fork.

## Training data (t3_make_training.py)
- Real distillation tables: cases_distill.json + cases_distill2.json, DISTILL_VARIANTS = 2 (v1 = as is, prompts identical
  to the teachers'; v2 = columns shuffled + 60-95% rows). Target = mean of the two teachers rounded to 5 (run 3 rule).
- Development tables: cases_dev.json + cases_dev2.json + cases_dev3.json (129), DEV_VARIANTS = 3, run 3's key clamps
  (leak >= 80, debatable 20-80, other <= 20) and category/reason rules.
- Generated tables (cases_gen.json, 800), variant 1 only (their prompts are exactly what GPT answered). Score from the
  key: leak types -> 95 with run 3's CATEGORY map; every other column 5 "fine" (decoys, traps, silently overwritten
  fields, the moment column included). Reason: GPT's own reason when GPT agrees with the key (key leak and GPT risk >= 50
  with a non-fine category; or key fine and GPT risk < 50 with category fine), else a specific template:
    outcome_status "A status that reflects the outcome, set after the prediction moment."
    post_event_date "A date that is only filled in after the prediction moment."
    snapshot_state "A current value taken when the data were pulled, after the prediction moment."
    outcome_only_sparse "Filled in only when the outcome happens."
    post_aggregate "A total that keeps growing after the prediction moment."
    target_derived "Computed from the outcome itself."
    identifier "An id that repeats across rows and lets a model memorize outcomes."
    target_part "Part of the outcome being predicted."
    event_measure "Measured during or after the event, not before the moment."
    assigned_during "Assigned during the process, after the prediction moment."
    followup_time "A follow-up time, known only after the outcome period."
    fine, decoy or trap column: "Known at the prediction moment, despite how its name sounds."
    any other fine column: "Known at the prediction moment."
  The manifest counts how many generated reasons came from GPT and how many from templates, per leak type.
- Validation: VAL_SHARE 0.05 of tables (whole tables, every source), SEED.
- STOP checks (run 3's patched t3, all kept): teacher-prompt drift; a source ending with 0 tables; generator check (42
  rebuild byte for byte); no training table reproduces a generated test table; no training table (any source) shares
  an id, url, raw-file sha256 or a column set (normalized, target included, Jaccard > 0.8) with a real test 4 table;
  same-prompt checks. Files written only after every check.
- Manifest: counts by source and variant, risk histogram by source, estimated tokens, longest example, tables left out,
  the reason sources above.

## Notebook (train2_runpod_run4.ipynb)
Run 3's patched notebook, changed where needed:
- Names: answers_base_run4.jsonl, answers_trained_run4.jsonl, train_run4.json, OUTPUT_NAME leakaudit4-qwen3.5-9b.
- Training: EPOCHS 2, LEARNING_RATE 1e-4, cosine schedule, warmup_ratio 0.03, LORA_RANK 32 (alpha 32), batch 4 x
  accumulation 4, eval every 100 steps, LoRA checkpoints saved at each eval (save_total_limit 3), and
  load_best_model_at_end on eval_loss (record the best step and every eval loss). TRAIN_MAX_TOKENS 8192, MAX_SEQ_LENGTH
  16384, seed 3407, UNSLOTH_EXPERIMENTAL_HYBRID_PACKING=0, padding_free False, answer-only loss with the same markers and
  masking asserts as run 3.
- Answering: K_SAMPLES = 3 (num_return_sequences) at T 0.6 / top_p 0.95 / top_k 20, EVAL_MAX_NEW_TOKENS 2048, prompts
  answered ANSWER_BATCH = 16 at a time (sorted by length, left padding, attention mask), thinking off.
  Batching check before the first stage: the first 16 prompts answered greedily (one return sequence) both in one batch
  and one at a time; if any answer is readable in one mode and not the other, or fewer than 90% of the rated columns get
  the same flag at risk >= 50, or batched generation raises, set ANSWER_BATCH = 1 for the whole run (both models) and
  record why in the run record. (With ANSWER_BATCH 1 the 3 samples still run together: one prompt, no padding.)
  Retry: a prompt whose samples leave any column unrated by every readable sample, or whose samples are all unreadable,
  is asked once more (K samples) with run 3's reminder text; what the retry adds is merged.
  Answer line: {"id", "table", "group", "label", "texts": [K strings], "texts_retry": [...] or null, "tokens": [...],
  "seconds", "attempts", "session", "readable": number of readable samples}. Atomic whole-file rewrite after each batch
  (no append mode), NUL/broken-line handling and the training-session stamp for trained answers, exactly as run 3's
  patched notebook.
- Preview after each stage: per group, the 3-sample mean, flag at risk >= 50.
- Run record: run 3's fields + K_SAMPLES, ANSWER_BATCH used and the batching-check result, best checkpoint step,
  eval losses, minutes per stage, test-prompt sha256.
- GGUF q4_k_m from the best model, renamed as before.

## Import (t5_import_gpu.py)
answers_base_run4.jsonl -> llm_cache/gpu4-qwen3.5-9b/chunks/, answers_trained_run4.jsonl ->
llm_cache/gpu4-leakaudit4-qwen3.5-9b/chunks/; plus first-sample labels gpu4-qwen3.5-9b-s1 and
gpu4-leakaudit4-qwen3.5-9b-s1 (only the first sample and its retry). Each chunk record: "parsed": {"columns": {col:
{"leak_risk": mean over the samples that rated it, "category": the most common, "reason": the first}}, ...},
"samples": the parsed samples, prompt_hash stamped as run 3. STOP if test_prompts.jsonl's sha256 differs from the one in
train_run4.json (run 3's patch). NUL bytes stripped and reported; lines split on "\n" only.

## Compare (t6_compare.py)
Run 3's patched t6 with: groups training domains / held-out domains / trap tables / real test 4; BASE_LABEL
gpu4-qwen3.5-9b, TRAINED_PREFIX gpu4-leakaudit4 (the verdict uses the 3-sample labels; the -s1 rows are shown for
reference); the new rule above (PASS / PARTIAL / FAIL); reference rows: run3-gpu-... chunk answers (generated groups),
whole-table answers (generated groups), claude/gpt chunk answers on real test 4 if TEST4_REFERENCE was run; a "useful
operating point" line per model and group: recall and false flags per table at risk >= 50; real test 4 by table;
output results_training_run4.txt.

## Mock test (sandbox)
End to end, as run 3's: a mock "leak training 3" folder (from /home/claude/run3/mock/lt3, or rebuilt), t0, t1 on a few
distill2 + test-4 stand-ins, t2a (a small GEN_TABLES_PER_DOMAIN for speed, then the full 800 once to time it), t2
(MOCK, including GPT-only generated tables and cache reuse: a second run asks nothing), t3, t4, the notebook's code
cells with a fake model that supports batched generate with num_return_sequences (resume, atomic writes, the batching
check and its fallback, retries, session stamps), t5, t6 (verdict branches PASS / PARTIAL / FAIL with constructed
answers). Python 3.9 + pandas 2.2.3 for the Mac-side scripts: /tmp/claude-0/-home-claude/1148d323-30d7-5c5c-a018-aeabaa4585a2/scratchpad/py39/bin/python.

## Amendments (after Part A shipped; before any run-4 result -- the rule above is unchanged)
1. `step1_get_data.py` is no longer byte-identical to run 3's. pandas does not quote a text value holding a bare
   carriage return, so reading the stored table back split that row in two (real test 4: ceo_departures_dismissal
   stored 25,127 rows from a 9,423-row file, cetacean_captivity_death 2,224 from 2,194). Now: `line_breaks()` stores
   \r\n and \r as \n (columns taken by position), and a stored table that does not read back with the same rows and
   columns is an error. Tables without a \r are untouched: all 433 distill2 tables re-prepare byte-identically, so no
   teacher prompt changes.
2. `t1_get_data.py` prepares again any table whose meta has more rows than its file had (rows split by an older step 1);
   `t4_make_test_prompts.py` STOPs on such a real test 4 table.
3. `t3_make_training.py`, generated tables: when GPT agrees with the key on a leak column (risk >= 50, a leak category,
   a reason), GPT's own reason AND category are used, so the two always fit; otherwise the template reason with the
   key's category. (t2's summary line "reasons usable in training" still counts with the older rule; t3's printout and
   train_manifest.json give the true counts.)
4. Notebook: an old `outputs/` is moved aside (`outputs_before_<time>/`) instead of deleted, and the best adapter is
   saved (`leakaudit4-qwen3.5-9b-lora/`) right after training, before the trained answers, so a crash while answering
   cannot cost the training.
5. t2 runs WORKERS = 8 per teacher (not 4).
6. Real test 4 (cases_test4.json): 56 tables (43 with leaks, 13 clean), 208 leak columns, 46 debatable; 239 test
   prompts in all (127 for the 42 generated tables, 112 for real test 4). Found by six searches, then checked by four
   independent checkers (documentation, every column, exact data relations, quotes) and one hint review of the task
   sentences (no column names, no value codes, no leak/clean tells in the wording). The checks and every final decision
   are in test4_review.json; the final decisions: avail_seat_km_per_week (airline), Term/daysterm/xx (SBA), case_no
   (H-2) and f1 (tornado) are debatable, not leaks; the H-2 target is case_status (17 certified statuses), because the
   published is_certified is wrong for every H-2A row of FY2020-2022.
7. Full-size rehearsal (sandbox, Mac stack, mock teachers, the notebook against fakes): t2 3,903 prompts for 1,630
   tables (31,761 columns, as on the Mac); t3 5,641 examples (train 5,415, val 226), about 6.6 million tokens per pass,
   longest example about 2,064 tokens, 253 s, peak memory 215 MB; t4 239 prompts for 98 tables; t5 and t6 read and
   score all 239 prompts.
