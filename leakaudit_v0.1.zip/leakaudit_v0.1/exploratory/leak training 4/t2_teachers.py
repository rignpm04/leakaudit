# t2_teachers.py -- the teachers of fine-tune run 4: Claude and GPT rate every column of the public training tables, a
# few columns per prompt (the same chunked prompts the small model gets); their ratings become the small model's
# training answers in t3_make_training.py. GPT also rates the generated training tables (cases_gen.json, made by
# t2a_make_generated.py): there only its short reasons are used -- the generator's answer key sets the scores. Python
# 3.9; press Run in PyCharm.
#
# Tables rated by both teachers: cases_distill.json (run 3's 268), cases_distill2.json (run 4's new public tables),
# cases_dev.json (the first 27 public datasets), cases_dev2.json (leak real test 2's 47) and cases_dev3.json (real
# test 3's 55). By GPT only: cases_gen.json. Real test 4 is NOT rated (it is the test), unless TEST4_REFERENCE is set
# after the run-4 verdict, for reference rows only. Run 3's saved answers (brought in by t0_import.py) are reused: only
# prompts without an answer are asked.
#
# How to run:
#   1. DRY_RUN = True (as shipped): prints, per file and teacher, the tables, prompts, prompts still to ask, cost and
#      time, and the first prompt. No calls.
#   2. Paste your two keys below (only here, on your Mac; never into a chat, never send this file with keys in it),
#      set DRY_RUN = False, press Run. It shows progress; you can stop it any time.
#   3. Press Run again until it says every prompt is answered: each answer is saved in llm_cache/<claude|gpt>/chunks/
#      as soon as it arrives, so a stopped run resumes where it left off and a finished one costs nothing to re-run.
# At the end it writes teacher_summary.txt: answers per teacher, cost, how often the two teachers agree, each teacher's
# recall and false flags on the development tables (documented leaks), and GPT against the generator's key on the
# generated tables, as sanity checks.

ANTHROPIC_API_KEY = "REDACTED_KEY"
OPENAI_API_KEY = "REDACTED_KEY"

DRY_RUN = False                 # True: estimate only, no calls. False: call the teachers.
TEACHERS = ["claude", "gpt"]
REASON_TEACHERS = ["gpt"]      # the teachers asked on cases_gen.json (only their reasons are used there)
CLAUDE_MODEL = "claude-sonnet-5-5"
GPT_MODEL = "gpt-6.1-sol"
WORKERS = 8                    # calls running at the same time, per teacher
MAX_TOKENS = 8000              # cap on one answer
TEST4_REFERENCE = True        # True ONLY after the run-4 verdict: both teachers also rate real test 4 (reference rows)
MOCK = False                   # True: fake offline teachers (pipeline test only; labels mock-claude, mock-gpt)

TRAIN_FILES = ["cases_distill.json", "cases_distill2.json", "cases_dev.json", "cases_dev2.json", "cases_dev3.json"]
GEN_FILE = "cases_gen.json"
TEST4_FILE = "cases_test4.json"
OUT_TOKENS_PER_COLUMN = 45     # cost estimate only: answer tokens per rated column
REASONING_TOKENS_EST = 300     # cost estimate only: GPT's hidden reasoning tokens per call
SECONDS_PER_CALL_EST = 15      # time estimate only

# ============================================================ internals
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402

SUMMARY_FILE = "teacher_summary.txt"
LOG_FILE = "t2_log.txt"
DEV_FILES = ["cases_dev.json", "cases_dev2.json", "cases_dev3.json"]
# the generator's leak types the training answers rate as leaks (risk 95); every other column of a generated table,
# the silently overwritten fields included, is rated fine (as in t3_make_training.py)
KEY_LEAK_TYPES = ("outcome_status", "post_event_date", "snapshot_state", "outcome_only_sparse", "post_aggregate",
                  "target_derived", "identifier", "target_part", "event_measure", "assigned_during", "followup_time")
_lock = threading.Lock()
DISABLED: Dict[str, str] = {}
LINES: List[str] = []


def setup() -> None:
    s3.ANTHROPIC_API_KEY = ANTHROPIC_API_KEY
    s3.OPENAI_API_KEY = OPENAI_API_KEY
    s3.CLAUDE_MODEL = CLAUDE_MODEL
    s3.GPT_MODEL = GPT_MODEL
    s3.MAX_TOKENS = MAX_TOKENS
    s3.MOCK = MOCK


def label(m: str) -> str:
    return ("mock-" if MOCK else "") + m


def used_model_id(m: str) -> str:
    """The model id stamped on each answer (and inside its prompt hash)."""
    return ("mock:" if MOCK else "") + s3.model_id(m)


def prompt_hash(model_id: str, user: str) -> str:
    return common.text_hash(model_id, s3.SYSTEM_PROMPT, user)


def cache_path(lab: str, chunk_id: str) -> str:
    return common.path("llm_cache", lab, "chunks", chunk_id + ".json")


def load_chunk_answer(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The cached answer of one teacher to one chunk prompt, if it answers exactly today's prompt."""
    rec = common.load_json(cache_path(lab, ch["chunk_id"]))
    if not (isinstance(rec, dict) and rec.get("parsed") and rec.get("model_id")):
        return None
    if rec.get("prompt_hash") != prompt_hash(str(rec["model_id"]), ch["user"]):
        return None
    return rec


def out(s: str = "") -> None:
    with _lock:
        print(s)
        LINES.append(s)


def log(msg: str) -> None:
    with _lock:
        print(msg)
        try:
            with open(common.path(LOG_FILE), "a", encoding="utf-8") as f:
                f.write("%s  %s%s\n" % (common.stamp(), "[mock] " if MOCK else "", " ".join(msg.split())))
        except OSError:
            pass


def disable(m: str, why: str) -> None:
    with _lock:
        first = m not in DISABLED
        DISABLED[m] = why
    if first:
        log("  %s: no more calls this run -- %s" % (m, why))


def teachers_for(fname: str) -> List[str]:
    """The teachers that rate the tables of this file."""
    if fname == GEN_FILE:
        return [m for m in TEACHERS if m in REASON_TEACHERS]
    return list(TEACHERS)


# ============================================================ the tables and their chunk prompts
def load_tables(files: List[str]) -> List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]]:
    """(file, case, chunks) for every case with data, in file order."""
    out_: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]] = []
    seen: Dict[str, str] = {}
    for fname in files:
        if not os.path.exists(common.path(fname)):
            print("  %s: not in this folder -- skipped" % fname)
            continue
        cases = common.load_cases(quiet=True, file=fname)
        no_data = []
        for c in cases:
            if c["id"] in seen:
                raise SystemExit("STOP: table %s is in both %s and %s. Tell Claude." % (c["id"], seen[c["id"]], fname))
            seen[c["id"]] = fname
            if not common.has_data(c["id"]):
                no_data.append(c["id"])
                continue
            out_.append((fname, c, s3.chunk_prompts(s3.chunk_info(c))))
        if no_data:
            print("  %s: %d table(s) have no data yet (run %s): %s"
                  % (fname, len(no_data), "t2a_make_generated.py" if fname == GEN_FILE else "t1_get_data.py",
                     ", ".join(no_data[:12]) + (" ..." if len(no_data) > 12 else "")))
    return out_


def chunks_for(m: str, tables: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]]) -> List[Dict[str, Any]]:
    """Every chunk prompt teacher m rates."""
    return [ch for fname, _, chunks in tables if m in teachers_for(fname) for ch in chunks]


# ============================================================ one teacher answer (with one retry)
def ask(m: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    lab = label(m)
    cols = ch["columns"]
    t0 = time.time()
    text1, u1, stop1 = s3.call_model(m, s3.SYSTEM_PROMPT, ch["user"])
    usage = dict(u1)
    p1 = s3.parse_answer(s3.strip_think(text1), cols)
    found = dict(p1["entries"]) if p1 else {}
    unknown = list(p1["unknown"]) if p1 else []
    missing = [c for c in cols if c not in found]
    text2, stop2 = None, None
    if p1 is None or missing:   # unreadable, or any column left out: ask once more
        why = "answer not readable" if p1 is None else "%d of %d columns missing" % (len(missing), len(cols))
        log("  %s / %s: %s (stop: %s) -- asking once more" % (lab, ch["chunk_id"], why, stop1 or "?"))
        reminder = s3.chunk_reminder(cols, None if p1 is None else [s3.shown_name(c) for c in missing])
        text2, u2, stop2 = s3.call_model(m, s3.SYSTEM_PROMPT, ch["user"] + "\n\n" + reminder)
        usage = s3.add_usage(usage, u2)
        p2 = s3.parse_answer(s3.strip_think(text2), cols)
        if p2:
            for c, e in p2["entries"].items():
                found.setdefault(c, e)
            unknown += p2["unknown"]
    cost = 0.0 if MOCK else s3.cost_of(m, usage)
    if not found:
        cut = any(w in str(stop2 or stop1).lower() for w in ("length", "max_tokens", "max_output_tokens"))
        log("  %s / %s: no usable answer after one retry -- not saved; press Run again later.%s It began: %r"
            % (lab, ch["chunk_id"], " The answer was cut off: raise MAX_TOKENS." if cut else "",
               (text2 if text2 is not None else text1)[:300]))
        return {"failed": True, "cost": cost}
    left_out = [c for c in cols if c not in found]
    if left_out:
        log("  %s / %s: no answer for %d column(s): %s" % (lab, ch["chunk_id"], len(left_out), ", ".join(left_out)))
    mid = used_model_id(m)
    rec = {"case_id": ch["table"], "chunk_id": ch["chunk_id"], "model": lab, "model_id": mid,
           "prompt_hash": prompt_hash(mid, ch["user"]), "timestamp": common.stamp(), "prompt": ch["user"],
           "raw": text1, "raw_retry": text2, "stop": [stop1, stop2],
           "parsed": {"columns": found, "missing": left_out, "unknown_names": unknown},
           "usage": usage, "cost": round(cost, 6), "seconds": round(time.time() - t0, 1)}
    common.write_json(cache_path(lab, ch["chunk_id"]), rec)
    return rec


def run_teacher(m: str, todo: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Asks one teacher every chunk in todo, WORKERS at a time; progress every 25 answers."""
    st = {"done": 0, "failed": 0, "cost": 0.0, "fails_in_a_row": 0}
    if not todo:
        return st
    t0 = time.time()

    def one(ch: Dict[str, Any]) -> None:
        if m in DISABLED:
            return
        try:
            rec = ask(m, ch)
        except common.ApiError as e:
            text = str(e).lower()
            if e.code in (401, 402, 403, 404) or "insufficient_quota" in text or "credit balance" in text:
                disable(m, "HTTP %d: check the key at the top, its credit, and the model id (%s)"
                        % (e.code, s3.model_id(m)))
            log("  %s / %s: API error: %s" % (label(m), ch["chunk_id"], " ".join(str(e).split())[:400]))
            rec = {"failed": True, "cost": 0.0}
        except Exception as e:  # one prompt failing must not stop the run
            log("  %s / %s: ERROR %s: %s" % (label(m), ch["chunk_id"], e.__class__.__name__,
                                              " ".join(str(e).split())[:400]))
            rec = {"failed": True, "cost": 0.0}
        with _lock:
            st["cost"] += float(rec.get("cost") or 0.0) if rec else 0.0
            if rec and rec.get("failed"):
                st["failed"] += 1
                st["fails_in_a_row"] += 1
            else:
                st["done"] += 1
                st["fails_in_a_row"] = 0
            n = st["done"] + st["failed"]
            stop_now = st["fails_in_a_row"] >= 10
        if stop_now:
            disable(m, "10 prompts in a row failed -- see %s, then press Run again" % LOG_FILE)
        if n % 25 == 0 or n == len(todo):
            el = time.time() - t0
            print("  %s: %d / %d prompts (%d failed), %.0f min, about %.0f min left, $%.2f so far"
                  % (label(m), n, len(todo), st["failed"], el / 60, el / max(n, 1) * (len(todo) - n) / 60, st["cost"]))

    with ThreadPoolExecutor(max_workers=max(1, int(WORKERS))) as pool:
        futures = [pool.submit(one, ch) for ch in todo]
        for f in as_completed(futures):
            f.result()
    return st


# ============================================================ estimate and summary
def cost_minutes(m: str, todo: List[Dict[str, Any]]) -> Tuple[float, float, float, float]:
    """(tokens in, tokens out, dollars, minutes) to ask these prompts."""
    tin = sum(len(s3.SYSTEM_PROMPT) + len(ch["user"]) for ch in todo) / s3.CHARS_PER_TOKEN
    tout = sum(len(ch["columns"]) for ch in todo) * OUT_TOKENS_PER_COLUMN + \
        (REASONING_TOKENS_EST * len(todo) if m == "gpt" else 0)
    p = s3.PRICE_PER_M.get(s3.model_id(m)) or s3.PRICE_PER_M.get(m) or (0.0, 0.0)
    return tin, tout, (tin * p[0] + tout * p[1]) / 1e6, len(todo) * SECONDS_PER_CALL_EST / max(1, WORKERS) / 60.0


def estimate(tables: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]], teachers: List[str]) -> None:
    files = []
    for fname, _, _ in tables:
        if fname not in files:
            files.append(fname)
    rows = []
    for fname in files:
        tabs = [chunks for f, _, chunks in tables if f == fname]
        chunks = [ch for c in tabs for ch in c]
        for m in teachers:
            if m not in teachers_for(fname):
                rows.append([fname, m, len(tabs), len(chunks), "not asked", "-", "-"])
                continue
            todo = [ch for ch in chunks if load_chunk_answer(label(m), ch) is None]
            _, _, cost, minutes = cost_minutes(m, todo)
            rows.append([fname, m, len(tabs), len(chunks), len(todo), "$%.2f" % cost, "%.0f" % minutes])
    print(common.format_table(["file", "teacher", "tables", "prompts", "still to ask", "about", "minutes"], rows))
    if tables:
        ch = tables[0][2][0]
        print("\nThe first prompt (%s), exactly as sent (system prompt first):\n%s\n%s\n%s\n%s"
              % (ch["chunk_id"], "-" * 100, s3.SYSTEM_PROMPT, ch["user"], "-" * 100))
    total_cost, total_min = 0.0, 0.0
    for m in teachers:
        mine = chunks_for(m, tables)
        todo = [ch for ch in mine if load_chunk_answer(label(m), ch) is None]
        tin, tout, cost, minutes = cost_minutes(m, todo)
        p = s3.PRICE_PER_M.get(s3.model_id(m)) or s3.PRICE_PER_M.get(m) or (0.0, 0.0)
        total_cost += cost
        total_min = max(total_min, minutes)
        print("%-6s %s: %d of %d prompts still to ask; about %.1fM tokens in, %.2fM out -> about $%.2f "
              "(at $%.2f / $%.2f per million), about %.0f min with WORKERS = %d"
              % (m, s3.model_id(m), len(todo), len(mine), tin / 1e6, tout / 1e6, cost, p[0], p[1], minutes, WORKERS))
    print("\nEstimate for both teachers: about $%.2f, about %.0f min (they run side by side). Check the providers' "
          "current prices; the estimate uses step3_llm_audit.py's PRICE_PER_M." % (total_cost, total_min))


def merged(lab: str, chunks: List[Dict[str, Any]]) -> Dict[str, Tuple[float, str]]:
    """{column: (risk, category)} from one teacher's cached answers to a table's chunks (missing columns left out)."""
    got: Dict[str, Tuple[float, str]] = {}
    for ch in chunks:
        rec = load_chunk_answer(lab, ch)
        if rec:
            for c, e in (rec["parsed"].get("columns") or {}).items():
                v = s3.to_risk((e or {}).get("leak_risk"))
                if np.isfinite(v):
                    got[c] = (v, s3.norm_category((e or {}).get("category")))
    return got


def generated_check(lab: str, gen: List[Tuple[Dict[str, Any], Dict[str, Tuple[float, str]]]]) -> None:
    """GPT on the generated training tables against the generator's key, flag at risk >= 50."""
    rec, ff, answered, dec_hit, dec_n, trap_hit, trap_n = [], 0, 0, 0, 0, 0, 0
    by_type: Dict[str, List[int]] = {}
    agree_leak, n_leak, agree_fine, n_fine = 0, 0, 0, 0
    for c, r in gen:
        if not r:
            continue
        answered += 1
        types = c.get("leak_types") or {}
        leaks = {x for x, t in types.items() if t in KEY_LEAK_TYPES}
        skip = {x for x, t in types.items() if t not in KEY_LEAK_TYPES}   # silently overwritten: count neither way
        decoys, traps = set(c.get("decoy_columns") or []), set((c.get("trap_columns") or {}).keys())
        flagged = {x for x, (v, _) in r.items() if v >= 50}
        ff += len(flagged - leaks - skip)
        dec_hit += len(flagged & decoys)
        dec_n += len(decoys & set(r))
        trap_hit += len(flagged & traps)
        trap_n += len(traps & set(r))
        rated_leaks = [x for x in leaks if x in r]
        if rated_leaks:
            rec.append(len(flagged & leaks) / float(len(rated_leaks)))
        for x in rated_leaks:
            v = by_type.setdefault(types[x], [0, 0])
            v[0] += x in flagged
            v[1] += 1
        for x, (v, cat) in r.items():   # the rule t3 uses to take GPT's reason instead of a template
            if x in leaks:
                n_leak += 1
                agree_leak += v >= 50 and cat != "fine"
            else:
                n_fine += 1
                agree_fine += v < 50 and cat == "fine"
    out("%s on the generated training tables against the generator's key (flag at risk >= 50; the silently "
        "overwritten fields count neither way):" % lab)
    out(common.format_table(["teacher", "tables answered", "macro recall", "false flags per table", "decoys flagged",
                             "trap columns flagged"],
                            [[lab, "%d / %d" % (answered, len(gen)), "%.2f" % float(np.mean(rec)) if rec else "-",
                              "%.2f" % (ff / float(max(answered, 1))), "%d / %d" % (dec_hit, dec_n),
                              "%d / %d" % (trap_hit, trap_n)]]))
    if by_type:
        out("  recall by leak type: " + ", ".join("%s %d/%d" % (t, v[0], v[1]) for t, v in sorted(by_type.items())))
    out("  %s's reasons usable in training (it agrees with the key): %d of %d leak columns, %d of %d fine columns; the "
        "others get a template reason." % (lab, agree_leak, n_leak, agree_fine, n_fine))


def summary(tables: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]], teachers: List[str],
            stats: Dict[str, Dict[str, Any]]) -> None:
    out("Teachers of fine-tune run 4 -- summary (%s)%s" % (common.stamp(), " [MOCK]" if MOCK else ""))
    out("Tables: %d; prompts: %d; columns: %d" % (len(tables), sum(len(c) for _, _, c in tables),
                                                  sum(len(ch["columns"]) for _, _, c in tables for ch in c)))
    rows = []
    risks: Dict[str, Dict[str, Dict[str, Tuple[float, str]]]] = {}
    for m in teachers:
        lab = label(m)
        answered, cost, cols, n_chunks, n_cols = 0, 0.0, 0, 0, 0
        for fname, case, chunks in tables:
            if m not in teachers_for(fname):
                continue
            n_chunks += len(chunks)
            n_cols += sum(len(ch["columns"]) for ch in chunks)
            for ch in chunks:
                rec = load_chunk_answer(lab, ch)
                if rec:
                    answered += 1
                    cost += float(rec.get("cost") or 0.0)
            r = merged(lab, chunks)
            risks.setdefault(lab, {})[case["id"]] = r
            cols += len(r)
        st = stats.get(m, {})
        rows.append([lab, "%d / %d" % (answered, n_chunks), "%d / %d" % (cols, n_cols),
                     "%d asked, %d failed" % (st.get("done", 0) + st.get("failed", 0), st.get("failed", 0)),
                     "$%.2f" % cost, DISABLED.get(m, "")])
    out(common.format_table(["teacher", "prompts answered", "columns rated", "this run", "cost (all answers)",
                             "stopped because"], rows))
    labs = [label(m) for m in teachers]
    if len(labs) == 2:
        agree, diffs = 0, []
        for _, case, _ in tables:
            a, b = risks[labs[0]].get(case["id"], {}), risks[labs[1]].get(case["id"], {})
            for c in set(a) & set(b):
                agree += (a[c][0] >= 50) == (b[c][0] >= 50)
                diffs.append(abs(a[c][0] - b[c][0]))
        if diffs:
            out("Agreement: on %d columns both rated, they agree on flag / no flag at risk 50 for %.1f%%; mean "
                "difference %.1f points." % (len(diffs), 100.0 * agree / len(diffs), float(np.mean(diffs))))
    dev = [(f, c) for f, c, _ in tables if f in DEV_FILES]
    if dev:
        out("Sanity check on the development tables (documented leaks; flag at risk >= 50):")
        rows = []
        for lab in labs:
            for fname in DEV_FILES:
                cases = [c for f, c in dev if f == fname]
                if not cases:
                    continue
                rec, ff, answered = [], 0, 0
                for c in cases:
                    r = risks[lab].get(c["id"], {})
                    if not r:
                        continue
                    answered += 1
                    leaks, skip = set(c["leak_columns"]), set(c["probable_leak_columns"])
                    flagged = {k for k, v in r.items() if v[0] >= 50}
                    ff += len(flagged - leaks - skip)
                    if leaks:
                        rec.append(len(flagged & leaks) / float(len(leaks)))
                rows.append([lab, fname, "%d / %d" % (answered, len(cases)),
                             "%.2f" % float(np.mean(rec)) if rec else "-", ff])
        out(common.format_table(["teacher", "tables", "answered", "macro recall", "false flags"], rows))
    gen = [c for f, c, _ in tables if f == GEN_FILE]
    if gen:
        for m in teachers:
            if m in teachers_for(GEN_FILE):
                generated_check(label(m), [(c, risks[label(m)].get(c["id"], {})) for c in gen])
    with open(common.path(SUMMARY_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(LINES) + "\n")


# ============================================================ main
def main() -> None:
    setup()
    bad = [m for m in TEACHERS if m not in ("claude", "gpt")] + [m for m in REASON_TEACHERS if m not in TEACHERS]
    if bad:
        raise SystemExit("TEACHERS may only name 'claude' and 'gpt', and REASON_TEACHERS only teachers in TEACHERS "
                         "(got %s)." % bad)
    mode = "MOCK -- fake offline teachers" if MOCK else ("DRY RUN" if DRY_RUN else "LIVE")
    files = list(TRAIN_FILES) + [GEN_FILE] + ([TEST4_FILE] if TEST4_REFERENCE else [])
    print("Teachers of run 4 [%s]: %s; tables from %s (%s: %s only)"
          % (mode, ", ".join("%s (%s)" % (m, s3.model_id(m)) for m in TEACHERS), ", ".join(files), GEN_FILE,
             ", ".join(teachers_for(GEN_FILE)) or "nobody"))
    t0 = time.time()
    tables = load_tables(files)
    if not tables:
        raise SystemExit("No tables with data -- run t0_import.py, t1_get_data.py and t2a_make_generated.py first.")
    print("Built %d prompts for %d tables (%.0f s)." % (sum(len(c) for _, _, c in tables), len(tables), time.time() - t0))
    if DRY_RUN and not MOCK:
        estimate(tables, TEACHERS)
        print("\nNext: paste the two keys at the top, set DRY_RUN = False, press Run.")
        return
    if not MOCK:
        for m in TEACHERS:
            k = {"claude": ANTHROPIC_API_KEY, "gpt": OPENAI_API_KEY}[m].strip()
            if not k or k.startswith("PASTE_"):
                raise SystemExit("Paste your %s key at the top (%s), then press Run again."
                                 % ("Anthropic" if m == "claude" else "OpenAI",
                                    "ANTHROPIC_API_KEY" if m == "claude" else "OPENAI_API_KEY"))
    stats: Dict[str, Dict[str, Any]] = {}
    todo = {m: [ch for ch in chunks_for(m, tables) if load_chunk_answer(label(m), ch) is None] for m in TEACHERS}
    for m in TEACHERS:
        print("%s: %d prompts to ask (%d already answered)"
              % (label(m), len(todo[m]), len(chunks_for(m, tables)) - len(todo[m])))
    threads = []
    for m in TEACHERS:   # the two teachers run side by side, each with its own WORKERS
        th = threading.Thread(target=lambda m=m: stats.__setitem__(m, run_teacher(m, todo[m])))
        th.start()
        threads.append(th)
    for th in threads:
        th.join()
    print("")
    summary(tables, TEACHERS, stats)
    left = sum(1 for m in TEACHERS for ch in chunks_for(m, tables) if load_chunk_answer(label(m), ch) is None)
    print("\n-> %s." % SUMMARY_FILE)
    if left:
        print("%d prompt answers are still missing: press Run again (only those are asked). If the same ones keep "
              "failing, send Claude %s and %s." % (left, SUMMARY_FILE, LOG_FILE))
    else:
        print("Every prompt is answered by every teacher that rates it. Next: send Claude %s." % SUMMARY_FILE)


if __name__ == "__main__":
    main()
