# t4_make_test_prompts.py -- writes test_prompts.jsonl: the run 4 prompts (at most 10 rated columns each, the same
# prompts as run 3) of every test table -- the 42 generated tables (cases.json) and real test 4 (cases_test4.json) --
# for the RunPod notebook to answer with the untrained and the trained model. Python 3.9; press Run in PyCharm after
# t3_make_training.py. No calls.
#
# No training table (cases_distill*.json, cases_dev*.json, cases_gen*.json) is ever written here. Each line also
# carries its table's group and the answer key for its columns (leak columns, and the debatable ones that count neither
# way), only so the notebook can print a first preview; the official numbers come from t6_compare.py.
# Also writes test_manifest.json (the number of prompts and tables, and the file's sha256).

TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]   # must match t3_make_training.py
HOLDOUT_DOMAINS = ["lending", "hospital"]
TEST_FILE = "test_prompts.jsonl"
TEST_MANIFEST = "test_manifest.json"

# ============================================================ internals
import fnmatch
import hashlib
import json
import os
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

TEST4_FILE = "cases_test4.json"
TRAINING_PATTERNS = ["cases_distill*.json", "cases_dev*.json", "cases_gen*.json"]
GROUPS = ["training domains", "held-out domains", "trap tables", "real test 4"]


def group_of(case: Dict[str, Any]) -> str:
    if case.get("url") != "generated":
        return "real test 4"
    if case.get("trap_columns"):
        return "trap tables"
    if case.get("domain") in TRAIN_DOMAINS:
        return "training domains"
    if case.get("domain") in HOLDOUT_DOMAINS:
        return "held-out domains"
    return "other"


def main() -> None:
    if not os.path.exists(common.path(TEST4_FILE)):
        raise SystemExit("%s is missing: Claude sends it; then run t1_get_data.py." % TEST4_FILE)
    gen = [c for c in common.load_cases(quiet=True) if c.get("url") == "generated"]
    test4 = common.load_cases(quiet=True, file=TEST4_FILE)
    training_ids: Dict[str, str] = {}
    for fn in sorted(os.listdir(HERE)):
        if any(fnmatch.fnmatch(fn, pat) for pat in TRAINING_PATTERNS):
            for c in common.load_cases(quiet=True, file=fn):
                training_ids[c["id"]] = fn
    cases: List[Dict[str, Any]] = gen + test4
    clash = sorted(c["id"] for c in cases if c["id"] in training_ids)
    if clash:
        raise SystemExit("STOP: a training table is in the test set: %s"
                         % ", ".join("%s (%s)" % (cid, training_ids[cid]) for cid in clash[:10]))
    ids = [c["id"] for c in cases]
    if len(set(ids)) != len(ids):
        raise SystemExit("STOP: a table id appears twice among the test tables.")
    missing = [c["id"] for c in cases if not common.has_data(c["id"])]
    if missing:
        raise SystemExit("No data for %d table(s): %s -- run t0_import.py / t1_get_data.py first."
                         % (len(missing), ", ".join(missing)))
    split = []
    for c in test4:   # rows are only ever dropped or sampled: more rows than the file had means rows were split
        m = common.read_meta(c["id"])
        if isinstance(m.get("rows"), int) and isinstance(m.get("rows_in_file"), int) and m["rows"] > m["rows_in_file"]:
            split.append("%s (%d rows from a file of %d)" % (c["id"], m["rows"], m["rows_in_file"]))
    if split:
        raise SystemExit("STOP: real test 4 table(s) %s were prepared with rows split at a carriage return (run 3's "
                         "step1_get_data.py). Put run 4's step1_get_data.py and t1_get_data.py here, run "
                         "t1_get_data.py, then this again." % "; ".join(split))
    infos = {c["id"]: s3.chunk_info(c) for c in cases}
    for c in cases:   # the answer key must fit the table it scores (checked before anything is written)
        cols = set(infos[c["id"]]["columns"])
        absent = sorted(set((c.get("leak_columns") or []) + (c.get("probable_leak_columns") or [])) - cols)
        if absent or not cols:
            raise SystemExit("STOP: test table %s %s. Run t1_get_data.py again; tell Claude if this stays."
                             % (c["id"], "has no columns besides the target" if not cols else
                                "lists leak/debatable columns that are not in its data: %s" % ", ".join(absent)))
    other = [c["id"] for c in cases if group_of(c) == "other"]
    if other:
        raise SystemExit("STOP: generated test table(s) of no known domain: %s. Tell Claude." % ", ".join(other))
    tables: Dict[str, int] = {}
    chunks: Dict[str, int] = {}
    tmp = common.path(TEST_FILE + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        for c in cases:
            g = group_of(c)
            info = infos[c["id"]]
            leaks, skip = set(c.get("leak_columns") or []), set(c.get("probable_leak_columns") or [])
            for ch in s3.chunk_prompts(info):
                row = {"id": ch["chunk_id"], "table": c["id"], "group": g, "part": ch["part"], "parts": ch["parts"],
                       "system": s3.SYSTEM_PROMPT, "user": ch["user"], "columns": ch["columns"],
                       "leak_columns": [x for x in ch["columns"] if x in leaks],
                       "probable_leak_columns": [x for x in ch["columns"] if x in skip]}
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                chunks[g] = chunks.get(g, 0) + 1
            tables[g] = tables.get(g, 0) + 1
    os.replace(tmp, common.path(TEST_FILE))
    with open(common.path(TEST_FILE), "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()
    n_chunks, n_tables = sum(chunks.values()), sum(tables.values())
    common.write_json(common.path(TEST_MANIFEST), {"chunks": n_chunks, "tables": n_tables, "sha256": digest,
                                                   "by_group": {g: {"tables": tables.get(g, 0),
                                                                    "prompts": chunks.get(g, 0)} for g in GROUPS},
                                                   "created": common.stamp()})
    print(common.format_table(["group", "tables", "prompts"],
                              [[g, tables.get(g, 0), chunks.get(g, 0)] for g in GROUPS] +
                              [["all", n_tables, n_chunks]]))
    print("%d prompts for %d test tables -> %s (sha256 %s...)" % (n_chunks, n_tables, TEST_FILE, digest[:16]))
    if len(gen) != 42:
        print("  note: expected 42 generated test tables, found %d" % len(gen))
    print("Next: upload train.jsonl, val.jsonl, %s and train2_runpod_run4.ipynb to RunPod (GUIDE.md)." % TEST_FILE)


if __name__ == "__main__":
    main()
