# t5_import_gpu.py -- stores the answers the RunPod notebook wrote (answers_base_run4.jsonl and
# answers_trained_run4.jsonl, both downloaded into this folder), one file per prompt, so t6_compare.py scores them.
# Python 3.9; press Run in PyCharm. No calls, no keys. Needs test_prompts.jsonl (made by t4_make_test_prompts.py) and
# train_run4.json (the notebook's run record).
#
# Each prompt was answered 3 times (3 samples). Two labels per model:
#   answers_base_run4.jsonl     -> llm_cache/gpu4-qwen3.5-9b/chunks/            (untrained; the 3-sample mean)
#                                  llm_cache/gpu4-qwen3.5-9b-s1/chunks/         (untrained; the first sample only)
#   answers_trained_run4.jsonl  -> llm_cache/gpu4-leakaudit4-qwen3.5-9b/chunks/     (trained; the 3-sample mean)
#                                  llm_cache/gpu4-leakaudit4-qwen3.5-9b-s1/chunks/  (trained; the first sample only)
# A column's risk is the mean over the samples that rated it (the retry fills in columns no first-round sample rated);
# its category is the most common one, its reason the first. Each answer is read with step 3's own reader and stamped
# with the hash of the exact prompt it answers. A prompt with no readable sample is stored as unreadable: it counts as
# nothing flagged. Any NUL bytes in a file are removed first and reported.

FILES = {"answers_base_run4.jsonl": ("gpu4-qwen3.5-9b", "runpod/qwen3.5-9b (untrained, run 4 prompts)"),
         "answers_trained_run4.jsonl": ("gpu4-leakaudit4-qwen3.5-9b", "runpod/leakaudit4-qwen3.5-9b (trained, run 4)")}
FIRST_SAMPLE_SUFFIX = "-s1"
TEST_FILE = "test_prompts.jsonl"
RUN_FILE = "train_run4.json"   # the notebook's run record: holds the sha256 of the test_prompts.jsonl the pod answered

# ============================================================ internals
import hashlib
import json
import os
import shutil
import sys
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402


def read_lines(p: str) -> Tuple[List[Dict[str, Any]], int, int]:
    """The answer rows of a notebook file, its NUL byte count, and how many lines did not parse."""
    with open(p, "rb") as f:
        raw = f.read()
    nul = raw.count(b"\x00")
    rows, bad = [], 0
    # split on "\n" only: str.splitlines() also breaks at U+2028 / U+0085, which json.dumps leaves inside strings
    for line in raw.replace(b"\x00", b"").decode("utf-8", "replace").split("\n"):
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except ValueError:
            bad += 1
            continue
        if isinstance(r, dict) and r.get("id"):
            rows.append(r)
        else:
            bad += 1
    return rows, nul, bad


def sha256_of(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def texts_of(r: Dict[str, Any]) -> Tuple[List[str], List[str]]:
    """(first-round samples, retry samples) of one answer line (a run 3 style line with one text also works)."""
    texts = r.get("texts")
    if not isinstance(texts, list):
        texts = [r.get("text")] if r.get("text") is not None else []
    retry = r.get("texts_retry")
    if not isinstance(retry, list):
        retry = [r.get("text_retry")] if r.get("text_retry") else []
    return [str(t or "") for t in texts], [str(t or "") for t in retry]


def parse(text: str, columns: List[str]) -> Optional[Dict[str, Any]]:
    return s3.parse_answer(s3.strip_think(text or ""), columns)


def finite(v: Any) -> Optional[float]:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if np.isfinite(x) else None


def combine(first: List[Optional[Dict[str, Any]]], retry: List[Optional[Dict[str, Any]]], columns: List[str]
            ) -> Optional[Dict[str, Any]]:
    """{columns: {col: {leak_risk, category, reason}}, missing, unknown_names} from the parsed samples: a column's
    risk is the mean over the first-round samples that rated it, or, if none did, over the retry samples that did;
    the category is the most common one, the reason the first. None if no sample is readable."""
    readable = [p for p in first if p] + [p for p in retry if p]
    if not readable:
        return None
    entries: Dict[str, Dict[str, Any]] = {}
    for c in columns:
        rated = [p["entries"][c] for p in first if p and c in p["entries"]]
        if not rated:
            rated = [p["entries"][c] for p in retry if p and c in p["entries"]]
        if not rated:
            continue
        vals = [x for x in (finite(e.get("leak_risk")) for e in rated) if x is not None]
        cats: Dict[str, int] = {}
        for e in rated:
            cats[e.get("category") or ""] = cats.get(e.get("category") or "", 0) + 1
        best = max(cats.values())
        category = next(e.get("category") or "" for e in rated if cats[e.get("category") or ""] == best)
        entries[c] = {"leak_risk": round(float(np.mean(vals)), 2) if vals else None, "category": category,
                      "reason": next((e.get("reason") for e in rated if e.get("reason")), ""),
                      "samples": len(rated)}
    unknown: List[str] = []
    for p in readable:
        unknown += [u for u in p["unknown"] if u not in unknown]
    return {"columns": entries, "missing": [c for c in columns if c not in entries], "unknown_names": unknown}


def main() -> None:
    if not os.path.exists(common.path(TEST_FILE)):
        raise SystemExit("%s is missing: run t4_make_test_prompts.py first." % TEST_FILE)
    digest = sha256_of(common.path(TEST_FILE))
    run = common.load_json(common.path(RUN_FILE)) or {}
    pod = ((run.get("files") or {}).get(TEST_FILE)) if isinstance(run, dict) else None
    if pod and pod != digest:   # each answer is stamped with the hash of the prompt in today's file: it must be that file
        raise SystemExit("STOP: %s here (sha256 %s...) is not the file the pod answered (%s says %s...). Put back the "
                         "file you uploaded, or tell Claude." % (TEST_FILE, digest[:16], RUN_FILE, pod[:16]))
    if not pod:
        print("note: %s is not here, so it cannot be checked that %s is the file the pod answered -- download it too"
              % (RUN_FILE, TEST_FILE))
    with open(common.path(TEST_FILE), encoding="utf-8") as f:
        tests: Dict[str, Dict[str, Any]] = {r["id"]: r for r in (json.loads(x) for x in f.read().split("\n")
                                                                  if x.strip())}
    tables: Dict[str, List[str]] = {}
    for cid, t in tests.items():
        tables.setdefault(t["table"], []).append(cid)
    found_any = False
    for fn, (lab, model_id) in FILES.items():
        p = common.path(fn)
        if not os.path.exists(p):
            print("%s: not here yet -- download it from RunPod into this folder" % fn)
            continue
        rows, nul, bad = read_lines(p)
        if rows:
            found_any = True
        else:
            print("%s: holds no answers -- download it again from RunPod" % fn)
        if nul:
            print("%s: %d NUL bytes removed before reading (the answers themselves are intact)" % (fn, nul))
        if bad:
            print("%s: %d line(s) could not be read at all (left out)" % (fn, bad))
        rec_sha = (run.get("answer_files") or {}).get(fn) if isinstance(run, dict) else None
        if rec_sha and rec_sha != sha256_of(p) and not nul:
            print("note: %s is not the file %s recorded (sha256 differs) -- download both from the same pod" % (fn, RUN_FILE))
        session = run.get("train_session") if isinstance(run, dict) else None
        if "trained" in fn and session:
            other = [r.get("id") for r in rows if r.get("session") != session]
            if other:
                raise SystemExit("STOP: %d answer(s) in %s come from another training run than %s records (e.g. %s). "
                                 "Download both files from the same pod, or tell Claude." % (len(other), fn, RUN_FILE,
                                                                                             other[0]))
        labels = {lab: model_id + ", mean of the samples", lab + FIRST_SAMPLE_SUFFIX: model_id + ", first sample"}
        for lb in labels:
            old = common.path("llm_cache", lb, "chunks")
            if os.path.isdir(old):   # a fresh import: no stale answer from an earlier file may survive
                shutil.rmtree(old)
        st = {lb: {"stored": 0, "unreadable": [], "missing": 0} for lb in labels}
        unknown_ids, n_samples, n_readable, n_retry, k_seen = [], 0, 0, 0, set()
        for r in rows:
            t = tests.get(r.get("id"))
            if t is None:
                unknown_ids.append(str(r.get("id")))
                continue
            texts, retry = texts_of(r)
            k_seen.add(len(texts))
            first = [parse(x, t["columns"]) for x in texts]
            again = [parse(x, t["columns"]) for x in retry]
            n_samples += len(first)
            n_readable += sum(1 for x in first if x)
            n_retry += bool(retry)
            versions = {lab: combine(first, again, t["columns"]),
                        lab + FIRST_SAMPLE_SUFFIX: combine(first[:1], again[:1], t["columns"])}
            for lb, parsed in versions.items():
                mid = labels[lb]
                rec = {"case_id": t["table"], "chunk_id": t["id"], "model": lb, "model_id": mid,
                       "prompt_hash": common.text_hash(mid, t["system"], t["user"]), "timestamp": common.stamp(),
                       "prompt": t["user"], "raw": texts if lb == lab else texts[:1],
                       "raw_retry": (retry if lb == lab else retry[:1]) or None, "attempts": r.get("attempts"),
                       "usage": {"out": r.get("tokens")}, "cost": 0.0, "seconds": r.get("seconds"),
                       "session": r.get("session"), "source": "RunPod notebook (%s)" % fn,
                       "samples": [x["entries"] if x else None for x in (first if lb == lab else first[:1])],
                       "samples_retry": [x["entries"] if x else None for x in (again if lb == lab else again[:1])]}
                if parsed:
                    st[lb]["missing"] += len(parsed["missing"])
                    rec["parsed"] = parsed
                    st[lb]["stored"] += 1
                else:
                    rec["parsed"] = None
                    rec["unreadable"] = True
                    st[lb]["unreadable"].append(t["id"])
                common.write_json(common.path("llm_cache", lb, "chunks", t["id"] + ".json"), rec)
        have = {r.get("id") for r in rows if r.get("id") in tests}
        complete = sum(1 for ids in tables.values() if all(i in have for i in ids))
        for lb in labels:
            s = st[lb]
            print("%s -> llm_cache/%s/chunks/: %d of %d prompts read; %d unreadable%s; %d columns left unanswered"
                  % (fn, lb, s["stored"], len(tests), len(s["unreadable"]),
                     (" (%s)" % ", ".join(s["unreadable"][:6])) if s["unreadable"] else "", s["missing"]))
        print("  %d of %d tables have every prompt answered; samples per prompt: %s; %d of %d samples readable; %d "
              "prompts asked again" % (complete, len(tables), "/".join(str(k) for k in sorted(k_seen)) or "-",
                                       n_readable, n_samples, n_retry))
        if unknown_ids:
            print("  note: %d answer(s) are for prompts not in %s (left out): %s"
                  % (len(unknown_ids), TEST_FILE, ", ".join(unknown_ids[:10])))
    if found_any:
        print("Next: t6_compare.py")


if __name__ == "__main__":
    main()
