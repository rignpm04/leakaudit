# t2a_make_generated.py -- builds the generated TRAINING tables of run 4 and stores them like any other table
# (data/<id>.csv.gz + data/<id>.meta.json, exactly as the 42 generated test tables are stored), so GPT can rate them in
# t2_teachers.py: its reasons are used in the training answers, while the scores come from the generator's answer key.
# Python 3.9; press Run in PyCharm. No keys, no downloads, no calls. Running it again only builds what is missing.
#
# GEN_TABLES_PER_DOMAIN tables for each training domain (claims, orders, saas, shipments; the held-out domains lending
# and hospital are never used), drawn by run 2/3's plan: TRAP_SHARE of them are trap tables (legitimate columns built to
# look late), the others are tables 1-6 of a domain (1-2 clear names, 3-4 abbreviated, 5 cryptic, 6 clean).
# Output: data/trn4_<domain>_NNNN.* and cases_gen.json (each table's answer key).

TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]
HOLDOUT_DOMAINS = ["lending", "hospital"]
GEN_TABLES_PER_DOMAIN = 200   # 4 x 200 = 800 tables
TRAP_SHARE = 0.15             # share of trap tables
SEED = 20261022               # this run's plan (which tables are trap tables, which of tables 1-6 the others are)

# ============================================================ internals
import csv
import gzip
import hashlib
import io
import json
import os
import sys
import time
import zlib
from typing import Any, Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_generate as s1  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

OUT_FILE = "cases_gen.json"
OTHER_FILES = ["cases.json", "cases_dev.json", "cases_dev2.json", "cases_dev3.json", "cases_distill.json",
               "cases_distill2.json", "cases_test4.json"]
SAVE_EVERY = 50


def plan() -> List[Tuple[str, str, int, bool]]:
    """(id, domain, k, traps) of every table. Each table's draws depend only on SEED and its id, so a smaller
    GEN_TABLES_PER_DOMAIN gives the first tables of the full plan."""
    out = []
    for dom in TRAIN_DOMAINS:
        for i in range(GEN_TABLES_PER_DOMAIN):
            tid = "trn4_%s_%04d" % (dom, i + 1)
            r = np.random.RandomState((SEED * 1000003 + zlib.crc32(tid.encode("utf-8"))) % (2 ** 32))
            traps = bool(r.uniform() < TRAP_SHARE)
            k = 0 if traps else int(r.randint(1, 7))      # 1-2 clear, 3-4 abbreviated, 5 cryptic, 6 clean
            out.append((tid, dom, k, traps))
    return out


def csv_text(header: List[str], rows: List[List[str]]) -> str:
    """The table exactly as step 1's write_table stores it."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def csv_sha256(case_id: str) -> str:
    with gzip.open(common.data_file(case_id), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def prompts_in_memory(case: Dict[str, Any], text: str) -> List[str]:
    """The chunk prompts built from the CSV text in memory (step 3's rule: same summaries, same seed)."""
    df = pd.read_csv(io.StringIO(text), low_memory=False)
    cols = [c for c in df.columns if c != common.TARGET]
    rng = np.random.RandomState((s3.SEED * 1000003 + zlib.crc32(case["id"].encode("utf-8"))) % (2 ** 32))
    info = {"case": case, "id": case["id"], "task": case["task"], "columns": cols,
            "summaries": {c: common.column_summary(df[c], s3.N_EXAMPLES, rng) for c in cols}, "n_rows": len(df),
            "real_text": {k: case.get(k) or "" for k in s3.TEXT_KEYS}}
    return [ch["user"] for ch in s3.chunk_prompts(info)]


def save(cases: List[Dict[str, Any]]) -> None:
    tmp = common.path(OUT_FILE + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cases, f, indent=1, ensure_ascii=False)
    os.replace(tmp, common.path(OUT_FILE))


def remove_table(cid: str) -> None:
    for p in (common.data_file(cid), common.meta_file(cid)):
        if os.path.exists(p):
            os.remove(p)


def main() -> None:
    t0 = time.time()
    bad = [d for d in TRAIN_DOMAINS if d not in s1.DOMAINS] + [d for d in TRAIN_DOMAINS if d in HOLDOUT_DOMAINS]
    if bad:
        raise SystemExit("Fix TRAIN_DOMAINS / HOLDOUT_DOMAINS: %s" % bad)
    if not os.path.exists(common.path("cases.json")):
        raise SystemExit("cases.json is missing: run t0_import.py first.")
    test = [c for c in common.load_cases(quiet=True) if c.get("url") == "generated"]
    no_data = [c["id"] for c in test if not common.has_data(c["id"])]
    if no_data or not test:
        raise SystemExit("The generated test tables are not all here (%s) -- run t0_import.py first."
                         % (", ".join(no_data[:10]) or "none in cases.json"))
    test_hash = {csv_sha256(c["id"]): c["id"] for c in test}
    other_ids: Dict[str, str] = {}
    for fname in OTHER_FILES:
        if os.path.exists(common.path(fname)):
            for c in common.load_cases(quiet=True, file=fname):
                other_ids[c["id"]] = fname
    jobs = plan()
    ids = [j[0] for j in jobs]
    clash = [(tid, other_ids[tid]) for tid in ids if tid in other_ids]
    if clash or len(set(ids)) != len(ids):
        raise SystemExit("STOP: a generated training table id is already used: %s. Tell Claude."
                         % (", ".join("%s (%s)" % x for x in clash[:5]) or "twice in the plan"))
    old: Dict[str, Dict[str, Any]] = {}
    if os.path.exists(common.path(OUT_FILE)):
        for c in common.load_json(common.path(OUT_FILE)) or []:
            if isinstance(c, dict) and c.get("id"):
                old[c["id"]] = c
    dropped = [cid for cid in old if cid not in set(ids)]
    if dropped:
        print("note: %d table(s) of an earlier, larger plan are no longer in %s (their files stay in data/)"
              % (len(dropped), OUT_FILE))
    print("Generated training tables for run 4: %d per domain x %s = %d (held out: %s); trap share %.2f, seed %d."
          % (GEN_TABLES_PER_DOMAIN, ", ".join(TRAIN_DOMAINS), len(jobs), ", ".join(HOLDOUT_DOMAINS), TRAP_SHARE, SEED))
    cases: List[Dict[str, Any]] = []
    built, kept = 0, 0
    for n, (tid, dom, k, traps) in enumerate(jobs, 1):
        prev = old.get(tid)
        same_plan = bool(prev and prev.get("gen_plan") == {"k": k, "traps": traps, "seed": SEED,
                                                            "generator_seed": s1.SEED, "options": "v2"})
        if same_plan and common.has_data(tid) and csv_sha256(tid) == prev.get("csv_sha256"):
            if prev["csv_sha256"] in test_hash:
                raise SystemExit("STOP: %s reproduces generated test table %s. Tell Claude."
                                 % (tid, test_hash[prev["csv_sha256"]]))
            cases.append(prev)
            kept += 1
        else:
            case, rows, header = s1.build(tid, dom, k, traps, v2=True)
            digest = s1.write_table(case, header, rows)
            if digest in test_hash:
                remove_table(tid)
                save(cases)
                raise SystemExit("STOP: %s reproduces generated test table %s. Tell Claude." % (tid, test_hash[digest]))
            case["gen_plan"] = {"k": k, "traps": traps, "seed": SEED, "generator_seed": s1.SEED, "options": "v2"}
            case["csv_sha256"] = digest
            cases.append(case)
            built += 1
        if built and (n % SAVE_EVERY == 0 or n == len(jobs)):
            save(cases)
        if n % 100 == 0 or n == len(jobs):
            el = time.time() - t0
            print("  %d / %d tables (%d built now, %d already here), %.0f s, about %.0f s left"
                  % (n, len(jobs), built, kept, el, el / n * (len(jobs) - n)))
    save(cases)

    # the stored tables must give exactly the prompts t3 would build in memory (2 tables, each domain's first), with
    # the cases read back the way t2 and t3 read them
    checked = []
    for c in common.load_cases(quiet=True, file=OUT_FILE):
        if len(checked) == 2:
            break
        if c["domain"] in {x["domain"] for x in cases if x["id"] in checked}:
            continue
        gp = c["gen_plan"]
        case, rows, header = s1.build(c["id"], c["domain"], gp["k"], gp["traps"], v2=True)
        mine = prompts_in_memory(case, csv_text(header, rows))
        theirs = [ch["user"] for ch in s3.chunk_prompts(s3.chunk_info(c))]
        if mine != theirs:
            raise SystemExit("STOP: the prompts built from data/ for %s differ from those built in memory. Tell Claude."
                             % c["id"])
        checked.append(c["id"])
    print("Same-prompt check: ok (%s: the prompts built from data/ equal those built in memory)" % ", ".join(checked))

    rows_d = []
    for dom in TRAIN_DOMAINS:
        cs = [c for c in cases if c["domain"] == dom]
        rows_d.append([dom, len(cs), sum(1 for c in cs if c.get("trap_columns")),
                       sum(1 for c in cs if c["kind"] == "clean"), sum(len(c["leak_columns"]) for c in cs),
                       sum(len(c.get("decoy_columns") or []) for c in cs),
                       sum(len(c.get("trap_columns") or {}) for c in cs)])
    rows_d.append(["all"] + [sum(r[i] for r in rows_d) for i in range(1, 7)])
    print(common.format_table(["domain", "tables", "trap tables", "clean", "leak columns", "decoys", "trap columns"],
                              rows_d))
    styles: Dict[str, int] = {}
    types: Dict[str, int] = {}
    for c in cases:
        styles[c["naming_style"]] = styles.get(c["naming_style"], 0) + 1
        for t in (c.get("leak_types") or {}).values():
            types[t] = types.get(t, 0) + 1
    print("Naming style: " + ", ".join("%s %d" % kv for kv in sorted(styles.items())))
    print("Leak columns by type: " + ", ".join("%s %d" % kv for kv in sorted(types.items())) +
          " (overwrite_silent is trained as fine: no method can see it)")
    print("%d tables -> data/ and %s (%d built now, %d already here); none reproduces a generated test table. %.0f s."
          % (len(cases), OUT_FILE, built, kept, time.time() - t0))
    print("Next: t2_teachers.py (DRY_RUN = True first).")


if __name__ == "__main__":
    main()
