# step5_data_checks.py -- the auditor's second half: label-free data checks that confirm or reject the LLM's timing
# claims. Local, no keys; press Run in PyCharm after step 2 (D3 reads its scores). Python 3.9.
#
# For every table in cases.json and every column except the target and the moment column:
#   D1 filled mostly when one outcome happened. Needs >= D1_MIN_MISSING missing and >= D1_MIN_FILLED filled rows.
#      Binary: purity = the larger class share among filled rows; fires if purity >= D1_PURITY and purity minus that
#      class's base rate >= D1_LIFT. Regression: fires if |point-biserial r| of "filled" with y >= D1_RPB.
#   D2 date after the moment (date columns): share_after = P(column > moment) where both are filled; fires if
#      >= D2_AFTER. share_before >= D2_BEFORE sets the contradiction flag (the data say the value is known in time).
#      Dates without a time of day are compared by day.
#   D3 built from the target. Three rules:
#      single column (decisive): binary, the column check's out-of-fold score (step 2) >= D3_SCORE; regression, the
#        single-column out-of-fold R^2 (step 2) >= D3_R2_SINGLE.
#      linear fit (decisive; regression): a greedy forward linear fit of y on up to D3_MAX_COLUMNS numeric columns
#        reaches R^2 >= D3_R2_COMBO. Flags the fit's members whose own correlation with y, max(|Pearson r|, |Spearman
#        rho|), is >= D3_FIT_MIN_R; weaker members are helpers and are not flagged.
#      date pair (confirming only; regression): the difference of two date columns in hours has |r| >= D3_PAIR_CORR
#        with y. Flags the member(s) D2 puts after the moment (both when the table has no moment column).
#      d3_fired = any of the three; d3_decisive = the single-column or linear-fit rule.
#   D4 repeated id that shares outcomes (category and text columns only; numbers are measurements, not ids): needs
#      D4_MIN_UNIQUE <= distinct values <= D4_MAX_UNIQUE_SHARE x filled rows and >= D4_MIN_GROUPED of filled rows in
#      groups of 2+. Leave-one-out group mean of y: fires if AUC >= D4_AUC (binary) or r >= D4_CORR (regression).
#   D5 grows with time since the moment (numeric columns): Spearman |rho| with exposure = extract_date - moment (days),
#      among negatives for binary tasks, over all rows for regression, n >= D5_MIN_N; fires if |rho| >= D5_RHO.
# D2 and D5 need the case's moment_column; cases without one (the quick test's) skip them. A missing extract_date is
# taken as the latest date in the table (it only shifts the exposure, which leaves Spearman's rho unchanged).
# Output: scores_checks.csv -- one row per table and column: the evidence of each check, a fired flag per check,
# d3_decisive, the contradiction flag, 'decisive' (D1 purity >= DECISIVE_D1_PURITY, or d3_decisive: the evidence step 6
# accepts without the LLM; D2 and the D3 date pair are never decisive) and a short reason. Step 6 combines it with the
# LLM's leak risk.

import os
import sys
import warnings
from typing import Any, Dict, List, Optional, Tuple

# ============================================================ settings (fixed in advance)
D1_MIN_MISSING = 0.20
D1_MIN_FILLED = 20
D1_PURITY = 0.90
D1_LIFT = 0.30
D1_RPB = 0.50
D2_AFTER = 0.80
D2_BEFORE = 0.95
D2_MIN_ROWS = 20
D3_SCORE = 0.995
D3_R2_SINGLE = 0.98
D3_R2_COMBO = 0.995
D3_MAX_COLUMNS = 4
D3_PAIR_CORR = 0.98
D3_FIT_MIN_R = 0.30           # linear-fit members whose max(|Pearson r|, |Spearman rho|) with y is lower are helpers
D4_MIN_UNIQUE = 20
D4_MAX_UNIQUE_SHARE = 0.9
D4_MIN_GROUPED = 0.30
D4_AUC = 0.65
D4_CORR = 0.30
D5_RHO = 0.30
D5_MIN_N = 50
DECISIVE_D1_PURITY = 0.95     # for the 'decisive' column; as DECISIVE_PURITY in step 6
MAX_ROWS = 20000              # rows used per table (random sample, positives kept at their share), as in step 2
SEED = 7

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy.stats import spearmanr  # noqa: E402
from sklearn.metrics import roc_auc_score  # noqa: E402

CC_FILE = "scores_column_check.csv"
OUT_FILE = "scores_checks.csv"
FIELDS = ["case_id", "column", "type", "task", "n_rows", "missing_share", "n_unique",
          "d1_purity", "d1_class", "d1_base", "d1_rpb", "d1_fired",
          "d2_share_after", "d2_share_before", "d2_n", "d2_fired", "contradiction",
          "d3_score", "d3_r2", "d3_combo_r2", "d3_combo_columns", "d3_fit_r", "d3_fit_rho",
          "d3_pair_with", "d3_pair_corr", "d3_fired", "d3_decisive",
          "d4_grouped_share", "d4_score", "d4_fired",
          "d5_rho", "d5_n", "d5_fired",
          "any_fired", "decisive", "reason"]


def finite(x: Any) -> bool:
    try:
        return x is not None and bool(np.isfinite(float(x)))
    except (TypeError, ValueError):
        return False


def has_time(dt: pd.Series) -> bool:
    d = dt.dropna()
    return bool(len(d)) and bool(((d.dt.hour != 0) | (d.dt.minute != 0) | (d.dt.second != 0)).any())


def corr(a: np.ndarray, b: np.ndarray) -> float:
    if len(a) < 3 or np.std(a) == 0 or np.std(b) == 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def own_corr(v: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    """(Pearson r, Spearman rho) of a column with y, on the rows where both are finite."""
    m = np.isfinite(v) & np.isfinite(y)
    if m.sum() < 3 or np.std(v[m]) == 0 or np.std(y[m]) == 0:
        return float("nan"), float("nan")
    return corr(v[m], y[m]), float(spearmanr(v[m], y[m])[0])


def r2_fit(cols: List[np.ndarray], y: np.ndarray) -> float:
    """In-sample R^2 of y on the columns (with an intercept)."""
    a = np.column_stack([np.ones(len(y))] + cols)
    coef = np.linalg.lstsq(a, y, rcond=None)[0]
    sst = float(np.sum((y - y.mean()) ** 2))
    return 0.0 if sst <= 0 else 1.0 - float(np.sum((y - a @ coef) ** 2)) / sst


def greedy_r2(numeric: Dict[str, np.ndarray], y: np.ndarray) -> Tuple[List[str], float]:
    """Greedy forward selection of up to D3_MAX_COLUMNS columns; stops once R^2 reaches D3_R2_COMBO."""
    chosen: List[str] = []
    best_r2 = 0.0
    min_rows = max(50, int(0.1 * len(y)))
    for _ in range(D3_MAX_COLUMNS):
        best = None
        for c, v in numeric.items():
            if c in chosen:
                continue
            mask = np.isfinite(y) & np.isfinite(v)
            for k in chosen:
                mask &= np.isfinite(numeric[k])
            if int(mask.sum()) < min_rows:
                continue
            r2 = r2_fit([numeric[k][mask] for k in chosen + [c]], y[mask])
            if best is None or r2 > best[1]:
                best = (c, r2)
        if best is None:
            break
        chosen.append(best[0])
        best_r2 = best[1]
        if best_r2 >= D3_R2_COMBO:
            break
    return chosen, best_r2


def loo_group_score(codes: pd.Series, y: np.ndarray, binary: bool) -> Tuple[float, float, int]:
    """(share of filled rows in groups of 2+, leave-one-out group-mean score, distinct values)."""
    filled = codes.notna().to_numpy()
    keys = codes[filled].astype(str).to_numpy()
    yy = y[filled]
    k_idx, uniq = pd.factorize(keys)
    n_g = np.bincount(k_idx)
    s_g = np.bincount(k_idx, weights=yy)
    size = n_g[k_idx]
    grouped = size >= 2
    share = float(grouped.mean()) if len(grouped) else 0.0
    if grouped.sum() < 20:
        return share, float("nan"), len(uniq)
    loo = (s_g[k_idx][grouped] - yy[grouped]) / (size[grouped] - 1)
    yg = yy[grouped]
    if binary:
        score = float(roc_auc_score(yg, loo)) if 0 < yg.sum() < len(yg) else float("nan")
    else:
        score = corr(loo, yg)
    return share, score, len(uniq)


def check_table(case: Dict[str, Any], cc: Optional[pd.DataFrame]) -> List[Dict[str, Any]]:
    df = common.read_data(case["id"])
    if common.TARGET not in df.columns:
        raise ValueError("data/%s.csv.gz has no 'target' column -- run step 1 again" % case["id"])
    binary = case["task"] == "binary"
    df = df[df[common.TARGET].notna()]
    if len(df) > MAX_ROWS:
        df = df.loc[common.sample_index(df[common.TARGET], MAX_ROWS, SEED, stratify=binary)]
    df = df.reset_index(drop=True)
    y = df[common.TARGET].to_numpy(dtype=float)
    n = len(df)

    # column types, the moment and the exposure
    types: Dict[str, str] = {}
    values: Dict[str, Optional[pd.Series]] = {}
    for c in df.columns:
        if c != common.TARGET:
            types[c], values[c] = common.analyze_column(df[c])
    mcol = case.get("moment_column")
    moment: Optional[pd.Series] = None
    notes = []
    if mcol:
        if mcol in types and types[mcol] == "date":
            moment = values[mcol]
        else:
            notes.append("moment_column %r is not a date column of this table -- D2 and D5 skipped" % mcol)
    dates = [c for c in types if types[c] == "date"]
    exposure = None
    if moment is not None:
        ext = pd.to_datetime(case.get("extract_date"), errors="coerce") if case.get("extract_date") else pd.NaT
        if pd.isna(ext):
            ext = max(values[c].max() for c in dates)
        exposure = ((ext - moment) / pd.Timedelta(days=1)).to_numpy(dtype=float)

    scores = {}
    if cc is not None:
        sub = cc[cc["case_id"] == case["id"]]
        scores = {c: (s, r) for c, s, r in zip(sub["column"], sub["score"], sub["score_r2"])}

    cols = [c for c in types if c != mcol]
    out: Dict[str, Dict[str, Any]] = {}
    for c in cols:
        s = df[c]
        filled = s.notna().to_numpy()
        row: Dict[str, Any] = {k: "" for k in FIELDS}
        row.update(case_id=case["id"], column=c, type=types[c], task=case["task"], n_rows=n,
                   missing_share=round(1.0 - float(filled.mean()), 4), n_unique=int(s.nunique(dropna=True)),
                   d1_fired=0, d2_fired=0, contradiction=0, d3_fired=0, d3_decisive=0, d4_fired=0, d5_fired=0)
        why: List[str] = []

        # D1: filled mostly when one outcome happened
        n_filled = int(filled.sum())
        if 1.0 - filled.mean() >= D1_MIN_MISSING and n_filled >= D1_MIN_FILLED:
            if binary:
                p1 = float(y[filled].mean())
                cls = 1 if p1 >= 0.5 else 0
                purity = max(p1, 1.0 - p1)
                base = float((y == cls).mean())
                row.update(d1_purity=round(purity, 4), d1_class=cls, d1_base=round(base, 4))
                if purity >= D1_PURITY and purity - base >= D1_LIFT:
                    row["d1_fired"] = 1
                    why.append("D1: filled in %.0f%% of rows, %.0f%% of them y=%d (base %.0f%%)"
                               % (100 * filled.mean(), 100 * purity, cls, 100 * base))
            else:
                rpb = corr(filled.astype(float), y)
                row["d1_rpb"] = round(rpb, 4) if finite(rpb) else ""
                if finite(rpb) and abs(rpb) >= D1_RPB:
                    row["d1_fired"] = 1
                    why.append("D1: whether it is filled correlates r=%.2f with y" % rpb)

        # D2: date after the moment
        if types[c] == "date" and moment is not None:
            a, b = values[c], moment
            if not (has_time(a) and has_time(b)):
                a, b = a.dt.floor("D"), b.dt.floor("D")
            both = (a.notna() & b.notna()).to_numpy()
            if both.sum() >= D2_MIN_ROWS:
                after = float((a[both] > b[both]).mean())
                before = float((a[both] < b[both]).mean())
                row.update(d2_share_after=round(after, 4), d2_share_before=round(before, 4), d2_n=int(both.sum()))
                if after >= D2_AFTER:
                    row["d2_fired"] = 1
                    why.append("D2: after the moment in %.0f%% of rows" % (100 * after))
                if before >= D2_BEFORE:
                    row["contradiction"] = 1
                    why.append("contradiction: before the moment in %.0f%% of rows" % (100 * before))

        # D3 (single-column rule, decisive): built from the target
        sc = scores.get(c)
        if sc is not None:
            if binary and finite(sc[0]):
                row["d3_score"] = round(float(sc[0]), 4)
                if float(sc[0]) >= D3_SCORE:
                    row.update(d3_fired=1, d3_decisive=1)
                    why.append("D3: the column alone predicts y (score %.3f)" % float(sc[0]))
            elif not binary and finite(sc[1]):
                row["d3_r2"] = round(float(sc[1]), 4)
                if float(sc[1]) >= D3_R2_SINGLE:
                    row.update(d3_fired=1, d3_decisive=1)
                    why.append("D3: the column alone explains y (R^2 %.3f)" % float(sc[1]))

        # D4: repeated id that shares outcomes
        if types[c] in ("category", "text") and n_filled:
            n_uniq = int(s.nunique(dropna=True))
            if D4_MIN_UNIQUE <= n_uniq <= D4_MAX_UNIQUE_SHARE * n_filled:
                share, score, _ = loo_group_score(s, y, binary)
                row["d4_grouped_share"] = round(share, 4)
                if share >= D4_MIN_GROUPED and finite(score):
                    row["d4_score"] = round(score, 4)
                    if score >= (D4_AUC if binary else D4_CORR):
                        row["d4_fired"] = 1
                        why.append("D4: rows sharing a value share outcomes (leave-one-out %s %.2f)"
                                   % ("AUC" if binary else "r", score))

        # D5: grows with time since the moment
        if types[c] == "numeric" and exposure is not None:
            v = values[c].to_numpy(dtype=float)
            mask = np.isfinite(v) & np.isfinite(exposure)
            if binary:
                mask &= y == 0
            if mask.sum() >= D5_MIN_N and np.std(v[mask]) > 0:
                rho = float(spearmanr(v[mask], exposure[mask])[0])
                row.update(d5_rho=round(rho, 4) if finite(rho) else "", d5_n=int(mask.sum()))
                if finite(rho) and abs(rho) >= D5_RHO:
                    row["d5_fired"] = 1
                    why.append("D5: moves with time since the moment (Spearman %.2f%s)"
                               % (rho, ", negatives" if binary else ""))
        row["_why"] = why
        out[c] = row

    # D3 (multi-column rules, regression only): the linear fit (decisive) and the date pair (confirming only)
    if not binary:
        numeric = {c: values[c].to_numpy(dtype=float) for c in cols if types[c] == "numeric"}
        chosen, r2 = greedy_r2(numeric, y)
        if chosen and r2 >= D3_R2_COMBO:
            for c in chosen:
                pr, rho = own_corr(numeric[c], y)
                strength = max(abs(pr) if finite(pr) else 0.0, abs(rho) if finite(rho) else 0.0)
                out[c].update(d3_combo_r2=round(r2, 5), d3_combo_columns="+".join(chosen),
                              d3_fit_r=round(pr, 4) if finite(pr) else "",
                              d3_fit_rho=round(rho, 4) if finite(rho) else "")
                if strength >= D3_FIT_MIN_R:
                    out[c].update(d3_fired=1, d3_decisive=1)
                    out[c]["_why"].append("D3: a linear fit on %s reproduces y (R^2 %.4f; this column's own r %.2f, "
                                          "rho %.2f)" % (" + ".join(chosen), r2, pr, rho))
        pair_cols = dates + ([mcol] if moment is not None and mcol not in dates else [])
        for i in range(len(pair_cols)):
            for j in range(i + 1, len(pair_cols)):
                ca, cb = pair_cols[i], pair_cols[j]
                diff = ((values[ca] - values[cb]) / pd.Timedelta(hours=1)).to_numpy(dtype=float)
                mask = np.isfinite(diff) & np.isfinite(y)
                if mask.sum() < 50:
                    continue
                rr = corr(diff[mask], y[mask])
                if not finite(rr) or abs(rr) < D3_PAIR_CORR:
                    continue
                for c, other in ((ca, cb), (cb, ca)):
                    if c == mcol or c not in out:
                        continue
                    if moment is None or out[c]["d2_fired"]:
                        out[c].update(d3_pair_with=other, d3_pair_corr=round(rr, 4), d3_fired=1)
                        out[c]["_why"].append("D3 date pair (confirms only): %s minus %s (hours) tracks y (r %.3f)"
                                              % (ca, cb, rr))

    rows = []
    for c in cols:
        row = out[c]
        fired = [k for k in ("d1", "d2", "d3", "d4", "d5") if row[k + "_fired"]]
        row["any_fired"] = int(bool(fired))
        d1_decisive = row["d1_fired"] and finite(row["d1_purity"]) and float(row["d1_purity"]) >= DECISIVE_D1_PURITY
        row["decisive"] = int(bool(d1_decisive or row["d3_decisive"]))
        row["reason"] = "; ".join(row.pop("_why")) or "no check fired"
        rows.append(row)
    for note in notes:
        print("  note: %s: %s" % (case["id"], note))
    return rows


def main() -> None:
    warnings.filterwarnings("ignore")
    print("Step 5 -- label-free data checks D1-D5 (no LLM, no keys)")
    cases = common.load_cases(quiet=True)
    cc = None
    if os.path.exists(common.path(CC_FILE)):
        cc = pd.read_csv(common.path(CC_FILE))
        cc["score"] = pd.to_numeric(cc["score"], errors="coerce")
        cc["score_r2"] = pd.to_numeric(cc.get("score_r2"), errors="coerce") if "score_r2" in cc.columns else np.nan
    else:
        print("  note: no %s -- D3's score-based parts are skipped (run step 2 first)" % CC_FILE)
    all_rows: List[Dict[str, Any]] = []
    for case in cases:
        if not common.has_data(case["id"]):
            print("  %s: no data -- skipped (run step 1)" % case["id"])
            continue
        if cc is not None and case["id"] not in set(cc["case_id"]):
            print("  note: %s has no step 2 scores -- D3's score-based parts skipped for it" % case["id"])
        try:
            rows = check_table(case, cc)
        except Exception as e:  # one table failing must not stop the run
            print("  %s: FAILED %s: %s" % (case["id"], e.__class__.__name__, e))
            continue
        all_rows += rows
        counts = {k: sum(int(r[k + "_fired"]) for r in rows) for k in ("d1", "d2", "d3", "d4", "d5")}
        print("  %-16s %3d columns  fired: D1 %d, D2 %d, D3 %d, D4 %d, D5 %d; decisive %d; contradictions %d%s"
              % (case["id"], len(rows), counts["d1"], counts["d2"], counts["d3"], counts["d4"], counts["d5"],
                 sum(int(r["decisive"]) for r in rows), sum(int(r["contradiction"]) for r in rows),
                 "" if case.get("moment_column") else "  (no moment_column: D2, D5 skipped)"))
    if not all_rows:
        print("\nNothing checked -- run step 1 (and step 2) first.")
        return
    pd.DataFrame(all_rows, columns=FIELDS).to_csv(common.path(OUT_FILE), index=False)
    n_fired = sum(int(r["any_fired"]) for r in all_rows)
    print("\n%d columns checked, %d with at least one check fired -> %s. Next: step6_auditor_eval.py"
          % (len(all_rows), n_fired, OUT_FILE))


if __name__ == "__main__":
    main()
