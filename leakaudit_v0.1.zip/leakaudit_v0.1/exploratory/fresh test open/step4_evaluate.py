# step4_evaluate.py -- step 4 of the fresh leakage test: score the column check (step 2) and the LLM audit (step 3)
# against the leaks planted by step1_generate.py and apply the pre-set rules. Python 3.9; press Run in PyCharm.
#
# Truth per column: a planted leak column (cases.json, leak_columns) = 1, every other column = 0. Thresholds are tuned
# for the best macro recall while the total number of false flags (over all tables, leak and clean) stays within
# BUDGET_FF_PER_DATASET x number of tables; ties go to fewer false flags.
# Methods: column check at a fixed 0.80 (H2O-like) and 0.925 (about DataRobot's normalized Gini 0.85), column check
# tuned, each LLM tuned, and combined for each LLM. "Column check strongest" tunes separate thresholds for binary and
# regression tables and tries every regression score step 2 wrote (Gini, concordance, R^2); it is the baseline for the
# rules, so the LLM has to beat the best version of the vendor check. Combined = flag if that column check flags the
# column (its two thresholds and score re-tuned) OR leak_risk >= t2; with t2 off it is the baseline, so its gain over
# the baseline is what the LLM adds.
# Breakdowns: by naming style (clear / abbreviated / cryptic), by leak type, by domain, and the share of decoy columns
# (legitimate columns whose names sound late) and of strong legitimate predictors that each method flags.
# Rules, fixed in advance (kind 'leak' tables, "real" condition; the best combined method is the one with the highest
# macro recall over all models):
#   K1  KILL if the baseline column check reaches a macro recall of K1_RECALL or more
#   K2  KILL if the best combined method adds less than K2_GAIN over the baseline
#   K4  KILL if, on the abbreviated-name tables, the best combined method adds less than K4_GAIN over the baseline on
#       those same tables
#   GO  if K1, K2 and K4 all pass; the model of the best combined method is named. Cryptic names: information only.
# Trap tables (step 1's traps_<domain>, cases with trap_columns) are left out of everything above and of the verdict;
# a separate section shows how the tuned methods do on them. A local model (step 3's "local") is one more model.
# Recognition: no model can know the generated tables, so a model "recognizes" one when its probe (step 3, probes.csv)
# names a public dataset with confidence RECOG_CONF or more (answers such as "unknown" or "synthetic" do not count).
# A warning is printed if a model recognizes more than RECOG_MAX of the tables. (For a case that is not generated,
# recognition means a guess names the case, its id or an alias, as in the quick test.)
# Output: results.txt (also printed).

import os
import sys
from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

# ============================================================ settings (edit here)
BUDGET_FF_PER_DATASET = 1.0   # allowed false flags = this x number of tables (leak and clean)
K1_RECALL = 0.90              # K1: KILL if the baseline column check alone reaches this macro recall
THIN_GAP = 0.75               # warn if the baseline is between this and K1_RECALL
K2_GAIN = 0.15                # K2: KILL if the best combined method adds less macro recall than this
K4_GAIN = 0.10                # K4: KILL if it adds less than this on the abbreviated-name tables
RECOG_MAX = 0.15              # warn if a model recognizes more than this share of the generated tables
RECOG_CONF = 50               # a probe guess naming a public dataset with this confidence (0-100) counts as recognition
H2O_LIKE = 0.80               # fixed column-check thresholds (AUC / concordance)
DATAROBOT_LIKE = 0.925

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

CC_FILE = "scores_column_check.csv"
LLM_FILE = "scores_llm.csv"
PROBE_FILE = "probes.csv"
OUT_FILE = "results.txt"
T1_GRID: List[Optional[float]] = [None] + [round(1.0 - 0.01 * i, 2) for i in range(46)]   # off, 1.00 ... 0.55
T2_GRID: List[Optional[float]] = [None] + [float(x) for x in range(100, -1, -5)]          # off, 100 ... 0
R2_GRID: List[Optional[float]] = [None] + [round(1.0 - 0.02 * i, 2) for i in range(51)]  # off, 1.00 ... 0.00
REG_METRICS = ["gini", "concordance", "r2"]
COND_ORDER = ["real", "reworded", "scrambled", "disguised"]
STYLE_ORDER = ["clear", "abbreviated", "cryptic"]
TYPE_ORDER = ["outcome_status", "post_event_date", "post_aggregate", "snapshot_state", "overwrite_silent",
              "outcome_only_sparse", "target_derived", "identifier"]
BUCKETS = [("< 0.70", -np.inf, 0.70), ("0.70 - 0.85", 0.70, 0.85), (">= 0.85", 0.85, np.inf)]
NO_DATASET_WORDS = {"unknown", "none", "null", "synthetic", "generated", "simulated", "fictional", "fictitious",
                    "artificial", "proprietary", "internal", "custom", "hypothetical", "unidentified", "unclear"}


def read_scores(name: str) -> Optional[pd.DataFrame]:
    p = common.path(name)
    if not os.path.exists(p):
        return None
    return pd.read_csv(p, dtype=str, keep_default_na=False)


def nz(x: float) -> float:
    return 0.0 if x is None or not np.isfinite(x) else float(x)


def fmt_t(t: Optional[float], llm: bool = False) -> str:
    if t is None:
        return "off"
    if llm:
        return "%d" % t
    s = "%.3f" % t
    return s[:-1] if s.endswith("0") else s   # 0.80, 0.925, 1.00


def fmt_r(x: float) -> str:
    return "n/a" if x is None or not np.isfinite(x) else "%.2f" % x


def fmt_g(x: float) -> str:
    return "n/a" if x is None or not np.isfinite(x) else "%+.2f" % x


def short(parts: List[str], width: int = 90) -> str:
    """The parts joined with '; ', stopping before the part that would pass the width."""
    text = ""
    for p in parts:
        longer = p if not text else text + "; " + p
        if len(longer) > width:
            return text + "; ..." if text else p[:width]
        text = longer
    return text


def is_generated(case: Dict[str, Any]) -> bool:
    return str(case.get("url") or "").strip().lower() == "generated"


def is_trap(case: Dict[str, Any]) -> bool:
    """A trap table (step 1's traps_<domain>): evaluated separately, never part of the verdict."""
    return bool(case.get("trap_columns"))


def names_a_dataset(guess: Any) -> bool:
    """A guess that names some dataset (not "unknown", "synthetic data", "none", "no public dataset" ...)."""
    g = str(guess or "").strip().lower()
    if not g or g.startswith(("no ", "not ")):
        return False
    return not (set(common.word_tokens(g)) & NO_DATASET_WORDS)


def to_conf(v: Any) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def probe_hit(r: Any, case: Dict[str, Any]) -> bool:
    """Does this probe answer recognize the case? Generated table: a guess names a public dataset with confidence
    RECOG_CONF or more. Other case: a guess names the case, its id or an alias."""
    for k in (1, 2, 3):
        g = r.get("guess%d" % k, "")
        if is_generated(case):
            conf = to_conf(r.get("conf%d" % k, ""))
            if names_a_dataset(g) and np.isfinite(conf) and conf >= RECOG_CONF:
                return True
        elif common.guess_matches(g, case):
            return True
    return False


def audit_claim(guess: Any, case: Dict[str, Any]) -> bool:
    """The audit's dataset_guess: for a generated table any named dataset is a (wrong) claim of recognition."""
    return names_a_dataset(guess) if is_generated(case) else common.guess_matches(guess, case)


class Scorer:
    """Flags -> macro / micro recall over leak tables and false flags over all tables."""

    def __init__(self, df: pd.DataFrame, datasets: List[str], by_id: Dict[str, Dict[str, Any]], budget: float):
        self.truth = df["is_leak"].to_numpy(dtype=bool)
        self.score = np.nan_to_num(df["score"].to_numpy(dtype=float), nan=-1.0)
        self.ds = df["case_id"].map({d: i for i, d in enumerate(datasets)}).to_numpy(dtype=int)
        self.n_ds = len(datasets)
        self.leak_total = np.bincount(self.ds, weights=self.truth.astype(float), minlength=self.n_ds)
        kind_leak = np.array([by_id[d]["kind"] == "leak" for d in datasets], dtype=bool)
        self.recall_ds = kind_leak & (self.leak_total > 0)
        self.in_recall = self.recall_ds[self.ds]
        self.budget = budget
        # macro recall and false flags as dot products with a 0/1 flag vector (for the fast combined search)
        n_rec = max(1, int(self.recall_ds.sum()))
        self.w = np.where(self.truth & self.in_recall, 1.0 / np.maximum(self.leak_total[self.ds], 1.0), 0.0) / n_rec
        self.nt = (~self.truth).astype(float)

    def evaluate(self, flags: np.ndarray) -> Dict[str, Any]:
        caught = np.bincount(self.ds, weights=(flags & self.truth).astype(float), minlength=self.n_ds)
        ff = np.bincount(self.ds, weights=(flags & ~self.truth).astype(float), minlength=self.n_ds)
        if self.recall_ds.any():
            macro = float(np.mean(caught[self.recall_ds] / self.leak_total[self.recall_ds]))
            micro = float(caught[self.recall_ds].sum() / self.leak_total[self.recall_ds].sum())
        else:
            macro = micro = float("nan")
        n_flags = int(flags.sum())
        precision = float((flags & self.truth).sum()) / n_flags if n_flags else float("nan")
        return {"macro": macro, "micro": micro, "ff": int(round(ff.sum())), "ff_ds": int((ff > 0).sum()),
                "precision": precision, "flags": flags, "caught": caught, "ff_per": ff}

    def tune_union(self, M: np.ndarray, risk: Optional[np.ndarray],
                   t2_grid: List[Optional[float]]) -> Tuple[Tuple[float, float], int, int]:
        """M: candidate column-check flags, one 0/1 row per threshold option. Flags = row OR risk >= t2. Returns the
        best (key, option, t2 index) within the budget; ties: fewer false flags, then the earlier option and t2."""
        mw, mn = M @ self.w, M @ self.nt
        r = None if risk is None else np.nan_to_num(risk, nan=-1.0)
        best = None
        for j, t2 in enumerate(t2_grid):
            if t2 is None or r is None:
                macro, ff = mw, mn
            else:
                lf = (r >= t2 - 1e-9).astype(float)
                macro = mw + lf @ self.w - M @ (lf * self.w)
                ff = mn + lf @ self.nt - M @ (lf * self.nt)
            macro = np.where(ff <= self.budget + 1e-9, np.round(macro, 9), -1.0)
            top = macro.max()
            if top < 0:
                continue
            idx = np.flatnonzero(macro == top)
            o = int(idx[np.argmin(ff[idx])])
            key = (float(top), -float(round(ff[o])))
            if best is None or key > best[0] or (key == best[0] and o < best[1]):
                best = (key, o, j)
        return best  # the option that flags nothing always fits the budget

    def macro_on(self, res: Dict[str, Any], subset: List[int]) -> float:
        """Macro recall over the leak tables among the given table indexes."""
        idx = [i for i in subset if self.recall_ds[i]]
        if not idx:
            return float("nan")
        return float(np.mean([res["caught"][i] / self.leak_total[i] for i in idx]))

    def flags(self, t1: Optional[float], risk: Optional[np.ndarray], t2: Optional[float]) -> np.ndarray:
        f = np.zeros(len(self.truth), dtype=bool)
        if t1 is not None:
            f |= self.score >= t1 - 1e-9
        if t2 is not None and risk is not None:
            f |= np.nan_to_num(risk, nan=-1.0) >= t2 - 1e-9
        return f

    def tune(self, risk: Optional[np.ndarray], t1_grid: List[Optional[float]],
             t2_grid: List[Optional[float]]) -> Tuple[Optional[float], Optional[float], Dict[str, Any]]:
        """Best macro recall within the false-flag budget; ties: fewer false flags, then stricter thresholds."""
        best = None
        for t1 in t1_grid:
            for t2 in t2_grid:
                res = self.evaluate(self.flags(t1, risk, t2))
                if res["ff"] > self.budget + 1e-9:
                    continue
                key = (nz(res["macro"]), -res["ff"])
                if best is None or key > best[0]:
                    best = (key, t1, t2, res)
        return best[1], best[2], best[3]  # "off/off" flags nothing, so something always fits the budget


def main() -> None:
    lines: List[str] = []

    def out(s: str = "") -> None:
        print(s)
        lines.append(s)

    cases = common.load_cases(quiet=True)
    by_id = {c["id"]: c for c in cases}
    cc = read_scores(CC_FILE)
    if cc is None or cc.empty:
        print("No %s -- run step2_column_check.py first." % CC_FILE)
        return
    cc["score"] = pd.to_numeric(cc["score"], errors="coerce")
    for m in REG_METRICS:
        col_name = "score_" + m
        cc[col_name] = pd.to_numeric(cc[col_name], errors="coerce") if col_name in cc.columns else np.nan
    gone = sorted(set(cc["case_id"]) - set(by_id))
    cc = cc[cc["case_id"].isin(by_id)].reset_index(drop=True)
    if cc.empty:
        print("None of the scored tables are in cases.json any more -- run steps 1 and 2 again.")
        return
    scored = set(cc["case_id"])
    trap_ids = [c["id"] for c in cases if c["id"] in scored and is_trap(c)]  # the trap set: reported separately
    datasets = [c["id"] for c in cases if c["id"] in scored and not is_trap(c)]
    cc["kind"] = cc["case_id"].map(lambda c: by_id[c]["kind"])
    cc["is_leak"] = [col in by_id[cid]["leak_columns"] for cid, col in zip(cc["case_id"], cc["column"])]
    cc["is_probable"] = [col in by_id[cid]["probable_leak_columns"] for cid, col in zip(cc["case_id"], cc["column"])]
    if not datasets:
        print("No scored table outside the trap set -- run steps 1 and 2 again.")
        return

    llm = read_scores(LLM_FILE)
    llm_traps = None
    if llm is not None:
        llm["leak_risk"] = pd.to_numeric(llm["leak_risk"], errors="coerce")
        llm_traps = llm[llm["case_id"].isin(trap_ids)]
        llm = llm[llm["case_id"].isin(datasets)]
        if llm.empty:
            llm = None
    pairs: List[Tuple[str, str]] = []
    if llm is not None:
        conds = [c for c in COND_ORDER if c in set(llm["condition"])]
        conds += sorted(set(llm["condition"]) - set(conds))
        for m in dict.fromkeys(llm["model"]):
            for c in conds:
                if ((llm["model"] == m) & (llm["condition"] == c)).any():
                    pairs.append((m, c))

    # recognition probes: (model, condition) -> {case_id: recognized}; first guesses for the report
    recog: Dict[Tuple[str, str], Dict[str, bool]] = {}
    first_guess: Dict[Tuple[str, str], List[str]] = {}
    probes = read_scores(PROBE_FILE)
    if probes is not None:
        for _, r in probes[probes["case_id"].isin(by_id)].iterrows():
            key = (r["model"], r["condition"])
            recog.setdefault(key, {})[r["case_id"]] = probe_hit(r, by_id[r["case_id"]])
            if r.get("guess1", ""):
                first_guess.setdefault(key, []).append(r["guess1"])

    out("Fresh leakage test -- results (%s)" % common.stamp())
    if any(m.startswith("mock-") for m, _ in pairs):
        out("WARNING: the LLM scores come from MOCK mode (a fake offline LLM). The verdict below is meaningless; "
            "run step 3 with MOCK = False.")
    if gone:
        out("note: ignoring scored tables that are no longer in cases.json: %s" % ", ".join(gone))
    for cid in datasets:
        have = set(cc.loc[cc["case_id"] == cid, "column"])
        absent = [c for c in by_id[cid]["leak_columns"] + by_id[cid]["probable_leak_columns"] if c not in have]
        if absent:
            out("note: %s lists %s, not among its scored columns (run steps 1-2 again) -- ignored" % (cid, absent))
    not_scored = [c["id"] for c in cases if c["id"] not in scored]
    if not_scored:
        out("note: tables in cases.json without column-check scores (failed or not run): %s" % ", ".join(not_scored))

    probable = cc[cc["is_probable"] & cc["case_id"].isin(datasets)].reset_index(drop=True)
    sc = cc[~cc["is_probable"] & cc["case_id"].isin(datasets)].reset_index(drop=True)
    budget = BUDGET_FF_PER_DATASET * len(datasets)
    S = Scorer(sc, datasets, by_id, budget)
    keys = list(zip(sc["case_id"], sc["column"]))
    decoys = {d: set(by_id[d].get("decoy_columns") or []) for d in datasets}
    strong = {d: set(by_id[d].get("strong_legit_columns") or []) for d in datasets}
    role = np.array(["leak" if S.truth[i] else "decoy" if keys[i][1] in decoys[keys[i][0]]
                     else "strong" if keys[i][1] in strong[keys[i][0]] else "legit" for i in range(len(keys))])
    risk: Dict[Tuple[str, str], np.ndarray] = {}
    detail: Dict[Tuple[str, str], Dict[Tuple[str, str], Tuple[float, str, str]]] = {}
    guesses: Dict[Tuple[str, str], Dict[str, str]] = {}
    for m, c in pairs:
        sub = llm[(llm["model"] == m) & (llm["condition"] == c)]
        d = {(a, b): (r, cat, why) for a, b, r, cat, why in
             zip(sub["case_id"], sub["column"], sub["leak_risk"], sub["category"], sub["reason"])}
        detail[(m, c)] = d
        risk[(m, c)] = np.array([d[k][0] if k in d else np.nan for k in keys], dtype=float)
        guesses[(m, c)] = dict(zip(sub["case_id"], sub["dataset_guess"]))

    n_leak_ds = int(S.recall_ds.sum())
    out("Tables: %d (%d leak, %d clean); leak columns scored: %d; decoy columns: %d; strong legitimate predictors: %d; "
        "probable columns (left out): %d; false-flag budget: %.0f in total%s"
        % (len(datasets), sum(by_id[d]["kind"] == "leak" for d in datasets),
           sum(by_id[d]["kind"] == "clean" for d in datasets), int(S.truth.sum()), int((role == "decoy").sum()),
           int((role == "strong").sum()), len(probable), budget,
           ("; plus %d trap tables, reported separately (not in the verdict)" % len(trap_ids)) if trap_ids else ""))
    for m, c in pairs:
        covered = len(guesses[(m, c)])
        blank = int(np.isnan(risk[(m, c)]).sum())
        if covered < len(datasets) or blank:
            out("note: LLM %s / %s covers %d of %d tables; %d scored columns have no risk (count as not flagged)"
                % (m, c, covered, len(datasets), blank))
    if n_leak_ds == 0:
        out("\nNo kind 'leak' table with a scored leak column -- recall cannot be computed.")

    # ---------------------------------------------------------------- methods
    methods: List[Dict[str, Any]] = []
    for name, t in (("column check @0.80 (H2O-like)", H2O_LIKE), ("column check @0.925 (DataRobot-like)",
                                                                  DATAROBOT_LIKE)):
        methods.append({"name": name, "family": "fixed", "t1": t, "t2": None,
                        "res": S.evaluate(S.flags(t, None, None))})
    t1, _, res = S.tune(None, T1_GRID, [None])
    col_single = {"name": "column check tuned", "family": "column", "t1": t1, "t2": None, "res": res}
    methods.append(col_single)

    # column-check threshold options: separate binary / regression thresholds, for every regression score step 2
    # wrote. "Column check strongest" is the best of them; each combined method searches them too, so with the LLM
    # switched off (t2 off) it is exactly the baseline and its gain measures what the LLM adds.
    is_bin = (sc["task"] == "binary").to_numpy()
    has_reg = bool((~is_bin).any())
    bin_vals = np.where(np.isfinite(sc["score_gini"].to_numpy(dtype=float)), sc["score_gini"].to_numpy(dtype=float),
                        sc["score"].to_numpy(dtype=float))
    bin_vals = np.nan_to_num(bin_vals, nan=-1.0)
    options: List[Tuple[str, List[Tuple[Optional[float], Optional[float]]], np.ndarray]] = []
    for m in REG_METRICS:
        reg_vals = sc["score_" + m].to_numpy(dtype=float)
        if has_reg and not np.isfinite(reg_vals[~is_bin]).any():
            continue
        reg_vals = np.nan_to_num(reg_vals, nan=-1.0)
        grid_reg = (R2_GRID if m == "r2" else T1_GRID) if has_reg else [None]
        params, flag_rows = [], []
        for tb in T1_GRID:
            fb = is_bin & (bin_vals >= (tb if tb is not None else 9.0) - 1e-9)
            for tr in grid_reg:
                flag_rows.append(fb | ((~is_bin) & (reg_vals >= (tr if tr is not None else 9.0) - 1e-9)))
                params.append((tb, tr))
        options.append((m, params, np.array(flag_rows, dtype=float)))
        if not has_reg:
            break  # no regression table: one set of options is enough
    variants = []
    for m, params, M in options:
        _, o, _ = S.tune_union(M, None, [None])
        variants.append({"name": "column check strongest (regression: %s)" % m, "family": "column", "metric": m,
                         "t1": params[o][0], "t1_reg": params[o][1], "t2": None, "res": S.evaluate(M[o] > 0.5)})
    methods += variants
    col = max(variants, key=lambda x: (nz(x["res"]["macro"]), -x["res"]["ff"])) if variants else col_single
    if nz(col_single["res"]["macro"]) > nz(col["res"]["macro"]):
        col = col_single

    def combine(r: np.ndarray) -> Dict[str, Any]:
        """Flag if a column-check option (any regression score) flags OR leak_risk >= t2; all thresholds tuned."""
        found = None
        for m, params, M in options:
            key, o, j = S.tune_union(M, r, T2_GRID)
            if found is None or key > found[0]:
                found = (key, m, params[o], M[o] > 0.5, T2_GRID[j])
        _, m, (tb, tr), colf, t2 = found
        llmf = (np.nan_to_num(r, nan=-1.0) >= t2 - 1e-9) if t2 is not None else np.zeros(len(colf), dtype=bool)
        return {"metric": m, "t1": tb, "t1_reg": tr, "t2": t2, "col_flags": colf, "llm_flags": llmf,
                "res": S.evaluate(colf | llmf)}

    llm_m, comb = [], []
    for m, c in pairs:
        _, t2, res = S.tune(risk[(m, c)], [None], T2_GRID)
        llm_m.append({"name": "LLM %s / %s tuned" % (m, c), "family": "llm", "model": m, "cond": c, "t1": None,
                      "t2": t2, "res": res})
    for m, c in pairs:
        x = combine(risk[(m, c)])
        x.update(name="combined %s / %s" % (m, c), family="combined", model=m, cond=c)
        comb.append(x)
    methods += llm_m + comb

    def best_of(ms: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        return max(ms, key=lambda x: (nz(x["res"]["macro"]), -x["res"]["ff"])) if ms else None

    real_comb = [x for x in comb if x["cond"] == "real"]
    best_llm = best_of([x for x in llm_m if x["cond"] == "real"])
    best = best_of(real_comb)

    def t1_text(x: Dict[str, Any]) -> str:
        if "t1_reg" in x and x["t1"] is None and x["t1_reg"] is None:
            return "off"
        if "t1_reg" in x:
            s = "bin %s / reg %s" % (fmt_t(x["t1"]), fmt_t(x["t1_reg"]))
            return s + (" (%s)" % x["metric"] if x["family"] == "combined" and has_reg else "")
        return fmt_t(x["t1"])

    def n_leak(subset: List[int]) -> int:
        return int(sum(1 for i in subset if S.recall_ds[i]))

    def count(x: Optional[Dict[str, Any]], idx: List[int], pct: bool = False) -> str:
        if x is None:
            return "-"
        k = int(sum(bool(x["res"]["flags"][i]) for i in idx))
        if not pct:
            return "%d / %d" % (k, len(idx))
        return "%d / %d (%.0f%%)" % (k, len(idx), 100.0 * k / len(idx)) if idx else "n/a"

    def ff_on(x: Optional[Dict[str, Any]], subset: List[int]) -> str:
        return "-" if x is None else "%d" % int(round(sum(x["res"]["ff_per"][i] for i in subset)))

    def head(text: str, x: Optional[Dict[str, Any]]) -> str:
        return text + (": " + x["name"] if x else "")

    out("\nMETHODS (macro recall = mean per-table recall over leak tables; false flags and precision over all tables)")
    rows = [[x["name"], t1_text(x), fmt_t(x["t2"], llm=True), fmt_r(x["res"]["macro"]), fmt_r(x["res"]["micro"]),
             x["res"]["ff"], x["res"]["ff_ds"], fmt_r(x["res"]["precision"])] for x in methods]
    out(common.format_table(["method", "t1 (score)", "t2 (risk)", "macro recall", "micro recall", "false flags",
                             "tables with a false flag", "precision"], rows))

    out("\nPER TABLE (leak columns caught / false flags)")
    rows = []
    for i, d in enumerate(datasets):
        r = [d, by_id[d]["kind"], by_id[d].get("naming_style") or "-", int(S.leak_total[i]),
             "%d / %d" % (col["res"]["caught"][i], col["res"]["ff_per"][i])]
        if best:
            r.append("%d / %d" % (best["res"]["caught"][i], best["res"]["ff_per"][i]))
        rows.append(r)
    out(common.format_table(["table", "kind", "names", "leak columns", "column check (baseline)"]
                            + ([head("best combined", best)] if best else []), rows))

    # ---------------------------------------------------------------- breakdowns
    leak_idx = [int(i) for i in np.flatnonzero(S.truth & S.in_recall)]
    out("\nLEAK COLUMNS BY THEIR OWN COLUMN-CHECK SCORE (leak tables only; the generator aims at about "
        "35% / 25% / 40%)")
    rows = []
    for name, lo, hi in BUCKETS:
        idx = [i for i in leak_idx if lo <= S.score[i] < hi]
        rows.append([name, len(idx), "%.0f%%" % (100.0 * len(idx) / max(1, len(leak_idx))), count(col, idx),
                     count(best_llm, idx), count(best, idx)])
    out(common.format_table(["score bucket", "leak columns", "share", "column check (baseline)",
                             head("best LLM only", best_llm), head("best combined", best)], rows))

    style_of = [str(by_id[d].get("naming_style") or "-") for d in datasets]
    styles = [s for s in STYLE_ORDER if s in style_of] + sorted(set(style_of) - set(STYLE_ORDER))
    groups = [("all", list(range(len(datasets))))] + [(s, [i for i, x in enumerate(style_of) if x == s])
                                                      for s in styles]
    out("\nBY NAMING STYLE (macro recall over the leak tables with these names; thresholds as tuned on all tables; "
        "cryptic: information only)")
    rows = [["column check (baseline)"] + [fmt_r(S.macro_on(col["res"], sub)) for _, sub in groups]]
    for x in comb + llm_m:
        rows.append([x["name"]] + [fmt_r(S.macro_on(x["res"], sub)) for _, sub in groups])
    if best:
        rows.append(["gain of the best combined"] + [fmt_g(S.macro_on(best["res"], sub) - S.macro_on(col["res"], sub))
                                                     for _, sub in groups])
    out(common.format_table(["method"] + ["%s (%d tables)" % (g, n_leak(sub)) for g, sub in groups], rows))

    ltype = {i: str((by_id[keys[i][0]].get("leak_types") or {}).get(keys[i][1]) or "-") for i in leak_idx}
    types = [t for t in TYPE_ORDER if t in ltype.values()] + sorted(set(ltype.values()) - set(TYPE_ORDER))
    out("\nBY LEAK TYPE (leak columns caught, leak tables only; overwrite_silent is a pre-moment field overwritten "
        "later, by design invisible in its name)")
    rows = []
    for t in types:
        idx = [i for i in leak_idx if ltype[i] == t]
        rows.append([t, len(idx), "%.2f" % float(np.median(S.score[idx])), count(col, idx), count(best_llm, idx),
                     count(best, idx)])
    out(common.format_table(["leak type", "leak columns", "median score", "column check (baseline)",
                             head("best LLM only", best_llm), head("best combined", best)], rows))

    dom_of = [str(by_id[d].get("domain") or "-") for d in datasets]
    out("\nBY DOMAIN (macro recall over the domain's leak tables; false flags over all its tables)")
    rows = []
    for dm in dict.fromkeys(dom_of):
        sub = [i for i, x in enumerate(dom_of) if x == dm]
        b = S.macro_on(col["res"], sub)
        r = [dm, n_leak(sub), int(sum(S.leak_total[i] for i in sub if S.recall_ds[i])), fmt_r(b), ff_on(col, sub)]
        r.append(fmt_r(S.macro_on(best_llm["res"], sub)) if best_llm else "-")
        if best:
            r += [fmt_r(S.macro_on(best["res"], sub)), fmt_g(S.macro_on(best["res"], sub) - b), ff_on(best, sub)]
        rows.append(r)
    hdr = ["domain", "leak tables", "leak columns", "baseline", "baseline false flags", "best LLM only"]
    out(common.format_table(hdr + (["best combined", "gain", "best combined false flags"] if best else []), rows))

    out("\nDECOYS AND STRONG LEGITIMATE PREDICTORS (share flagged; every flag here is a false flag)")
    rows = []
    for text, rl in (("decoy columns (legitimate, names sound late)", "decoy"),
                     ("strong legitimate predictors", "strong"), ("other legitimate columns", "legit")):
        idx = [int(i) for i in np.flatnonzero(role == rl)]
        if idx:
            rows.append([text, len(idx), "%.2f" % float(np.median(S.score[idx])), count(col, idx, True),
                         count(best_llm, idx, True), count(best, idx, True)])
    out(common.format_table(["columns", "count", "median score", "column check (baseline)",
                             head("best LLM only", best_llm), head("best combined", best)], rows)
        if rows else "  none listed in cases.json")

    # ---------------------------------------------------------------- lists for manual review
    def llm_notes(cid: str, column: str) -> List[str]:
        notes = []
        for m in dict.fromkeys(p[0] for p in pairs):
            parts = []
            for c in [p[1] for p in pairs if p[0] == m]:
                v = detail[(m, c)].get((cid, column))
                parts.append("%s %s" % (c, "-" if v is None or not np.isfinite(v[0]) else "%.0f" % v[0]))
            real = detail.get((m, "real"), {}).get((cid, column))
            why = (" | real: [%s] %s" % (real[1], real[2])) if real else ""
            notes.append("      %s: %s%s" % (m, ", ".join(parts), why))
        return notes

    out("\nLEAK COLUMNS MISSED BY THE BASELINE COLUMN CHECK (%s, thresholds %s)" % (col["name"], t1_text(col)))
    missed = [i for i in leak_idx if not col["res"]["flags"][i]]
    if not missed:
        out("  none")
    for i in missed:
        cid, column = keys[i]
        out("  %s / %s  [%s]  (score %.3f)" % (cid, column, ltype.get(i, "-"), S.score[i]))
        for n in llm_notes(cid, column):
            out(n)

    if best:
        out("\nFALSE FLAGS OF THE BEST COMBINED METHOD (%s: t1 %s, t2 %s) -- for manual review"
            % (best["name"], t1_text(best), fmt_t(best["t2"], llm=True)))
        r = risk[(best["model"], best["cond"])]
        ff_idx = np.flatnonzero(best["res"]["flags"] & ~S.truth)
        if len(ff_idx) == 0:
            out("  none")
        for i in ff_idx:
            cid, column = keys[i]
            by_score, by_llm = bool(best["col_flags"][i]), bool(best["llm_flags"][i])
            v = detail[(best["model"], "real")].get((cid, column))
            tag = {"decoy": ", decoy", "strong": ", strong legitimate predictor"}.get(str(role[i]), "")
            out("  %s / %s (%s%s): score %.3f, risk %s, flagged by %s%s"
                % (cid, column, by_id[cid]["kind"], tag, S.score[i], "-" if not np.isfinite(r[i]) else "%.0f" % r[i],
                   "both" if by_score and by_llm else ("column check" if by_score else "LLM"),
                   (" -- [%s] %s" % (v[1], v[2])) if v else ""))

    out("\nPROBABLE LEAK COLUMNS (not scored)")
    if probable.empty:
        out("  none")
    for _, p in probable.iterrows():
        out("  %s / %s  (score %.3f)" % (p["case_id"], p["column"], p["score"]))
        for n in llm_notes(p["case_id"], p["column"]):
            out(n)

    # ---------------------------------------------------------------- trap set (separate; not part of the verdict)
    if trap_ids:
        tr = cc[~cc["is_probable"] & cc["case_id"].isin(trap_ids)].reset_index(drop=True)
        t_keys = list(zip(tr["case_id"], tr["column"]))
        t_type = np.array([(by_id[a].get("trap_columns") or {}).get(b, "") for a, b in t_keys], dtype=object)
        t_leak = tr["is_leak"].to_numpy(dtype=bool)
        t_trap = t_type != ""
        t_risk: Dict[Tuple[str, str], np.ndarray] = {}
        for m, c in pairs:
            sub = llm_traps[(llm_traps["model"] == m) & (llm_traps["condition"] == c)]
            d = dict(zip(zip(sub["case_id"], sub["column"]), sub["leak_risk"]))
            t_risk[(m, c)] = np.array([d.get(k, np.nan) for k in t_keys], dtype=float)

        def on_traps(x: Dict[str, Any]) -> np.ndarray:
            """Flags of method x on the trap tables, with the thresholds tuned on the main tables."""
            f = np.zeros(len(tr), dtype=bool)
            if x["family"] != "llm":
                if "t1_reg" in x:
                    isb = (tr["task"] == "binary").to_numpy()
                    g = tr["score_gini"].to_numpy(dtype=float)
                    bv = np.nan_to_num(np.where(np.isfinite(g), g, tr["score"].to_numpy(dtype=float)), nan=-1.0)
                    rv = np.nan_to_num(tr["score_" + x["metric"]].to_numpy(dtype=float), nan=-1.0)
                    if x["t1"] is not None:
                        f |= isb & (bv >= x["t1"] - 1e-9)
                    if x["t1_reg"] is not None:
                        f |= (~isb) & (rv >= x["t1_reg"] - 1e-9)
                elif x["t1"] is not None:
                    f |= np.nan_to_num(tr["score"].to_numpy(dtype=float), nan=-1.0) >= x["t1"] - 1e-9
            if x.get("t2") is not None and (x.get("model"), x.get("cond")) in t_risk:
                f |= np.nan_to_num(t_risk[(x["model"], x["cond"])], nan=-1.0) >= x["t2"] - 1e-9
            return f

        kinds = ["planned_future_date", "legit_time_trend", "legit_sparse_signal", "legit_high_card_signal"]
        out("\nTRAP SET (%d tables, thresholds as tuned above; not part of the verdict): planted leaks caught, "
            "and legitimate trap columns flagged (every flag on a trap column is a false flag)" % len(trap_ids))
        shown = [col] + llm_m + comb
        rows = []
        for x in shown:
            f = on_traps(x)
            rows.append([x["name"], count({"res": {"flags": f}}, list(np.flatnonzero(t_leak))),
                         count({"res": {"flags": f}}, list(np.flatnonzero(t_trap)), True)]
                        + [count({"res": {"flags": f}}, list(np.flatnonzero(t_type == k))) for k in kinds]
                        + [int((f & ~t_leak & ~t_trap).sum())])
        out(common.format_table(["method", "leaks caught", "trap columns flagged", "planned date", "time trend",
                                 "sparse signal", "high-card code", "other false flags"], rows))
        if best:
            fb, fc = on_traps(best), on_traps(col)
            rows = []
            for d in trap_ids:
                ix = [i for i, k in enumerate(t_keys) if k[0] == d]
                rows.append([d, int(t_leak[ix].sum()), "%d / %d" % (int((fc[ix] & t_leak[ix]).sum()),
                                                                    int((fc[ix] & t_trap[ix]).sum())),
                             "%d / %d" % (int((fb[ix] & t_leak[ix]).sum()), int((fb[ix] & t_trap[ix]).sum())),
                             ", ".join(t_keys[i][1] for i in ix if fb[i] and t_trap[i]) or "-"])
            out(common.format_table(["trap table", "leak columns", "baseline: leaks / traps flagged",
                                     head("best combined", best) + ": leaks / traps flagged",
                                     "trap columns the best combined flags"], rows))

    # ---------------------------------------------------------------- recognition (sanity check)
    recog_warn: List[str] = []
    if recog:
        out("\nRECOGNITION PROBES (a generated table counts as recognized if a guess names a public dataset with "
            "confidence >= %d; warning above %.0f%%)" % (RECOG_CONF, 100 * RECOG_MAX))
        order = {c: k for k, c in enumerate(COND_ORDER)}
        p_models = list(dict.fromkeys(m for m, _ in recog))
        rows = []
        for (m, c) in sorted(recog, key=lambda k: (p_models.index(k[0]), order.get(k[1], 99), k[1])):
            d = recog[(m, c)]
            k = sum(d.values())
            top = Counter(first_guess.get((m, c), [])).most_common(3)
            rows.append([m, c, "%d / %d" % (k, len(d)), "%.0f%%" % (100.0 * k / len(d)),
                         short(["%s (%d)" % t for t in top])])
            if k / float(len(d)) > RECOG_MAX + 1e-12:
                recog_warn.append("WARNING: %s recognizes %.0f%% of the tables in its %s probe (more than RECOG_MAX = "
                                  "%.0f%%): it takes them for known public datasets, so its audit may lean on memory."
                                  % (m, 100.0 * k / len(d), c, 100 * RECOG_MAX))
        out(common.format_table(["model", "condition", "recognized", "share", "most frequent first guesses (count)"],
                                rows))
        for w in recog_warn:
            out(w)
    elif pairs:
        out("\nRECOGNITION PROBES: no %s (step 3 writes it when PROBES = True)" % PROBE_FILE)
    if pairs:
        out("\nDATASET GUESS IN THE AUDIT ANSWERS (dataset_guess; for a generated table any named dataset is wrong)")
        rows = []
        for m, c in pairs:
            g = guesses[(m, c)]
            named = Counter(v for cid, v in g.items() if audit_claim(v, by_id[cid]))
            rows.append([m, c, "%d / %d" % (sum(named.values()), len(g)),
                         short(["%s (%d)" % t for t in named.most_common(4)])])
        out(common.format_table(["model", "condition", "names a dataset", "most frequent (count)"], rows))

    # ---------------------------------------------------------------- verdict
    out("\nVERDICT (kind 'leak' tables, 'real' condition; best combined method = highest macro recall over all models)")
    ct = col["res"]["macro"]
    abbr = [i for i, x in enumerate(style_of) if x == "abbreviated"]
    cryp = [i for i, x in enumerate(style_of) if x == "cryptic"]
    kills: List[str] = []
    notes: List[str] = []
    verdict = ""
    if n_leak_ds == 0:
        verdict = "NOT EVALUATED (no leak table with scored leak columns)"
    else:
        out("  baseline = %s: macro recall %.2f (thresholds %s)" % (col["name"], ct, t1_text(col)))
        if ct >= K1_RECALL - 1e-12:
            kills.append("K1: the column check alone reaches %.2f >= %.2f" % (ct, K1_RECALL))
        elif ct >= THIN_GAP:
            out("  WARNING (thin gap): the column check already reaches %.2f; at most %.2f of recall is left "
                "to gain" % (ct, 1 - ct))
        if not pairs or best is None:
            why = "no LLM scores" if not pairs else "no 'real' condition"
            out("  K2 and K4 not evaluated: %s%s" % (why, " (run step 3)" if not pairs else " in " + LLM_FILE))
            verdict = "KILL (K1)" if kills else "INCOMPLETE (%s; K1 passed)" % why
        else:
            gain = best["res"]["macro"] - ct
            out("  best combined: %s (t1 %s, t2 %s), macro recall %.2f, gain %+.2f (K2 needs >= %.2f)"
                % (best["name"], t1_text(best), fmt_t(best["t2"], llm=True), best["res"]["macro"], gain, K2_GAIN))
            if gain < K2_GAIN - 1e-12:
                kills.append("K2: the best combined method adds %+.2f < %.2f" % (gain, K2_GAIN))
            base_a = S.macro_on(col["res"], abbr)
            if n_leak(abbr):
                gain_a = S.macro_on(best["res"], abbr) - base_a
                out("  abbreviated-name tables (%d): baseline %.2f, best combined %.2f, gain %+.2f (K4 needs >= %.2f)"
                    % (n_leak(abbr), base_a, S.macro_on(best["res"], abbr), gain_a, K4_GAIN))
                if gain_a < K4_GAIN - 1e-12:
                    kills.append("K4: on the abbreviated-name tables the best combined method adds %+.2f < %.2f"
                                 % (gain_a, K4_GAIN))
            else:
                out("  K4 not evaluated: no abbreviated-name leak tables")
            if n_leak(cryp):
                base_c = S.macro_on(col["res"], cryp)
                out("  cryptic-name tables (%d): baseline %.2f, best combined %.2f, gain %+.2f (information only)"
                    % (n_leak(cryp), base_c, S.macro_on(best["res"], cryp), S.macro_on(best["res"], cryp) - base_c))
            if any(k.startswith(("K2", "K4")) for k in kills) and not any(k.startswith("K1") for k in kills):
                for x in real_comb:
                    g_all = x["res"]["macro"] - ct
                    g_abbr = S.macro_on(x["res"], abbr) - base_a if n_leak(abbr) else float("inf")
                    if x is not best and g_all >= K2_GAIN - 1e-12 and g_abbr >= K4_GAIN - 1e-12:
                        notes.append("note: %s would pass K2 and K4 (gain %+.2f, abbreviated %+.2f), but the rules use "
                                     "the best combined method" % (x["name"], g_all, g_abbr))
            if kills:
                verdict = "KILL (%s)" % ", ".join(k[:2] for k in kills)
            elif not n_leak(abbr):
                verdict = "INCOMPLETE (no abbreviated-name leak tables for K4)"
            else:
                verdict = "GO (model: %s)" % best["model"]
    for k in kills:
        out("  " + k)
    for n in notes + recog_warn:
        out("  " + n)
    out("\nVERDICT: " + verdict)
    out("Caveat: thresholds are tuned on the same data, which is optimistic for every method equally; the sample is "
        "small, so read the results as directional.")

    with open(common.path(OUT_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n(written to %s)" % OUT_FILE)


if __name__ == "__main__":
    main()
