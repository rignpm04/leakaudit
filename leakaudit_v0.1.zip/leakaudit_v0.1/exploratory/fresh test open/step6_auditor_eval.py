# step6_auditor_eval.py -- the auditor test: do the label-free data checks (step 5) make the LLM's leak audit (step 3)
# better -- fewer false flags, more leaks caught -- and do they survive the trap tables? Local, no keys; press Run in
# PyCharm after steps 2, 3 and 5. Python 3.9.
#
# Columns: a planted leak = 1; probable columns are left out; decoys, strong legitimate predictors, trap columns and
# every other column are clean, so any flag on them is a false flag (reported separately for each kind).
# Scope: the main evaluation uses the 36 fresh-test tables. The 6 trap tables (the trap set) are reported separately,
# with the thresholds tuned on the main tables.
# Methods, per model (r = the model's leak risk, 0-100, "real" condition):
#   A0  LLM only: r >= T
#   A1  LLM OR column check: step 4's combined method
#   A2  LLM + checks: flag if (r >= T_high and no contradiction) or (r >= T_low and any check fired) or there is
#       decisive evidence in the data alone: D1 purity >= DECISIVE_PURITY, or D3's single-column rule, or D3's linear
#       fit (members whose own max(|Pearson|, |Spearman|) with y >= 0.3) -- step 5's d3_decisive. D2 (date after the moment) and D3's date
#       pair only confirm, through T_low: only the LLM can tell a planned date from a realized one. The contradiction
#       (D2: before the moment in >= 95% of rows) blocks the T_high path.
#   A3  A2 OR column check
# Methods without an LLM: C0 any check fired; C1 C0 OR column check. Baseline: step 4's strongest column check.
# Thresholds: T, T_high and T_low (and the column check's) are tuned on grids for the best macro recall within the
# false-flag budget of step 4 (BUDGET_FF_PER_DATASET per table on average; ties go to fewer false flags). A2 and A3 are
# also shown at FIXED_T_HIGH / FIXED_T_LOW with no tuning (A3's column check keeps the baseline's thresholds).
# Rules, fixed in advance:
#   CHECKS PASS if (a) for the best frontier model (highest A1 macro recall), A3 needs at least FF_CUT fewer false flags
#     than A1 at the same macro recall -- both tuned for their fewest false flags with a macro recall >= A1's (tuned)
#     - RECALL_SLACK -- or (b) for DeepSeek or an in-house model, A3 lifts macro recall by >= LIFT over that model's A1.
#     (Until Oct 18, 2026, (a) compared A3's fewest-false-flag setting with A1's tuned setting; that gave A3 a tuning
#     step A1 did not get, so the earlier comparison is only printed for reference.)
#   TRAP RULE: on the trap set, A3 with the best frontier model flags at most TRAP_MAX of the trap columns (C0 shown
#     too).
#   IN-HOUSE PASS if an open-weight model -- the local one in LM Studio, or one of the open models step 3 runs through
#     OpenRouter (labels open-...) -- reaches an A3 macro recall >= LOCAL_RECALL. The bar is 0.78: at least 5 points
#     above the checks with no AI at all (C1 reached 0.73 on Oct 18, 2026; the earlier bar, 0.75, barely asked the model
#     to add anything).
#   GO if CHECKS PASS, the TRAP RULE and IN-HOUSE PASS all hold; otherwise the failing part is named.
# Output: results_auditor.txt (also printed).

import os
import sys
from typing import Any, Dict, List, Optional, Tuple

# ============================================================ settings (fixed in advance)
BUDGET_FF_PER_DATASET = 1.0   # as in step 4
FF_CUT = 0.30                 # CHECKS PASS (a): A3 cuts false flags by at least this share versus A1
RECALL_SLACK = 0.01           # ... at a macro recall of at least A1's minus this
LIFT = 0.10                   # CHECKS PASS (b): A3 lifts macro recall by at least this over the model's A1
TRAP_MAX = 0.20               # TRAP RULE: share of trap columns A3 may flag
LOCAL_RECALL = 0.78           # IN-HOUSE PASS: an open-weight model's A3 macro recall (0.75 until Oct 18, 2026)
FIXED_T_HIGH = 70             # robustness line: A2 and A3 without tuning
FIXED_T_LOW = 30
DECISIVE_PURITY = 0.95        # decisive evidence in A2: D1 purity at least this (D3's decisive rules come from step 5)
FRONTIER = ("deepseek", "claude", "gpt")

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

CC_FILE = "scores_column_check.csv"
LLM_FILE = "scores_llm.csv"
CHECK_FILE = "scores_checks.csv"
OUT_FILE = "results_auditor.txt"
T1_GRID: List[Optional[float]] = [None] + [round(1.0 - 0.01 * i, 2) for i in range(46)]   # as in step 4
T2_GRID: List[Optional[float]] = [None] + [float(x) for x in range(100, -1, -5)]
R2_GRID: List[Optional[float]] = [None] + [round(1.0 - 0.02 * i, 2) for i in range(51)]
REG_METRICS = ["gini", "concordance", "r2"]
STYLE_ORDER = ["clear", "abbreviated", "cryptic"]
TYPE_ORDER = ["outcome_status", "post_event_date", "post_aggregate", "snapshot_state", "overwrite_silent",
              "outcome_only_sparse", "target_derived", "identifier"]
TRAP_KINDS = ["planned_future_date", "legit_time_trend", "legit_sparse_signal", "legit_high_card_signal"]
CHECKS = ["d1", "d2", "d3", "d4", "d5"]
CLEAN_ROLES = ["decoy", "strong", "legit", "trap"]


def read(name: str) -> Optional[pd.DataFrame]:
    p = common.path(name)
    return pd.read_csv(p, dtype=str, keep_default_na=False) if os.path.exists(p) else None


def num(s: pd.Series) -> np.ndarray:
    return pd.to_numeric(s, errors="coerce").to_numpy(dtype=float)


def nz(x: float) -> float:
    return 0.0 if x is None or not np.isfinite(x) else float(x)


def fmt_r(x: float) -> str:
    return "n/a" if x is None or not np.isfinite(x) else "%.2f" % x


def fmt_risk(t: Optional[float]) -> str:
    return "off" if t is None else "%d" % t


def fmt_score(t: Optional[float]) -> str:
    if t is None:
        return "off"
    s = "%.3f" % t
    return s[:-1] if s.endswith("0") else s   # 0.80, 0.925, 1.00 (as in step 4)


def base_model(m: str) -> str:
    return m[5:] if m.startswith("mock-") else m


class Ctx:
    """The scored columns of one set of tables, with everything the methods need."""

    def __init__(self, df: pd.DataFrame, ck: Dict[Tuple[str, str], Dict[str, Any]], cases: Dict[str, Dict[str, Any]],
                 llm: Optional[pd.DataFrame], models: List[str]):
        self.df = df
        self.keys = list(zip(df["case_id"], df["column"]))
        self.n = len(df)
        self.truth = df["is_leak"].to_numpy(dtype=bool)
        self.is_bin = (df["task"] == "binary").to_numpy()
        self.score = np.nan_to_num(num(df["score"]), nan=-1.0)
        g = num(df["score_gini"])
        self.bin_vals = np.nan_to_num(np.where(np.isfinite(g), g, num(df["score"])), nan=-1.0)
        self.reg_vals = {m: num(df["score_" + m]) if "score_" + m in df.columns else np.full(self.n, np.nan)
                         for m in REG_METRICS}
        rows = [ck.get(k, {}) for k in self.keys]

        def col(name: str) -> np.ndarray:
            return np.array([float(r.get(name)) if r.get(name) not in (None, "") else np.nan for r in rows])
        self.fired = {c: np.nan_to_num(col(c + "_fired"), nan=0.0) > 0.5 for c in CHECKS}
        self.anyf = np.nan_to_num(col("any_fired"), nan=0.0) > 0.5
        self.contra = np.nan_to_num(col("contradiction"), nan=0.0) > 0.5
        purity = np.nan_to_num(col("d1_purity"), nan=0.0)
        d3_decisive = np.nan_to_num(col("d3_decisive"), nan=0.0) > 0.5
        self.dec_data = d3_decisive | (self.fired["d1"] & (purity >= DECISIVE_PURITY - 1e-12))
        self.check_reason = [str(r.get("reason") or "not checked") for r in rows]
        self.role = np.array([role_of(cases[a], b) for a, b in self.keys], dtype=object)
        self.ltype = np.array([(cases[a].get("leak_types") or {}).get(b, "") for a, b in self.keys], dtype=object)
        self.ttype = np.array([(cases[a].get("trap_columns") or {}).get(b, "") for a, b in self.keys], dtype=object)
        self.risk: Dict[str, np.ndarray] = {}
        self.why: Dict[str, Dict[Tuple[str, str], str]] = {}
        for m in models:
            sub = llm[llm["model"] == m]
            d = dict(zip(zip(sub["case_id"], sub["column"]), pd.to_numeric(sub["leak_risk"], errors="coerce")))
            self.risk[m] = np.array([d.get(k, np.nan) for k in self.keys], dtype=float)
            self.why[m] = dict(zip(zip(sub["case_id"], sub["column"]), sub["reason"]))

    def col_flags(self, opt: Optional[Tuple[Any, ...]]) -> np.ndarray:
        """opt: None, ('single', t1) on the main score, or ('split', metric, t_binary, t_regression)."""
        f = np.zeros(self.n, dtype=bool)
        if opt is None:
            return f
        if opt[0] == "single":
            return f | (self.score >= opt[1] - 1e-9) if opt[1] is not None else f
        _, metric, tb, tr = opt
        if tb is not None:
            f |= self.is_bin & (self.bin_vals >= tb - 1e-9)
        if tr is not None:
            f |= (~self.is_bin) & (np.nan_to_num(self.reg_vals[metric], nan=-1.0) >= tr - 1e-9)
        return f

    def r(self, m: str) -> np.ndarray:
        return np.nan_to_num(self.risk[m], nan=-1.0)

    def a2(self, m: str, th: Optional[float], tl: Optional[float]) -> np.ndarray:
        r = self.r(m)
        f = self.dec_data.copy()
        if th is not None:
            f = f | ((r >= th - 1e-9) & ~self.contra)
        if tl is not None:
            f = f | ((r >= tl - 1e-9) & self.anyf)
        return f

    def flags(self, s: Dict[str, Any]) -> np.ndarray:
        k, m = s["kind"], s.get("model")
        col = self.col_flags(s.get("col"))
        if k == "BASE":
            return col
        if k == "C0":
            return self.anyf.copy()
        if k == "C1":
            return self.anyf | col
        if k == "A0":
            return self.r(m) >= s["t"] - 1e-9 if s["t"] is not None else np.zeros(self.n, dtype=bool)
        if k == "A1":
            return col | ((self.r(m) >= s["t"] - 1e-9) if s["t"] is not None else False)
        a2 = self.a2(m, s["th"], s["tl"])
        return a2 if k == "A2" else a2 | col


def role_of(case: Dict[str, Any], column: str) -> str:
    if column in case.get("leak_columns", []):
        return "leak"
    if column in (case.get("trap_columns") or {}):
        return "trap"
    if column in (case.get("decoy_columns") or []):
        return "decoy"
    if column in (case.get("strong_legit_columns") or []):
        return "strong"
    return "legit"


class Scorer:
    """Macro / micro recall over leak tables and false flags over all tables (as step 4), plus the fast union search."""

    def __init__(self, ctx: Ctx, datasets: List[str], cases: Dict[str, Dict[str, Any]], budget: float):
        self.ctx = ctx
        self.truth = ctx.truth
        self.ds = np.array([datasets.index(a) for a, _ in ctx.keys], dtype=int)
        self.n_ds = len(datasets)
        self.leak_total = np.bincount(self.ds, weights=self.truth.astype(float), minlength=self.n_ds)
        kind_leak = np.array([cases[d]["kind"] == "leak" for d in datasets], dtype=bool)
        self.recall_ds = kind_leak & (self.leak_total > 0)
        self.in_recall = self.recall_ds[self.ds]
        self.budget = budget
        n_rec = max(1, int(self.recall_ds.sum()))
        self.w = np.where(self.truth & self.in_recall, 1.0 / np.maximum(self.leak_total[self.ds], 1.0), 0.0) / n_rec
        self.nt = (~self.truth).astype(float)

    def evaluate(self, flags: np.ndarray) -> Dict[str, Any]:
        caught = np.bincount(self.ds, weights=(flags & self.truth).astype(float), minlength=self.n_ds)
        ff_per = np.bincount(self.ds, weights=(flags & ~self.truth).astype(float), minlength=self.n_ds)
        if self.recall_ds.any():
            macro = float(np.mean(caught[self.recall_ds] / self.leak_total[self.recall_ds]))
            micro = float(caught[self.recall_ds].sum() / self.leak_total[self.recall_ds].sum())
        else:
            macro = micro = float("nan")
        by_role = {r: int((flags & (self.ctx.role == r)).sum()) for r in CLEAN_ROLES}
        return {"macro": macro, "micro": micro, "ff": int(round(ff_per.sum())), "flags": flags, "caught": caught,
                "ff_per": ff_per, "by_role": by_role}

    def macro_on(self, res: Dict[str, Any], subset: List[int]) -> float:
        idx = [i for i in subset if self.recall_ds[i]]
        return float(np.mean([res["caught"][i] / self.leak_total[i] for i in idx])) if idx else float("nan")

    def tune_union(self, M: np.ndarray, r: np.ndarray, t2_grid: List[Optional[float]]
                   ) -> Tuple[Tuple[float, float], int, int]:
        """Step 4's combined search, unchanged: column option OR r >= t2; best (key, option, t2 index)."""
        mw, mn = M @ self.w, M @ self.nt
        best = None
        for j, t2 in enumerate(t2_grid):
            if t2 is None:
                macro, ff = mw, mn
            else:
                lf = (r >= t2 - 1e-9).astype(float)
                macro = mw + lf @ self.w - M @ (lf * self.w)
                ff = mn + lf @ self.nt - M @ (lf * self.nt)
            macro = np.where(ff <= self.budget + 1e-9, np.round(macro, 9), -1.0)
            top = macro.max()
            if top < 0:
                continue
            idx = np.flatnonzero(macro == top)
            o = int(idx[np.argmin(ff[idx])])
            key = (float(top), -float(round(ff[o])))
            if best is None or key > best[0] or (key == best[0] and o < best[1]):
                best = (key, o, j)
        return best

    def union(self, M: np.ndarray, extra: np.ndarray, target: Optional[float] = None
              ) -> Optional[Tuple[Tuple[float, float], int]]:
        """Best column-check option (row of M) OR the fixed flags 'extra', within the budget. target=None: best macro
        recall (ties: fewer false flags, then the earlier option); else the fewest false flags with macro >= target."""
        lf = extra.astype(float)
        macro = M @ self.w + lf @ self.w - M @ (lf * self.w)
        ff = M @ self.nt + lf @ self.nt - M @ (lf * self.nt)
        macro = np.round(macro, 9)
        ok = ff <= self.budget + 1e-9
        if target is None:
            m2 = np.where(ok, macro, -1.0)
            top = m2.max()
            if top < 0:
                return None
            idx = np.flatnonzero(m2 == top)
            o = int(idx[np.argmin(ff[idx])])
            return (float(top), -float(round(ff[o]))), o
        ok &= macro >= target - 1e-9
        if not ok.any():
            return None
        f2 = np.where(ok, ff, np.inf)
        low = f2.min()
        idx = np.flatnonzero(f2 == low)
        o = int(idx[np.argmax(macro[idx])])
        return (-float(round(low)), float(macro[o])), o


def better(key: Tuple[float, float], best: Optional[Tuple[Any, ...]]) -> bool:
    return best is None or key > best[0]


def main() -> None:
    lines: List[str] = []

    def out(s: str = "") -> None:
        print(s)
        lines.append(s)

    cases_l = common.load_cases(quiet=True)
    cases = {c["id"]: c for c in cases_l}
    cc, ckf, llm = read(CC_FILE), read(CHECK_FILE), read(LLM_FILE)
    if cc is None or cc.empty:
        print("No %s -- run step2_column_check.py first." % CC_FILE)
        return
    if ckf is None or ckf.empty:
        print("No %s -- run step5_data_checks.py first." % CHECK_FILE)
        return
    if "d3_decisive" not in ckf.columns:
        print("%s comes from an older step 5 -- run step5_data_checks.py again." % CHECK_FILE)
        return
    cc = cc[cc["case_id"].isin(cases)].reset_index(drop=True)
    cc["is_leak"] = [b in cases[a]["leak_columns"] for a, b in zip(cc["case_id"], cc["column"])]
    probable = [b in cases[a]["probable_leak_columns"] for a, b in zip(cc["case_id"], cc["column"])]
    cc = cc[~np.array(probable, dtype=bool)].reset_index(drop=True)
    ck = {(r["case_id"], r["column"]): r for r in ckf.to_dict("records")}
    scored = set(cc["case_id"])
    main_ids = [c["id"] for c in cases_l if c["id"] in scored and not c.get("trap_columns")]
    trap_ids = [c["id"] for c in cases_l if c["id"] in scored and c.get("trap_columns")]
    models: List[str] = []
    if llm is not None:
        llm = llm[llm["condition"] == "real"]
        models = [m for m in dict.fromkeys(llm["model"]) if (llm["model"] == m).any()]
    frontier = [m for m in models if base_model(m) in FRONTIER]
    inhouse = [m for m in models if base_model(m) == "local" or base_model(m).startswith("open-")]
    unchecked = sorted(set(main_ids + trap_ids) - set(a for a, _ in ck))

    M_ctx = Ctx(cc[cc["case_id"].isin(main_ids)].reset_index(drop=True), ck, cases, llm, models)
    S = Scorer(M_ctx, main_ids, cases, BUDGET_FF_PER_DATASET * len(main_ids))
    T_ctx = Ctx(cc[cc["case_id"].isin(trap_ids)].reset_index(drop=True), ck, cases, llm, models) if trap_ids else None

    # column-check options (step 4's strongest check)
    has_reg = bool((~M_ctx.is_bin).any())
    options: List[Tuple[str, List[Tuple[Any, ...]], np.ndarray]] = []
    for metric in REG_METRICS:
        rv = M_ctx.reg_vals[metric]
        if has_reg and not np.isfinite(rv[~M_ctx.is_bin]).any():
            continue
        grid_reg = (R2_GRID if metric == "r2" else T1_GRID) if has_reg else [None]
        opts = [("split", metric, tb, tr) for tb in T1_GRID for tr in grid_reg]
        options.append((metric, opts, np.array([M_ctx.col_flags(o) for o in opts], dtype=float)))
        if not has_reg:
            break
    none_flags = np.zeros(M_ctx.n, dtype=bool)

    def best_col(extra: np.ndarray, target: Optional[float] = None) -> Optional[Tuple[Tuple[float, float], Any]]:
        found = None
        for metric, opts, M in options:
            r = S.union(M, extra, target)
            if r is not None and better(r[0], found):
                found = (r[0], opts[r[1]])
        return found

    # the baseline, exactly as step 4 picks it
    settings: Dict[str, Dict[str, Any]] = {}
    variants = []
    for metric, opts, M in options:
        r0 = S.union(M, none_flags)
        variants.append((r0[0], opts[r0[1]]))
    found = max(variants, key=lambda v: v[0]) if variants else None
    best_single = None
    for t in T1_GRID:
        res = S.evaluate(M_ctx.col_flags(("single", t)))
        key = (nz(res["macro"]), -res["ff"])
        if res["ff"] <= S.budget + 1e-9 and better(key, best_single):
            best_single = (key, t)
    base_col = found[1] if found and nz(found[0][0]) >= nz(best_single[0][0]) else ("single", best_single[1])
    settings["baseline (strongest column check)"] = {"kind": "BASE", "col": base_col}
    settings["C0 checks only"] = {"kind": "C0"}
    c1 = best_col(M_ctx.anyf)
    settings["C1 checks OR column check"] = {"kind": "C1", "col": c1[1] if c1 else None}

    per_model: Dict[str, Dict[str, Optional[Dict[str, Any]]]] = {}
    pairs = [(th, tl) for th in T2_GRID for tl in T2_GRID if th is None or tl is None or tl <= th]
    over_budget: List[str] = []
    for m in models:
        ps: Dict[str, Optional[Dict[str, Any]]] = {}
        r = M_ctx.r(m)
        best_t = None
        for t in T2_GRID:
            res = S.evaluate(r >= t - 1e-9 if t is not None else none_flags)
            key = (nz(res["macro"]), -res["ff"])
            if res["ff"] <= S.budget + 1e-9 and better(key, best_t):
                best_t = (key, t)
        ps["A0"] = {"kind": "A0", "model": m, "t": best_t[1]}
        best_a1 = None  # step 4's combined method, same search and tie-breaking
        for metric, opts, M in options:
            key, o, j = S.tune_union(M, r, T2_GRID)
            if best_a1 is None or key > best_a1[0]:
                best_a1 = (key, T2_GRID[j], opts[o])
        ps["A1"] = {"kind": "A1", "model": m, "t": best_a1[1], "col": best_a1[2]}
        a1_macro = S.evaluate(M_ctx.flags(ps["A1"]))["macro"]
        low_a1 = None  # A1 tuned the same way as "A3 fewest false flags", for a fair CHECKS PASS (a)
        for t in T2_GRID:
            got = best_col(r >= t - 1e-9 if t is not None else none_flags, target=nz(a1_macro) - RECALL_SLACK)
            if got is not None and better(got[0], low_a1):
                low_a1 = (got[0], t, got[1])
        ps["A1 fewest false flags"] = None if low_a1 is None else \
            {"kind": "A1", "model": m, "t": low_a1[1], "col": low_a1[2]}
        best_a2, best_a3, low_a3 = None, None, None
        for th, tl in pairs:
            f = M_ctx.a2(m, th, tl)
            res = S.evaluate(f)
            key = (nz(res["macro"]), -res["ff"])
            if res["ff"] <= S.budget + 1e-9 and better(key, best_a2):
                best_a2 = (key, th, tl)
            got = best_col(f)
            if got is not None and better(got[0], best_a3):
                best_a3 = (got[0], th, tl, got[1])
            got = best_col(f, target=nz(a1_macro) - RECALL_SLACK)
            if got is not None and better(got[0], low_a3):
                low_a3 = (got[0], th, tl, got[1])
        if best_a2 is None or best_a3 is None:  # the decisive evidence alone breaks the budget
            over_budget.append(m)
            best_a2 = best_a2 or ((0.0, 0.0), None, None)
            best_a3 = best_a3 or ((0.0, 0.0), None, None, None)
        ps["A2"] = {"kind": "A2", "model": m, "th": best_a2[1], "tl": best_a2[2]}
        ps["A3"] = {"kind": "A3", "model": m, "th": best_a3[1], "tl": best_a3[2], "col": best_a3[3]}
        ps["A3 fewest false flags"] = None if low_a3 is None else \
            {"kind": "A3", "model": m, "th": low_a3[1], "tl": low_a3[2], "col": low_a3[3]}
        ps["A2 fixed"] = {"kind": "A2", "model": m, "th": FIXED_T_HIGH, "tl": FIXED_T_LOW}
        ps["A3 fixed"] = {"kind": "A3", "model": m, "th": FIXED_T_HIGH, "tl": FIXED_T_LOW, "col": base_col}
        per_model[m] = ps

    def describe(s: Optional[Dict[str, Any]]) -> str:
        if not s:
            return "-"
        parts = []
        if "t" in s:
            parts.append("T %s" % fmt_risk(s["t"]))
        if "th" in s:
            parts.append("T_high %s, T_low %s" % (fmt_risk(s["th"]), fmt_risk(s["tl"])))
        c = s.get("col")
        if c is not None:
            parts.append("column check " + (fmt_score(c[1]) if c[0] == "single" else
                                            "bin %s / reg %s (%s)" % (fmt_score(c[2]), fmt_score(c[3]), c[1])))
        return "; ".join(parts) or "-"

    results: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for name, s in settings.items():
        results[("", name)] = S.evaluate(M_ctx.flags(s))
    for m, ps in per_model.items():
        for name, s in ps.items():
            if s:
                results[(m, name)] = S.evaluate(M_ctx.flags(s))

    out("Auditor test -- LLM + label-free data checks (%s)" % common.stamp())
    if any(m.startswith("mock-") for m in models):
        out("WARNING: the LLM scores come from MOCK mode (a fake offline LLM). The verdict below is meaningless.")
    out("Main tables: %d (%d leak columns); trap tables: %d; models: %s; false-flag budget: %.0f"
        % (len(main_ids), int(M_ctx.truth.sum()), len(trap_ids), ", ".join(models) or "none (no %s)" % LLM_FILE,
           S.budget))
    if unchecked:
        out("note: no step 5 checks for %s -- run step5_data_checks.py again" % ", ".join(unchecked))
    for m in over_budget:
        out("note: %s: the decisive evidence alone breaks the false-flag budget, so A2 and A3 are shown at T_high and "
            "T_low off" % m)
    for m in models:
        blank = int(np.isnan(M_ctx.risk[m]).sum())
        if blank:
            out("note: %s has no risk for %d scored main-table columns (count as not flagged)" % (m, blank))

    # ---------------------------------------------------------------- methods
    out("\nMETHODS ON THE MAIN TABLES (macro recall = mean per-table recall; false flags split by kind of column)")
    out("A2 flags a column if (risk >= T_high and no D2 contradiction) or (risk >= T_low and any check fired) or the "
        "data alone are decisive: D1 purity >= %.2f, D3's single-column rule, or D3's linear fit (members with "
        "max(|Pearson|, |Spearman|) >= 0.3). D2 and D3's date pair only confirm (through T_low). A3 = A2 OR column check." % DECISIVE_PURITY)
    per = ("A0", "A1", "A1 fewest false flags", "A2", "A3", "A3 fewest false flags", "A2 fixed", "A3 fixed")
    order = [("", n) for n in settings] + [(m, n) for m in models for n in per]
    rows = []
    for key in order:
        if key not in results:
            continue
        res = results[key]
        s = settings[key[1]] if key[0] == "" else per_model[key[0]][key[1]]
        rows.append([(key[0] + " " + key[1]).strip(), describe(s), fmt_r(res["macro"]), fmt_r(res["micro"]),
                     res["ff"], res["by_role"]["decoy"], res["by_role"]["strong"], res["by_role"]["legit"]])
    out(common.format_table(["method", "thresholds", "macro recall", "micro recall", "false flags", "on decoys",
                             "on strong predictors", "on other legitimate"], rows))

    # ---------------------------------------------------------------- by naming style and leak type
    style_of = [str(cases[d].get("naming_style") or "-") for d in main_ids]
    styles = [s for s in STYLE_ORDER if s in style_of] + sorted(set(style_of) - set(STYLE_ORDER))
    groups = [("all", list(range(len(main_ids))))] + [(s, [i for i, x in enumerate(style_of) if x == s])
                                                      for s in styles]
    show = [("", n) for n in settings] + [(m, n) for m in models for n in ("A1", "A3")]
    out("\nBY NAMING STYLE (macro recall)")
    rows = [[(k[0] + " " + k[1]).strip()] + [fmt_r(S.macro_on(results[k], sub)) for _, sub in groups]
            for k in show if k in results]
    out(common.format_table(["method"] + ["%s (%d)" % (g, sum(1 for i in sub if S.recall_ds[i])) for g, sub in groups],
                            rows))

    leak_idx = [int(i) for i in np.flatnonzero(M_ctx.truth & S.in_recall)]
    types = [t for t in TYPE_ORDER if t in set(M_ctx.ltype[leak_idx])] + \
        sorted(set(M_ctx.ltype[leak_idx]) - set(TYPE_ORDER))

    def caught(res: Dict[str, Any], idx: List[int]) -> int:
        return int(sum(bool(res["flags"][i]) for i in idx))

    out("\nBY LEAK TYPE (leak columns caught; per model A1 -> A3)")
    rows = []
    for t in types + ["ALL"]:
        idx = leak_idx if t == "ALL" else [i for i in leak_idx if M_ctx.ltype[i] == t]
        r_ = [t, len(idx)] + [caught(results[("", n)], idx) for n in settings]
        r_ += ["%d -> %d" % (caught(results[(m, "A1")], idx), caught(results[(m, "A3")], idx)) for m in models]
        rows.append(r_)
    out(common.format_table(["leak type", "leak columns", "baseline", "C0", "C1"] + models, rows))

    # ---------------------------------------------------------------- rescued leaks and rejected false flags
    best_f = max(frontier, key=lambda m: (nz(results[(m, "A1")]["macro"]), -results[(m, "A1")]["ff"])) \
        if frontier else None
    best_in = max(inhouse, key=lambda m: (nz(results[(m, "A3")]["macro"]), -results[(m, "A3")]["ff"])) \
        if inhouse else None
    for m in models:
        a1, a3 = results[(m, "A1")]["flags"], results[(m, "A3")]["flags"]
        resc = [i for i in leak_idx if a3[i] and not a1[i]]
        lost = [i for i in leak_idx if a1[i] and not a3[i]]
        rej = [i for i in range(M_ctx.n) if a1[i] and not a3[i] and not M_ctx.truth[i]]
        added = [i for i in range(M_ctx.n) if a3[i] and not a1[i] and not M_ctx.truth[i]]
        out("\n%s: A3 versus A1 -- %d leaks rescued, %d lost; %d false flags rejected, %d added"
            % (m, len(resc), len(lost), len(rej), len(added)))
        if m not in (best_f, best_in):  # the column-by-column detail only for the best frontier and in-house model
            continue
        for title, idx in (("rescued leaks (missed by A1, caught by A3)", resc),
                           ("rejected false flags (flagged by A1, cleared by A3)", rej),
                           ("lost leaks (caught by A1, missed by A3)", lost),
                           ("added false flags (flagged by A3, not by A1)", added)):
            if not idx:
                continue
            out("  %s:" % title)
            for i in idx:
                cid, column = M_ctx.keys[i]
                rr = M_ctx.risk[m][i]
                out("    %s / %s [%s]: risk %s -- LLM: %s | checks: %s"
                    % (cid, column, M_ctx.ltype[i] or M_ctx.role[i], "-" if not np.isfinite(rr) else "%.0f" % rr,
                       M_ctx.why[m].get((cid, column), "-"), M_ctx.check_reason[i]))

    # ---------------------------------------------------------------- the checks on their own
    def check_rates(ctx: Ctx, mask: np.ndarray) -> List[str]:
        n = int(mask.sum())
        return [str(n)] + ["%d" % int((ctx.fired[c] & mask).sum()) for c in CHECKS] + \
            ["%d (%.0f%%)" % (int((ctx.anyf & mask).sum()), 100.0 * (ctx.anyf & mask).sum() / n if n else 0),
             "%d" % int((ctx.dec_data & mask).sum())]

    check_head = ["columns", "count", "D1", "D2", "D3", "D4", "D5", "any", "decisive"]
    out("\nTHE CHECKS ON THEIR OWN -- hits on leaks by type, and false fires on clean columns (main tables)")
    rows = []
    for t in types:
        rows.append([t] + check_rates(M_ctx, (M_ctx.ltype == t) & M_ctx.truth))
    rows.append(["ALL LEAKS"] + check_rates(M_ctx, M_ctx.truth))
    for rl, label in (("decoy", "decoys"), ("strong", "strong predictors"), ("legit", "other legitimate")):
        rows.append([label] + check_rates(M_ctx, M_ctx.role == rl))
    out(common.format_table(check_head, rows))

    # ---------------------------------------------------------------- trap set
    trap_share: Dict[str, float] = {}
    if T_ctx is not None:
        out("\nTRAP SET (%d tables; thresholds as tuned on the main tables)" % len(trap_ids))
        rows = []
        for rl, label in (("trap", "trap columns"), ("decoy", "decoys"), ("strong", "strong predictors"),
                          ("legit", "other legitimate")):
            rows.append([label] + check_rates(T_ctx, T_ctx.role == rl))
        for k in TRAP_KINDS:
            rows.append(["  " + k] + check_rates(T_ctx, T_ctx.ttype == k))
        rows.append(["trap-table leaks"] + check_rates(T_ctx, T_ctx.truth))
        out("The checks on their own:")
        out(common.format_table(check_head, rows))
        traps = T_ctx.role == "trap"
        for m in models:
            blank = int(np.isnan(T_ctx.risk[m]).sum())
            if blank:
                out("note: %s has no risk for %d of the %d trap-table columns (count as not flagged; run step 3 "
                    "again)" % (m, blank, T_ctx.n))
        rows = []
        for key in [("", n) for n in settings] + [(m, n) for m in models for n in ("A1", "A3", "A3 fixed")]:
            s = settings.get(key[1]) if key[0] == "" else per_model[key[0]].get(key[1])
            if not s:
                continue
            f = T_ctx.flags(s)
            share = float((f & traps).sum()) / max(1, int(traps.sum()))
            trap_share[(key[0] + " " + key[1]).strip()] = share
            leaks_hit = "%d / %d" % (int((f & T_ctx.truth).sum()), int(T_ctx.truth.sum()))
            rows.append([(key[0] + " " + key[1]).strip(), leaks_hit,
                         "%d / %d (%.0f%%)" % (int((f & traps).sum()), int(traps.sum()), 100 * share)]
                        + ["%d" % int((f & (T_ctx.ttype == k)).sum()) for k in TRAP_KINDS]
                        + [int((f & ~T_ctx.truth & ~traps).sum())])
        out("Methods on the trap set:")
        out(common.format_table(["method", "leaks caught", "trap columns flagged", "planned date", "time trend",
                                 "sparse signal", "high-card code", "other false flags"], rows))
        if best_f:
            f = T_ctx.flags(per_model[best_f]["A3"])
            hit = [i for i in range(T_ctx.n) if f[i] and traps[i]]
            if hit:
                out("Trap columns flagged by %s A3:" % best_f)
                for i in hit:
                    cid, column = T_ctx.keys[i]
                    rr = T_ctx.risk[best_f][i]
                    out("  %s / %s [%s]: risk %s -- LLM: %s | checks: %s"
                        % (cid, column, T_ctx.ttype[i], "-" if not np.isfinite(rr) else "%.0f" % rr,
                           T_ctx.why[best_f].get((cid, column), "-"), T_ctx.check_reason[i]))

    # ---------------------------------------------------------------- in-house candidates
    if inhouse:
        c1 = results[("", "C1 checks OR column check")]
        out("\nIN-HOUSE CANDIDATES (open-weight models a bank could run on its own servers; bar: A3 macro recall >= %.2f;"
            " C1, the checks with no AI, reaches %s)" % (LOCAL_RECALL, fmt_r(c1["macro"])))
        rows = []
        for m in inhouse + [x for x in frontier]:
            a0, a3 = results[(m, "A0")], results[(m, "A3")]
            share = trap_share.get(m + " A3")
            rows.append([m + ("" if m in inhouse else " (frontier, for reference)"),
                         "%s / %d" % (fmt_r(a0["macro"]), a0["ff"]), "%s / %d" % (fmt_r(a3["macro"]), a3["ff"]),
                         "%+.2f" % (a3["macro"] - c1["macro"]), "-" if share is None else "%.0f%%" % (100 * share),
                         ("PASS" if a3["macro"] >= LOCAL_RECALL - 1e-12 else "FAIL") if m in inhouse else "-"])
        out(common.format_table(["model", "A0 (LLM only): macro / false flags", "A3: macro / false flags",
                                 "A3 minus C1", "trap columns flagged (A3)", "bar"], rows))

    # ---------------------------------------------------------------- rules and verdict
    out("\nRULES (fixed in advance)")
    out("  CHECKS PASS: (a) for the best frontier model, A3 needs >= %.0f%% fewer false flags than A1 at the same macro "
        "recall (both at their fewest false flags with macro >= A1's - %.2f); or (b) for DeepSeek or an in-house model, "
        "A3 lifts macro recall by >= %.2f over its A1" % (100 * FF_CUT, RECALL_SLACK, LIFT))
    out("  TRAP RULE: on the trap set, A3 with the best frontier model flags at most %.0f%% of the trap columns"
        % (100 * TRAP_MAX))
    out("  IN-HOUSE PASS: an open-weight model (local, or open-... through OpenRouter) reaches A3 macro recall >= %.2f"
        % LOCAL_RECALL)
    out("  GO if all three hold.")
    out("\nVERDICT")
    fails: List[str] = []
    checks_pass = False
    if not models:
        out("  no LLM scores (run step 3) -- the rules need them")
    if best_f:
        a1 = results[(best_f, "A1")]
        low = per_model[best_f]["A3 fewest false flags"]
        low1 = per_model[best_f]["A1 fewest false flags"]
        if low and low1:
            r3 = S.evaluate(M_ctx.flags(low))
            r1 = S.evaluate(M_ctx.flags(low1))
            cut = 1.0 - r3["ff"] / float(r1["ff"]) if r1["ff"] else 0.0
            ok = r1["ff"] > 0 and cut >= FF_CUT - 1e-12
            old = 1.0 - r3["ff"] / float(a1["ff"]) if a1["ff"] else 0.0
            out("  (a) best frontier model %s, both at their fewest false flags with macro >= %.2f: A1 needs %d (macro "
                "%.2f), A3 needs %d (macro %.2f): a cut of %.0f%% (needs >= %.0f%%) -> %s"
                % (best_f, a1["macro"] - RECALL_SLACK, r1["ff"], r1["macro"], r3["ff"], r3["macro"], 100 * cut,
                   100 * FF_CUT, "PASS" if ok else "FAIL"))
            out("      for reference, against A1 at its tuned setting (%d false flags, macro %.2f) the cut reads %.0f%%; "
                "that comparison gave A3 a tuning step A1 did not get, so it no longer decides" % (a1["ff"],
                                                                                                  a1["macro"], 100 * old))
        else:
            ok = False
            out("  (a) best frontier model %s: no A3 setting reaches A1's macro recall %.2f - %.2f within the budget "
                "-> FAIL" % (best_f, a1["macro"], RECALL_SLACK))
        checks_pass |= ok
    for m in models:
        if base_model(m) == "deepseek" or m in inhouse:
            lift = results[(m, "A3")]["macro"] - results[(m, "A1")]["macro"]
            ok = lift >= LIFT - 1e-12
            out("  (b) %s: A1 macro %.2f -> A3 macro %.2f, lift %+.2f (needs >= %.2f) -> %s"
                % (m, results[(m, "A1")]["macro"], results[(m, "A3")]["macro"], lift, LIFT, "PASS" if ok else "FAIL"))
            checks_pass |= ok
    if models:
        out("  CHECKS PASS: %s" % ("yes" if checks_pass else "no"))
        if not checks_pass:
            fails.append("CHECKS PASS")
    missing: List[str] = []  # parts that could not be evaluated
    trap_ok = None
    if T_ctx is not None and best_f and np.isnan(T_ctx.risk[best_f]).all():
        out("  TRAP RULE: not evaluated -- %s has no scores for the trap tables (run step 3 again)" % best_f)
        missing.append("TRAP RULE not evaluated (no LLM scores for the trap tables)")
    elif T_ctx is not None and best_f:
        share = trap_share.get(best_f + " A3", 0.0)
        trap_ok = share <= TRAP_MAX + 1e-12
        out("  TRAP RULE: %s A3 flags %.0f%% of the trap columns (C0: %.0f%%; limit %.0f%%) -> %s"
            % (best_f, 100 * share, 100 * trap_share.get("C0 checks only", 0.0), 100 * TRAP_MAX,
               "PASS" if trap_ok else "FAIL"))
        if not trap_ok:
            fails.append("TRAP RULE")
    elif T_ctx is None:
        out("  TRAP RULE: no trap tables scored (run steps 1, 2, 3 and 5 again)")
        missing.append("TRAP RULE not evaluated (no trap tables)")
    if inhouse:
        passing = []
        for m in inhouse:
            ok = results[(m, "A3")]["macro"] >= LOCAL_RECALL - 1e-12
            out("  IN-HOUSE PASS: %s A3 macro recall %.2f (needs >= %.2f) -> %s"
                % (m, results[(m, "A3")]["macro"], LOCAL_RECALL, "PASS" if ok else "FAIL"))
            if ok:
                passing.append(m)
        if passing:
            out("  IN-HOUSE PASS: yes (%s)" % ", ".join(passing))
        else:
            out("  IN-HOUSE PASS: no")
            fails.append("IN-HOUSE PASS")
    else:
        out("  IN-HOUSE: not run (no local or open model in %s)" % LLM_FILE)
        missing.append("IN-HOUSE: not run")
    if not models:
        verdict = "INCOMPLETE (no LLM scores)"
    elif fails:
        verdict = "NO GO -- failed: %s%s" % (", ".join(fails), ("; " + "; ".join(missing)) if missing else "")
    elif missing:
        verdict = "INCOMPLETE -- everything evaluated passed; %s" % "; ".join(missing)
    else:
        verdict = "GO"
    out("\nVERDICT: " + verdict)
    out("Caveat: thresholds are tuned on the same data, which is optimistic for every method equally; the sample is "
        "small, so read the results as directional.")
    with open(common.path(OUT_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n(written to %s)" % OUT_FILE)


if __name__ == "__main__":
    main()
