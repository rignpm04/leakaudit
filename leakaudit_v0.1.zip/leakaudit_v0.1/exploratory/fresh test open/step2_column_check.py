# step2_column_check.py -- step 2 of the leakage-auditor quick test: the vendor-style baseline. Each column is scored
# on its own, out of fold: how well does a small gradient-boosting model predict the target from that one column?
# Vendors flag the very predictive ones as likely leaks. Python 3.9; press Run in PyCharm after step 1. No keys needed.
#
# Column preparation: numeric (or more than 95% numeric text) -> float; else a date (more than 90% parse) -> days since
# 1970; else categorical: the MAX_CATEGORIES most frequent values, the rest "__other__", missing "__missing__".
# Score: binary = ROC AUC of out-of-fold predictions. Regression gets three scores, all from the same out-of-fold
# predictions: normalized Gini on the AUC scale ((Gini_norm + 1) / 2, the measure DataRobot uses; equals the AUC for a
# 0/1 target), concordance ((Kendall tau_b + 1) / 2 on up to 5000 rows) and R^2 (clipped at 0). The 'score' column holds
# the one picked by REGRESSION_SCORE; step 4 also tries the others and keeps the strongest version of the check.
# A column with a single value scores 0.5 (R^2 0).
# Output: scores_column_check.csv (one row per case and column), and the top 5 columns per case on screen.

import os
import sys
import time
import warnings
from typing import Any, Dict, List, Tuple

# ============================================================ settings (edit here)
N_FOLDS = 3
MAX_ROWS = 20000          # rows used per case (random sample; binary targets keep their positive share)
SEED = 7
MAX_CATEGORIES = 200      # most frequent values kept per categorical column (at most 253)
REGRESSION_SCORE = "gini" # regression score copied into 'score': "gini", "concordance" or "r2"

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy.stats import kendalltau  # noqa: E402
from sklearn.metrics import roc_auc_score  # noqa: E402
from sklearn.model_selection import KFold, StratifiedKFold  # noqa: E402

try:
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
except ImportError:  # scikit-learn older than 1.0
    from sklearn.experimental import enable_hist_gradient_boosting  # noqa: F401
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

OUT_FILE = "scores_column_check.csv"
FIELDS = ["case_id", "column", "inferred_type", "task", "score", "score_gini", "score_concordance", "score_r2",
          "n_rows", "n_unique", "missing_rate", "is_leak", "is_probable", "kind"]


def prepare(s: pd.Series) -> Tuple[np.ndarray, bool, str]:
    """One column as model input: (n x 1 array, categorical?, inferred type)."""
    col_type, values = common.analyze_column(s)
    if col_type == "numeric":
        return values.to_numpy(dtype=float).reshape(-1, 1), False, col_type
    if col_type == "date":
        return common.days_since_epoch(values).to_numpy(dtype=float).reshape(-1, 1), False, col_type
    present = s.notna()
    txt = s.astype(str).where(present, "__missing__")
    top = txt[present].value_counts().index[:min(MAX_CATEGORIES, 253)]
    txt = txt.where(txt.isin(top) | ~present, "__other__")
    codes, _ = pd.factorize(txt, sort=True)
    return codes.astype(float).reshape(-1, 1), True, col_type


def gini_auc_scale(y: np.ndarray, pred: np.ndarray) -> float:
    """Normalized Gini of pred against y, mapped to [0, 1] as (Gini_norm + 1) / 2. Tie-aware (average ranks); y is
    shifted to be non-negative. For a 0/1 target this equals the ROC AUC."""
    from scipy.stats import rankdata
    w = y - np.min(y)
    if not np.isfinite(w).all() or w.sum() <= 0:
        return 0.5
    n = len(w)

    def gini(order_by: np.ndarray) -> float:
        r = rankdata(order_by)  # ascending average ranks
        return 2.0 * float(np.sum(r * w)) / (n * float(w.sum())) - (n + 1.0) / n

    best = gini(w)
    if best <= 0:
        return 0.5
    return float(np.clip((gini(pred) / best + 1.0) / 2.0, 0.0, 1.0))


def oof_score(x: np.ndarray, y: np.ndarray, categorical: bool, binary: bool, folds: List[Any]) -> Dict[str, float]:
    cat = [True] if categorical else None
    oof = np.zeros(len(y), dtype=float)
    for tr, te in folds:
        if binary:
            m = HistGradientBoostingClassifier(max_iter=100, early_stopping=False, random_state=SEED,
                                               categorical_features=cat)
            m.fit(x[tr], y[tr])
            oof[te] = m.predict_proba(x[te])[:, 1]
        else:
            m = HistGradientBoostingRegressor(max_iter=100, early_stopping=False, random_state=SEED,
                                              categorical_features=cat)
            m.fit(x[tr], y[tr])
            oof[te] = m.predict(x[te])
    if binary:
        auc = float(roc_auc_score(y, oof))
        return {"score_gini": auc, "score_concordance": auc, "score_r2": float("nan")}
    idx = np.random.RandomState(SEED).choice(len(y), size=min(5000, len(y)), replace=False)
    tau = kendalltau(oof[idx], y[idx])[0]
    conc = 0.5 if tau is None or not np.isfinite(tau) else float(tau + 1.0) / 2.0
    sst = float(np.sum((y - y.mean()) ** 2))
    r2 = 0.0 if sst <= 0 else max(0.0, 1.0 - float(np.sum((y - oof) ** 2)) / sst)
    return {"score_gini": gini_auc_scale(y, oof), "score_concordance": conc, "score_r2": r2}


def score_case(case: Dict[str, Any]) -> List[Dict[str, Any]]:
    df = common.read_data(case["id"])
    if common.TARGET not in df.columns:
        raise ValueError("data/%s.csv.gz has no 'target' column -- run step 1 again" % case["id"])
    binary = case["task"] == "binary"
    df = df[df[common.TARGET].notna()]
    if len(df) > MAX_ROWS:
        df = df.loc[common.sample_index(df[common.TARGET], MAX_ROWS, SEED, stratify=binary)]
    df = df.reset_index(drop=True)
    y = df[common.TARGET].to_numpy(dtype=int if binary else float)
    if binary:
        if min(int((y == 1).sum()), int((y == 0).sum())) < N_FOLDS:
            raise ValueError("fewer than N_FOLDS positives or negatives")
        folds = list(StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED).split(np.zeros(len(y)), y))
    else:
        folds = list(KFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED).split(np.zeros(len(y))))

    columns = [c for c in df.columns if c != common.TARGET]
    leak, probable = set(case["leak_columns"]), set(case["probable_leak_columns"])
    gone = sorted((leak | probable) - set(columns))
    if gone:
        print("  note: %s listed in cases.json but not in the data -- run step 1 again" % gone)
    rows = []
    for c in columns:
        s = df[c]
        x, categorical, col_type = prepare(s)
        if s.nunique(dropna=False) <= 1:
            sc = {"score_gini": 0.5, "score_concordance": 0.5, "score_r2": float("nan") if binary else 0.0}
        else:
            sc = oof_score(x, y, categorical, binary, folds)
        main_score = sc["score_gini"] if binary else sc["score_" + REGRESSION_SCORE]
        rows.append({"case_id": case["id"], "column": c, "inferred_type": col_type, "task": case["task"],
                     "score": round(main_score, 6),
                     "score_gini": round(sc["score_gini"], 6), "score_concordance": round(sc["score_concordance"], 6),
                     "score_r2": round(sc["score_r2"], 6) if np.isfinite(sc["score_r2"]) else "",
                     "n_rows": len(df), "n_unique": int(s.nunique(dropna=True)),
                     "missing_rate": round(float(s.isna().mean()), 6), "is_leak": int(c in leak),
                     "is_probable": int(c in probable), "kind": case["kind"]})
    return rows


def mark(r: Dict[str, Any]) -> str:
    return "[LEAK]" if r["is_leak"] else ("[probable]" if r["is_probable"] else "")


def main() -> None:
    warnings.filterwarnings("ignore", category=FutureWarning)
    if REGRESSION_SCORE not in ("gini", "concordance", "r2"):
        raise SystemExit("REGRESSION_SCORE must be 'gini', 'concordance' or 'r2'")
    print("Step 2 -- single-column out-of-fold check (%d folds, up to %d rows per case; regression score: %s)"
          % (N_FOLDS, MAX_ROWS, REGRESSION_SCORE))
    cases = common.load_cases(quiet=True)
    all_rows: List[Dict[str, Any]] = []
    done = 0
    for case in cases:
        if not common.has_data(case["id"]):
            print("\n%s: no data -- skipped (run step 1; it reports why this case failed)" % case["id"])
            continue
        t0 = time.time()
        try:
            rows = score_case(case)
        except Exception as e:
            print("\n%s: ERROR %s: %s -- skipped" % (case["id"], e.__class__.__name__, e))
            continue
        done += 1
        all_rows.extend(rows)
        ranked = sorted(rows, key=lambda r: -r["score"])
        print("\n%s (%s, %s): %d columns, %d rows, %.0f s"
              % (case["id"], case["kind"], case["task"], len(rows), rows[0]["n_rows"] if rows else 0,
                 time.time() - t0))
        for i, r in enumerate(ranked[:5]):
            print("  %3d. %-34s %.3f  %-8s %s" % (i + 1, r["column"][:34], r["score"], r["inferred_type"], mark(r)))
        rest = [(i + 1, r) for i, r in enumerate(ranked) if i >= 5 and (r["is_leak"] or r["is_probable"])]
        for rank, r in rest:
            print("  %3d. %-34s %.3f  %-8s %s" % (rank, r["column"][:34], r["score"], r["inferred_type"], mark(r)))
    if not all_rows:
        print("\nNothing scored -- run step 1 first.")
        return
    pd.DataFrame(all_rows, columns=FIELDS).to_csv(common.path(OUT_FILE), index=False)
    print("\n%d cases, %d columns scored -> %s. Next: step3_llm_audit.py" % (done, len(all_rows), OUT_FILE))


if __name__ == "__main__":
    main()
