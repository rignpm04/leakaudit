# Auditor test: step-by-step

Allow about 20 minutes of setup, then about an hour of waiting while it runs. The API cost is about $0.20 and the local model is free.

## Part A: Update your folder (5 min)

1. Unzip `leakaudit_auditor_test.zip`.
2. Copy every file from it into your existing **freshtest** folder and let it replace the old files. Do **not** delete `data/`, `llm_cache/` or your `scores_*.csv` files; they hold the answers you already paid for.
3. Open `step3_llm_audit.py` and paste your three API keys at the top, the same as last time. Don't change the model names.

## Part B: Install the local model (15–20 min, one time)

1. Go to **lmstudio.ai**, download LM Studio for Mac (Apple Silicon), install it and open it.
2. Open the **Discover** tab (magnifying glass). Search for **Qwen2.5 7B Instruct** and download a **4-bit** version (Q4_K_M, or MLX 4-bit). It is about 4–5 GB.
   - Llama 3.1 8B Instruct is a fine alternative.
   - Avoid models labelled "thinking" or "reasoning". They work, but they are 2–4 times slower.
3. Turn on Developer Mode in **Settings → Developer**, then open the **Developer** tab.
4. Click **Select a model to load** and choose the model.
   - In its load settings, set **Context Length to 16384**, then load it.
   - If you can't find the setting, load it anyway and tell me if step 3 later reports cut-off answers.
5. Switch the server on, so it shows as running at **http://localhost:1234**.
6. Copy the model's **identifier** from the Developer tab, for example `qwen2.5-7b-instruct`.
   - Or open **http://localhost:1234/v1/models** in your browser; the `"id"` value is the identifier.
   - Paste it into `LOCAL_MODEL` near the top of `step3_llm_audit.py`.
7. Leave LM Studio open and the Mac plugged in and awake until step 3 finishes.

## Part C: Run it (in PyCharm, press Run on each file)

1. **`step1_generate.py`** takes about 20 seconds. It adds 6 "trap" tables. Check these two printed lines:
   - 36 tables: `a5a2ba75…cc9298` (the same as before)
   - 42 tables: `5254adcc…978c86`
2. **`step2_column_check.py`** takes 7–10 minutes.
3. **`step3_llm_audit.py`** with `DRY_RUN = True` (as shipped). Check the estimate table:
   - DeepSeek, Claude and GPT each show **72 already cached** and about 12 new calls.
   - local shows **42 calls**.
   - If a model shows fewer than 72 cached, stop and tell me.
4. Set `DRY_RUN = False` and run step 3 again.
   - It takes about an hour, mostly the local model.
   - If it says LM Studio's server isn't running, go back to Part B, steps 4–5. Then rerun step 3 with `MODELS = ["local"]`; your other answers are kept.
5. **`step4_evaluate.py`**, then **`step5_data_checks.py`** (about 15 seconds), then **`step6_auditor_eval.py`**.
6. Send me **`results.txt`** and **`results_auditor.txt`**.

## Part D: Open-weight models through OpenRouter (about 30 minutes, about $1.50)

This tests models a bank could run on its own servers (Gemma 4 31B, Qwen3.6 27B, Qwen3.8 27B, gpt-oss-120b). OpenRouter hosts them, so nothing runs on your Mac.

1. **Let any LM Studio run finish first.** If a local run is still going, wait until step 3 prints its summary. Running two copies of step 3 at once can drop results.
2. **Get an OpenRouter key.** At **openrouter.ai**, sign up, add **$5** of credit, then create a key under **Keys** and copy it.
3. **Replace two files.** Copy the new **`step3_llm_audit.py`** and **`step6_auditor_eval.py`** into your freshtest folder, replacing the old ones. Keep everything else.
4. **Paste your settings into the new step 3.** It ships with placeholders. For this run you only need two:
   - the new key into `OPENROUTER_API_KEY`;
   - `LOCAL_MODEL` = the id of your last LM Studio model, for example `"qwen/qwen3.5-9b"`. Without it, those answers drop out of the results.
   - Then set `MODELS = ["open"]`. Your DeepSeek, Claude and GPT answers are cached, so their keys can stay as placeholders.
5. **Do a dry run.** Run step 3 with `DRY_RUN = True`. The table should show the four `open-...` models with 42 calls each and about $1.50 in all, and "still to paste: none".
6. **Do the real run.** Set `DRY_RUN = False` and run step 3 again. It takes about 10–20 minutes.
7. **Score it.** Run **`step4_evaluate.py`**, then **`step6_auditor_eval.py`**. Step 5 doesn't need rerunning.
8. **Send me `results.txt` and `results_auditor.txt`.** Step 6 now has an **IN-HOUSE CANDIDATES** table: each open model and your local one, next to the frontier models.

## What the run decides (rules fixed in advance)

- **The checks earn their place** if either of these holds:
  - for GPT, at the same recall, they need at least 30% fewer false flags (both methods tuned the same way);
  - they lift DeepSeek or an in-house model by 10 or more points.
- **Trap rule:** the checks must not get fooled by the trap columns, meaning no more than 1 trap column in 5 gets flagged.
- **An in-house model is viable** if one open-weight model, local or through OpenRouter, scores **0.78** or more with the checks. That is 5 points above the checks with no AI (0.73).
- **GO** means all three hold. Otherwise step 6 says which part failed.

## If something goes wrong

- **LM Studio answers 404:** `LOCAL_MODEL` doesn't match the identifier. Recopy it.
- **Local calls take more than 3 minutes each:** it's a thinking model or a large one. Switch to a 7–8B Instruct model.
- **LM Studio crashes or runs out of memory:** load the model with a context length of 12288 instead.
- **A certificate error:** double-click "Install Certificates.command" in Applications → Python 3.9.
