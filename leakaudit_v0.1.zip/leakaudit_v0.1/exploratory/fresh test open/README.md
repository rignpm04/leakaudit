# Fresh leakage test

The quick test couldn't separate reasoning from memory: even after disguise, every model still named 92–100% of the public datasets. This test uses tables that no model can have seen. `step1_generate.py` builds them on your computer, with leaks planted at times known by construction.

## What's in it

- **Six domains**, one prediction task each:

  | Domain | One row is | Target | Prediction moment |
  |---|---|---|---|
  | Consumer lending | a loan application | default within 12 months | at application |
  | Insurance claims | a claim | fraud found after investigation | at first notice of loss, before any investigation |
  | E-commerce orders | an order | returned | at checkout |
  | SaaS subscriptions | an account in one quarter | churned by the end of the quarter | on the first day of the quarter |
  | Hospital stays | an inpatient stay | readmitted within 30 days | at discharge |
  | Logistics shipments | a shipment | delay in hours (regression) | at dispatch |

- **Six tables per domain, 36 in all.**
  - Five tables have 3–6 planted leaks each: two with clear column names, two abbreviated (`ln_stat_cd`), and one with cryptic codes (`KL53`).
  - One table is clean and uses abbreviated names.
  - Each table has 3,000–8,000 rows and 22–29 columns, plus the target.
- **139 leak columns of eight types:**
  - final status;
  - dates after the moment;
  - totals that build up after the moment;
  - values "as of" the extract date;
  - fields filled only for some positive cases;
  - fields computed from the outcome;
  - row identifiers (SaaS and hospital only);
  - a field known at the moment but silently overwritten later. Nothing can detect this one, by design.
- **Decoys:** each table has 2–4 legitimate columns whose names sound late, such as `last_payment_date_prior_loan`.
- **Strong predictors:** each table has 1–3 strong legitimate predictors that tempt the column check.
- **Trap tables:** 6 more tables (`traps_<domain>`), used only by the auditor test below.
- **Answer key:** `cases.json` lists every leak, its type and its strength. It also lists the decoys, the strong predictors, the trap columns, and each table's moment column.

## Run order (PyCharm: open each file, press Run)

1. **`step1_generate.py`** writes `data/`, `cases.json` and `generated_checksums.txt`. It takes about 20 seconds.
   - Near the end it prints `Checksum of the 36 fresh-test tables: a5a2ba75d0c1e3831498c293c7553d785f663a4b348b399a0a696cfebdcc9298`. Yours must match.
   - The next line covers all 42 tables, the trap tables included: `5254adccb89117d017719df9f13d6cbc1d1f0b6c65b5e7e1efc4e2b5a7978c86`.
   - Older and newer numpy versions give the same tables. If yours differs, tell me.
2. **`step2_column_check.py`** runs the vendor-style column check. It takes about 6–10 minutes.
3. **`step3_llm_audit.py`** runs the LLM audit.
   - Run it once as shipped (`DRY_RUN = True`). It prints three example prompts (clear, abbreviated and cryptic names) and a cost and time estimate, and makes no calls.
   - Then paste your keys, set `DRY_RUN = False`, and run it again.
   - Only the real column names are used.
   - Each model also gets one short probe per table asking which public dataset the table comes from. This is a sanity check: no model should know.
4. **`step4_evaluate.py`** prints the verdict and writes `results.txt`. Send me that file. The trap tables are listed separately and don't change the verdict.

**Check:** if you run step 4 before step 3, it should show the baseline at a macro recall of 0.49, with 33 false flags.

## Keys, time and cost

- **Keys:** paste `DEEPSEEK_API_KEY`, `ANTHROPIC_API_KEY` and `OPENAI_API_KEY` at the top of step 3, and nowhere else. A model whose key isn't pasted is skipped.
- **First run:** 216 calls (36 tables × 3 models, plus one probe per table and model). It takes about 10–20 minutes and costs about $1.10, plus GPT's reasoning tokens. The dry run prints the estimate.
- **Caching:** every call is cached, so a rerun only pays for what failed or changed.
- **Results:** `scores_llm.csv` and `probes.csv` are rebuilt after every run from all cached answers, so leaving a model out of `MODELS` never drops its results.

## Rules, fixed in advance

- **Baseline:** the strongest version of the column check. It gets separate thresholds for classification and regression and the best of three regression scores.
- **Combined method:** a column is flagged if the column check flags it OR the LLM's risk is above its threshold.
- **Thresholds:** every method is tuned within the same budget of 1 false flag per table on average.
- **K1 – KILL** if the column check alone reaches a macro recall of 0.90 or more.
- **K2 – KILL** if the best combined method (any model) adds less than 0.15 to the baseline.
- **K4 – KILL** if, on the abbreviated-name tables, the best combined method adds less than 0.10 to the baseline on those same tables.
- **GO** if K1, K2 and K4 all pass. Step 4 names the model.
- **Cryptic names:** reported as information only.
- **Recognition:** step 4 warns if a model takes more than 15% of the tables for a known public dataset, meaning a probe guess with confidence 50 or more.
- **Breakdowns:** step 4 also breaks results down by naming style, leak type and domain, and shows the share of decoys and of strong predictors that each method flags.

These are directional results on a small sample. All methods are tuned on the same data, which flatters each of them equally.

## Auditor test (steps 5 and 6)

This test checks the auditor's second half: data checks that confirm or reject the LLM's timing claims without using the labels, plus a small model running on your own computer.

- **`step5_data_checks.py`** (local, no keys, about 15 seconds) writes `scores_checks.csv`. It runs five checks on every column:
  - **D1:** is the column filled mostly when one outcome happened?
  - **D2:** does the date fall after the prediction moment?
  - **D3:** is the column built from the target?
  - **D4:** does a repeated id share outcomes?
  - **D5:** does the value grow with the time since the moment?
- **`step6_auditor_eval.py`** (local, a few seconds) writes `results_auditor.txt`. It compares each model's audit with and without the checks, on the 36 tables and on the 6 trap tables. The trap tables hold legitimate columns built to fool the checks.
- **The local model (LM Studio):**
  1. Load a model in LM Studio and start its server (Developer tab).
  2. Paste the model id LM Studio shows into `LOCAL_MODEL` at the top of step 3.
  - Step 3 sends it the same prompts, one at a time, at no cost. If LM Studio isn't running, step 3 says so and carries on without it.
  - Step 3 starts by asking LM Studio about the model: whether it is loaded, its context length, and whether it can think. It prints advice if anything is off, such as a short context or two models loaded at once.
  - For a model that thinks, set `LOCAL_REASONING_EFFORT = "medium"` and `LOCAL_TEMPERATURE = 0.6`.
- **Open-weight models through OpenRouter (`"open"` in `MODELS`):**
  - Every model in `OPEN_MODELS` gets the same prompts. A bank could run these models on its own servers, because their weights are public; OpenRouter just hosts them for the test.
  - The shipped list is Gemma 4 31B, Qwen3.6 27B, Qwen3.8 27B and gpt-oss-120b. Each gets its own results, labeled `open-<name>`.
  - They think before answering (`OPEN_REASONING`), at temperature 0.6, and only on providers that run the full or 8-bit weights (`OPEN_QUANTIZATIONS`).
  - One key covers all of them: paste it into `OPENROUTER_API_KEY`. The dry run estimates about $1.50 for all four; the real cost, as OpenRouter reports it, is recorded with each answer.
- **Rules:** step 6 prints its rules (CHECKS PASS, TRAP RULE, IN-HOUSE PASS) and then the verdict: GO, or exactly which part failed.
  - **IN-HOUSE PASS** needs one open-weight model, local or through OpenRouter, to reach an A3 macro recall of 0.78. That is 5 points above what the checks reach with no AI.
  - **CHECKS PASS (a)** now compares A1 and A3 on equal terms: both at their fewest false flags for the same recall.

**Adding this to your existing folder:**
1. Copy the new files over the old ones. Keep `data/`, `llm_cache/` and your scores files.
2. Run step 1. It adds the 6 trap tables; your 36 tables come out byte-identical, and the checksum above proves it.
3. Run step 2. It rescores all 42 tables (about 7–10 minutes); the old 36 get the same scores as before.
4. Paste your three keys into the new step 3 again (it ships with placeholders), plus `LOCAL_MODEL`. Run it as a dry run first. The API models only make calls for the 6 trap tables, about $0.20 plus GPT's reasoning tokens. Every other prompt is unchanged, so the cache answers it.
5. Run steps 5 and 6, then send me `results_auditor.txt` and `results.txt`.

The local model makes 42 calls. At 15 tokens per second that takes about 47 minutes; a model that thinks before answering takes 2–4 times longer. The dry run prints the estimate for your settings.

## Your data stays on your computer

The tables are generated locally. Steps 1, 2, 4, 5 and 6 run locally, and so does the LM Studio model. The only thing that leaves your computer is what step 3 sends to the API providers (DeepSeek, Anthropic, OpenAI, and OpenRouter for the open models):

- the task text;
- the row count;
- a summary of each column: its name, type, missing share, number of distinct values, min / median / max or its most common categories, and a few example values.

The dry run shows you exactly what that is.

## If something fails

- **Certificate error on the Mac:** double-click "Install Certificates.command" in Applications > Python 3.9.
- **DeepSeek rejects the model name:** set `DEEPSEEK_MODEL` to the name shown in your DeepSeek console.
- **GPT answers get cut off:** `step3_log.txt` will say so. Raise `MAX_TOKENS`.
- **LM Studio answers HTTP 404:** `LOCAL_MODEL` doesn't match the loaded model's id.
- **The local model is too slow:** raise `LOCAL_TIMEOUT_S`, or use a smaller model.
- **The local model's answers come back broken:** set `LOCAL_JSON_MODE = True`.
- **A local model that thinks gets stuck repeating itself:** set `LOCAL_TEMPERATURE = 0.6`.
- **OpenRouter answers HTTP 402:** the account is out of credit. Add a few dollars and press Run again.
- **OpenRouter answers HTTP 404 for one model:** its id is wrong, or no provider fits the filters. Check the id on openrouter.ai, or allow every provider with `OPEN_QUANTIZATIONS = []` (that can include 4-bit copies of the model).
- **An open model's answers get cut off:** raise `OPEN_MAX_TOKENS`.
- **Testing without spending:** `MOCK = True` in step 3 runs the whole pipeline with a fake LLM. Its verdict means nothing.
