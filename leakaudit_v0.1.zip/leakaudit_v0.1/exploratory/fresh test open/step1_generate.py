# step1_generate.py -- step 1 of the fresh leakage test: generates 36 realistic tables that no model has seen, with
# leaks planted at known times. Python 3.9; press Run in PyCharm. No keys, no downloads.
#
# Six domains x 6 tables. Per domain: 5 tables with planted leaks (2 with clear column names, 2 abbreviated, 1 cryptic)
# and 1 clean table (abbreviated names). For every entity the generator draws pre-moment attributes and history, a
# latent risk from them that produces the outcome, post-moment events that depend on the outcome, and a fixed extract
# date after every outcome window. Leak columns come from the post-moment events (or are stored values updated after
# the outcome); decoys sound late but hold pre-moment history; strong legitimate predictors trap the vendor check.
# Plus one trap table per domain (traps_<domain>, abbreviated names, 3-5 leaks) with four legitimate columns built to
# fool label-free data checks: a planned date after the moment, a value that trends with the moment date, a mostly
# missing field that is nearly always one class when present, and a high-cardinality code whose groups share outcomes
# (cases.json: trap_columns). Every case also names its moment_column and the domain's extract_date.
#
# Output, read unchanged by steps 2-6: data/<id>.csv.gz, data/<id>.meta.json, cases.json, and generated_checksums.txt
# (a SHA-256 of every table's CSV text; compare it with the published list to verify a run). Every draw comes from
# np.random.RandomState, seeded per table from SEED, so the tables are identical on every machine and numpy version,
# and the 36 fresh-test tables are the same as before the trap tables were added.

import csv
import gzip
import hashlib
import io
import json
import math
import os
import sys
import zlib
from typing import Any, Callable, Dict, List, Optional, Tuple

# ============================================================ settings (edit here)
SEED = 20261017            # changing it gives a different set of tables
ROWS = (3000, 8000)        # rows per table
FEATURES = (22, 34)        # feature columns drawn per table (target on top); at most 20 legitimate ones, so 22-30

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
from scipy.special import ndtr, ndtri  # noqa: E402

CHECKSUM_FILE = "generated_checksums.txt"
DATE0 = np.datetime64("2022-01-01", "D")
SPAN = 730                 # moment dates are spread over two years from DATE0
LETTERS = "ABCEGHJKLMNPRSTVWXYZ"

# Leak strength tiers (0 = weak, 1 = mid, 2 = strong) and what they mean per leak type. Calibrated with step 2 so that
# the leaks' own single-column scores spread like real datasets' leaks (about 35% < 0.70, 25% 0.70-0.85, 40% >= 0.85).
TIER_P = {"outcome_status": (0.08, 0.27, 0.65), "post_event_date": (0.15, 0.33, 0.52),
          "post_aggregate": (0.12, 0.30, 0.58), "snapshot_state": (0.15, 0.33, 0.52),
          "overwrite_silent": (0.75, 0.25, 0.0), "outcome_only_sparse": (0.25, 0.37, 0.38),
          "target_derived": (0.08, 0.30, 0.62), "identifier": (1.0, 0.0, 0.0)}
PICK_WEIGHT = {"overwrite_silent": 0.6, "identifier": 0.6}  # quiet types are drawn a little less often
Q_STATUS = {0: (0.22, 0.42), 1: (0.50, 0.72), 2: (0.86, 0.97)}     # share of rows whose status follows the outcome
C_SPARSE = {0: (0.12, 0.30), 1: (0.40, 0.65), 2: (0.78, 0.95)}     # share of positives with the event date
W_ALWAYS = {0: (0.15, 0.35), 1: (0.45, 0.70), 2: (0.85, 1.00)}     # share of rows whose date follows the outcome
SIG_AGG = {0: (0.80, 1.20), 1: (0.50, 0.80), 2: (0.12, 0.30)}      # log-scale noise on post-moment aggregates
K_AGG = {0: (0.10, 0.25), 1: (0.35, 0.55), 2: (0.95, 1.00)}        # share of the outcome contrast an aggregate keeps
SD_SNAP = {0: (1.60, 2.40), 1: (0.80, 1.20), 2: (0.25, 0.45)}      # noise on snapshot shifts (in shift units)
Q_OVER = {0: (0.10, 0.28), 1: (0.35, 0.55), 2: (0.60, 0.80)}       # share of positives whose value was overwritten
C_OUTCOME = {0: (0.06, 0.28), 1: (0.38, 0.62), 2: (0.75, 0.92)}    # share of positives with the outcome-only field
C_DERIVED = {0: (0.15, 0.35), 1: (0.45, 0.70), 2: (0.85, 1.00)}    # share of positives with the derived field
LATENT_NOISE = 0.6         # outcome latent = F + 0.5 G + LATENT_NOISE x N(0, 1) (+ entity effect)
STRONG_LOAD = (0.80, 0.95)  # loading of a strong legitimate predictor on the main risk factor F


# ============================================================ small helpers
def day_of(s: str) -> int:
    return int((np.datetime64(s, "D") - DATE0).astype(int))


def day_str(days: np.ndarray) -> np.ndarray:
    out = np.full(len(days), None, dtype=object)
    ok = ~np.isnan(days)
    if ok.any():
        d = DATE0 + np.floor(days[ok]).astype("int64").astype("timedelta64[D]")
        out[ok] = np.datetime_as_string(d, unit="D")
    return out


def ts_str(hours: np.ndarray) -> np.ndarray:
    out = np.full(len(hours), None, dtype=object)
    ok = ~np.isnan(hours)
    if ok.any():
        t = DATE0.astype("datetime64[m]") + np.round(hours[ok] * 60).astype("int64").astype("timedelta64[m]")
        out[ok] = [s.replace("T", " ") for s in np.datetime_as_string(t, unit="m")]
    return out


def amount(d: np.ndarray, median: float, sigma: float, step: float) -> np.ndarray:
    return np.round(median * np.exp(sigma * d) / step) * step


def ratio(d: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return lo + (hi - lo) * ndtr(d)


def intr(d: np.ndarray, lo: int, hi: int) -> np.ndarray:
    return np.clip(np.floor(lo + (hi - lo + 1) * ndtr(d)), lo, hi)


def score(d: np.ndarray, mean: float, sd: float, lo: float, hi: float) -> np.ndarray:
    return np.clip(np.round(mean + sd * d), lo, hi)


def cat(d: np.ndarray, levels: List[Any], probs: List[float]) -> np.ndarray:
    """Levels by thresholds on the driver: later levels go with higher risk."""
    p = np.asarray(probs, dtype=float)
    edges = np.cumsum(p / p.sum())[:-1]
    return np.array(levels, dtype=object)[np.searchsorted(edges, ndtr(d), side="right")]


def flag(d: np.ndarray, prob: float, yes: str = "Y", no: str = "N") -> np.ndarray:
    return np.where(d > ndtri(1.0 - prob), yes, no).astype(object)


def pick(r: np.random.RandomState, n: int, levels: List[Any], probs: List[float]) -> np.ndarray:
    p = np.asarray(probs, dtype=float)
    return np.array(levels, dtype=object)[r.choice(len(levels), size=n, p=p / p.sum())]


def pois(r: np.random.RandomState, d: np.ndarray, mean: float, k: float) -> np.ndarray:
    return r.poisson(mean * np.exp(k * d - 0.5 * k * k)).astype(float)


def unif(r: np.random.RandomState, lo: Any, hi: Any, n: int) -> np.ndarray:
    return lo + (np.asarray(hi, dtype=float) - lo) * r.uniform(size=n)


def codes(r: np.random.RandomState, k: int, maker: Callable[[np.random.RandomState], str]) -> List[str]:
    out, seen = [], set()
    while len(out) < k:
        c = maker(r)
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def postal_codes(r: np.random.RandomState, n: int, k: int) -> np.ndarray:
    """High-cardinality postal-prefix codes (letter digit letter) with a long-tailed frequency."""
    def maker(g: np.random.RandomState) -> str:
        return "%s%d%s" % (LETTERS[g.randint(0, len(LETTERS))], g.randint(0, 10), LETTERS[g.randint(0, len(LETTERS))])
    pool = codes(r, k, maker)
    w = 1.0 / np.arange(1, k + 1) ** 0.8
    return np.array(pool, dtype=object)[r.choice(k, size=n, p=w / w.sum())]


def cryptic_names(r: np.random.RandomState, k: int) -> List[str]:
    makers = [lambda g: "F_%03d" % g.randint(1, 1000),
              lambda g: "X%d%s" % (g.randint(0, 10), LETTERS[g.randint(0, len(LETTERS))]),
              lambda g: "C%02d" % g.randint(1, 100),
              lambda g: "V_%03d" % g.randint(1, 1000),
              lambda g: "K%s%d" % (LETTERS[g.randint(0, len(LETTERS))], g.randint(10, 100)),
              lambda g: "Q%03d" % g.randint(1, 1000)]
    return codes(r, k, lambda g: makers[g.randint(0, len(makers))](g))


def installment(amt: np.ndarray, rate_pct: np.ndarray, term: np.ndarray) -> np.ndarray:
    i = rate_pct / 1200.0
    return np.round(amt * i / (1.0 - (1.0 + i) ** (-term)), 2)


# ============================================================ one table under construction
class TableGen:
    """Holds the risk factors, the outcome and every candidate column of one table."""

    def __init__(self, r: np.random.RandomState, n: int, strong: List[str],
                 F: Optional[np.ndarray] = None, G: Optional[np.ndarray] = None):
        self.r, self.n, self.strong = r, n, set(strong)
        self.F = r.normal(size=n) if F is None else F      # main risk factor
        self.G = r.normal(size=n) if G is None else G      # secondary risk factor
        self.cols: Dict[str, Dict[str, Any]] = {}
        self.md = np.zeros(n)
        self.pos = np.zeros(n, dtype=int)
        self.target: Optional[np.ndarray] = None

    def drv(self, key: str, load: float, gload: float = 0.0) -> np.ndarray:
        """A standard-normal driver for one feature; strong predictors load heavily on F."""
        a = load
        if key in self.strong:
            a = (1.0 if load >= 0 else -1.0) * self.r.uniform(*STRONG_LOAD)
        s = math.sqrt(max(0.0, 1.0 - a * a - gload * gload))
        return a * self.F + gload * self.G + s * self.r.normal(size=self.n)

    def add(self, key: str, clear: str, abbr: str, values: Any, role: str = "legit", ltype: Optional[str] = None,
            dec: Optional[int] = None, miss: float = 0.0) -> None:
        v = np.asarray(values)
        if v.dtype != object:
            v = v.astype(float)
        if miss > 0:
            m = self.r.uniform(size=self.n) < miss
            v = v.copy()
            v[m] = None if v.dtype == object else np.nan
        if role == "legit" and key in self.strong:
            role = "strong"
        self.cols[key] = {"values": v, "role": role, "ltype": ltype, "clear": clear, "abbr": abbr, "dec": dec}

    def outcome_binary(self, rate: float, extra: Optional[np.ndarray] = None) -> None:
        L = self.F + 0.5 * self.G + LATENT_NOISE * self.r.normal(size=self.n)
        if extra is not None:
            L = L + extra
        self.set_binary(L, rate)

    def set_binary(self, L: np.ndarray, rate: float) -> None:
        k = int(round(rate * len(L)))
        y = np.zeros(len(L), dtype=int)
        y[np.argsort(-L, kind="mergesort")[:k]] = 1
        self.pos, self.target = y, y.astype(float)

    # ---------------------------------------------------------------- leak makers (tier: 0 weak, 1 mid, 2 strong)
    def tv(self, tier: int, ranges: Dict[int, Tuple[float, float]]) -> float:
        return float(self.r.uniform(*ranges[tier]))

    def mk_status(self, tier: int, pos_lv: List[str], pos_p: List[float], neg_lv: List[str],
                  neg_p: List[float]) -> np.ndarray:
        """Final status / disposition: follows the outcome for a share q of rows, else drawn from the overall mix."""
        r, n = self.r, self.n
        q = self.tv(tier, Q_STATUS)
        true = np.where(self.pos == 1, pick(r, n, pos_lv, pos_p), pick(r, n, neg_lv, neg_p))
        rate = self.pos.mean()
        levels = list(dict.fromkeys(list(pos_lv) + list(neg_lv)))
        mix = [rate * (pos_p[pos_lv.index(v)] / sum(pos_p) if v in pos_lv else 0.0)
               + (1 - rate) * (neg_p[neg_lv.index(v)] / sum(neg_p) if v in neg_lv else 0.0) for v in levels]
        noise = pick(r, n, levels, mix)
        return np.where(r.uniform(size=n) < q, true, noise)

    def mk_sparse_date(self, tier: int, pos_delay: Tuple[float, float], neg_delay: Tuple[float, float],
                       extract: int) -> np.ndarray:
        """Date of a post-moment event that mostly positives have; absent if after the extract date."""
        r, n = self.r, self.n
        c_pos, c_neg = self.tv(tier, C_SPARSE), r.uniform(0.02, 0.06)
        u = r.uniform(size=n)
        present = np.where(self.pos == 1, u < c_pos, u < c_neg)
        days = np.floor(self.md + np.where(self.pos == 1, unif(r, pos_delay[0], pos_delay[1], n),
                                           unif(r, neg_delay[0], neg_delay[1], n)))
        return np.where(present & (days <= extract), days, np.nan)

    def mk_always_date(self, tier: int, pos_lo: Any, pos_hi: Any, neg_lo: Any, neg_hi: Any,
                       extract: int, open_missing: bool = False) -> np.ndarray:
        """Date of a post-moment event every row gets (last activity, closing): positives' offsets differ. A date
        after the extract is the extract date (last activity), or missing if the event has not happened yet."""
        r, n = self.r, self.n
        w = self.tv(tier, W_ALWAYS)
        off_pos = unif(r, pos_lo, pos_hi, n)
        off_neg = unif(r, neg_lo, neg_hi, n)
        follow = r.uniform(size=n) < w
        pooled = np.where(r.uniform(size=n) < self.pos.mean(), off_pos, off_neg)
        off = np.where(follow, np.where(self.pos == 1, off_pos, off_neg), pooled)
        days = np.floor(self.md + off)
        return np.where(days <= extract, days, np.nan) if open_missing else np.minimum(days, extract)

    def mk_agg(self, tier: int, base: np.ndarray, pos_mult: np.ndarray, neg_mult: np.ndarray,
               step: float, cap: Any = None) -> np.ndarray:
        """Cumulative post-moment amount: base x outcome-dependent multiplier x log-normal noise, at most cap."""
        s, k = self.tv(tier, SIG_AGG), self.tv(tier, K_AGG)
        mult = np.where(self.pos == 1, neg_mult + k * (pos_mult - neg_mult), neg_mult)
        v = base * mult * np.exp(s * np.clip(self.r.normal(size=self.n), -2.5, 2.5))
        if cap is not None:
            v = np.minimum(v, cap)
        return np.round(v / step) * step

    def mk_count(self, tier: int, lam_neg: float, lam_pos: float) -> np.ndarray:
        """Post-moment count (contacts, tickets, scans): Poisson with an outcome-dependent rate."""
        s, k = self.tv(tier, SIG_AGG), self.tv(tier, K_AGG)
        lam = np.where(self.pos == 1, lam_neg + k * (lam_pos - lam_neg), lam_neg)
        lam = lam * np.exp(s * np.clip(self.r.normal(size=self.n), -2.5, 2.5) - 0.5 * s * s)
        return self.r.poisson(lam).astype(float)

    def mk_zero_amount(self, tier: int, amt: np.ndarray, neg_cov: Tuple[float, float] = (0.01, 0.05),
                       neg_amt: Optional[np.ndarray] = None) -> np.ndarray:
        """Amount that only some rows get after the moment (recoveries, refunds, reserves): mostly positives."""
        r, n = self.r, self.n
        c_pos, c_neg = self.tv(tier, C_SPARSE), r.uniform(*neg_cov)
        u = r.uniform(size=n)
        present = np.where(self.pos == 1, u < c_pos, u < c_neg)
        v = amt if neg_amt is None else np.where(self.pos == 1, amt, neg_amt)
        return np.where(present, np.round(v, 2), 0.0)

    def mk_snapshot(self, tier: int, base: np.ndarray, pos_shift: float, neg_shift: float, lo: float,
                    hi: float, dec: int) -> np.ndarray:
        """Value as of the extract date: the moment value moved by an outcome-dependent shift plus noise."""
        sd = self.tv(tier, SD_SNAP) * abs(pos_shift - neg_shift)
        v = base + np.where(self.pos == 1, pos_shift, neg_shift) + sd * self.r.normal(size=self.n)
        return np.round(np.clip(v, lo, hi), dec)

    def mk_snapshot_cat(self, tier: int, values: np.ndarray, pos_lv: List[str], pos_p: List[float]) -> np.ndarray:
        """Category as of the extract date: positives moved to an end state, the rest keep their value."""
        r, n = self.r, self.n
        q = self.tv(tier, Q_STATUS)
        moved = (self.pos == 1) & (r.uniform(size=n) < q)
        drift = (self.pos == 0) & (r.uniform(size=n) < 0.03)
        end = pick(r, n, pos_lv, pos_p)
        return np.where(moved | drift, end, values)

    def mk_overwrite(self, tier: int, values: np.ndarray, bad: str) -> np.ndarray:
        """An attribute known at the moment whose stored value was updated after the outcome (silent)."""
        r, n = self.r, self.n
        q = self.tv(tier, Q_OVER)
        u = r.uniform(size=n)
        over = np.where(self.pos == 1, u < q, u < 0.02)
        v = values.copy()
        v[over] = bad
        return v

    def mk_outcome_sparse(self, tier: int, lv: List[str], p: List[float]) -> np.ndarray:
        """A field only some positives have (agency codes, referral ids, reasons)."""
        r, n = self.r, self.n
        c = self.tv(tier, C_OUTCOME)
        v = pick(r, n, lv, p)
        v[~((self.pos == 1) & (r.uniform(size=n) < c))] = None
        return v

    def mk_days_to(self, tier: int, lo: float, hi: float) -> np.ndarray:
        """Days from the moment to the outcome event, filled for (some) positives only."""
        r, n = self.r, self.n
        c = self.tv(tier, C_DERIVED)
        d = np.floor(unif(r, lo, hi + 1, n))
        return np.where((self.pos == 1) & (r.uniform(size=n) < c), d, np.nan)

    def mk_ids(self, entity: np.ndarray, prefix: str, digits: int) -> np.ndarray:
        def maker(g: np.random.RandomState) -> str:
            return prefix + "".join(str(g.randint(0, 10)) for _ in range(digits))
        ids = codes(self.r, int(entity.max()) + 1, maker)
        return np.array(ids, dtype=object)[entity]


LeakSpec = Tuple[str, str, str, Optional[int], Callable[[int], np.ndarray]]  # clear, abbr, type, decimals, maker


def add_leaks(T: TableGen, plan: Dict[str, Any], specs: Dict[str, LeakSpec]) -> None:
    for key, tier in plan["leaks"].items():
        clear, abbr, ltype, dec, fn = specs[key]
        T.add(key, clear, abbr, fn(tier), role="leak", ltype=ltype, dec=dec)


# ============================================================ trap columns (the 6 trap tables only)
# Legitimate columns built to fool label-free data checks, one of each kind per trap table: a date planned at the
# moment but falling after it, a value that trends with the moment date, a mostly missing pre-moment field that is
# nearly always one class when present, and a high-cardinality code (not an entity id) whose groups share outcomes.
# The other 36 tables never run this code, so they stay byte-identical.
TRAP_GROUPS = (40, 160)             # codes of the high-cardinality signal
TRAP_GROUP_SD = 1.0                 # SD of one code's effect on the latent risk
TRAP_SPARSE_SHARE = (0.03, 0.06)    # share of rows with the sparse field
TRAP_SPARSE_PURITY = (0.90, 0.94)   # share of those rows in the positive class (binary tasks)


def trap_group(r: np.random.RandomState, n_units: int, plan: Dict[str, Any], prefix: str,
               digits: int) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    """Trap tables only: a code per unit (row, account or stay), with uneven group sizes, and its latent effect."""
    if not plan.get("traps"):
        return None
    k = int(r.randint(TRAP_GROUPS[0], TRAP_GROUPS[1] + 1))

    def maker(g: np.random.RandomState) -> str:
        return prefix + "".join(str(g.randint(0, 10)) for _ in range(digits))
    labels = np.array(codes(r, k, maker), dtype=object)
    w = 1.0 / np.arange(1, k + 1) ** 0.7
    idx = r.choice(k, size=n_units, p=w / w.sum())
    effect = r.normal(0.0, TRAP_GROUP_SD, size=k)
    return labels[idx], effect[idx]


def trap_sparse_rows(r: np.random.RandomState, pos: np.ndarray) -> np.ndarray:
    """Rows that have the sparse field: a few percent of rows, TRAP_SPARSE_PURITY of them positive."""
    n = len(pos)
    k = max(25, int(round(r.uniform(*TRAP_SPARSE_SHARE) * n)))
    k_pos = min(int(round(r.uniform(*TRAP_SPARSE_PURITY) * k)), int(pos.sum()))
    rows = np.zeros(n, dtype=bool)
    rows[r.choice(np.flatnonzero(pos == 1), size=k_pos, replace=False)] = True
    rows[r.choice(np.flatnonzero(pos == 0), size=k - k_pos, replace=False)] = True
    return rows


def trap_sparse_rows_reg(r: np.random.RandomState, y: np.ndarray) -> np.ndarray:
    """Regression version: most rows with the field come from the top tail of the target."""
    n = len(y)
    k = max(25, int(round(r.uniform(*TRAP_SPARSE_SHARE) * n)))
    k_hi = int(round(0.9 * k))
    hi = np.argsort(-y, kind="mergesort")[:k]
    rows = np.zeros(n, dtype=bool)
    rows[r.choice(hi, size=k_hi, replace=False)] = True
    rows[r.choice(np.flatnonzero(~rows), size=k - k_hi, replace=False)] = True
    return rows


def add_traps(T: TableGen, traps: List[Tuple[str, str, str, str, Any, Optional[int]]]) -> None:
    """(key, clear name, abbreviated name, trap type, values, decimals) for each trap column."""
    for key, clear, abbr, ttype, values, dec in traps:
        T.add(key, clear, abbr, values, role="trap", ltype=ttype, dec=dec)


# ============================================================ domain 1: consumer lending
def gen_lending(r: np.random.RandomState, n: int, plan: Dict[str, Any]) -> TableGen:
    T = TableGen(r, n, plan["strong"])
    ext = day_of(DOMAINS["lending"]["extract"])
    T.md = md = np.floor(r.uniform(0, SPAN, size=n))
    T.add("application_date", "application_date", "app_dt", day_str(md), role="moment")
    income = np.clip(amount(T.drv("annual_income", -0.20), 64000, 0.45, 100), 12000, 400000)
    T.add("annual_income", "annual_income", "ann_inc_amt", income, dec=0, miss=0.03)
    amt = np.clip(amount(T.drv("requested_amount", 0.10), 11000, 0.60, 100), 1000, 40000)
    T.add("requested_amount", "requested_amount", "req_amt", amt, dec=0)
    fico = score(T.drv("credit_score", -0.30), 705, 48, 560, 850)
    T.add("credit_score", "credit_score", "fico_scr", fico, dec=0)
    T.add("debt_to_income", "debt_to_income_pct", "dti_pct", np.round(ratio(T.drv("debt_to_income", 0.25), 1, 45), 1),
          dec=1, miss=0.02)
    rate = np.round(ratio(T.drv("interest_rate", 0.30), 5.5, 29), 2)
    T.add("interest_rate", "interest_rate_pct", "int_rt_pct", rate, dec=2)
    term = np.where(T.drv("term_months", 0.15) > ndtri(0.72), 60.0, 36.0)
    T.add("term_months", "term_months", "term_mo", term, dec=0)
    T.add("employment_length", "employment_length_yrs", "emp_len_yrs", intr(T.drv("employment_length", -0.12), 0, 30),
          dec=0, miss=0.05)
    T.add("home_ownership", "home_ownership", "home_own_cd",
          cat(T.drv("home_ownership", 0.15), ["MORTGAGE", "OWN", "RENT", "OTHER"], [0.42, 0.12, 0.43, 0.03]))
    T.add("loan_purpose", "loan_purpose", "purp_cd",
          cat(T.drv("loan_purpose", 0.12), ["HOME_IMPR", "AUTO", "DEBT_CONSOL", "CREDIT_CARD", "MEDICAL", "OTHER"],
              [0.12, 0.10, 0.45, 0.20, 0.05, 0.08]))
    T.add("revolving_utilization", "revolving_utilization_pct", "revol_util_pct",
          np.round(ratio(T.drv("revolving_utilization", 0.28), 0, 100), 1), dec=1, miss=0.01)
    T.add("open_accounts", "open_accounts", "open_acct_cnt", pois(r, T.drv("open_accounts", 0.05), 9, 0.3), dec=0)
    T.add("inquiries_6m", "inquiries_last_6m", "inq_6m_cnt", pois(r, T.drv("inquiries_6m", 0.25), 1.1, 0.6), dec=0)
    T.add("delinquencies_2y", "delinquencies_last_2y", "dlq_2y_cnt", pois(r, T.drv("delinquencies_2y", 0.25), 0.3, 0.8),
          dec=0)
    T.add("credit_history_months", "credit_history_months", "cr_hist_mo",
          intr(T.drv("credit_history_months", -0.20), 12, 480), dec=0)
    T.add("postal_prefix", "postal_prefix", "pstl_pfx", postal_codes(r, n, 320))
    T.add("application_channel", "application_channel", "app_chnl_cd",
          cat(T.drv("application_channel", 0.05), ["BRANCH", "ONLINE", "BROKER"], [0.25, 0.60, 0.15]))
    pmt = installment(amt, rate, term)
    T.add("monthly_installment", "monthly_installment", "instl_amt", pmt, dec=2)
    T.add("income_verified", "income_verified_flag", "inc_vrfy_ind", flag(T.drv("income_verified", -0.10), 0.62))
    T.add("dependents", "dependents_count", "dpnd_cnt", pois(r, T.drv("dependents", 0.05), 1.0, 0.3), dec=0)
    T.add("months_at_address", "months_at_current_address", "addr_mo", intr(T.drv("months_at_address", -0.10), 1, 240),
          dec=0, miss=0.08)
    emp = cat(T.drv("employment_status", 0.10), ["EMPLOYED", "SELF_EMPLOYED", "RETIRED", "UNEMPLOYED"],
              [0.72, 0.16, 0.08, 0.04])
    # decoys: history before the application
    T.add("prior_chargeoff_count", "prior_chargeoff_count", "prior_co_cnt",
          pois(r, T.drv("prior_chargeoff_count", 0.35), 0.15, 1.0), role="decoy", dec=0)
    has_prior = flag(T.drv("has_prior_loan", -0.05), 0.45) == "Y"
    back = np.clip(np.floor(amount(T.drv("days_since_prior_payment", 0.25), 120, 0.9, 1)), 1, 2000)
    T.add("last_payment_date_prior_loan", "last_payment_date_prior_loan", "last_pmt_dt_prior_ln",
          day_str(np.where(has_prior, md - back, np.nan)), role="decoy")
    has_dlq = flag(T.drv("ever_delinquent", 0.30), 0.38) == "Y"
    T.add("months_since_last_delinquency", "months_since_last_delinquency", "mo_since_last_dlq",
          np.where(has_dlq, intr(T.drv("months_since_last_delinquency", -0.30), 1, 120), np.nan), role="decoy", dec=0)
    T.add("prior_loans_paid_off", "prior_loans_paid_off_count", "prior_pif_cnt",
          pois(r, T.drv("prior_loans_paid_off", -0.20), 0.8, 0.5), role="decoy", dec=0)
    T.add("prior_collections_flag", "prior_collections_flag", "prior_coll_ind",
          flag(T.drv("prior_collections_flag", 0.30), 0.08), role="decoy")
    tg = trap_group(r, n, plan, "BR", 3)  # trap tables only (None otherwise, no draws)
    T.outcome_binary(plan["rate"], None if tg is None else tg[1])
    months = np.clip((ext - md) / 30.4, 0, None)
    base_paid = pmt * np.minimum(term, months)
    specs = {
        "loan_status": ("loan_status", "ln_stat_cd", "outcome_status", None, lambda t: T.mk_status(
            t, ["CO", "DFLT", "LT120"], [0.65, 0.20, 0.15], ["CUR", "PIF", "LT30"], [0.60, 0.34, 0.06])),
        "chargeoff_date": ("chargeoff_date", "co_dt", "post_event_date", None,
                           lambda t: day_str(T.mk_sparse_date(t, (120, 420), (380, 900), ext))),
        "last_payment_date": ("last_payment_date", "last_pymnt_dt", "post_event_date", None,
                              lambda t: day_str(T.mk_always_date(t, 20, 330, 0.7 * (ext - md), ext - md - 1, ext))),
        "total_paid_amount": ("total_paid_amount", "tot_pymnt_amt", "post_aggregate", 2,
                              lambda t: T.mk_agg(t, base_paid, unif(r, 0.02, 0.35, n), unif(r, 0.95, 1.08, n), 0.01,
                                                 cap=pmt * term)),
        "recovery_amount": ("recovery_amount", "recov_amt", "post_aggregate", 2,
                            lambda t: T.mk_zero_amount(t, amt * unif(r, 0.02, 0.35, n))),
        "collection_calls": ("collection_call_count", "coll_call_cnt", "post_aggregate", 0,
                             lambda t: T.mk_count(t, 0.4, 5.0)),
        "current_balance": ("current_balance", "cur_bal_amt", "snapshot_state", 2, lambda t: T.mk_agg(
            t, amt, unif(r, 0.55, 0.95, n), np.maximum(0.0, 1 - months / term) * unif(r, 0.9, 1.1, n) + 0.01, 0.01,
            cap=amt)),
        "current_credit_score": ("current_credit_score", "cur_fico_scr", "snapshot_state", 0,
                                 lambda t: T.mk_snapshot(t, fico, -85, 6, 300, 850, 0)),
        "employment_status": ("employment_status", "emp_stat_cd", "overwrite_silent", None,
                              lambda t: T.mk_overwrite(t, emp, "UNEMPLOYED")),
        "collection_agency_code": ("collection_agency_code", "coll_agcy_cd", "outcome_only_sparse", None,
                                   lambda t: T.mk_outcome_sparse(t, ["AG%02d" % i for i in range(1, 10)], [1] * 9)),
        "hardship_plan_code": ("hardship_plan_code", "hrdshp_pln_cd", "outcome_only_sparse", None,
                               lambda t: T.mk_outcome_sparse(t, ["DEFER", "REDUCE", "EXTEND"], [0.5, 0.3, 0.2])),
        "days_to_default": ("days_to_default", "days_to_dflt", "target_derived", 0, lambda t: T.mk_days_to(t, 25, 365)),
    }
    add_leaks(T, plan, specs)
    if "employment_status" not in plan["leaks"]:
        T.add("employment_status", "employment_status", "emp_stat_cd", emp)
    if tg is not None:
        sparse = trap_sparse_rows(r, T.pos)
        base = np.interp(md, [0, 75, 135, 195, 255, 320, 390, 450, 575, 730],
                         [0.25, 0.25, 0.75, 1.75, 3.25, 4.50, 4.75, 5.00, 5.25, 5.33])  # benchmark rate path
        add_traps(T, [
            ("first_payment_due_date", "first_payment_due_date", "first_pmt_due_dt", "planned_future_date",
             day_str(md + 30 + np.floor(unif(r, 0, 16, n))), None),
            ("base_rate", "benchmark_rate_pct", "bnchmk_rt_pct", "legit_time_trend", np.round(base, 2), 2),
            ("prior_bankruptcy_date", "prior_bankruptcy_date", "prior_bkrpt_dt", "legit_sparse_signal",
             day_str(np.where(sparse, md - np.floor(unif(r, 400, 3000, n)), np.nan)), None),
            ("branch_code", "branch_code", "branch_cd", "legit_high_card_signal", tg[0], None)])
    return T


# ============================================================ domain 2: insurance claims
def gen_claims(r: np.random.RandomState, n: int, plan: Dict[str, Any]) -> TableGen:
    T = TableGen(r, n, plan["strong"])
    ext = day_of(DOMAINS["claims"]["extract"])
    T.md = md = np.floor(r.uniform(0, SPAN, size=n))
    T.add("fnol_date", "first_notice_date", "fnol_dt", day_str(md), role="moment")
    lag = np.clip(np.floor(amount(T.drv("report_lag_days", 0.30), 3, 1.1, 1)), 0, 365)
    T.add("loss_date", "loss_date", "loss_dt", day_str(md - lag))
    T.add("report_lag_days", "report_lag_days", "rpt_lag_days", lag, dec=0)
    limit = cat(T.drv("coverage_limit", 0.05), [25000, 50000, 100000, 250000], [0.2, 0.35, 0.3, 0.15]).astype(float)
    T.add("coverage_limit", "coverage_limit", "cov_lmt_amt", limit, dec=0)
    to_limit = np.round(np.exp(-4.2 + 1.3 * T.drv("claim_amount_to_limit", 0.30)), 4)
    claim_amt = np.clip(np.round(to_limit * limit), 50, None)
    T.add("claim_amount_to_limit", "claim_to_limit_ratio", "clm_lmt_rt", np.round(claim_amt / limit, 4), dec=4)
    T.add("reported_amount", "reported_claim_amount", "rptd_clm_amt", claim_amt, dec=0)
    T.add("policy_tenure", "policy_tenure_months", "pol_tenure_mo", intr(T.drv("policy_tenure", -0.30), 0, 240), dec=0)
    T.add("policy_type", "policy_type", "pol_typ_cd",
          cat(T.drv("policy_type", 0.10), ["HOME", "AUTO", "RENTERS", "COMMERCIAL"], [0.30, 0.50, 0.12, 0.08]))
    T.add("deductible", "deductible_amount", "ded_amt",
          cat(T.drv("deductible", -0.05), [250, 500, 1000, 2500], [0.15, 0.45, 0.3, 0.1]).astype(float), dec=0)
    T.add("policyholder_age", "policyholder_age", "ph_age", intr(T.drv("policyholder_age", -0.20), 18, 88), dec=0)
    T.add("loss_type", "loss_type", "loss_typ_cd",
          cat(T.drv("loss_type", 0.20), ["GLASS", "WATER", "COLLISION", "FIRE", "LIABILITY", "THEFT"],
              [0.10, 0.20, 0.35, 0.07, 0.13, 0.15]))
    T.add("police_report", "police_report_filed", "plc_rpt_ind", flag(T.drv("police_report", -0.30), 0.40))
    T.add("witness_count", "witness_count", "wtns_cnt", pois(r, T.drv("witness_count", -0.15), 0.8, 0.5), dec=0)
    T.add("injury_claimed", "injury_claimed_flag", "inj_ind", flag(T.drv("injury_claimed", 0.20), 0.18))
    T.add("asset_age", "vehicle_or_property_age_yrs", "asst_age_yrs", intr(T.drv("asset_age", 0.10), 0, 60), dec=0,
          miss=0.05)
    T.add("annual_premium", "annual_premium", "ann_prem_amt", amount(T.drv("annual_premium", 0.0), 1400, 0.40, 1),
          dec=0)
    T.add("agent_channel", "agent_channel", "agt_chnl_cd",
          cat(T.drv("agent_channel", 0.15), ["CAPTIVE", "INDEPENDENT", "DIRECT", "ONLINE"], [0.35, 0.30, 0.20, 0.15]))
    T.add("postal_prefix", "postal_prefix", "pstl_pfx", postal_codes(r, n, 300))
    T.add("loss_hour", "loss_hour", "loss_hr", intr(T.drv("loss_hour", 0.10), 0, 23), dec=0, miss=0.12)
    T.add("claimant_is_policyholder", "claimant_is_policyholder", "clmt_ph_ind",
          flag(T.drv("claimant_is_policyholder", -0.10), 0.80))
    T.add("premium_payment_method", "premium_payment_method", "prem_pay_cd",
          cat(T.drv("premium_payment_method", 0.05), ["AUTOPAY", "CARD", "CHECK", "AGENT"], [0.45, 0.30, 0.15, 0.10]))
    T.add("multi_policy", "multi_policy_flag", "multi_pol_ind", flag(T.drv("multi_policy", -0.15), 0.35))
    T.add("attorney_at_fnol", "attorney_at_first_notice", "atty_fnol_ind", flag(T.drv("attorney_at_fnol", 0.30), 0.12))
    seg = cat(T.drv("customer_segment", 0.08), ["S1", "S2", "S3", "S4", "S5"], [0.25, 0.30, 0.25, 0.15, 0.05])
    # decoys
    has_prev = flag(T.drv("has_prior_claim", 0.15), 0.42) == "Y"
    T.add("days_since_last_claim", "days_since_last_claim", "days_since_prev_clm",
          np.where(has_prev, np.floor(amount(T.drv("days_since_last_claim", -0.30), 400, 0.8, 1)) + 1, np.nan),
          role="decoy", dec=0)
    T.add("prior_claim_count", "prior_claim_count_5y", "prior_clm_cnt_5y",
          pois(r, T.drv("prior_claim_count", 0.35), 0.7, 0.7), role="decoy", dec=0)
    T.add("prior_denied_claims", "prior_denied_claims_count", "prior_dnl_cnt",
          pois(r, T.drv("prior_denied_claims", 0.40), 0.12, 1.0), role="decoy", dec=0)
    T.add("last_premium_payment_date", "last_premium_payment_date", "last_prem_pmt_dt",
          day_str(md - np.floor(unif(r, 1, 45, n)) - np.where(T.drv("late_premium", 0.25) > 1.2, 60, 0)), role="decoy")
    tg = trap_group(r, n, plan, "AG", 4)  # trap tables only
    T.outcome_binary(plan["rate"], None if tg is None else tg[1])
    specs = {
        "claim_disposition": ("claim_disposition", "clm_dispo_cd", "outcome_status", None, lambda t: T.mk_status(
            t, ["DENIED", "SIU_CLOSED", "WITHDRAWN"], [0.6, 0.25, 0.15], ["PAID", "PAID_PARTIAL", "WITHDRAWN"],
            [0.8, 0.15, 0.05])),
        "siu_referral_date": ("siu_referral_date", "siu_ref_dt", "post_event_date", None,
                              lambda t: day_str(T.mk_sparse_date(t, (5, 90), (10, 120), ext))),
        "claim_closed_date": ("claim_closed_date", "clm_cls_dt", "post_event_date", None,
                              lambda t: day_str(T.mk_always_date(t, 90, 300, 10, 120, ext, open_missing=True))),
        "total_paid": ("total_paid_to_date", "tot_pd_amt", "post_aggregate", 0, lambda t: np.round(np.where(
            (T.pos == 1) & (r.uniform(size=n) < T.tv(t, C_SPARSE)), 0.0,
            np.where(r.uniform(size=n) < 0.08, 0.0, np.minimum(claim_amt * unif(r, 0.5, 1.0, n), limit))))),
        "adjuster_notes": ("adjuster_note_count", "adj_note_cnt", "post_aggregate", 0, lambda t: T.mk_count(t, 6, 22)),
        "investigation_hours": ("investigation_hours", "invst_hrs", "post_aggregate", 1,
                                lambda t: T.mk_agg(t, np.ones(n), unif(r, 12, 40, n), unif(r, 1.5, 5, n), 0.5,
                                                   cap=250.0)),
        "current_reserve": ("current_reserve_amount", "cur_rsrv_amt", "snapshot_state", 0, lambda t: np.round(
            T.mk_zero_amount(t, claim_amt * unif(r, 0.3, 1.0, n), (0.06, 0.12), claim_amt * unif(r, 0.05, 0.4, n)))),
        "policy_status_current": ("policy_status_current", "pol_stat_cur_cd", "snapshot_state", None,
                                  lambda t: T.mk_snapshot_cat(t, pick(r, n, ["ACTIVE", "LAPSED"], [0.9, 0.1]),
                                                              ["CANCELLED", "NONRENEWED"], [0.6, 0.4])),
        "customer_segment": ("customer_segment", "cust_seg_cd", "overwrite_silent", None,
                             lambda t: T.mk_overwrite(t, seg, "S5")),
        "fraud_referral_id": ("fraud_referral_id", "frd_ref_id", "outcome_only_sparse", None,
                              lambda t: T.mk_outcome_sparse(t, ["FR-%05d" % i for i in range(1, 401)], [1] * 400)),
        "days_to_fraud_finding": ("days_to_fraud_finding", "days_to_frd_fnd", "target_derived", 0,
                                  lambda t: T.mk_days_to(t, 20, 180)),
    }
    add_leaks(T, plan, specs)
    if "customer_segment" not in plan["leaks"]:
        T.add("customer_segment", "customer_segment", "cust_seg_cd", seg)
    if tg is not None:
        sparse = trap_sparse_rows(r, T.pos)
        inspected = r.uniform(size=n) < 0.75
        add_traps(T, [
            ("scheduled_inspection_date", "scheduled_inspection_date", "sched_insp_dt", "planned_future_date",
             day_str(np.where(inspected, md + np.floor(unif(r, 1, 15, n)), np.nan)), None),
            ("repair_cost_index", "repair_cost_index", "rpr_cost_idx", "legit_time_trend",
             np.round(100.0 * 1.08 ** (md / 365.0) + 0.3 * r.normal(size=n), 1), 1),
            ("prior_siu_referral_date", "prior_claim_siu_referral_date", "prior_siu_ref_dt", "legit_sparse_signal",
             day_str(np.where(sparse, md - np.floor(unif(r, 200, 2500, n)), np.nan)), None),
            ("agent_code", "agent_code", "agt_cd", "legit_high_card_signal", tg[0], None)])
    return T


# ============================================================ domain 3: e-commerce orders
def gen_orders(r: np.random.RandomState, n: int, plan: Dict[str, Any]) -> TableGen:
    T = TableGen(r, n, plan["strong"])
    ext = day_of(DOMAINS["orders"]["extract"])
    T.md = md = np.floor(r.uniform(0, SPAN, size=n))
    hour = intr(T.drv("checkout_hour", 0.05), 0, 23)
    T.add("checkout_time", "checkout_timestamp", "chkout_ts",
          ts_str(md * 24 + hour + np.floor(r.uniform(0, 60, n)) / 60), role="moment")
    T.add("checkout_hour", "checkout_hour", "chkout_hr", hour, dec=0)
    value = np.clip(amount(T.drv("order_value", 0.15), 78, 0.8, 0.01), 3, 4000)
    T.add("order_value", "order_value", "ord_val_amt", value, dec=2)
    items = 1 + pois(r, T.drv("item_count", 0.20), 1.6, 0.5)
    T.add("item_count", "item_count", "itm_cnt", items, dec=0)
    T.add("main_category", "main_category", "prim_cat_cd",
          cat(T.drv("main_category", 0.35), ["GROCERY", "BOOKS", "HOME", "ELECTRONICS", "BEAUTY", "SHOES", "APPAREL"],
              [0.08, 0.10, 0.17, 0.15, 0.10, 0.12, 0.28]))
    T.add("discount_pct", "discount_pct", "disc_pct",
          np.round(ratio(T.drv("discount_pct", 0.15), 0, 60) * (r.uniform(size=n) < 0.55), 1), dec=1)
    T.add("payment_method", "payment_method", "pay_mthd_cd",
          cat(T.drv("payment_method", 0.20), ["CARD", "WALLET", "GIFT_CARD", "COD", "BNPL"],
              [0.48, 0.25, 0.05, 0.07, 0.15]))
    T.add("shipping_speed", "shipping_speed", "ship_spd_cd",
          cat(T.drv("shipping_speed", 0.05), ["STANDARD", "EXPRESS", "NEXT_DAY"], [0.65, 0.25, 0.10]))
    T.add("customer_tenure_days", "customer_tenure_days", "cust_tenure_d",
          intr(T.drv("customer_tenure_days", -0.20), 0, 3000), dec=0)
    T.add("first_order", "first_order_flag", "first_ord_ind", flag(T.drv("first_order", 0.15), 0.18))
    T.add("device_type", "device_type", "dvc_typ_cd",
          cat(T.drv("device_type", 0.05), ["DESKTOP", "APP", "MOBILE_WEB", "TABLET"], [0.30, 0.35, 0.28, 0.07]))
    T.add("multiple_sizes", "multiple_sizes_same_item", "multi_sz_ind", flag(T.drv("multiple_sizes", 0.45), 0.14))
    T.add("promo_code", "promo_code_used", "promo_ind", flag(T.drv("promo_code", 0.10), 0.30))
    T.add("avg_item_price", "avg_item_price", "avg_itm_prc", np.round(value / items, 2), dec=2)
    T.add("postal_prefix", "postal_prefix", "pstl_pfx", postal_codes(r, n, 350))
    T.add("gift_order", "gift_order_flag", "gift_ind", flag(T.drv("gift_order", -0.10), 0.07))
    T.add("free_shipping", "free_shipping_flag", "free_ship_ind", flag(T.drv("free_shipping", 0.10), 0.45))
    T.add("product_rating", "avg_product_rating", "avg_prod_rtg",
          np.round(ratio(T.drv("product_rating", -0.25), 2.6, 5.0), 2), dec=2, miss=0.04)
    T.add("sale_items_share", "sale_items_pct", "sale_itm_pct",
          np.round(ratio(T.drv("sale_items_share", 0.10), 0, 100), 0), dec=0)
    T.add("customer_age_band", "customer_age_band", "cust_age_bnd",
          cat(T.drv("customer_age_band", 0.05), ["55+", "45-54", "35-44", "25-34", "18-24"],
              [0.12, 0.15, 0.22, 0.31, 0.20]), miss=0.10)
    tier0 = cat(T.drv("loyalty_tier", -0.10), ["PLATINUM", "GOLD", "SILVER", "BRONZE"], [0.07, 0.18, 0.30, 0.45])
    # decoys
    prev_ret = pois(r, T.drv("previous_returns", 0.40), 0.9, 0.8)
    T.add("previous_returns", "previous_return_count", "prev_rtrn_cnt", prev_ret, role="decoy", dec=0)
    T.add("last_return_date_prior", "last_return_date_before_order", "last_rtrn_dt_prior",
          day_str(np.where(prev_ret > 0, md - np.floor(amount(T.drv("days_since_return", -0.2), 90, 0.9, 1)) - 1,
                           np.nan)), role="decoy")
    T.add("prior_return_rate", "prior_return_rate", "prior_rtrn_rt",
          np.round(ratio(T.drv("prior_return_rate", 0.35), 0, 0.8), 3) * (r.uniform(size=n) > 0.15), role="decoy",
          dec=3)
    T.add("days_since_previous_order", "days_since_previous_order", "days_since_prev_ord",
          np.floor(amount(T.drv("days_since_previous_order", 0.10), 40, 0.9, 1)) + 1, role="decoy", dec=0, miss=0.12)
    tg = trap_group(r, n, plan, "SL", 5)  # trap tables only
    T.outcome_binary(plan["rate"], None if tg is None else tg[1])
    specs = {
        "order_status": ("order_status_final", "ord_stat_cd", "outcome_status", None, lambda t: T.mk_status(
            t, ["RETURNED", "REFUNDED", "EXCHANGED"], [0.55, 0.30, 0.15], ["DELIVERED", "CANCELLED", "DELIVERED_LATE"],
            [0.90, 0.04, 0.06])),
        "return_received_date": ("return_received_date", "rtrn_rcvd_dt", "post_event_date", None,
                                 lambda t: day_str(T.mk_sparse_date(t, (6, 45), (20, 80), ext))),
        "last_contact_date": ("last_customer_contact_date", "last_cntct_dt", "post_event_date", None,
                              lambda t: day_str(T.mk_always_date(t, 8, 50, 0, 15, ext))),
        "refund_amount": ("refund_amount", "rfnd_amt", "post_aggregate", 2,
                          lambda t: T.mk_zero_amount(t, value * unif(r, 0.4, 1.0, n))),
        "service_contacts": ("customer_service_contacts", "cs_cntct_cnt", "post_aggregate", 0,
                             lambda t: T.mk_count(t, 0.3, 2.5)),
        "lifetime_returns": ("customer_lifetime_returns", "cust_ltd_rtrn_cnt", "snapshot_state", 0,
                             lambda t: T.mk_snapshot(t, prev_ret + pois(r, np.zeros(n), 0.6, 0.0), 1.6, 0.0, 0, 200,
                                                     0)),
        "store_credit_balance": ("store_credit_balance", "str_crdt_bal_amt", "snapshot_state", 2,
                                 lambda t: T.mk_zero_amount(t, value * unif(r, 0.3, 1.0, n), (0.12, 0.25),
                                                            unif(r, 5, 40, n))),
        "loyalty_tier": ("loyalty_tier", "lylty_tier_cd", "overwrite_silent", None,
                         lambda t: T.mk_overwrite(t, tier0, "BRONZE")),
        "return_reason_code": ("return_reason_code", "rtrn_rsn_cd", "outcome_only_sparse", None,
                               lambda t: T.mk_outcome_sparse(t, ["SIZE", "DAMAGED", "NOT_AS_DESCRIBED", "CHANGED_MIND",
                                                                 "LATE"], [0.4, 0.15, 0.2, 0.2, 0.05])),
        "days_to_return": ("days_to_return", "days_to_rtrn", "target_derived", 0, lambda t: T.mk_days_to(t, 3, 45)),
    }
    add_leaks(T, plan, specs)
    if "loyalty_tier" not in plan["leaks"]:
        T.add("loyalty_tier", "loyalty_tier", "lylty_tier_cd", tier0)
    if tg is not None:
        sparse = trap_sparse_rows(r, T.pos)
        speed = T.cols["shipping_speed"]["values"]
        promised = np.select([speed == "NEXT_DAY", speed == "EXPRESS"],
                             [1.0, 2.0 + np.floor(unif(r, 0, 2, n))], 4.0 + np.floor(unif(r, 0, 4, n)))
        add_traps(T, [
            ("promised_delivery_date", "promised_delivery_date", "prom_dlvry_dt", "planned_future_date",
             day_str(md + promised), None),
            ("category_price_index", "category_price_index", "cat_prc_idx", "legit_time_trend",
             np.round(100.0 * 1.05 ** (md / 365.0) * np.exp(0.01 * r.normal(size=n)), 1), 1),
            ("last_chargeback_date", "last_chargeback_date_before_order", "last_chrgbk_dt", "legit_sparse_signal",
             day_str(np.where(sparse, md - np.floor(unif(r, 30, 1500, n)), np.nan)), None),
            ("seller_code", "seller_code", "slr_cd", "legit_high_card_signal", tg[0], None)])
    return T


# ============================================================ domain 4: SaaS subscriptions (account-quarters)
QUARTERS = [day_of(s) for s in ("2022-01-01", "2022-04-01", "2022-07-01", "2022-10-01", "2023-01-01", "2023-04-01",
                                "2023-07-01", "2023-10-01")]


def gen_saas(r: np.random.RandomState, n: int, plan: Dict[str, Any]) -> TableGen:
    ext = day_of(DOMAINS["saas"]["extract"])
    # accounts join in some quarter and stay, one row per quarter, until they churn or the window ends
    acct, qidx = [], []
    a = 0
    while len(acct) < int(n * 1.6):
        start = int(r.choice(8, p=[0.30, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10, 0.10]))
        acct += [a] * (8 - start)
        qidx += list(range(start, 8))
        a += 1
    acct_a, q_a = np.array(acct), np.array(qidx)
    u = r.normal(size=a)
    m = len(acct_a)
    F = 0.7 * u[acct_a] + math.sqrt(1 - 0.49) * r.normal(size=m)
    G = r.normal(size=m)
    L = F + 0.5 * G + LATENT_NOISE * r.normal(size=m) + 0.6 * u[acct_a]
    tg = trap_group(r, a, plan, "CSM", 3)  # trap tables only: one success manager per account
    if tg is not None:
        L = L + tg[1][acct_a]

    def churn_panel(thr: float) -> Tuple[np.ndarray, np.ndarray]:
        """An account churns in its first quarter with latent risk above thr; its later quarters are not observed."""
        y_ = (L > thr).astype(int)
        keep_ = np.ones(m, dtype=bool)
        gone = set()
        for i in range(m):  # rows are in account order, quarters ascending
            if acct_a[i] in gone:
                keep_[i] = False
            elif y_[i] == 1:
                gone.add(acct_a[i])
        return y_, np.flatnonzero(keep_)[:n]

    lo, hi = float(np.min(L)), float(np.max(L))
    for _ in range(30):  # threshold so that the observed churn rate matches the plan
        mid = 0.5 * (lo + hi)
        y, idx = churn_panel(mid)
        if y[idx].mean() > plan["rate"]:
            lo = mid
        else:
            hi = mid
    y, idx = churn_panel(hi)
    T = TableGen(r, len(idx), plan["strong"], F=F[idx], G=G[idx])
    T.pos, T.target = y[idx], y[idx].astype(float)
    acct_r, q_r = acct_a[idx], q_a[idx]
    n = len(idx)
    T.md = md = np.array([QUARTERS[q] for q in q_r], dtype=float)
    T.add("quarter_start", "quarter_start_date", "qtr_strt_dt", day_str(md), role="moment")
    seats = np.clip(np.round(amount(T.drv("seats", -0.10), 18, 0.9, 1)), 1, 2000)
    T.add("seats", "seats_licensed", "seat_cnt", seats, dec=0)
    plan_tier = cat(T.drv("plan_tier", -0.20), ["ENTERPRISE", "BUSINESS", "PRO", "STARTER"], [0.10, 0.25, 0.35, 0.30])
    T.add("plan_tier", "plan_tier", "plan_cd", plan_tier)
    price = np.select([plan_tier == "ENTERPRISE", plan_tier == "BUSINESS", plan_tier == "PRO"], [95.0, 55.0, 30.0],
                      12.0)
    mrr = np.round(seats * price * np.exp(0.15 * r.normal(size=n)), 2)
    T.add("mrr", "monthly_recurring_revenue", "mrr_amt", mrr, dec=2)
    T.add("contract_type", "contract_type", "cntrct_typ_cd",
          cat(T.drv("contract_type", 0.30), ["ANNUAL", "MONTHLY"], [0.55, 0.45]))
    T.add("tenure_months", "tenure_months", "tenure_mo", intr(T.drv("tenure_months", -0.25), 1, 96), dec=0)
    T.add("industry_code", "industry_code", "ind_cd", pick(r, n, ["I%02d" % i for i in range(1, 19)], [1] * 18))
    T.add("company_size_band", "company_size_band", "co_size_bnd",
          cat(T.drv("company_size_band", -0.10), ["1000+", "201-1000", "51-200", "11-50", "1-10"],
              [0.08, 0.17, 0.25, 0.30, 0.20]))
    T.add("billing_postal_prefix", "billing_postal_prefix", "bill_pstl_pfx", postal_codes(r, n, 280))
    logins = pois(r, T.drv("logins_30d", -0.35), 120, 0.7)
    T.add("logins_30d", "logins_last_30d", "login_cnt_30d", logins, dec=0)
    util = np.round(ratio(T.drv("seat_utilization", -0.45), 5, 100), 1)
    T.add("seat_utilization", "seat_utilization_pct", "seat_util_pct", util, dec=1)
    T.add("active_users_last_month", "active_users_last_month", "actv_usr_cnt_mo", np.round(seats * util / 100.0),
          dec=0)
    T.add("feature_adoption", "feature_adoption_score", "feat_adopt_scr",
          np.round(ratio(T.drv("feature_adoption", -0.30), 0, 100), 0), dec=0)
    T.add("tickets_prev_quarter", "support_tickets_prev_quarter", "tkt_cnt_prev_q",
          pois(r, T.drv("tickets_prev_quarter", 0.15), 2.0, 0.6), dec=0)
    T.add("nps", "nps_last_survey", "nps_scr", score(T.drv("nps", -0.20), 7, 2, 0, 10), dec=0, miss=0.30)
    T.add("auto_renew", "auto_renew_flag", "auto_rnw_ind", flag(T.drv("auto_renew", -0.35), 0.60))
    T.add("payment_method", "payment_method", "pay_mthd_cd",
          cat(T.drv("payment_method", 0.05), ["INVOICE", "ACH", "CARD"], [0.30, 0.20, 0.50]))
    T.add("discount_pct", "discount_pct", "disc_pct",
          np.round(ratio(T.drv("discount_pct", 0.05), 0, 30) * (r.uniform(size=n) < 0.4), 1), dec=1)
    T.add("integrations", "integrations_count", "intg_cnt", pois(r, T.drv("integrations", -0.20), 3, 0.6), dec=0)
    T.add("days_to_renewal", "days_to_renewal", "days_to_rnwl", intr(T.drv("days_to_renewal", -0.10), 1, 365), dec=0)
    T.add("admin_count", "admin_count", "admin_cnt", 1 + pois(r, T.drv("admin_count", -0.05), 1.2, 0.4), dec=0)
    health = np.round(ratio(T.drv("health_score", -0.10), 0, 100), 0)
    # decoys: history before the quarter
    T.add("last_login_date", "last_login_date", "last_login_dt",
          day_str(md - 1 - np.floor(amount(T.drv("days_since_login", 0.35), 2, 1.2, 1))), role="decoy")
    T.add("prior_downgrades", "prior_downgrade_count", "prior_dngrd_cnt",
          pois(r, T.drv("prior_downgrades", 0.35), 0.3, 0.8), role="decoy", dec=0)
    T.add("days_since_last_ticket", "days_since_last_ticket", "days_since_last_tkt",
          np.floor(amount(T.drv("days_since_last_ticket", -0.25), 45, 0.9, 1)) + 1, role="decoy", dec=0, miss=0.15)
    T.add("prev_quarter_seat_change", "prev_quarter_seat_change", "prev_q_seat_chg",
          np.round(T.drv("prev_quarter_seat_change", -0.35) * 3 + r.normal(size=n)), role="decoy", dec=0)
    # account-level fields as of the extract date: an account's cancel date, last activity and current plan show on
    # all of its rows (also the quarters before it churned)
    accts = np.unique(acct_r)
    a_pos = np.searchsorted(accts, acct_r)
    churn_day = np.full(len(accts), np.nan)
    churn_day[a_pos[T.pos == 1]] = md[T.pos == 1]
    churned = ~np.isnan(churn_day)

    def per_account(values: np.ndarray) -> np.ndarray:
        return values[a_pos]

    def cancel_dates(t: int) -> np.ndarray:
        rec = churned & (r.uniform(size=len(accts)) < T.tv(t, C_SPARSE))
        days = np.floor(churn_day + r.uniform(5, 91, size=len(accts)))
        return per_account(np.where(rec & (days <= ext), days, np.nan))

    def last_activity(t: int) -> np.ndarray:
        w = T.tv(t, W_ALWAYS)
        churn_like = np.floor(np.nan_to_num(churn_day, nan=0.0) + r.uniform(0, 60, size=len(accts)))
        active = ext - np.floor(r.uniform(0, 15, size=len(accts)))
        follow = r.uniform(size=len(accts)) < w
        # accounts that do not follow get a date unrelated to churn: somewhere between their first quarter and now
        first_day = np.array([md[a_pos == i].min() for i in range(len(accts))])
        unrelated = np.floor(first_day + r.uniform(size=len(accts)) * (ext - first_day))
        days = np.where(follow, np.where(churned, churn_like, active), unrelated)
        return per_account(days)

    def current_plan(t: int) -> np.ndarray:
        moved = churned & (r.uniform(size=len(accts)) < T.tv(t, Q_STATUS))
        return np.where(per_account(moved), "NONE", plan_tier).astype(object)

    def current_mrr(t: int) -> np.ndarray:
        s = T.tv(t, SIG_AGG)
        zeroed = per_account(churned & (r.uniform(size=len(accts)) < T.tv(t, Q_STATUS)))
        v = mrr * np.minimum(np.exp(s * np.clip(r.normal(size=n), -2.5, 2.5)), 2.5) * np.where(zeroed, 0.0, 1.0)
        return np.round(v, 2)

    specs = {
        "quarter_end_status": ("quarter_end_status", "qtr_end_stat_cd", "outcome_status", None, lambda t: T.mk_status(
            t, ["CANCELLED", "NON_RENEWED", "SUSPENDED"], [0.6, 0.3, 0.1], ["ACTIVE", "DOWNGRADED", "PAST_DUE"],
            [0.88, 0.07, 0.05])),
        "cancel_date": ("cancel_date", "cncl_dt", "post_event_date", None, lambda t: day_str(cancel_dates(t))),
        "last_activity_date": ("last_activity_date", "last_actv_dt", "post_event_date", None,
                               lambda t: day_str(last_activity(t))),
        "tickets_this_quarter": ("support_tickets_this_quarter", "tkt_cnt_cur_q", "post_aggregate", 0,
                                 lambda t: T.mk_count(t, 2.0, 6.0)),
        "logins_this_quarter": ("logins_this_quarter", "login_cnt_cur_q", "post_aggregate", 0,
                                lambda t: np.round(T.mk_agg(t, logins * 3, unif(r, 0.05, 0.4, n), unif(r, 0.8, 1.1, n),
                                                            1, cap=logins * 6 + 30))),
        "current_plan_tier": ("current_plan_tier", "cur_plan_cd", "snapshot_state", None, current_plan),
        "current_mrr": ("current_mrr", "cur_mrr_amt", "snapshot_state", 2, current_mrr),
        "health_score": ("health_score", "hlth_scr", "overwrite_silent", 0,
                         lambda t: np.where((T.pos == 1) & (r.uniform(size=n) < T.tv(t, Q_OVER)),
                                            np.round(unif(r, 0, 25, n)), health)),
        "retention_offer_code": ("retention_offer_code", "ret_offr_cd", "outcome_only_sparse", None,
                                 lambda t: T.mk_outcome_sparse(t, ["DISC20", "DISC35", "FREE_MONTH", "DOWNGRADE_OFFER"],
                                                               [0.35, 0.2, 0.3, 0.15])),
        "account_id": ("account_id", "acct_id", "identifier", None, lambda t: T.mk_ids(acct_r - acct_r.min(), "A", 6)),
        "days_to_cancel": ("days_to_cancel", "days_to_cncl", "target_derived", 0, lambda t: T.mk_days_to(t, 3, 90)),
    }
    add_leaks(T, plan, specs)
    if "health_score" not in plan["leaks"]:
        T.add("health_score", "health_score", "hlth_scr", health, dec=0)
    if tg is not None:
        sparse = trap_sparse_rows(r, T.pos)
        add_traps(T, [
            ("renewal_date", "contract_renewal_date", "rnwl_dt", "planned_future_date",
             day_str(md + T.cols["days_to_renewal"]["values"]), None),
            ("list_price_index", "list_price_index", "list_prc_idx", "legit_time_trend",
             np.round(100.0 * 1.025 ** q_r.astype(float), 1), 1),
            ("cancel_request_date", "cancellation_request_date_prior", "cncl_req_prior_dt", "legit_sparse_signal",
             day_str(np.where(sparse, md - np.floor(unif(r, 1, 61, n)), np.nan)), None),
            ("csm_code", "success_manager_code", "csm_cd", "legit_high_card_signal", tg[0][acct_r], None)])
    return T


# ============================================================ domain 5: hospital stays (patients with several stays)
def gen_hospital(r: np.random.RandomState, n: int, plan: Dict[str, Any]) -> TableGen:
    ext = day_of(DOMAINS["hospital"]["extract"])
    pat = []
    p = 0
    while len(pat) < int(n * 1.5):
        pat += [p] * min(6, int(r.geometric(0.5)))
        p += 1
    pat_a = np.array(pat)
    m = len(pat_a)
    frail = r.normal(size=p)
    F = 0.65 * frail[pat_a] + math.sqrt(1 - 0.65 ** 2) * r.normal(size=m)
    G = r.normal(size=m)
    L = F + 0.5 * G + LATENT_NOISE * r.normal(size=m) + 0.5 * frail[pat_a]
    tg = trap_group(r, m, plan, "U", 3)  # trap tables only: the ward unit of each stay
    if tg is not None:
        L = L + tg[1]
    k = int(round(plan["rate"] * m))
    y = np.zeros(m, dtype=int)
    y[np.argsort(-L, kind="mergesort")[:k]] = 1
    los = np.clip(np.floor(amount(0.6 * F + 0.8 * r.normal(size=m), 4, 0.6, 1)), 1, 60)
    # dates per patient: a readmitted stay is followed by the next stay within 30 days
    disc = np.full(m, np.nan)
    gap_prev = np.full(m, np.nan)
    gap_next = np.where(y == 1, np.floor(1 + 29 * r.uniform(size=m)), np.floor(31 + 340 * r.uniform(size=m) ** 2))
    prior_adm = np.zeros(m)
    prior_readm = np.zeros(m)
    starts = r.uniform(0, SPAN * 0.85, size=p)
    last, hist = {}, {}
    for i in range(m):
        pi = pat_a[i]
        if pi not in last:
            adm = np.floor(starts[pi])
        else:
            adm = disc[last[pi]] + gap_next[last[pi]]  # a readmitted stay is followed by the next one within 30 days
            gap_prev[i] = gap_next[last[pi]]
        d = adm + los[i]
        disc[i] = d
        h = hist.setdefault(pi, [])
        prior_adm[i] = sum(1 for dd, _ in h if adm - dd <= 365)
        prior_readm[i] = sum(1 for dd, yy in h if yy == 1 and adm - dd <= 365)
        h.append((d, y[i]))
        last[pi] = i
    idx = np.flatnonzero(disc < SPAN)[:n]
    T = TableGen(r, len(idx), plan["strong"], F=F[idx], G=G[idx])
    T.pos, T.target = y[idx], y[idx].astype(float)
    n = len(idx)
    T.md = md = disc[idx]
    los_r = los[idx]
    T.add("discharge_date", "discharge_date", "dschg_dt", day_str(md), role="moment")
    T.add("admit_date", "admit_date", "adm_dt", day_str(md - los_r))
    T.add("length_of_stay", "length_of_stay_days", "los_days", los_r, dec=0)
    T.add("age", "age_years", "age_yrs", intr(T.drv("age", 0.20), 18, 98), dec=0)
    T.add("sex", "sex", "sex_cd", pick(r, n, ["F", "M"], [0.52, 0.48]))
    T.add("admission_type", "admission_type", "adm_typ_cd",
          cat(T.drv("admission_type", 0.20), ["ELECTIVE", "URGENT", "EMERGENCY", "TRAUMA"], [0.25, 0.20, 0.50, 0.05]))
    T.add("diagnosis_count", "diagnosis_count", "dx_cnt", 1 + pois(r, T.drv("diagnosis_count", 0.25), 6, 0.4), dec=0)
    T.add("procedure_count", "procedure_count", "proc_cnt", pois(r, T.drv("procedure_count", 0.05), 1.5, 0.5), dec=0)
    T.add("medication_count", "medication_count", "med_cnt", pois(r, T.drv("medication_count", 0.20), 12, 0.4), dec=0)
    T.add("primary_dx_group", "primary_diagnosis_group", "prim_dx_grp_cd",
          cat(T.drv("primary_dx_group", 0.15), ["MUSCULOSKELETAL", "INJURY", "DIGESTIVE", "GENITOURINARY",
                                                "RESPIRATORY", "CIRCULATORY", "NEOPLASM"],
              [0.12, 0.10, 0.15, 0.08, 0.17, 0.28, 0.10]))
    T.add("comorbidity_index", "comorbidity_index", "cci_scr", intr(T.drv("comorbidity_index", 0.35), 0, 12), dec=0)
    T.add("prior_admissions_12m", "prior_admissions_12m", "prior_adm_cnt_12m", prior_adm[idx], dec=0)
    T.add("icu_days", "icu_days", "icu_day_cnt",
          np.where(T.drv("icu_flag", 0.15) > 1.0, 1 + pois(r, np.zeros(n), 2, 0), 0.0), dec=0)
    T.add("discharge_disposition", "discharge_disposition", "dschg_dispo_cd",
          cat(T.drv("discharge_disposition", 0.30), ["HOME", "HOME_HEALTH", "REHAB", "SKILLED_NURSING", "LEFT_AMA"],
              [0.55, 0.18, 0.08, 0.16, 0.03]))
    T.add("insurance_type", "insurance_type", "ins_typ_cd",
          cat(T.drv("insurance_type", 0.15), ["COMMERCIAL", "SELF_PAY", "MEDICAID", "MEDICARE"],
              [0.35, 0.07, 0.20, 0.38]))
    T.add("abnormal_lab_count", "abnormal_lab_count", "abn_lab_cnt", pois(r, T.drv("abnormal_lab_count", 0.20), 3, 0.5),
          dec=0)
    T.add("hba1c_tested", "hba1c_tested_flag", "a1c_tst_ind", flag(T.drv("hba1c_tested", -0.05), 0.30))
    T.add("ward_code", "ward_code", "ward_cd", pick(r, n, ["W%02d" % i for i in range(1, 21)], [1] * 20))
    T.add("attending_specialty", "attending_specialty", "attnd_spclty_cd",
          cat(T.drv("attending_specialty", 0.10), ["ORTHO", "SURGERY", "IM", "PULM", "CARDIO", "ONCO"],
              [0.12, 0.18, 0.30, 0.12, 0.18, 0.10]))
    T.add("postal_prefix", "postal_prefix", "pstl_pfx", postal_codes(r, n, 260))
    T.add("lives_alone", "lives_alone_flag", "lives_alone_ind", flag(T.drv("lives_alone", 0.15), 0.25), miss=0.20)
    T.add("followup_scheduled", "followup_appointment_scheduled", "fu_appt_ind",
          flag(T.drv("followup_scheduled", -0.25), 0.55))
    frail_flag = flag(T.drv("frailty_flag", 0.15), 0.20)
    # decoys: history before this admission
    T.add("prior_readmissions_12m", "prior_readmissions_12m", "prior_readmit_cnt_12m", prior_readm[idx],
          role="decoy", dec=0)
    T.add("days_since_last_discharge", "days_since_last_discharge", "days_since_prev_dschg", gap_prev[idx],
          role="decoy", dec=0)
    T.add("last_ed_visit_date", "last_ed_visit_date", "last_ed_vst_dt",
          day_str(np.where(T.drv("has_ed_visit", 0.25) > -0.2,
                           md - los_r - 1 - np.floor(amount(T.drv("days_since_ed", -0.25), 60, 1.0, 1)), np.nan)),
          role="decoy")
    T.add("prior_ed_visits_6m", "prior_ed_visits_6m", "prior_ed_cnt_6m",
          pois(r, T.drv("prior_ed_visits", 0.35), 0.8, 0.7), role="decoy", dec=0)
    specs = {
        "post_discharge_outcome": (
            "post_discharge_outcome", "pd_outcm_cd", "outcome_status", None, lambda t: T.mk_status(
                t, ["READMITTED", "ED_RETURN", "TRANSFERRED"], [0.75, 0.18, 0.07],
                ["FOLLOWUP_DONE", "NO_FOLLOWUP", "HOSPICE"], [0.70, 0.27, 0.03])),
        "readmission_date": ("readmission_date", "readmit_dt", "post_event_date", None,
                             lambda t: day_str(readmit_dates(t))),
        "last_contact_date": ("last_contact_date", "last_cntct_dt", "post_event_date", None,
                              lambda t: day_str(T.mk_always_date(t, 15, 45, 0, 20, ext))),
        "ed_visits_30d_after": ("ed_visits_30d_after", "ed_vst_cnt_30d", "post_aggregate", 0,
                                lambda t: T.mk_count(t, 0.15, 1.6)),
        "post_discharge_calls": ("post_discharge_calls", "pd_call_cnt", "post_aggregate", 0,
                                 lambda t: T.mk_count(t, 1.2, 6.5)),
        "total_charges_90d": ("total_charges_90d", "tot_chrg_90d_amt", "post_aggregate", 0,
                              lambda t: T.mk_agg(t, 9000 * los_r ** 0.6, unif(r, 2.5, 4.0, n), unif(r, 0.9, 1.15, n), 1,
                                                 cap=9000 * los_r ** 0.6 * 8)),
        "care_plan_status": ("care_plan_status", "care_pln_stat_cd", "snapshot_state", None,
                             lambda t: T.mk_snapshot_cat(t, pick(r, n, ["NONE", "STANDARD"], [0.6, 0.4]),
                                                         ["CASE_MANAGED", "INTENSIVE"], [0.7, 0.3])),
        "current_risk_score": ("current_risk_score", "cur_risk_scr", "snapshot_state", 1,
                               lambda t: T.mk_snapshot(t, np.round(ratio(T.drv("risk_base", 0.30), 0, 60), 1), 25, 0,
                                                       0, 100, 1)),
        "frailty_flag": ("frailty_flag", "frail_ind", "overwrite_silent", None,
                         lambda t: T.mk_overwrite(t, frail_flag, "Y")),
        "readmission_review_code": ("readmission_review_code", "readmit_rvw_cd", "outcome_only_sparse", None,
                                    lambda t: T.mk_outcome_sparse(t, ["PREVENTABLE", "PLANNED", "UNRELATED", "PENDING"],
                                                                  [0.35, 0.15, 0.3, 0.2])),
        "patient_id": ("patient_id", "pat_id", "identifier", None,
                       lambda t: T.mk_ids(pat_a[idx] - pat_a[idx].min(), "P", 7)),
        "days_to_readmission": ("days_to_readmission", "days_to_readmit", "target_derived", 0,
                                lambda t: np.where(np.isnan(T.mk_days_to(t, 1, 30)), np.nan, gap_next[idx])),
    }

    def readmit_dates(t: int) -> np.ndarray:
        """The next admission's date: recorded for most readmitted stays, and for a few later readmissions."""
        c_pos, c_neg = T.tv(t, C_SPARSE), r.uniform(0.02, 0.06)
        u = r.uniform(size=n)
        days = md + gap_next[idx]
        present = np.where(T.pos == 1, u < c_pos, u < c_neg) & (days <= ext)
        return np.where(present, days, np.nan)
    add_leaks(T, plan, specs)
    if "frailty_flag" not in plan["leaks"]:
        T.add("frailty_flag", "frailty_flag", "frail_ind", frail_flag)
    if tg is not None:
        sparse = trap_sparse_rows(r, T.pos)
        booked = T.cols["followup_scheduled"]["values"] == "Y"
        add_traps(T, [
            ("followup_date", "followup_appointment_date", "fu_appt_dt", "planned_future_date",
             day_str(np.where(booked, md + np.floor(unif(r, 3, 31, n)), np.nan)), None),
            ("drg_base_rate", "drg_base_payment_rate", "drg_base_rt", "legit_time_trend",
             np.select([md < 273, md < 638], [6121.0, 6375.0], 6497.0), 0),  # fiscal years start Oct 1
            ("dialysis_start_date", "dialysis_start_date", "dlys_strt_dt", "legit_sparse_signal",
             day_str(np.where(sparse, md - los_r - np.floor(unif(r, 30, 2500, n)), np.nan)), None),
            ("unit_code", "ward_unit_code", "unit_cd", "legit_high_card_signal", tg[0][idx], None)])
    return T


# ============================================================ domain 6: logistics shipments (regression)
def gen_shipments(r: np.random.RandomState, n: int, plan: Dict[str, Any]) -> TableGen:
    T = TableGen(r, n, plan["strong"])  # every post-dispatch event falls before the extract date
    T.md = md = np.floor(r.uniform(0, SPAN, size=n))
    hour = intr(T.drv("dispatch_hour", 0.10), 5, 22)
    t0 = md * 24 + hour + np.floor(r.uniform(0, 60, n)) / 60
    T.add("dispatch_time", "dispatch_timestamp", "dsptch_ts", ts_str(t0), role="moment")
    T.add("dispatch_hour", "dispatch_hour", "dsptch_hr", hour, dec=0)
    dist = np.clip(amount(T.drv("distance_km", 0.30), 520, 0.75, 1), 5, 4000)
    T.add("distance_km", "distance_km", "dist_km", dist, dec=0)
    svc = cat(T.drv("service_level", 0.15), ["SAMEDAY", "EXPRESS", "STANDARD", "ECONOMY"], [0.05, 0.25, 0.50, 0.20])
    T.add("service_level", "service_level", "svc_lvl_cd", svc)
    speed = np.select([svc == "SAMEDAY", svc == "EXPRESS", svc == "STANDARD"], [70.0, 55.0, 35.0], 25.0)
    sched = np.round(6 + dist / speed, 1)
    T.add("scheduled_hours", "scheduled_transit_hours", "sched_trnst_hrs", sched, dec=1)
    T.add("weight_kg", "weight_kg", "wt_kg", np.clip(amount(T.drv("weight_kg", 0.10), 8, 1.0, 0.1), 0.1, 2000), dec=1)
    T.add("parcel_count", "parcel_count", "pcl_cnt", 1 + pois(r, T.drv("parcel_count", 0.10), 0.8, 0.5), dec=0)
    T.add("carrier_code", "carrier_code", "carr_cd",
          cat(T.drv("carrier_code", 0.20), ["C03", "C01", "C07", "C02", "C05", "C04", "C06", "C08"], [1] * 8))
    T.add("origin_hub", "origin_hub_code", "orig_hub_cd", pick(r, n, ["H%02d" % i for i in range(1, 26)], [1] * 25))
    T.add("destination_postal_prefix", "destination_postal_prefix", "dest_pstl_pfx", postal_codes(r, n, 330))
    T.add("dispatch_weekday", "dispatch_weekday", "dsptch_dow",
          cat(T.drv("dispatch_weekday", 0.10), ["TUE", "WED", "MON", "THU", "SUN", "FRI", "SAT"],
              [1, 1, 1, 1, 0.4, 1, 0.6]))
    T.add("hazmat", "hazmat_flag", "hzmt_ind", flag(T.drv("hazmat", 0.15), 0.05))
    T.add("declared_value", "declared_value", "decl_val_amt", amount(T.drv("declared_value", 0.0), 140, 1.0, 1), dec=0)
    T.add("packaging_type", "packaging_type", "pkg_typ_cd",
          cat(T.drv("packaging_type", 0.10), ["ENVELOPE", "BOX", "TUBE", "PALLET"], [0.20, 0.60, 0.05, 0.15]))
    T.add("weather_risk_index", "weather_risk_index", "wthr_risk_idx",
          np.round(ratio(T.drv("weather_risk_index", 0.40), 0, 10), 1), dec=1)
    T.add("route_congestion_index", "route_congestion_index", "rte_cngst_idx",
          np.round(ratio(T.drv("route_congestion_index", 0.35), 0, 1), 3), dec=3)
    T.add("customs_required", "customs_required_flag", "cstms_ind", flag(T.drv("customs_required", 0.30), 0.08))
    T.add("driver_tenure", "driver_tenure_months", "drvr_tenure_mo", intr(T.drv("driver_tenure", -0.10), 0, 180), dec=0,
          miss=0.10)
    T.add("route_stops", "stops_on_route", "rte_stop_cnt", pois(r, T.drv("route_stops", 0.20), 14, 0.4), dec=0)
    T.add("remote_area", "remote_area_flag", "rmt_area_ind", flag(T.drv("remote_area", 0.25), 0.10))
    T.add("volume_m3", "volume_cubic_m", "vol_m3", np.round(amount(T.drv("volume_m3", 0.05), 0.04, 1.1, 0.001), 3),
          dec=3)
    risk_tier0 = cat(T.drv("route_risk_tier", 0.10), ["T1", "T2", "T3", "T4"], [0.35, 0.35, 0.2, 0.1])
    # decoys: lane history before dispatch
    T.add("prior_late_shipments_30d", "prior_late_shipments_30d", "prior_late_cnt_30d",
          pois(r, T.drv("prior_late_30d", 0.35), 3, 0.6), role="decoy", dec=0)
    T.add("last_delay_hours_prior", "last_delay_hours_prior_shipment", "last_dly_hrs_prior",
          np.round(np.maximum(-4, 3 * T.drv("last_delay_prior", 0.35) + 2), 1), role="decoy", dec=1, miss=0.08)
    T.add("days_since_route_incident", "days_since_last_route_incident", "days_since_rte_incdnt",
          np.floor(amount(T.drv("days_since_incident", -0.25), 30, 1.0, 1)) + 1, role="decoy", dec=0)
    T.add("carrier_on_time_rate_prev_month", "carrier_on_time_rate_prev_month", "carr_ot_rt_prev_mo",
          np.round(ratio(T.drv("carrier_ot_prev", -0.30), 0.70, 0.99), 3), role="decoy", dec=3)
    # target: delay in hours against the promised time (negative = early)
    tg = trap_group(r, n, plan, "RT", 4)  # trap tables only: the route of each shipment
    L = T.F + 0.5 * T.G + LATENT_NOISE * r.normal(size=n)
    if tg is not None:
        L = L + tg[1]
    delay = np.round(4.0 * L + 10.0 * np.maximum(0.0, L - 0.7) ** 2 + 1.5 * r.normal(size=n), 1)
    delay = np.maximum(delay, np.round(-0.4 * sched, 1))  # a parcel can arrive early, but not in no time
    T.target = delay
    T.pos = (delay >= np.quantile(delay, 0.75)).astype(int)  # "delayed" shipments, for the outcome-dependent events
    actual = sched + delay
    late = np.maximum(0.0, delay)

    def status(t: int) -> np.ndarray:
        band = np.select([delay < -4, delay <= 2, delay <= 12], ["EARLY", "ON_TIME", "LATE"],
                         "VERY_LATE").astype(object)
        levels = ["EARLY", "ON_TIME", "LATE", "VERY_LATE"]
        mix = pick(r, n, levels, [(band == v).mean() for v in levels])
        return np.where(r.uniform(size=n) < T.tv(t, Q_STATUS), band, mix)

    def exception_dates(t: int) -> np.ndarray:
        p_ev = T.tv(t, C_SPARSE) * np.clip(late / 8.0, 0, 1) + 0.02
        return np.where(r.uniform(size=n) < p_ev, np.floor(md + 1 + late / 24.0 * r.uniform(size=n)), np.nan)

    def count_by_delay(t: int, base: float, per_hour: float) -> np.ndarray:
        k, s = T.tv(t, K_AGG), T.tv(t, SIG_AGG)
        lam = (base + k * per_hour * late) * np.exp(s * np.clip(r.normal(size=n), -2.5, 2.5) - 0.5 * s * s)
        return r.poisson(lam).astype(float)

    specs = {
        "delivery_status": ("final_delivery_status", "dlvry_stat_cd", "outcome_status", None, status),
        "exception_scan_time": ("exception_scan_date", "excptn_scan_dt", "post_event_date", None,
                                lambda t: day_str(exception_dates(t))),
        "delivered_time": ("delivered_timestamp", "dlvrd_ts", "post_event_date", None, lambda t: ts_str(t0 + actual)),
        "scan_events": ("scan_event_count", "scan_evt_cnt", "post_aggregate", 0,
                        lambda t: count_by_delay(t, 8.0, 0.5)),
        "customer_inquiries": ("customer_inquiry_count", "cust_inq_cnt", "post_aggregate", 0,
                               lambda t: count_by_delay(t, 0.15, 0.12)),
        "claim_status_current": ("claim_status_current", "clm_stat_cur_cd", "snapshot_state", None, lambda t: np.where(
            r.uniform(size=n) < T.tv(t, Q_STATUS) * np.clip(late / 10.0, 0, 1) + 0.02,
            pick(r, n, ["OPEN", "PAID", "DENIED"], [0.4, 0.4, 0.2]), "NONE").astype(object)),
        "route_risk_tier": ("route_risk_tier", "rte_risk_tier_cd", "overwrite_silent", None,
                            lambda t: T.mk_overwrite(t, risk_tier0, "T4")),
        "exception_code": ("exception_code", "excptn_cd", "outcome_only_sparse", None, lambda t: np.where(
            r.uniform(size=n) < T.tv(t, C_OUTCOME) * np.clip(late / 8.0, 0, 1),
            pick(r, n, ["WX", "ADDR", "DMG", "CUSTOMS", "MISSORT"], [0.35, 0.2, 0.1, 0.15, 0.2]), None).astype(object)),
        "actual_transit_hours": ("actual_transit_hours", "act_trnst_hrs", "target_derived", 1,
                                 lambda t: np.round(np.maximum(actual + r.normal(size=n) * {0: 14.0, 1: 5.0, 2: 1.0}[t],
                                                               0.5 * actual), 1)),
        "delivery_offset_hours": ("delivery_offset_hours", "dlvry_ofst_hrs", "target_derived", 1,
                                  lambda t: np.round(np.where(r.uniform(size=n) < T.tv(t, C_DERIVED),
                                                              delay + r.normal(size=n), np.nan), 1)),
    }
    add_leaks(T, plan, specs)
    if "route_risk_tier" not in plan["leaks"]:
        T.add("route_risk_tier", "route_risk_tier", "rte_risk_tier_cd", risk_tier0)
    if tg is not None:
        sparse = trap_sparse_rows_reg(r, delay)
        add_traps(T, [
            ("promised_time", "promised_delivery_timestamp", "prom_dlvry_ts", "planned_future_date",
             ts_str(t0 + sched), None),
            ("linehaul_rate_index", "linehaul_rate_index", "lnhl_rt_idx", "legit_time_trend",
             np.round(100.0 * (1.0 + 0.15 * md / 365.0) + 0.5 * r.normal(size=n), 1), 1),
            ("storm_warning_time", "storm_warning_issued_at", "storm_warn_ts", "legit_sparse_signal",
             ts_str(np.where(sparse, t0 - unif(r, 2, 48, n), np.nan)), None),
            ("route_id", "route_id", "rte_id", "legit_high_card_signal", tg[0], None)])
    return T


# ============================================================ domain catalogue
DOMAINS: Dict[str, Dict[str, Any]] = {
    "lending": {
        "label": "consumer lending", "task": "binary", "rate": (0.06, 0.25), "extract": "2025-02-28",
        "gen": gen_lending,
        "unit": "One consumer loan application.",
        "target_description": "Whether the borrower defaults on the loan within 12 months of the application "
                              "(1 = default).",
        "prediction_time": "At application, when the credit decision is made.",
        "target_names": ("defaulted_12m", "dflt_12m_ind"),
        "strong": ["credit_score", "interest_rate", "revolving_utilization", "debt_to_income"],
        "legit": ["annual_income", "requested_amount", "credit_score", "debt_to_income", "interest_rate", "term_months",
                  "employment_length", "home_ownership", "loan_purpose", "revolving_utilization", "open_accounts",
                  "inquiries_6m", "delinquencies_2y", "credit_history_months", "postal_prefix", "application_channel",
                  "monthly_installment", "income_verified", "dependents", "months_at_address", "employment_status"],
        "decoys": ["prior_chargeoff_count", "last_payment_date_prior_loan", "months_since_last_delinquency",
                   "prior_loans_paid_off", "prior_collections_flag"],
        "leaks": {"loan_status": "outcome_status", "chargeoff_date": "post_event_date",
                  "last_payment_date": "post_event_date", "total_paid_amount": "post_aggregate",
                  "recovery_amount": "post_aggregate", "collection_calls": "post_aggregate",
                  "current_balance": "snapshot_state", "current_credit_score": "snapshot_state",
                  "employment_status": "overwrite_silent", "collection_agency_code": "outcome_only_sparse",
                  "hardship_plan_code": "outcome_only_sparse", "days_to_default": "target_derived"},
    },
    "claims": {
        "label": "insurance claims", "task": "binary", "rate": (0.05, 0.15), "extract": "2024-08-31", "gen": gen_claims,
        "unit": "One insurance claim.",
        "target_description": "Whether the claim is found to be fraudulent after investigation (1 = fraudulent).",
        "prediction_time": "At first notice of loss, when the claim is first reported and before any investigation.",
        "target_names": ("fraud_confirmed", "frd_cnfrm_ind"),
        "strong": ["report_lag_days", "claim_amount_to_limit", "policy_tenure", "policyholder_age"],
        "legit": ["loss_date", "report_lag_days", "reported_amount", "policy_tenure", "policy_type", "coverage_limit",
                  "deductible", "policyholder_age", "loss_type", "police_report", "witness_count", "injury_claimed",
                  "asset_age", "annual_premium", "agent_channel", "postal_prefix", "loss_hour",
                  "claimant_is_policyholder", "premium_payment_method", "multi_policy", "attorney_at_fnol",
                  "claim_amount_to_limit", "customer_segment"],
        "decoys": ["days_since_last_claim", "prior_claim_count", "prior_denied_claims", "last_premium_payment_date"],
        "leaks": {"claim_disposition": "outcome_status", "siu_referral_date": "post_event_date",
                  "claim_closed_date": "post_event_date", "total_paid": "post_aggregate",
                  "adjuster_notes": "post_aggregate", "investigation_hours": "post_aggregate",
                  "current_reserve": "snapshot_state", "policy_status_current": "snapshot_state",
                  "customer_segment": "overwrite_silent", "fraud_referral_id": "outcome_only_sparse",
                  "days_to_fraud_finding": "target_derived"},
    },
    "orders": {
        "label": "e-commerce orders", "task": "binary", "rate": (0.10, 0.40), "extract": "2024-04-30",
        "gen": gen_orders,
        "unit": "One online order.",
        "target_description": "Whether the order is returned (1 = returned).",
        "prediction_time": "At checkout, when the order is placed.",
        "target_names": ("returned", "rtrn_ind"),
        "strong": ["main_category", "product_rating", "customer_tenure_days", "order_value"],
        "legit": ["checkout_hour", "order_value", "item_count", "main_category", "discount_pct", "payment_method",
                  "shipping_speed", "customer_tenure_days", "first_order", "device_type", "multiple_sizes",
                  "promo_code", "avg_item_price", "postal_prefix", "gift_order", "free_shipping", "product_rating",
                  "sale_items_share", "customer_age_band", "loyalty_tier"],
        "decoys": ["previous_returns", "last_return_date_prior", "prior_return_rate", "days_since_previous_order"],
        "leaks": {"order_status": "outcome_status", "return_received_date": "post_event_date",
                  "last_contact_date": "post_event_date", "refund_amount": "post_aggregate",
                  "service_contacts": "post_aggregate", "lifetime_returns": "snapshot_state",
                  "store_credit_balance": "snapshot_state", "loyalty_tier": "overwrite_silent",
                  "return_reason_code": "outcome_only_sparse", "days_to_return": "target_derived"},
    },
    "saas": {
        "label": "SaaS subscriptions", "task": "binary", "rate": (0.06, 0.20), "extract": "2024-01-31", "gen": gen_saas,
        "unit": "One subscription account in one calendar quarter.",
        "target_description": "Whether the account churns (cancels its subscription) by the end of the quarter "
                              "(1 = churned).",
        "prediction_time": "On the first day of the quarter.",
        "target_names": ("churned_in_quarter", "chrn_q_ind"),
        "strong": ["seat_utilization", "logins_30d", "feature_adoption", "tenure_months"],
        "legit": ["seats", "plan_tier", "mrr", "contract_type", "tenure_months", "industry_code", "company_size_band",
                  "billing_postal_prefix", "logins_30d", "seat_utilization", "active_users_last_month",
                  "feature_adoption", "tickets_prev_quarter", "nps", "auto_renew", "payment_method", "discount_pct",
                  "integrations", "days_to_renewal", "admin_count", "health_score"],
        "decoys": ["last_login_date", "prior_downgrades", "days_since_last_ticket", "prev_quarter_seat_change"],
        "leaks": {"quarter_end_status": "outcome_status", "cancel_date": "post_event_date",
                  "last_activity_date": "post_event_date", "tickets_this_quarter": "post_aggregate",
                  "logins_this_quarter": "post_aggregate", "current_plan_tier": "snapshot_state",
                  "current_mrr": "snapshot_state", "health_score": "overwrite_silent",
                  "retention_offer_code": "outcome_only_sparse", "account_id": "identifier",
                  "days_to_cancel": "target_derived"},
    },
    "hospital": {
        "label": "hospital encounters", "task": "binary", "rate": (0.08, 0.25), "extract": "2024-03-31",
        "gen": gen_hospital,
        "unit": "One inpatient hospital stay.",
        "target_description": "Whether the patient is readmitted to hospital within 30 days of discharge "
                              "(1 = readmitted).",
        "prediction_time": "At discharge.",
        "target_names": ("readmitted_30d", "readmit_30d_ind"),
        "strong": ["comorbidity_index", "discharge_disposition", "medication_count", "diagnosis_count"],
        "legit": ["admit_date", "length_of_stay", "age", "sex", "admission_type", "diagnosis_count", "procedure_count",
                  "medication_count", "primary_dx_group", "comorbidity_index", "prior_admissions_12m", "icu_days",
                  "discharge_disposition", "insurance_type", "abnormal_lab_count", "hba1c_tested", "ward_code",
                  "attending_specialty", "postal_prefix", "lives_alone", "followup_scheduled", "frailty_flag"],
        "decoys": ["prior_readmissions_12m", "days_since_last_discharge", "last_ed_visit_date", "prior_ed_visits_6m"],
        "leaks": {"post_discharge_outcome": "outcome_status", "readmission_date": "post_event_date",
                  "last_contact_date": "post_event_date", "ed_visits_30d_after": "post_aggregate",
                  "post_discharge_calls": "post_aggregate", "total_charges_90d": "post_aggregate",
                  "care_plan_status": "snapshot_state", "current_risk_score": "snapshot_state",
                  "frailty_flag": "overwrite_silent", "readmission_review_code": "outcome_only_sparse",
                  "patient_id": "identifier", "days_to_readmission": "target_derived"},
    },
    "shipments": {
        "label": "logistics shipments", "task": "regression", "rate": None, "extract": "2024-01-31",
        "gen": gen_shipments,
        "unit": "One parcel shipment.",
        "target_description": "Delivery delay in hours: actual delivery time minus the promised delivery time "
                              "(negative = delivered early).",
        "prediction_time": "At dispatch, when the shipment leaves the origin hub.",
        "target_names": ("delivery_delay_hours", "dlvry_dly_hrs"),
        "strong": ["weather_risk_index", "route_congestion_index", "distance_km", "route_stops"],
        "legit": ["dispatch_hour", "distance_km", "service_level", "scheduled_hours", "weight_kg", "parcel_count",
                  "carrier_code", "origin_hub", "destination_postal_prefix", "dispatch_weekday", "hazmat",
                  "declared_value", "packaging_type", "weather_risk_index", "route_congestion_index",
                  "customs_required", "driver_tenure", "route_stops", "remote_area", "volume_m3", "route_risk_tier"],
        "decoys": ["prior_late_shipments_30d", "last_delay_hours_prior", "days_since_route_incident",
                   "carrier_on_time_rate_prev_month"],
        "leaks": {"delivery_status": "outcome_status", "exception_scan_time": "post_event_date",
                  "delivered_time": "post_event_date", "scan_events": "post_aggregate",
                  "customer_inquiries": "post_aggregate", "claim_status_current": "snapshot_state",
                  "route_risk_tier": "overwrite_silent", "exception_code": "outcome_only_sparse",
                  "actual_transit_hours": "target_derived", "delivery_offset_hours": "target_derived"},
    },
}
DOMAIN_ORDER = ["lending", "claims", "orders", "saas", "hospital", "shipments"]
STYLES = ["clear", "clear", "abbreviated", "abbreviated", "cryptic", "abbreviated"]  # table 6 is the clean one


# ============================================================ planning and writing
def table_rng(table_id: str) -> np.random.RandomState:
    return np.random.RandomState((SEED * 1000003 + zlib.crc32(table_id.encode("utf-8"))) % (2 ** 32))


def plan_table(r: np.random.RandomState, dom: Dict[str, Any], k: int, traps: bool = False) -> Dict[str, Any]:
    """Table k (1-6) of a domain; traps=True plans the domain's trap table (abbreviated names, 3-5 leaks)."""
    clean = k == 6 and not traps
    plan: Dict[str, Any] = {"style": "abbreviated" if traps else STYLES[k - 1], "kind": "clean" if clean else "leak",
                            "n": int(r.randint(ROWS[0], ROWS[1] + 1)),
                            "total": int(r.randint(FEATURES[0], FEATURES[1] + 1)),
                            "rate": float(r.uniform(*dom["rate"])) if dom["rate"] else None, "traps": traps}
    plan["strong"] = [str(x) for x in r.choice(dom["strong"], size=int(r.randint(1, 4)), replace=False)]
    plan["decoys"] = [str(x) for x in r.choice(dom["decoys"], size=int(r.randint(2, 5)), replace=False)]
    leaks: Dict[str, int] = {}
    if not clean:
        keys = list(dom["leaks"])
        w = np.array([PICK_WEIGHT.get(dom["leaks"][key], 1.0) for key in keys])
        for key in r.choice(keys, size=int(r.randint(3, 6) if traps else r.randint(3, 7)), replace=False,
                            p=w / w.sum()):
            ltype = dom["leaks"][str(key)]
            leaks[str(key)] = int(r.choice(3, p=TIER_P[ltype]))
    plan["leaks"] = leaks
    n_legit = int(np.clip(plan["total"] - len(plan["decoys"]) - len(leaks) - (4 if traps else 0), 10, 20))
    others = [x for x in dom["legit"] if x not in plan["strong"] and x not in leaks]
    extra = min(n_legit - 1 - len(plan["strong"]), len(others))
    plan["legit"] = list(plan["strong"]) + [str(x) for x in r.choice(others, size=extra, replace=False)]
    return plan


def fmt(values: np.ndarray, dec: Optional[int]) -> List[str]:
    if values.dtype == object:
        return ["" if v is None or (isinstance(v, float) and v != v) else str(v) for v in values]
    out = []
    form = "%." + str(dec) + "f" if dec else None
    for x in values.astype(float):
        if x != x:
            out.append("")
        elif not dec:
            out.append(str(int(round(x))))
        else:
            out.append(form % (round(x, dec) + 0.0))
    return out


def build(table_id: str, dom_key: str, k: int,
          traps: bool = False) -> Tuple[Dict[str, Any], List[List[str]], List[str]]:
    dom = DOMAINS[dom_key]
    r = table_rng(table_id)
    plan = plan_table(r, dom, k, traps)
    T = dom["gen"](r, plan["n"], plan)
    moment = [key for key, c in T.cols.items() if c["role"] == "moment"]
    chosen = moment + plan["legit"] + plan["decoys"] + list(plan["leaks"]) + \
        [key for key, c in T.cols.items() if c["role"] == "trap"]  # trap columns: trap tables only
    missing = [key for key in chosen if key not in T.cols]
    if missing:
        raise RuntimeError("%s: generator did not produce %s" % (table_id, missing))
    order = [chosen[i] for i in r.permutation(len(chosen))]
    style = plan["style"]
    if style == "cryptic":
        names = dict(zip(order + ["__target__"], cryptic_names(r, len(order) + 1)))
        target_name = names.pop("__target__")
    else:
        names = {key: T.cols[key]["clear" if style == "clear" else "abbr"] for key in order}
        target_name = dom["target_names"][0 if style == "clear" else 1]
    if len(set(names.values())) != len(names):
        raise RuntimeError("%s: duplicate column names" % table_id)
    header = [names[key] for key in order] + [common.TARGET]
    cols = [fmt(T.cols[key]["values"], T.cols[key]["dec"]) for key in order]
    cols.append(fmt(T.target, 0 if dom["task"] == "binary" else 1))
    rows = [list(x) for x in zip(*cols)]
    roles = {key: T.cols[key]["role"] for key in order}
    tiers = ", ".join("%s=%s" % (names[key], ["weak", "mid", "strong"][t]) for key, t in plan["leaks"].items())
    if traps:
        name = "Generated %s trap table (%s names)" % (dom["label"], style)
        notes = ("Synthetic trap table. Leaks are planted by construction; tiers: %s. The trap columns are legitimate "
                 "(known at the prediction moment) but built to fool label-free data checks." % tiers)
    else:
        name = "Generated %s table %d (%s names)" % (dom["label"], k, style)
        notes = ("Synthetic. Leaks are planted by construction; tiers: %s." % tiers if plan["leaks"] else
                 "Synthetic. Clean table: no leaks planted.")
    case = {
        "id": table_id, "name": name, "aliases": [],
        "kind": plan["kind"], "url": "generated",
        "format": {"sep": ",", "encoding": "utf-8", "compression": "gzip", "zip_member": None},
        "sample_rows": None, "target": target_name, "task": dom["task"],
        "positive_values": [1] if dom["task"] == "binary" else None,
        "unit": dom["unit"], "prediction_time": dom["prediction_time"], "target_description": dom["target_description"],
        "drop_columns": [], "leak_columns": [names[key] for key in order if roles[key] == "leak"],
        "probable_leak_columns": [], "docs": [], "canonical_source": "generated by step1_generate.py (SEED %d)" % SEED,
        "notes": notes, "domain": dom_key, "naming_style": style,
        "leak_types": {names[key]: T.cols[key]["ltype"] for key in order if roles[key] == "leak"},
        "decoy_columns": [names[key] for key in order if roles[key] == "decoy"],
        "strong_legit_columns": [names[key] for key in order if roles[key] == "strong"],
        "trap_columns": {names[key]: T.cols[key]["ltype"] for key in order if roles[key] == "trap"},
        "moment_column": names[moment[0]], "extract_date": dom["extract"],
    }
    return case, rows, header


def write_table(case: Dict[str, Any], header: List[str], rows: List[List[str]]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    text = buf.getvalue().encode("utf-8")
    digest = hashlib.sha256(text).hexdigest()
    os.makedirs(common.path("data"), exist_ok=True)
    tmp = common.data_file(case["id"]) + ".tmp"
    with open(tmp, "wb") as f:
        with gzip.GzipFile(filename="", mode="wb", fileobj=f, mtime=0) as gz:
            gz.write(text)
    os.replace(tmp, common.data_file(case["id"]))
    back = common.read_data(case["id"])
    binary = case["task"] == "binary"
    meta = {"id": case["id"], "name": case["name"], "kind": case["kind"], "task": case["task"],
            "target_original": case["target"], "rows": int(len(back)), "rows_in_file": int(len(back)),
            "rows_without_target": 0, "sampled": False,
            "positive_rate": float(back[common.TARGET].mean()) if binary else None,
            "target_mean": None if binary else float(back[common.TARGET].mean()),
            "columns": {c: common.infer_type(back[c]) for c in back.columns if c != common.TARGET},
            "leak_columns": case["leak_columns"], "probable_leak_columns": [], "url": case["url"],
            "created": common.stamp()}
    common.write_json(common.meta_file(case["id"]), meta)
    return digest


def main() -> None:
    print("Step 1 -- generate the fresh tables (SEED %d)" % SEED)
    cases, sums = [], []
    jobs = [("%s_%02d" % (dom_key, k), dom_key, k, False) for dom_key in DOMAIN_ORDER for k in range(1, 7)]
    jobs += [("traps_" + dom_key, dom_key, 0, True) for dom_key in DOMAIN_ORDER]  # the 6 trap tables come last
    for table_id, dom_key, k, traps in jobs:
        case, rows, header = build(table_id, dom_key, k, traps)
        digest = write_table(case, header, rows)
        cases.append(case)
        sums.append((table_id, digest))
        rate = ("%.3f" % (sum(float(x[-1]) for x in rows) / len(rows))) if case["task"] == "binary" else \
            "mean %.1f h" % (sum(float(x[-1]) for x in rows) / len(rows))
        print("  %-15s %-5s %-11s %5d rows %3d columns  target %-11s  leaks %d decoys %d strong %d traps %d  sha256 %s"
              % (table_id, case["kind"], case["naming_style"], len(rows), len(header) - 1, rate,
                 len(case["leak_columns"]), len(case["decoy_columns"]), len(case["strong_legit_columns"]),
                 len(case["trap_columns"]), digest[:16]))
    text = json.dumps(cases, indent=1, ensure_ascii=False)
    with open(common.path(common.CASES_FILE), "w", encoding="utf-8") as f:
        f.write(text)
    n_fresh = sum(1 for _, _, _, traps in jobs if not traps)
    fresh = hashlib.sha256("".join(d for _, d in sums[:n_fresh]).encode("ascii")).hexdigest()
    combined = hashlib.sha256("".join(d for _, d in sums).encode("ascii")).hexdigest()
    with open(common.path(CHECKSUM_FILE), "w", encoding="utf-8") as f:
        f.write("# SHA-256 of each generated table's CSV text (uncompressed), SEED %d\n" % SEED)
        for table_id, digest in sums:
            f.write("%s  %s.csv\n" % (digest, table_id))
        f.write("%s  cases.json\n" % hashlib.sha256(text.encode("utf-8")).hexdigest())
        f.write("%s  FRESH_TABLES (the %d tables of the fresh test)\n" % (fresh, n_fresh))
        f.write("%s  ALL_TABLES (all %d, with the trap tables)\n" % (combined, len(sums)))
    print("\n%d tables (%d with leaks, %d clean; %d of them trap tables) -> data/, cases.json, %s"
          % (len(cases), sum(c["kind"] == "leak" for c in cases), sum(c["kind"] == "clean" for c in cases),
             len(sums) - n_fresh, CHECKSUM_FILE))
    print("Checksum of the %d fresh-test tables: %s  (compare with the published value)" % (n_fresh, fresh))
    print("Checksum of all %d tables:            %s" % (len(sums), combined))
    print("Next: step2_column_check.py")


if __name__ == "__main__":
    main()
