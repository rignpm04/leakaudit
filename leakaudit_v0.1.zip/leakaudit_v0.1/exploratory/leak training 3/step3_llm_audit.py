# step3_llm_audit.py -- RUN 3 KIT VERSION: a library for t2-t6 (nothing to run or paste here). Run 2's copy plus the
# chunked prompts of fine-tune run 3 (chunk_prompts, chunk_info, CHUNK_SIZE: at most 10 rated columns per prompt, a
# short reason before each risk); everything else is unchanged, so the whole-table prompts are rebuilt exactly.
#
# step3_llm_audit.py -- TRAINING-KIT VERSION. Same prompts and caches as the fresh test's step 3, with two changes:
#   1. Each local model gets its own label and cache folder, named after its id (qwen/qwen3.5-9b -> local-qwen3.5-9b,
#      in llm_cache/local-qwen3.5-9b/), so the untrained and the trained model can both be scored side by side.
#   2. It also audits the public datasets in cases_real.json (run 2: leak real test 2's 47), next to the 42 generated tables.
# Shipped for the local model only (MODELS = ["local"]); the other models' answers come in through eval0_import.py.
# Everything below this paragraph describes the original step 3 and still applies.
#
# step3_llm_audit.py -- step 3 of the fresh leakage test: LLMs read each generated table's task, column names and sample
# values and rate every column's leak risk (0-100). Python 3.9, HTTP through urllib; press Run in PyCharm after step 2.
# The fresh tables were never seen by any model, so only the "real" condition is used (CONDITIONS); the recognition
# probe on the real table is a sanity check that no model claims to know them. The other conditions still work if
# you add them.
#
# Conditions:
#   real       original column names and the case's own task text
#   reworded   names and task text rewritten by PARAPHRASE_MODEL (one call per case, cached in reworded/<id>.json)
#              with no dataset name, source or organization -- tests whether the LLM only recognizes famous datasets
#   scrambled  names col_01..col_NN, the reworded task text, values shown as usual
#   disguised  a condition the models should not be able to recognize: DISGUISE_MODEL (one call per case, cached in
#              disguised/<id>.json) rewrites the task text, every column name and every shown category label; the
#              columns are shuffled, counts and values are rounded, dates are shifted by 7-15 years
# Recognition probes (PROBES): each model is also asked, in a separate short call, which public dataset the table
# comes from (the real table, and the disguised one if that condition is on; cached in
# llm_cache/<model>/probe_<condition>/; output probes.csv). Step 4 warns if a model takes more than 15% of the
# generated tables for known public datasets.
# The step 2 scores are never shown to the LLM.
#
# Local model ("local" in MODELS): a model you run yourself in LM Studio, through its OpenAI-compatible server
# (LOCAL_URL). It gets exactly the same prompts, one call at a time, costs nothing and needs no key: paste the model
# identifier shown in LM Studio into LOCAL_MODEL. Answers are read after any <think>...</think> block. No probes for it
# unless PROBES_LOCAL = True.
#
# Open-weight models ("open" in MODELS): every model in OPEN_MODELS, through OpenRouter (one key for all of them).
# Their weights are public, so a bank could run the same model on its own server; OpenRouter just hosts them, for
# cents. They get exactly the same prompts; each model gets its own results, labeled open-<name> (for example
# open-gemma-4-31b-it). They think before answering (OPEN_REASONING), run on full- or 8-bit providers only
# (OPEN_QUANTIZATIONS), and the cost OpenRouter reports is recorded. No probes for them unless PROBES_OPEN = True.
#
# How to run:
#   1. DRY_RUN = True (as shipped): prints the first prompt for each condition and a token / cost / time estimate.
#      No calls.
#   2. Paste your keys below (only here, never into a chat), set DRY_RUN = False, press Run again.
# Every call is cached in llm_cache/<model>/<condition>/<case>.json: a stopped run resumes where it left off, and an
# unchanged second run costs nothing. MOCK = True runs everything with a fake offline LLM (pipeline test only; its
# results are labeled mock-<model>; it ignores DRY_RUN). Output: scores_llm.csv and probes.csv, rebuilt after every
# run from all cached answers of every model (also models left out of MODELS this time); problems go to step3_log.txt.

import json
import os
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import zlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional, Tuple

# ============================================================ settings (edit here)
DEEPSEEK_API_KEY = "PASTE_DEEPSEEK_KEY_HERE"
ANTHROPIC_API_KEY = "PASTE_ANTHROPIC_KEY_HERE"
OPENAI_API_KEY = "PASTE_OPENAI_KEY_HERE"

MODELS = ["local"]                     # any of "deepseek", "claude", "gpt", "local", "open" ("open" = every model in OPEN_MODELS);
#                                                          a model with no key (or LOCAL_MODEL) is skipped
DEEPSEEK_MODEL = "deepseek-chat"        # if DeepSeek rejects it, use the model name from your DeepSeek console
CLAUDE_MODEL = "claude-sonnet-5-5"
GPT_MODEL = "gpt-6.1-sol"

# Local model in LM Studio (Developer tab: load the model, start the server). No key needed, costs nothing.
LOCAL_URL = "http://localhost:1234/v1/chat/completions"
LOCAL_MODEL = "qwen/qwen3.5-9b"        # the model identifier LM Studio shows for the loaded model (GUIDE.md says when to change it)
LOCAL_TIMEOUT_S = 2400                 # a local model can be slow; one call waits at most this long
LOCAL_MAX_TOKENS = 12000               # cap on a local answer (thinking included)
LOCAL_JSON_MODE = False                # True: ask LM Studio for schema-checked JSON (only if answers come back broken)
LOCAL_TEMPERATURE = 0.6                # the setting of the untrained Qwen3.5 9B run; keep it for the trained model too
LOCAL_REASONING_EFFORT = None          # None: LM Studio's default; "medium": let a model that can think, think
LOCAL_MIN_CONTEXT = 12000              # the start-up check warns if the loaded model's context length is below this
PROBES_LOCAL = False                   # also run the recognition probes for the local model
LOCAL_TOKENS_PER_S = 15                # dry-run time estimate only: your model's output speed (LM Studio shows it)
LOCAL_PROMPT_TOKENS_PER_S = 300        # dry-run time estimate only: how fast it reads the prompt

# Open-weight models through OpenRouter ("open" in MODELS). Key: openrouter.ai > Settings > Keys (add a few dollars
# of credit first). Each model costs cents for all 42 tables.
OPENROUTER_API_KEY = "PASTE_OPENROUTER_KEY_HERE"
OPEN_MODELS = ["google/gemma-4-31b-it",   # Google, 31B
               "qwen/qwen3.6-27b",        # Alibaba, 27B
               "qwen/qwen3.8-27b",        # Alibaba, 27B, newest
               "openai/gpt-oss-120b"]     # OpenAI, 120B (fits one 80 GB server GPU)
OPEN_URL = "https://openrouter.ai/api/v1/chat/completions"
OPEN_REASONING = True                  # let each model think before it answers
OPEN_TEMPERATURE = 0.6                 # thinking models can loop at 0; 0.6 is the usual setting for them
OPEN_TOP_P = 0.95
OPEN_MAX_TOKENS = 16000                # cap on one answer, thinking included
OPEN_QUANTIZATIONS = ["bf16", "fp16", "fp8"]  # only providers that run the full or 8-bit weights (no 4-bit copies)
OPEN_TIMEOUT_S = 600
OPEN_WORKERS = 4                       # calls running at the same time for each open model
PROBES_OPEN = False                    # also run the recognition probes for the open models
OPEN_REASONING_TOKENS_EST = 4000       # dry-run cost estimate only: thinking tokens per call

CONDITIONS = ["real"]
PARAPHRASE_MODEL = "deepseek"          # writes the reworded names and task text (one call per case)
DISGUISE_MODEL = "gpt"                 # writes the disguised names, labels and task text (one call per case)
PROBES = True                          # ask each model which public dataset the table comes from (sanity check)

N_EXAMPLES = 5                         # example values per column in the prompt
MAX_TOKENS = 8000                      # cap on each answer
WRITER_MAX_TOKENS = 16000              # cap on the disguise writer's answer (it renames every column and label)
PROBE_MAX_TOKENS = 4000                # cap on a probe answer (short, but reasoning models need room)
TEMPERATURE = 0                        # sent to DeepSeek only (Claude and GPT reject it)

DRY_RUN = True                         # True: print prompts and a cost estimate, make no calls
MOCK = False                           # True: fake offline LLM for testing the pipeline (ignores DRY_RUN)

# USD per 1M tokens (input, output), looked up by model id, then by "deepseek" / "claude" / "gpt". Check the
# providers' current price pages before a real run; these are only used for the cost estimate.
PRICE_PER_M = {"deepseek": (0.28, 0.42), "claude-sonnet-5-5": (2.00, 10.00), "gpt-6.1-sol": (2.00, 10.00),
               "local": (0.0, 0.0),
               # open models: rough upper prices of OpenRouter's full/8-bit providers, for the dry-run estimate only
               # (a live run records the cost OpenRouter reports)
               "google/gemma-4-31b-it": (0.20, 0.60), "qwen/qwen3.6-27b": (0.35, 3.25),
               "qwen/qwen3.8-27b": (0.25, 2.50), "openai/gpt-oss-120b": (0.10, 0.60)}

WORKERS = 4                            # API calls running at the same time (1 = one after another); local: always 1
SEED = 7                               # picks the random example values (fixed, so prompts and caches stay stable)
TIMEOUT_S = 300
MAX_RETRIES = 5

# API endpoints (change only for testing)
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
OPENAI_URL = "https://api.openai.com/v1/responses"

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

OUT_FILE = "scores_llm.csv"
REAL_CASES_FILE = "cases_real.json"    # the public test datasets (run 2: the 47 of leak real test 2), audited too
PROBE_FILE = "probes.csv"
LOG_FILE = "step3_log.txt"
FIELDS = ["case_id", "column", "model", "condition", "leak_risk", "category", "reason", "dataset_guess"]
PROBE_FIELDS = ["case_id", "model", "condition", "guess1", "conf1", "guess2", "conf2", "guess3", "conf3"]
KNOWN_MODELS = ("deepseek", "claude", "gpt", "local", "open")  # what MODELS may name ("open" expands, see below)
WRITER_MODELS = ("deepseek", "claude", "gpt", "local")         # what PARAPHRASE_MODEL and DISGUISE_MODEL may name
PROVIDER_WORKERS = {"local": 1}        # LM Studio answers one request at a time; the APIs share WORKERS
LOCAL_DUMMY_KEY = "lm-studio"          # LM Studio ignores the key, but OpenAI-style clients send one
KNOWN_CONDITIONS = ("real", "reworded", "scrambled", "disguised")
CATEGORIES = ("post_outcome", "target_derived", "identifier", "future_aggregate", "fine")
TEXT_KEYS = ("unit", "target_description", "prediction_time")
CHARS_PER_TOKEN = 3.5                  # dry-run estimate
OUT_TOKENS_PER_COLUMN = 35             # dry-run estimate
PROBE_OUT_TOKENS = 80                  # dry-run estimate for one probe answer

SYSTEM_PROMPT = (
    "You audit tabular datasets for target leakage before a model is trained. A column leaks if, at the moment the "
    "prediction is made, its value would not yet be known, or it was computed from the outcome, or it identifies rows "
    "in a way that lets a model memorize outcomes. Strong but legitimate predictors are not leaks. Judge each column "
    "only against the stated prediction moment.")

INSTRUCTION = (
    'Return only a json object, with no other text:\n'
    '{"dataset_guess": "<name of the public dataset if you recognize it, else null>", "columns": [{"column": "<name>", '
    '"leak_risk": <0-100>, "category": "post_outcome|target_derived|identifier|future_aggregate|fine", '
    '"reason": "<one short sentence>"}]}\n'
    'Include every column exactly once, using the names exactly as given. Keep each reason under 15 words.')
REMINDER_ALL = "Reminder: answer with one json object only, in exactly the form above, covering all %d columns."
REMINDER_MISSING = ("Reminder: your previous answer left out these columns: %s. Answer with one json object in the "
                    "same form, covering just these columns, with the names exactly as given.")

PARAPHRASE_SYSTEM = "You rename table columns and rewrite short task descriptions. Answer with one json object only."
PARAPHRASE_INSTRUCTION = (
    "1. Give every column a different but equivalent name in the snake_case style of an internal company data "
    "warehouse (lowercase letters, digits and underscores). Keep each column's meaning, but use synonyms or "
    "abbreviations instead of the original wording. Every new name must be unique.\n"
    "2. Rewrite the three texts with the same meaning, without naming the dataset, its source, any organization, "
    "competition or website, and without quoting the original column names.\n"
    'Return only a json object: {"columns": {"<original name>": "<new name>", ...}, "unit": "...", '
    '"target_description": "...", "prediction_time": "..."}, with every original column name exactly once.')
PARAPHRASE_REMINDER = ("Reminder: return one json object with a new name for every column listed above, plus the "
                       "three rewritten texts.")

DISGUISE_SYSTEM = ("You disguise descriptions of data tables so that nobody can tell which public dataset they come "
                   "from, while keeping their meaning. Answer with one json object only.")
DISGUISE_RULES = (
    "Rules:\n"
    "1. Rewrite the three texts with the same meaning. They must not contain any dataset name, source, organization, "
    "place, brand, person, year or size (no counts of rows, records, people or places), and must not use these "
    "words: %s.\n"
    "2. Give every column a new name: exactly one per column, all different, each different from its original. Keep "
    "the same level of detail: abbreviations and codes become different abbreviations or codes of similar length "
    "and are never expanded (for example \"LBE\" -> \"QTR\", \"A\" -> \"K\"); descriptive names become paraphrases. "
    "Never add words about timing, outcome or leakage that the original name does not have.\n"
    "3. Rewrite every listed label with the same meaning but different wording. Proper nouns, places, brands, "
    "organizations and country codes become generic placeholders such as region_A or property_type_B.\n"
    "4. Do not comment on the columns, their usefulness or leakage.\n"
    'Return only a json object: {"unit": "...", "target_description": "...", "prediction_time": "...", '
    '"columns": {"<original name>": "<new name>", ...}, "labels": {"<original column name>": {"<original label>": '
    '"<new label>", ...}, ...}}, with every original column name exactly once in "columns".')
DISGUISE_REMINDER = "Reminder: your previous answer had these problems: %s. Return the complete json object again, fixed."

PROBE_SYSTEM = "You identify public datasets from descriptions of their tables. Answer with one json object only."
PROBE_QUESTION = ('Which public dataset (e.g. from UCI, Kaggle or OpenML) is this table most likely taken from? '
                  'Return JSON {"guesses": [{"name": ..., "confidence": 0-100}]} with up to 3 guesses; give your best '
                  'guesses even if unsure.')
PROBE_REMINDER = ('Reminder: answer with one json object only, in the form {"guesses": [{"name": "...", '
                  '"confidence": 50}]}.')

_lock = threading.Lock()
STATE: Dict[str, Dict[str, Any]] = {"disabled": {}, "skipped": {}, "ok": {}, "bad400": {}}


# ============================================================ settings helpers
def open_key(model: str) -> str:
    """The label of one OpenRouter model: open-<name without the maker>, e.g. open-gemma-4-31b-it."""
    name = str(model).split("/")[-1].strip().lower()
    return "open-" + (re.sub(r"[^a-z0-9._-]+", "-", name).strip("-") or "model")


def open_keys() -> Dict[str, str]:
    """{label: OpenRouter model id} for OPEN_MODELS."""
    return {open_key(x): str(x).strip() for x in OPEN_MODELS}


def is_open(m: str) -> bool:
    return m.startswith("open-")


def expand(models: List[str]) -> List[str]:
    """MODELS with "open" replaced by one entry per model in OPEN_MODELS."""
    out: List[str] = []
    for m in models:
        out += list(open_keys()) if m == "open" else [m]
    return list(dict.fromkeys(out))


def all_models() -> List[str]:
    """Every model whose cached answers go into scores_llm.csv, whether or not it is in MODELS this run."""
    return ["deepseek", "claude", "gpt", "local"] + list(open_keys())


def model_id(m: str) -> str:
    if is_open(m):
        return open_keys()[m]
    return {"deepseek": DEEPSEEK_MODEL, "claude": CLAUDE_MODEL, "gpt": GPT_MODEL, "local": LOCAL_MODEL}[m]


def api_key(m: str) -> str:
    if is_open(m):
        return OPENROUTER_API_KEY
    return {"deepseek": DEEPSEEK_API_KEY, "claude": ANTHROPIC_API_KEY, "gpt": OPENAI_API_KEY,
            "local": LOCAL_DUMMY_KEY}[m]


def key_name(m: str) -> str:
    if is_open(m):
        return "OPENROUTER_API_KEY"
    return {"deepseek": "DEEPSEEK_API_KEY", "claude": "ANTHROPIC_API_KEY", "gpt": "OPENAI_API_KEY",
            "local": "LOCAL_MODEL"}[m]


def max_tokens_name(m: str) -> str:
    return "OPEN_MAX_TOKENS" if is_open(m) else ("LOCAL_MAX_TOKENS" if m == "local" else "MAX_TOKENS")


def has_key(m: str) -> bool:
    """For the local model: its model id is pasted (LM Studio needs no key)."""
    k = (model_id(m) if m == "local" else api_key(m) or "").strip()
    return bool(k) and not k.startswith("PASTE_")


def probe_models(models: List[str]) -> List[str]:
    return [m for m in models if (m != "local" or PROBES_LOCAL) and (not is_open(m) or PROBES_OPEN)]


def add_usage(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    """Two calls' usage together: tokens and any reported cost (usd) added up, the providers listed."""
    out: Dict[str, Any] = {"in": common.num(a.get("in")) + common.num(b.get("in")),
                           "out": common.num(a.get("out")) + common.num(b.get("out"))}
    if "usd" in a or "usd" in b:
        out["usd"] = float(a.get("usd") or 0.0) + float(b.get("usd") or 0.0)
    if "reasoning" in a or "reasoning" in b:
        out["reasoning"] = common.num(a.get("reasoning")) + common.num(b.get("reasoning"))
    prov = [p for p in (a.get("provider"), b.get("provider")) if p]
    if prov:
        out["provider"] = " + ".join(dict.fromkeys(prov))
    return out


def local_key(model: str) -> str:
    """The label of a local model: local-<id without the publisher>, e.g. qwen/qwen3.5-9b -> local-qwen3.5-9b."""
    name = str(model).split("/")[-1].strip().lower()
    return "local-" + (re.sub(r"[^a-z0-9._-]+", "-", name).strip("-") or "model")


def label(m: str) -> str:
    """Name used in llm_cache/ and scores_llm.csv; mock results never mix with real ones. Each local model is labeled
    after its id, so different LM Studio models never share a cache folder."""
    base = local_key(LOCAL_MODEL) if m == "local" else m
    return "mock-" + base if MOCK else base


def price(m: str) -> Optional[Tuple[float, float]]:
    return PRICE_PER_M.get(model_id(m)) or PRICE_PER_M.get(m)


def cost_of(m: str, usage: Dict[str, Any]) -> float:
    """The cost the API reported (OpenRouter), else tokens times PRICE_PER_M."""
    if usage.get("usd") is not None:
        return float(usage["usd"])
    p = price(m)
    return 0.0 if not p else (usage.get("in", 0) * p[0] + usage.get("out", 0) * p[1]) / 1e6


def needs_paraphrase() -> bool:
    return any(c in ("reworded", "scrambled") for c in CONDITIONS)


def needs_disguise() -> bool:
    return "disguised" in CONDITIONS


def probe_conditions() -> List[str]:
    if not PROBES:
        return []
    return ["real"] + (["disguised"] if needs_disguise() else [])


def needed_models() -> List[str]:
    ms = expand(MODELS) + ([PARAPHRASE_MODEL] if needs_paraphrase() else []) + \
        ([DISGUISE_MODEL] if needs_disguise() else [])
    return sorted(set(ms))


def check_settings() -> List[str]:
    problems = []
    if not MODELS:
        problems.append("MODELS is empty")
    if not CONDITIONS:
        problems.append("CONDITIONS is empty")
    for m in MODELS:
        if m not in KNOWN_MODELS:
            problems.append("MODELS: unknown %r (use 'deepseek', 'claude', 'gpt', 'local' or 'open')" % m)
    if "open" in MODELS:
        if not OPEN_MODELS:
            problems.append("OPEN_MODELS is empty (MODELS has 'open')")
        for x in OPEN_MODELS:
            if "/" not in str(x):
                problems.append("OPEN_MODELS: %r is not an OpenRouter id like 'google/gemma-4-31b-it'" % x)
        if len(open_keys()) != len(OPEN_MODELS):
            problems.append("OPEN_MODELS: two models end in the same name -- keep one of them")
    for c in CONDITIONS:
        if c not in KNOWN_CONDITIONS:
            problems.append("CONDITIONS: unknown %r (use 'real', 'reworded', 'scrambled' or 'disguised')" % c)
    if needs_paraphrase() and PARAPHRASE_MODEL not in WRITER_MODELS:
        problems.append("PARAPHRASE_MODEL: unknown %r" % PARAPHRASE_MODEL)
    if needs_disguise() and DISGUISE_MODEL not in WRITER_MODELS:
        problems.append("DISGUISE_MODEL: unknown %r" % DISGUISE_MODEL)
    return problems


def say(msg: str) -> None:
    with _lock:
        print(msg)


def log(msg: str) -> None:
    """Prints and appends to step3_log.txt."""
    with _lock:
        print(msg)
        try:
            with open(common.path(LOG_FILE), "a", encoding="utf-8") as f:
                f.write("%s  %s%s\n" % (common.stamp(), "[mock] " if MOCK else "", " ".join(msg.split())))
        except OSError:
            pass


def disable(m: str, why: str) -> None:
    with _lock:
        first = m not in STATE["disabled"]
        STATE["disabled"][m] = why
    if first:
        log("  %s: no more calls this run -- %s" % (m, why))


# ============================================================ providers
def call_deepseek(system: str, user: str, max_tokens: Optional[int] = None) -> Tuple[str, Dict[str, int], str]:
    body = {"model": DEEPSEEK_MODEL,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "temperature": TEMPERATURE, "max_tokens": min(int(max_tokens or MAX_TOKENS), 8192),  # DeepSeek's cap
            "response_format": {"type": "json_object"}}
    headers = {"Content-Type": "application/json", "Authorization": "Bearer " + DEEPSEEK_API_KEY}
    r = common.http_post(DEEPSEEK_URL, headers, body, TIMEOUT_S, MAX_RETRIES)
    choices = r.get("choices") or [{}]
    ch = choices[0] if isinstance(choices[0], dict) else {}
    text = (ch.get("message") or {}).get("content") or ""
    u = r.get("usage") or {}
    return (str(text), {"in": common.num(u.get("prompt_tokens")), "out": common.num(u.get("completion_tokens"))},
            str(ch.get("finish_reason") or ""))


def call_claude(system: str, user: str, max_tokens: Optional[int] = None) -> Tuple[str, Dict[str, int], str]:
    body = {"model": CLAUDE_MODEL, "max_tokens": int(max_tokens or MAX_TOKENS), "system": system,
            "messages": [{"role": "user", "content": user}]}  # current Claude models reject temperature
    headers = {"content-type": "application/json", "x-api-key": ANTHROPIC_API_KEY,
               "anthropic-version": "2023-06-01"}
    r = common.http_post(ANTHROPIC_URL, headers, body, TIMEOUT_S, MAX_RETRIES)
    text = "".join(str(b.get("text") or "") for b in (r.get("content") or [])
                   if isinstance(b, dict) and b.get("type") == "text")
    u = r.get("usage") or {}
    return (text, {"in": common.num(u.get("input_tokens")), "out": common.num(u.get("output_tokens"))},
            str(r.get("stop_reason") or ""))


def call_gpt(system: str, user: str, max_tokens: Optional[int] = None) -> Tuple[str, Dict[str, int], str]:
    body = {"model": GPT_MODEL, "instructions": system, "input": user,
            "max_output_tokens": int(max_tokens or MAX_TOKENS), "store": False}
    headers = {"Content-Type": "application/json", "Authorization": "Bearer " + OPENAI_API_KEY}
    r = common.http_post(OPENAI_URL, headers, body, TIMEOUT_S, MAX_RETRIES)
    texts = []
    for item in r.get("output") or []:
        if isinstance(item, dict) and item.get("type") == "message":
            for c in item.get("content") or []:
                if isinstance(c, dict) and c.get("type") == "output_text":
                    texts.append(str(c.get("text") or ""))
    u = r.get("usage") or {}
    stop = str(r.get("status") or "")
    if stop == "incomplete":
        stop += ": " + str((r.get("incomplete_details") or {}).get("reason") or "")
    return "".join(texts), {"in": common.num(u.get("input_tokens")), "out": common.num(u.get("output_tokens"))}, stop


class LocalDown(Exception):
    """LM Studio's server refuses the connection (not running)."""


LOCAL_DOWN = "LM Studio's server isn't running -- open LM Studio, load the model, start the server"
AUDIT_SCHEMA = {"type": "object", "required": ["dataset_guess", "columns"], "properties": {
    "dataset_guess": {"type": ["string", "null"]},
    "columns": {"type": "array", "items": {
        "type": "object", "required": ["column", "leak_risk", "category", "reason"],
        "properties": {"column": {"type": "string"}, "leak_risk": {"type": "number"}, "category": {"type": "string"},
                       "reason": {"type": "string"}}}}}}
PROBE_SCHEMA = {"type": "object", "required": ["guesses"], "properties": {"guesses": {"type": "array", "items": {
    "type": "object", "required": ["name", "confidence"],
    "properties": {"name": {"type": "string"}, "confidence": {"type": "number"}}}}}}


def strip_think(text: str) -> str:
    """The answer without the reasoning a thinking model writes in <think>...</think> (also when the opening tag came
    from the chat template, or when the answer was cut off before the block closed)."""
    t = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S | re.I)
    if re.search(r"</think>", t, flags=re.I):
        t = re.split(r"</think>", t, flags=re.I)[-1]
    t = re.sub(r"<think>.*\Z", "", t, flags=re.S | re.I)
    return t.strip()


def refused(reason: Any) -> bool:
    return isinstance(reason, ConnectionRefusedError) or "refused" in str(reason).lower()


def lmstudio_base() -> str:
    """http://localhost:1234 from LOCAL_URL."""
    u = LOCAL_URL.rstrip("/")
    for tail in ("/v1/chat/completions", "/chat/completions"):
        if u.endswith(tail):
            return u[:-len(tail)]
    return u.rsplit("/v1/", 1)[0]


def local_check() -> None:
    """Start-up check of the local model: asks LM Studio (GET /api/v1/models) whether LOCAL_MODEL is loaded, with what
    context length, and whether it can think, and prints advice. It never stops the run."""
    url = lmstudio_base() + "/api/v1/models"
    try:
        req = urllib.request.Request(url, headers={"Authorization": "Bearer " + LOCAL_DUMMY_KEY})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as e:  # LM Studio not running, or an older version without this endpoint
        print("Local model check: no answer from %s (%s) -- start LM Studio's server before the real run"
              % (url, e.__class__.__name__))
        return
    models = [x for x in (data.get("models") or []) if isinstance(x, dict)]
    entry, inst = None, None
    for x in models:
        for li in x.get("loaded_instances") or []:
            if isinstance(li, dict) and str(li.get("id")) == LOCAL_MODEL:
                entry, inst = x, li
    if entry is None:
        for x in models:
            if str(x.get("key")) == LOCAL_MODEL:
                entry = x
                loaded = [li for li in (x.get("loaded_instances") or []) if isinstance(li, dict)]
                inst = loaded[0] if loaded else None
    n_loaded = sum(len(x.get("loaded_instances") or []) for x in models)
    notes = []
    if entry is None:
        print("Local model check: LM Studio doesn't list %r -- copy the exact id from %s" % (LOCAL_MODEL, url))
        return
    if inst is None:
        notes.append("it is downloaded but not loaded: load it (Load tab: Context Length 16384) before the real run")
        ctx = None
    else:
        ctx = common.num((inst.get("config") or {}).get("context_length"))
        if ctx and ctx < LOCAL_MIN_CONTEXT:
            notes.append("context length %d is below %d: eject it, set Context Length to 16384 on the Load tab and "
                         "load it again" % (ctx, LOCAL_MIN_CONTEXT))
    if n_loaded > 1:
        notes.append("%d models are loaded in LM Studio: eject all but this one (they share your memory)" % n_loaded)
    rcfg = (entry.get("capabilities") or {}).get("reasoning")
    if isinstance(rcfg, dict):
        allowed = [str(a) for a in (rcfg.get("allowed_options") or [])]
        default = str(rcfg.get("default") or "")
        asked = LOCAL_REASONING_EFFORT or default
        thinking = str(asked).lower() not in ("off", "none", "")
        think_txt = "can think (%s; LM Studio default %r); this run asks for %r" % ("/".join(allowed), default, asked)
        if not LOCAL_REASONING_EFFORT and default == "off" and "on" in allowed:
            notes.append('thinking is off by default: set LOCAL_REASONING_EFFORT = "medium" to let it think')
        if thinking and LOCAL_TEMPERATURE == 0:
            notes.append("a model that thinks can loop at temperature 0: set LOCAL_TEMPERATURE = 0.6")
    else:
        think_txt = "has no thinking setting"
        if LOCAL_REASONING_EFFORT:
            notes.append("LOCAL_REASONING_EFFORT is set, but this model can't think: set it back to None")
    print("Local model check: %s is %s%s, and %s." % (LOCAL_MODEL, "loaded" if inst is not None else "not loaded",
                                                      (" with context length %d" % ctx) if ctx else "", think_txt))
    for n in notes:
        print("  -> " + n)
    if not notes:
        print("  -> ready")


def call_local(system: str, user: str, max_tokens: Optional[int] = None) -> Tuple[str, Dict[str, int], str]:
    """One chat request to LM Studio's OpenAI-compatible server; no retries (a local timeout means: too slow)."""
    body: Dict[str, Any] = {"model": LOCAL_MODEL,
                            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                            "temperature": LOCAL_TEMPERATURE, "max_tokens": int(max_tokens or LOCAL_MAX_TOKENS),
                            "stream": False}
    if LOCAL_REASONING_EFFORT:
        body["reasoning_effort"] = LOCAL_REASONING_EFFORT
    schema = {SYSTEM_PROMPT: AUDIT_SCHEMA, PROBE_SYSTEM: PROBE_SCHEMA}.get(system)
    if LOCAL_JSON_MODE and schema:
        body["response_format"] = {"type": "json_schema", "json_schema": {"name": "answer", "schema": schema}}
    req = urllib.request.Request(LOCAL_URL, data=json.dumps(body).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json",
                                          "Authorization": "Bearer " + LOCAL_DUMMY_KEY})
    slow = ("LM Studio did not answer within LOCAL_TIMEOUT_S = %d s -- raise it or use a smaller model"
            % LOCAL_TIMEOUT_S)
    try:
        with urllib.request.urlopen(req, timeout=LOCAL_TIMEOUT_S) as resp:
            r = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:800]
        raise common.ApiError("HTTP %s from LM Studio (%s) -- check LOCAL_MODEL and that the model is loaded.\n%s"
                              % (e.code, LOCAL_URL, detail), e.code)
    except urllib.error.URLError as e:
        if refused(e.reason):
            raise LocalDown(LOCAL_DOWN)
        if isinstance(e.reason, (socket.timeout, TimeoutError)):
            raise common.ApiError(slow)
        raise common.ApiError("cannot reach LM Studio at %s: %s" % (LOCAL_URL, e.reason))
    except (socket.timeout, TimeoutError):
        raise common.ApiError(slow)
    except ConnectionRefusedError:
        raise LocalDown(LOCAL_DOWN)
    except (ConnectionError, OSError, ValueError) as e:  # a dropped connection or a garbled answer
        raise common.ApiError("LM Studio: %s: %s" % (e.__class__.__name__, e))
    choices = r.get("choices") or [{}]
    ch = choices[0] if isinstance(choices[0], dict) else {}
    text = strip_think(str((ch.get("message") or {}).get("content") or ""))
    u = r.get("usage") or {}
    return (text, {"in": common.num(u.get("prompt_tokens")), "out": common.num(u.get("completion_tokens"))},
            str(ch.get("finish_reason") or ""))


def open_error(err: Any, http_code: int = 0) -> "common.ApiError":
    """An error object inside an OpenRouter answer, as an ApiError carrying its code."""
    code = http_code
    if isinstance(err, dict):
        try:
            code = int(err.get("code") or http_code or 0)
        except (TypeError, ValueError):
            code = http_code
        msg = str(err.get("message") or err)
    else:
        msg = str(err)
    return common.ApiError("OpenRouter error %s: %s" % (code or "?", " ".join(msg.split())[:400]), code)


def call_open(m: str, system: str, user: str, max_tokens: Optional[int] = None) -> Tuple[str, Dict[str, Any], str]:
    """One chat request through OpenRouter to an open-weight model (OPEN_MODELS). The answer is read after any
    reasoning; the usage carries the cost OpenRouter reports (usd), the thinking tokens and the provider."""
    body: Dict[str, Any] = {"model": model_id(m),
                            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                            "max_tokens": int(max_tokens or OPEN_MAX_TOKENS), "stream": False,
                            "usage": {"include": True}}
    if OPEN_TEMPERATURE is not None:
        body["temperature"] = OPEN_TEMPERATURE
    if OPEN_TOP_P is not None:
        body["top_p"] = OPEN_TOP_P
    if OPEN_REASONING:
        body["reasoning"] = {"enabled": True}
    provider: Dict[str, Any] = {"allow_fallbacks": True}
    if OPEN_QUANTIZATIONS:
        provider["quantizations"] = list(OPEN_QUANTIZATIONS)
    body["provider"] = provider
    headers = {"Content-Type": "application/json", "Authorization": "Bearer " + OPENROUTER_API_KEY,
               "X-Title": "leakaudit fresh test"}
    r = common.http_post(OPEN_URL, headers, body, OPEN_TIMEOUT_S, MAX_RETRIES)
    if r.get("error"):
        raise open_error(r["error"])
    choices = r.get("choices") or [{}]
    ch = choices[0] if isinstance(choices[0], dict) else {}
    if ch.get("error"):
        raise open_error(ch["error"])
    content = (ch.get("message") or {}).get("content")
    if isinstance(content, list):  # some providers send the answer as a list of parts
        content = "".join(str(p.get("text") or "") for p in content if isinstance(p, dict))
    text = strip_think(str(content or ""))
    u = r.get("usage") or {}
    usage: Dict[str, Any] = {"in": common.num(u.get("prompt_tokens")), "out": common.num(u.get("completion_tokens"))}
    if u.get("cost") is not None:
        try:
            usage["usd"] = float(u["cost"])
        except (TypeError, ValueError):
            pass
    usage["reasoning"] = common.num((u.get("completion_tokens_details") or {}).get("reasoning_tokens"))
    if r.get("provider"):
        usage["provider"] = str(r["provider"])
    return text, usage, str(ch.get("finish_reason") or "")


def call_model(m: str, system: str, user: str, max_tokens: Optional[int] = None) -> Tuple[str, Dict[str, Any], str]:
    if MOCK:
        return mock_call(m, system, user)
    if is_open(m):
        return call_open(m, system, user, max_tokens)
    return {"deepseek": call_deepseek, "claude": call_claude, "gpt": call_gpt,
            "local": call_local}[m](system, user, max_tokens)


# ============================================================ prompts
def prepare_case(case: Dict[str, Any]) -> Dict[str, Any]:
    df = common.read_data(case["id"])
    cols = [c for c in df.columns if c != common.TARGET]
    rng = np.random.RandomState((SEED * 1000003 + zlib.crc32(case["id"].encode("utf-8"))) % (2 ** 32))
    summaries = {c: common.column_summary(df[c], N_EXAMPLES, rng) for c in cols}
    return {"case": case, "id": case["id"], "task": case["task"], "columns": cols, "summaries": summaries,
            "n_rows": len(df), "real_text": {k: case.get(k) or "" for k in TEXT_KEYS},
            "dz": disguise_stats(df, cols, summaries)}


def user_prompt(text: Dict[str, str], task: str, lines: List[str], n_rows: int) -> str:
    kind = "binary classification" if task == "binary" else "regression"
    parts = ["Unit of observation: " + (text.get("unit") or "(not given)"),
             "Target (%s): %s" % (kind, text.get("target_description") or "(not given)"),
             "Prediction moment: " + (text.get("prediction_time") or "(not given)"),
             "",
             "Columns (%d; values from %d rows) -- name | type | missing | distinct values | examples:"
             % (len(lines), n_rows)]
    return "\n".join(parts + lines + ["", INSTRUCTION])


def scrambled_names(cols: List[str]) -> Dict[str, str]:
    width = max(2, len(str(len(cols))))
    return {c: "col_%0*d" % (width, i + 1) for i, c in enumerate(cols)}


def condition_prompt(info: Dict[str, Any], cond: str, rw: Optional[Dict[str, Any]],
                     dz: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """The user prompt for one condition and the names it shows ({original: shown}); None without reworded (or
    disguised) names and text."""
    cols = info["columns"]
    if cond == "disguised":
        if not dz or dz.get("failed"):
            return None
        text, lines, rows = disguised_parts(info, dz)
        return {"user": describe(text, info["task"], lines, rows) + "\n\n" + INSTRUCTION, "names": dz["names"]}
    if cond == "real":
        names, text = {c: c for c in cols}, info["real_text"]
    else:
        if not rw or rw.get("failed"):
            return None
        text = rw["text"]
        names = rw["names"] if cond == "reworded" else scrambled_names(cols)
    lines = [common.column_line(names[c], info["summaries"][c]) for c in cols]
    return {"user": user_prompt(text, info["task"], lines, info["n_rows"]), "names": names}


# ============================================================ run 3: chunked prompts
# Fine-tune run 3 rates at most CHUNK_SIZE columns per prompt. Each prompt names every column of the table (for
# context) and shows the summaries of the columns it asks about; the answer gives a short reason before the risk. The
# whole-table prompts above are unchanged, so earlier answers can still be checked against them.
CHUNK_SIZE = 10
INSTRUCTION_CHUNK = (
    'Return only a json object, with no other text:\n'
    '{"columns": [{"column": "<name>", "reason": "<one short sentence>", "category": '
    '"post_outcome|target_derived|identifier|future_aggregate|fine", "leak_risk": <0-100>}]}\n'
    'Rate exactly the %d columns listed with values above, each once, using the names exactly as given. Keep each '
    'reason under 15 words.')


def shown_name(name: Any) -> str:
    """A column name as the prompts show it (runs of whitespace collapsed, as common.column_line does)."""
    return " ".join(str(name).split())


def chunk_parts(cols: List[str], size: Optional[int] = None) -> List[List[str]]:
    """cols split into ceil(n / size) runs of consecutive columns, sizes as equal as possible, larger ones first
    (23 columns -> 8, 8, 7)."""
    size = int(size or CHUNK_SIZE)
    n = len(cols)
    if n == 0:
        return []
    k = (n + size - 1) // size
    base, extra = divmod(n, k)
    out, i = [], 0
    for j in range(k):
        m = base + (1 if j < extra else 0)
        out.append(list(cols[i:i + m]))
        i += m
    return out


def chunk_user(text: Dict[str, str], task: str, all_cols: List[str], n_rows: int, lines: List[str], part: int,
               parts: int) -> str:
    kind = "binary classification" if task == "binary" else "regression"
    head = ["Unit of observation: " + (text.get("unit") or "(not given)"),
            "Target (%s): %s" % (kind, text.get("target_description") or "(not given)"),
            "Prediction moment: " + (text.get("prediction_time") or "(not given)"),
            "",
            "The table has %d columns besides the target (values from %d rows). All of them: %s"
            % (len(all_cols), n_rows, ", ".join(shown_name(c) for c in all_cols)),
            "",
            "Rate these %d columns (part %d of %d) -- name | type | missing | distinct values | examples:"
            % (len(lines), part, parts)]
    return "\n".join(head + lines + ["", INSTRUCTION_CHUNK % len(lines)])


def chunk_prompts(info: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The run 3 prompts of one table (info as prepare_case or chunk_info builds it): one per chunk, in order.
    Each: chunk_id "<table id>__c<j>of<k>", table, part, parts, columns (the chunk's columns), user (the prompt)."""
    cols = list(info["columns"])
    groups = chunk_parts(cols)
    out = []
    for j, g in enumerate(groups, 1):
        lines = [common.column_line(c, info["summaries"][c]) for c in g]
        out.append({"chunk_id": "%s__c%dof%d" % (info["id"], j, len(groups)), "table": info["id"], "part": j,
                    "parts": len(groups), "columns": g,
                    "user": chunk_user(info["real_text"], info["task"], cols, info["n_rows"], lines, j, len(groups))})
    return out


def chunk_info(case: Dict[str, Any]) -> Dict[str, Any]:
    """What prepare_case builds (same columns, same summaries, same seed rule), without the disguise statistics."""
    df = common.read_data(case["id"])
    cols = [c for c in df.columns if c != common.TARGET]
    rng = np.random.RandomState((SEED * 1000003 + zlib.crc32(case["id"].encode("utf-8"))) % (2 ** 32))
    summaries = {c: common.column_summary(df[c], N_EXAMPLES, rng) for c in cols}
    return {"case": case, "id": case["id"], "task": case["task"], "columns": cols, "summaries": summaries,
            "n_rows": len(df), "real_text": {k: case.get(k) or "" for k in TEXT_KEYS}}


def chunk_reminder(shown: List[str], missing: Optional[List[str]]) -> str:
    """The retry reminder: every column again if the answer was unreadable, else just the missing ones."""
    return REMINDER_ALL % len(shown) if missing is None else REMINDER_MISSING % ", ".join(missing)


# ============================================================ reading answers
_FLAT_OBJECT = re.compile(r"\{[^{}]*\}", re.S)
_GUESS = re.compile(r'"dataset_guess"\s*:\s*(null|"(?:[^"\\]|\\.)*")')


def to_risk(v: Any) -> float:
    if isinstance(v, bool) or v is None:
        return float("nan")
    if isinstance(v, (int, float)):
        x = float(v)
    else:
        m = re.search(r"-?\d+(?:\.\d+)?", str(v))
        if not m:
            return float("nan")
        x = float(m.group(0))
    return float(min(100.0, max(0.0, x))) if np.isfinite(x) else float("nan")


def norm_category(v: Any) -> str:
    s = re.sub(r"[\s\-]+", "_", str(v or "").strip().lower())
    return s if s in CATEGORIES else s[:40]


def clean_guess(v: Any) -> Optional[str]:
    if v is None:
        return None
    s = " ".join(str(v).split()).strip(" .\"'")
    if s.lower() in ("", "null", "none", "unknown", "n/a", "na", "no", "not recognized", "unrecognized"):
        return None
    return s[:200]


def salvage(text: str) -> Tuple[List[Dict[str, Any]], Any]:
    """From a cut-off or broken answer: every complete {...} entry that names a column, and the dataset guess."""
    items = []
    for m in _FLAT_OBJECT.finditer(text or ""):
        try:
            obj = common.loads_lenient(m.group(0))
        except ValueError:
            continue
        if isinstance(obj, dict) and ("column" in obj or "name" in obj):
            items.append(obj)
    guess = None
    g = _GUESS.search(text or "")
    if g:
        try:
            guess = json.loads(g.group(1))
        except ValueError:
            pass
    return items, guess


def loose_key(name: str) -> str:
    """Case, punctuation and leading zeros ignored: 'Col_1', 'col01' and 'col_01' match."""
    return re.sub(r"(?<!\d)0+(?=\d)", "", common.norm_text(name))


def parse_answer(text: str, shown: List[str]) -> Optional[Dict[str, Any]]:
    """{'dataset_guess', 'entries': {shown name: {leak_risk, category, reason}}, 'unknown': [...]} or None."""
    obj = common.extract_json(text)
    items: Any = None
    guess = None
    if isinstance(obj, dict):
        guess = obj.get("dataset_guess")
        cols = obj.get("columns")
        if isinstance(cols, list):
            items = cols
        elif isinstance(cols, dict):
            items = [dict(v, column=k) if isinstance(v, dict) else {"column": k, "leak_risk": v}
                     for k, v in cols.items()]
    elif isinstance(obj, list):
        items = obj
    if not items:
        items, guess2 = salvage(text)
        guess = guess if guess is not None else guess2
    if not items:
        return None
    exact = set(shown)
    loose_all: Dict[str, List[str]] = {}
    for n in shown:
        loose_all.setdefault(loose_key(n), []).append(n)
    loose = {k: v[0] for k, v in loose_all.items() if len(v) == 1}  # only names that stay unique
    entries: Dict[str, Dict[str, Any]] = {}
    unknown = []
    for it in items:
        if not isinstance(it, dict):
            continue
        name = it.get("column", it.get("name"))
        if name is None:
            continue
        name = str(name).strip().strip("`'\"")
        hit = name if name in exact else loose.get(loose_key(name))
        if hit is None:
            unknown.append(name)
            continue
        if hit not in entries:
            entries[hit] = {"leak_risk": to_risk(it.get("leak_risk")), "category": norm_category(it.get("category")),
                            "reason": " ".join(str(it.get("reason") or "").split())[:300]}
    if not entries:
        return None
    return {"dataset_guess": clean_guess(guess), "entries": entries, "unknown": unknown}


# ============================================================ one audit call (cached)
def cache_path(m: str, cond: str, case_id: str) -> str:
    return common.path("llm_cache", label(m), cond, case_id + ".json")


def audit(info: Dict[str, Any], cond: str, m: str, prompt: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    cid = info["id"]
    tag = "%s / %s / %s" % (label(m), cond, cid)
    cpath = cache_path(m, cond, cid)
    phash = common.text_hash(model_id(m), SYSTEM_PROMPT, prompt["user"])
    cached = common.load_json(cpath)
    if isinstance(cached, dict) and cached.get("prompt_hash") == phash and cached.get("parsed"):
        cached["from_cache"] = True
        return cached
    if m in STATE["disabled"]:
        with _lock:
            STATE["skipped"][m] = STATE["skipped"].get(m, 0) + 1
        return None
    if cached:
        say("  %s: the prompt changed since the cached answer -- asking again" % tag)
    shown = [prompt["names"][c] for c in info["columns"]]
    back = {prompt["names"][c]: c for c in info["columns"]}
    t0 = time.time()
    text1, u1, stop1 = call_model(m, SYSTEM_PROMPT, prompt["user"])
    usage = dict(u1)
    p1 = parse_answer(text1, shown)
    found = dict(p1["entries"]) if p1 else {}
    guess = p1["dataset_guess"] if p1 else None
    unknown = list(p1["unknown"]) if p1 else []
    missing = [d for d in shown if d not in found]
    text2, stop2 = None, None
    if p1 is None or len(missing) > 0.10 * len(shown):
        why = "answer not readable" if p1 is None else "%d of %d columns missing" % (len(missing), len(shown))
        log("  %s: %s (stop: %s) -- asking once more" % (tag, why, stop1 or "?"))
        reminder = REMINDER_ALL % len(shown) if p1 is None else REMINDER_MISSING % ", ".join(missing)
        text2, u2, stop2 = call_model(m, SYSTEM_PROMPT, prompt["user"] + "\n\n" + reminder)
        usage = add_usage(usage, u2)
        p2 = parse_answer(text2, shown)
        if p2:
            for d, e in p2["entries"].items():
                if d not in found:
                    found[d] = e
            guess = guess if guess is not None else p2["dataset_guess"]
            unknown += p2["unknown"]
    cost = cost_of(m, usage)
    if not found:
        cut = any(w in str(stop2 or stop1).lower() for w in ("length", "max_tokens", "max_output_tokens"))
        log("  %s: no usable answer after one retry -- not cached, press Run again later.%s It began: %r"
            % (tag, (" The answer was cut off: raise %s." % max_tokens_name(m)) if cut else "",
               (text2 if text2 is not None else text1)[:300]))
        return {"failed": True, "usage": usage, "cost": cost, "from_cache": False}
    columns = {back[d]: e for d, e in found.items()}
    left_out = [c for c in info["columns"] if c not in columns]
    if left_out:
        log("  %s: no answer for %d column(s), left blank: %s" % (tag, len(left_out), ", ".join(left_out)))
    if unknown:
        log("  %s: ignored %d name(s) not in the table: %s" % (tag, len(unknown), ", ".join(unknown[:10])))
    rec = {"case_id": cid, "model": label(m), "model_id": "mock" if MOCK else model_id(m), "condition": cond,
           "prompt_hash": phash, "timestamp": common.stamp(), "prompt": prompt["user"], "raw": text1,
           "raw_retry": text2, "stop": [stop1, stop2], "names": prompt["names"],
           "parsed": {"dataset_guess": guess, "columns": columns, "missing": left_out, "unknown_names": unknown},
           "usage": usage, "cost": round(cost, 6), "seconds": round(time.time() - t0, 1)}
    common.write_json(cpath, rec)
    say("  %s: %d/%d columns rated, guess %s, $%.4f, %.0f s"
        % (tag, len(columns), len(shown), json.dumps(guess), cost, time.time() - t0))
    rec["from_cache"] = False
    return rec


# ============================================================ reworded names and task text (cached)
def snake(s: Any) -> str:
    out = re.sub(r"[^a-z0-9]+", "_", str(s).strip().lower()).strip("_")
    if out and out[0].isdigit():
        out = "c_" + out
    return out[:60]


def validate_names(cols: List[str], pairs: Dict[str, Any]) -> Tuple[Dict[str, str], List[str]]:
    """One new snake_case name per column, all unique and different from the original. Columns without a usable
    name get field_<i> (i = position in the table, from 1)."""
    loose: Dict[str, Any] = {}
    for k, v in pairs.items():
        loose.setdefault(common.norm_text(k), v)
    names: Dict[str, str] = {}
    used = set()
    failed = []
    for c in cols:
        new = pairs.get(c)
        if new is None:
            new = loose.get(common.norm_text(c))
        new = snake(new) if isinstance(new, str) else ""
        if (not new or new == snake(c) or new in used or new == common.TARGET
                or re.match(r"^(col|field)_\d+(_\d+)?$", new)):
            failed.append(c)
            continue
        names[c] = new
        used.add(new)
    for c in failed:
        base = "field_%d" % (cols.index(c) + 1)
        new, k = base, 2
        while new in used:
            new, k = "%s_%d" % (base, k), k + 1
        names[c] = new
        used.add(new)
    return {c: names[c] for c in cols}, failed


def parse_paraphrase(text: str, cols: List[str]) -> Optional[Dict[str, Any]]:
    obj = common.extract_json(text)
    if not isinstance(obj, dict):
        return None
    texts = {}
    for k in TEXT_KEYS:
        v = obj.get(k)
        if not isinstance(v, str) or not v.strip():
            return None
        texts[k] = " ".join(v.split())
    raw = obj.get("columns")
    pairs: Dict[str, Any] = {}
    if isinstance(raw, dict):
        pairs = {str(k): v for k, v in raw.items()}
    elif isinstance(raw, list):
        for it in raw:
            if isinstance(it, dict):
                old = it.get("original", it.get("old", it.get("column")))
                new = it.get("new", it.get("new_name", it.get("renamed", it.get("name"))))
                if old is not None:
                    pairs[str(old)] = new
    names, fallbacks = validate_names(cols, pairs)
    return {"names": names, "fallbacks": fallbacks, "text": texts}


def paraphrase_user(info: Dict[str, Any]) -> str:
    t = info["real_text"]
    lines = ["- %s (%s)" % (c, info["summaries"][c]["type"]) for c in info["columns"]]
    return ("Here are the %d columns of one table, and three short texts that describe a prediction task on it.\n\n"
            % len(lines) + "\n".join(lines) + "\n\nunit: %s\ntarget_description: %s\nprediction_time: %s\n\n"
            % (t["unit"], t["target_description"], t["prediction_time"]) + PARAPHRASE_INSTRUCTION)


def get_paraphrase(info: Dict[str, Any], calls_allowed: bool = True) -> Optional[Dict[str, Any]]:
    if MOCK:
        return mock_paraphrase(info)
    cid = info["id"]
    cpath = common.path("reworded", cid + ".json")
    user = paraphrase_user(info)
    phash = common.text_hash(model_id(PARAPHRASE_MODEL), PARAPHRASE_SYSTEM, user)
    cached = common.load_json(cpath)
    if isinstance(cached, dict) and cached.get("prompt_hash") == phash and cached.get("names") and cached.get("text"):
        cached["from_cache"] = True
        return cached
    if not calls_allowed:
        return None
    if PARAPHRASE_MODEL in STATE["disabled"]:
        with _lock:
            STATE["skipped"][PARAPHRASE_MODEL] = STATE["skipped"].get(PARAPHRASE_MODEL, 0) + 1
        return None
    usage = {"in": 0, "out": 0}
    raws: List[str] = []
    best = None
    for attempt in range(2):
        text, u, stop = call_model(PARAPHRASE_MODEL, PARAPHRASE_SYSTEM,
                                   user if attempt == 0 else user + "\n\n" + PARAPHRASE_REMINDER)
        usage = {"in": usage["in"] + u["in"], "out": usage["out"] + u["out"]}
        raws.append(text)
        p = parse_paraphrase(text, info["columns"])
        if p is not None and (best is None or len(p["fallbacks"]) < len(best["fallbacks"])):
            best = p
        if best is not None and len(best["fallbacks"]) <= len(info["columns"]) / 2.0:
            break
        if attempt == 0:
            log("  paraphrase / %s: %s (stop: %s) -- asking once more"
                % (cid, "answer not usable" if p is None else "most names unusable", stop or "?"))
    cost = cost_of(PARAPHRASE_MODEL, usage)
    if best is None:
        log("  paraphrase / %s: no usable answer -- reworded and scrambled skipped for this case" % cid)
        return {"failed": True, "usage": usage, "cost": cost, "from_cache": False}
    if best["fallbacks"]:
        log("  paraphrase / %s: %d name(s) unusable, shown as field_<i>: %s"
            % (cid, len(best["fallbacks"]), ", ".join(best["fallbacks"][:10])))
    if len(cid) >= 5 and common.norm_text(cid) in common.norm_text(" ".join(best["text"].values())):
        log("  paraphrase / %s: note -- the reworded task text still contains the case id" % cid)
    rec = {"case_id": cid, "model": PARAPHRASE_MODEL, "model_id": model_id(PARAPHRASE_MODEL), "prompt_hash": phash,
           "timestamp": common.stamp(), "raw": raws[0], "raw_retry": raws[1] if len(raws) > 1 else None,
           "names": best["names"], "fallbacks": best["fallbacks"], "text": best["text"], "usage": usage,
           "cost": round(cost, 6)}
    common.write_json(cpath, rec)
    say("  paraphrase / %s: %d names, %d fallbacks, $%.4f" % (cid, len(best["names"]), len(best["fallbacks"]), cost))
    rec["from_cache"] = False
    return rec


# ============================================================ disguised condition: what it shows
def label_text(v: Any, width: int = 40) -> str:
    t = " ".join(str(v).split())
    return t if len(t) <= width else t[:width - 3] + "..."


def year_like(name: str, v: pd.Series) -> bool:
    """Whole numbers that are years (1800-2100), or two-digit years in a column whose name says year."""
    if not bool((v == v.round()).all()):
        return False
    lo, hi = float(v.min()), float(v.max())
    if 1800 <= lo and hi <= 2100:
        return True
    return bool(re.search(r"(^|[^a-z])(year|yr)", name.lower())) and 0 <= lo and hi <= 99 and v.nunique() > 2


def disguise_stats(df: pd.DataFrame, cols: List[str], summaries: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Per column, what the disguised prompt can show before renaming: type, missing share, distinct count, and the
    numeric levels (10 or fewer) or min / median / max, the date range, or the most frequent labels."""
    out: Dict[str, Dict[str, Any]] = {}
    n = len(df)
    for c in cols:
        s = df[c]
        typ = summaries[c]["type"]
        nonnull = s.dropna()
        st: Dict[str, Any] = {"type": typ, "missing": (1.0 - len(nonnull) / float(n)) if n else 0.0,
                              "n_unique": int(nonnull.nunique())}
        if typ == "numeric":
            v = common.as_float(s)[0].dropna()
            st["n_distinct"] = int(v.nunique())
            if len(v):
                st["year_like"] = year_like(c, v)
                if st["n_distinct"] <= 10:
                    st["levels"] = sorted((float(k), float(cnt) / len(v)) for k, cnt in v.value_counts().items())
                else:
                    st["min"], st["median"], st["max"] = float(v.min()), float(v.median()), float(v.max())
        elif typ == "date":
            d = common.analyze_column(s)[1]
            d = d.dropna() if d is not None else None
            if d is not None and len(d):
                st["min"], st["max"] = d.min(), d.max()
        else:
            txt = nonnull.astype(str)
            if len(txt):
                top = sorted(txt.value_counts().items(), key=lambda kv: (-kv[1], kv[0]))[:N_EXAMPLES]
                st["labels"] = [label_text(k) for k, _ in top]
                st["shares"] = [cnt / float(len(txt)) for _, cnt in top]
        out[c] = st
    return out


def sig(x: float, digits: int = 2) -> str:
    """x rounded to `digits` significant figures, no scientific notation; thousands separators from 10,000."""
    x = float(x)
    if not np.isfinite(x):
        return "nan"
    if x == 0:
        return "0"
    d = digits - 1 - int(np.floor(np.log10(abs(x))))
    r = round(x, d)
    if d <= 0:
        r = int(round(r))
        return "{:,}".format(r) if abs(r) >= 10000 else str(r)
    s = "%.*f" % (d, r)
    return s.rstrip("0").rstrip(".") if "." in s else s


def count_sig(n: int) -> str:
    return str(n) if n < 100 else sig(n, 2)


def about_rows(n: int) -> str:
    if n <= 0:
        return "no rows"
    d = int(np.floor(np.log10(n)))
    return "about {:,} rows".format(int(round(n, -d)))


def pct_whole(share: float) -> str:
    p = 100.0 * float(share)
    if p <= 0:
        return "0%"
    return "<1%" if p < 0.5 else "%d%%" % int(round(p))


def disguise_layout(info: Dict[str, Any]) -> Tuple[List[str], int]:
    """Shuffled column order and the date shift in years (7-15), both fixed by the case id."""
    rng = np.random.RandomState(zlib.crc32(("disguise:" + info["id"]).encode("utf-8")) % (2 ** 32))
    shift = 7 + int(rng.randint(0, 9))
    order = list(info["columns"])
    rng.shuffle(order)
    return order, shift


def disguised_examples(st: Dict[str, Any], labels: Dict[str, str], shift: int) -> str:
    t = st["type"]
    if t == "numeric":
        if not st.get("n_distinct"):
            return "(no values)"
        add = shift if st.get("year_like") else 0
        if "levels" in st:
            return "values: " + ", ".join("%s %s" % (common.fmt_num(v + add), pct_whole(p)) for v, p in st["levels"])
        return "min %s, median %s, max %s" % (sig(st["min"] + add), sig(st["median"] + add), sig(st["max"] + add))
    if t == "date":
        if st.get("min") is None:
            return "(no values)"
        lo, hi = st["min"] + pd.DateOffset(years=shift), st["max"] + pd.DateOffset(years=shift)
        return "min %s, max %s" % (lo.strftime("%Y-%m"), hi.strftime("%Y-%m"))
    if not st.get("labels"):
        return "(no values)"
    return "top: " + ", ".join("%s %s" % (common.quote(labels.get(lab) or "label_%d" % (k + 1)), pct_whole(p))
                               for k, (lab, p) in enumerate(zip(st["labels"], st["shares"])))


def disguised_parts(info: Dict[str, Any], dz: Dict[str, Any]) -> Tuple[Dict[str, str], List[str], str]:
    """Task text, column lines (shuffled, rounded, renamed) and the rounded row count of the disguised table."""
    order, shift = disguise_layout(info)
    all_labels = dz.get("labels") or {}
    lines = []
    for c in order:
        st = info["dz"][c]
        lines.append("- %s | %s | %s missing | %s distinct | %s"
                     % (dz["names"][c], st["type"], pct_whole(st["missing"]), count_sig(st["n_unique"]),
                        disguised_examples(st, all_labels.get(c) or {}, shift)))
    return dz["text"], lines, about_rows(info["n_rows"])


def describe(text: Dict[str, str], task: str, lines: List[str], rows: str) -> str:
    """The table description of a prompt (everything before the instruction). For the real condition this is
    exactly the first part of the audit prompt, so the real probe sees what the real audit sees."""
    kind = "binary classification" if task == "binary" else "regression"
    parts = ["Unit of observation: " + (text.get("unit") or "(not given)"),
             "Target (%s): %s" % (kind, text.get("target_description") or "(not given)"),
             "Prediction moment: " + (text.get("prediction_time") or "(not given)"),
             "",
             "Columns (%d; values from %s) -- name | type | missing | distinct values | examples:" % (len(lines), rows)]
    return "\n".join(parts + lines)


# ============================================================ disguised names, labels and task text (cached)
def banned_words(case: Dict[str, Any]) -> List[str]:
    """Words that would give the dataset away; a generated table has no public identity to hide."""
    return [] if case.get("url") == "generated" else common.identity_words(case)


def writer_user(info: Dict[str, Any]) -> str:
    t = info["real_text"]
    lines = []
    for c in info["columns"]:
        st = info["dz"][c]
        line = "- %s (%s)" % (c, st["type"])
        if st.get("labels"):
            line += " labels: " + ", ".join(json.dumps(lab, ensure_ascii=False) for lab in st["labels"])
        lines.append(line)
    words = banned_words(info["case"])
    return ("Here are three texts that describe a prediction task on a table, and the table's %d columns with their "
            "types; categorical columns also list the labels that will be shown.\n\n"
            "unit: %s\ntarget_description: %s\nprediction_time: %s\n\n%s\n\n%s"
            % (len(lines), t["unit"], t["target_description"], t["prediction_time"], "\n".join(lines),
               DISGUISE_RULES % (", ".join(words) if words else "(none)")))


def name_pairs(raw: Any) -> Dict[str, Any]:
    if isinstance(raw, dict):
        return {str(k): v for k, v in raw.items()}
    pairs: Dict[str, Any] = {}
    if isinstance(raw, list):
        for it in raw:
            if isinstance(it, dict):
                old = it.get("original", it.get("old", it.get("column")))
                new = it.get("new", it.get("new_name", it.get("renamed", it.get("name"))))
                if old is not None:
                    pairs[str(old)] = new
    return pairs


def parse_disguise(text: str, info: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], List[str]]:
    """(result, []) or (None, problems). Every column needs a unique new name that differs from its original
    (case-blind); the task texts must not use the case's identity words (name, aliases, places...) or years.
    Labels are optional: a missing, unchanged or identifying rewrite is shown as label_<k>."""
    obj = common.extract_json(text)
    if not isinstance(obj, dict):
        return None, ["the answer was not a json object"]
    problems = []
    texts = {}
    for k in TEXT_KEYS:
        v = obj.get(k)
        if isinstance(v, str) and v.strip():
            texts[k] = " ".join(v.split())
        else:
            problems.append("no %s text" % k)
    pairs = name_pairs(obj.get("columns"))
    loose: Dict[str, Any] = {}
    for k, v in pairs.items():
        loose.setdefault(common.norm_text(k), v)
    names: Dict[str, str] = {}
    missing, same, by_new = [], [], {}  # type: List[str], List[str], Dict[str, List[str]]
    for c in info["columns"]:
        new = pairs[c] if c in pairs else loose.get(common.norm_text(c))
        if not isinstance(new, str) or not new.strip():
            missing.append(c)
            continue
        new = " ".join(new.split()).replace("|", "/")
        if new.lower() == c.strip().lower():
            same.append(c)
        by_new.setdefault(new.lower(), []).append(c)
        names[c] = new
    dups = sorted(k for k, v in by_new.items() if len(v) > 1)
    if missing:
        problems.append("no new name for: %s" % ", ".join(missing[:20]))
    if same:
        problems.append("new name equal to the original for: %s" % ", ".join(same[:20]))
    if dups:
        problems.append("the same new name for several columns: %s" % ", ".join(dups[:20]))
    words = banned_words(info["case"])
    joined = " ".join(texts.values())
    hits = common.identity_hits(joined, words)
    if hits:
        problems.append("the texts use forbidden words: %s" % ", ".join(hits))
    years = sorted(set(re.findall(r"\b(1[5-9]\d\d|20\d\d)\b", joined)))
    if years:
        problems.append("the texts contain years: %s" % ", ".join(years))
    if problems:
        return None, problems
    raw_labels = obj.get("labels") if isinstance(obj.get("labels"), dict) else {}
    loose_cols = {common.norm_text(k): v for k, v in raw_labels.items()}
    labels: Dict[str, Dict[str, str]] = {}
    unmapped = 0
    for c in info["columns"]:
        shown = info["dz"][c].get("labels") or []
        if not shown:
            continue
        given = raw_labels[c] if c in raw_labels else loose_cols.get(common.norm_text(c))
        given = given if isinstance(given, dict) else {}
        given_loose = {" ".join(str(k).split()).lower(): v for k, v in given.items()}
        mapped = {}
        for lab in shown:
            new = given[lab] if lab in given else given_loose.get(lab.lower())
            ok = isinstance(new, (str, int, float)) and not isinstance(new, bool)
            new = " ".join(str(new).split()) if ok else ""
            if new and new.lower() != lab.lower() and not common.identity_hits(new, words):
                mapped[lab] = new
            else:
                unmapped += 1
        labels[c] = mapped
    return {"names": names, "labels": labels, "text": texts, "unmapped_labels": unmapped}, []


def get_disguise(info: Dict[str, Any], calls_allowed: bool = True) -> Optional[Dict[str, Any]]:
    if MOCK:
        return mock_disguise(info)
    cid = info["id"]
    cpath = common.path("disguised", cid + ".json")
    user = writer_user(info)
    phash = common.text_hash(model_id(DISGUISE_MODEL), DISGUISE_SYSTEM, user)
    cached = common.load_json(cpath)
    if (isinstance(cached, dict) and cached.get("prompt_hash") == phash
            and isinstance(cached.get("names"), dict) and all(c in cached["names"] for c in info["columns"])
            and isinstance(cached.get("text"), dict) and all(k in cached["text"] for k in TEXT_KEYS)):
        cached["from_cache"] = True
        return cached
    if not calls_allowed:
        return None
    if DISGUISE_MODEL in STATE["disabled"]:
        with _lock:
            STATE["skipped"][DISGUISE_MODEL] = STATE["skipped"].get(DISGUISE_MODEL, 0) + 1
        return None
    usage = {"in": 0, "out": 0}
    raws: List[str] = []
    res, problems = None, []  # type: Optional[Dict[str, Any]], List[str]
    for attempt in range(2):
        u = user if attempt == 0 else user + "\n\n" + DISGUISE_REMINDER % "; ".join(problems)
        text, uu, stop = call_model(DISGUISE_MODEL, DISGUISE_SYSTEM, u, WRITER_MAX_TOKENS)
        usage = {"in": usage["in"] + uu["in"], "out": usage["out"] + uu["out"]}
        raws.append(text)
        res, problems = parse_disguise(text, info)
        if res is not None:
            break
        if attempt == 0:
            log("  disguise / %s: %s (stop: %s) -- asking once more" % (cid, "; ".join(problems)[:300], stop or "?"))
    cost = cost_of(DISGUISE_MODEL, usage)
    if res is None:
        log("  disguise / %s: still not usable (%s) -- disguised condition skipped for this case"
            % (cid, "; ".join(problems)[:300]))
        return {"failed": True, "usage": usage, "cost": cost, "from_cache": False}
    rec = {"case_id": cid, "model": DISGUISE_MODEL, "model_id": model_id(DISGUISE_MODEL), "prompt_hash": phash,
           "timestamp": common.stamp(), "raw": raws[0], "raw_retry": raws[1] if len(raws) > 1 else None,
           "names": res["names"], "labels": res["labels"], "text": res["text"],
           "unmapped_labels": res["unmapped_labels"], "usage": usage, "cost": round(cost, 6)}
    common.write_json(cpath, rec)
    say("  disguise / %s: %d names, %d labels unmapped, $%.4f" % (cid, len(res["names"]), res["unmapped_labels"], cost))
    rec["from_cache"] = False
    return rec


# ============================================================ recognition probes (cached)
def probe_user(info: Dict[str, Any], cond: str, dz: Optional[Dict[str, Any]]) -> Optional[str]:
    """The table description the audit sees in this condition, followed by the probe question."""
    if cond == "real":
        lines = [common.column_line(c, info["summaries"][c]) for c in info["columns"]]
        summary = describe(info["real_text"], info["task"], lines, "%d rows" % info["n_rows"])
    else:
        if not dz or dz.get("failed"):
            return None
        text, lines, rows = disguised_parts(info, dz)
        summary = describe(text, info["task"], lines, rows)
    return summary + "\n\n" + PROBE_QUESTION


def parse_probe(text: str) -> Optional[List[Dict[str, Any]]]:
    """Up to 3 {name, confidence} guesses; [] if the answer is readable but names nothing; None if unreadable."""
    obj = common.extract_json(text)
    items: Any = None
    if isinstance(obj, dict):
        if isinstance(obj.get("guesses"), list):
            items = obj["guesses"]
        elif obj.get("name"):
            items = [obj]
    elif isinstance(obj, list):
        items = obj
    if items is None:
        found = re.findall(r'"name"\s*:\s*"((?:[^"\\]|\\.)*)"', text or "")
        if not found:
            return None
        items = [{"name": n} for n in found]
    out = []
    for it in items:
        if isinstance(it, str):
            name, conf = it, float("nan")
        elif isinstance(it, dict):
            name, conf = it.get("name", it.get("dataset")), to_risk(it.get("confidence"))
        else:
            continue
        name = clean_guess(name)
        if name:
            out.append({"name": name, "confidence": conf})
        if len(out) == 3:
            break
    return out


def probe(info: Dict[str, Any], cond: str, m: str, user: str) -> Optional[Dict[str, Any]]:
    cid = info["id"]
    tag = "%s / probe_%s / %s" % (label(m), cond, cid)
    cpath = common.path("llm_cache", label(m), "probe_" + cond, cid + ".json")
    phash = common.text_hash(model_id(m), PROBE_SYSTEM, user)
    cached = common.load_json(cpath)
    if (isinstance(cached, dict) and cached.get("prompt_hash") == phash
            and isinstance((cached.get("parsed") or {}).get("guesses"), list)):
        cached["from_cache"] = True
        return cached
    if m in STATE["disabled"]:
        with _lock:
            STATE["skipped"][m] = STATE["skipped"].get(m, 0) + 1
        return None
    t0 = time.time()
    if MOCK:
        text1, u1, stop1 = mock_probe(info, cond, m, user)
    else:
        text1, u1, stop1 = call_model(m, PROBE_SYSTEM, user, PROBE_MAX_TOKENS)
    usage = dict(u1)
    guesses = parse_probe(text1)
    text2 = None
    if guesses is None:
        log("  %s: answer not readable (stop: %s) -- asking once more" % (tag, stop1 or "?"))
        text2, u2, stop2 = call_model(m, PROBE_SYSTEM, user + "\n\n" + PROBE_REMINDER, PROBE_MAX_TOKENS)
        usage = add_usage(usage, u2)
        guesses = parse_probe(text2)
    cost = cost_of(m, usage)
    if guesses is None:
        log("  %s: no usable answer after one retry -- not cached. It began: %r"
            % (tag, (text2 if text2 is not None else text1)[:200]))
        return {"failed": True, "usage": usage, "cost": cost, "from_cache": False}
    rec = {"case_id": cid, "model": label(m), "model_id": "mock" if MOCK else model_id(m), "condition": cond,
           "kind": "probe", "prompt_hash": phash, "timestamp": common.stamp(), "prompt": user, "raw": text1,
           "raw_retry": text2, "parsed": {"guesses": guesses}, "usage": usage, "cost": round(cost, 6),
           "seconds": round(time.time() - t0, 1)}
    common.write_json(cpath, rec)
    say("  %s: %s, $%.4f" % (tag, "; ".join("%s (%s)" % (g["name"], "?" if not np.isfinite(g["confidence"])
                                                         else "%.0f" % g["confidence"]) for g in guesses)
                            or "no guess", cost))
    rec["from_cache"] = False
    return rec


# ============================================================ mock LLM (offline, deterministic)
MOCK_RULES = [("status", 90, "post_outcome"), ("pymnt", 90, "post_outcome"), ("recover", 90, "post_outcome"),
              ("boat", 85, "post_outcome"), ("body", 80, "post_outcome"), ("date", 70, "post_outcome"),
              ("assigned", 55, "post_outcome")]
MOCK_GUESSES = [("reservation_status", "Hotel booking demand"), ("boat", "Titanic"),
                ("checking_balance", "German credit (Statlog)")]


def _noise(*parts: str) -> int:
    return int(common.text_hash(*parts)[:6], 16) % 11 - 5


def mock_call(m: str, system: str, user: str) -> Tuple[str, Dict[str, int], str]:
    """Reads the column lines back out of the prompt and rates names by keyword (status/date/pymnt/recover... high),
    plus a little noise. Claude-labeled answers come wrapped in prose and a code fence, to exercise the lenient
    parser."""
    entries = []
    names = []
    for line in user.splitlines():
        if not line.startswith("- "):
            continue
        parts = [p.strip() for p in line[2:].split(" | ")]
        if len(parts) < 2:
            continue
        name, ctype = parts[0], parts[1]
        names.append(name)
        low = name.lower()
        risk, cat, why = 10, "fine", "mock: no keyword in the name"
        for kw, r, c in MOCK_RULES:
            if kw in low:
                risk, cat, why = r, c, "mock: name contains '%s'" % kw
                break
        else:
            if ctype == "date":
                risk, cat, why = 45, "post_outcome", "mock: a date column"
            elif low == "id" or low.endswith("_id"):
                risk, cat, why = 60, "identifier", "mock: looks like an id"
        risk = max(0, min(100, risk + _noise(m, name)))
        entries.append({"column": name, "leak_risk": risk, "category": cat, "reason": why})
    guess = None
    for kw, g in MOCK_GUESSES:
        if kw in names:
            guess = g
            break
    text = json.dumps({"dataset_guess": guess, "columns": entries})
    if m == "claude":
        text = "Here is the audit:\n```json\n" + json.dumps({"dataset_guess": guess, "columns": entries},
                                                             indent=1) + "\n```"
    return text, {"in": len(system + user) // 4, "out": len(text) // 4}, "stop"


def mock_paraphrase(info: Dict[str, Any]) -> Dict[str, Any]:
    """Offline stand-in: drops the vowels from each name (wh_ prefix) and marks the task text as reworded."""
    pairs = {c: "wh_" + re.sub(r"[aeiou]", "", c.lower()) for c in info["columns"]}
    names, fallbacks = validate_names(info["columns"], pairs)
    text = {k: "[reworded] " + (info["real_text"][k] or "") for k in TEXT_KEYS}
    return {"names": names, "fallbacks": fallbacks, "text": text, "usage": {"in": 0, "out": 0}, "cost": 0.0,
            "mock": True, "from_cache": False}


def mock_disguise(info: Dict[str, Any]) -> Dict[str, Any]:
    """Offline stand-in for the disguise writer (also the dry run's placeholder): numbered names built from the
    reversed letters of the original, labels level_A..., a generic task text. It goes through the same validation as
    a real answer."""
    names = {c: "m%02d_%s" % (i + 1, (re.sub(r"[^a-z0-9]", "", c.lower())[::-1] or "x")[:6])
             for i, c in enumerate(info["columns"])}
    labels = {c: {lab: "level_%s" % chr(65 + k) for k, lab in enumerate(st["labels"])}
              for c, st in info["dz"].items() if st.get("labels")}
    obj = {"unit": "One row of the table.",
           "target_description": "The outcome to predict (%s)." % ("yes or no" if info["task"] == "binary" else
                                                                  "a number"),
           "prediction_time": "At the moment the prediction is made.", "columns": names, "labels": labels}
    res, problems = parse_disguise(json.dumps(obj), info)
    if res is None:
        return {"failed": True, "usage": {"in": 0, "out": 0}, "cost": 0.0, "mock": True, "from_cache": False}
    res.update(usage={"in": 0, "out": 0}, cost=0.0, mock=True, from_cache=False)
    return res


def mock_probe(info: Dict[str, Any], cond: str, m: str, user: str) -> Tuple[str, Dict[str, int], str]:
    """Fake recognition: mock-gpt names the dataset (confidence 70) in 90% of real and 60% of disguised probes, the
    other mock models in 60% of real and none of the disguised ones, so step 4's recognition warning gets exercised."""
    case = info["case"]
    h = int(common.text_hash("probe", m, cond, info["id"])[:6], 16) % 100
    rate = (90 if m == "gpt" else 60) if cond == "real" else (60 if m == "gpt" else 0)
    if h < rate:
        name = (case.get("aliases") or [case["name"]])[0]
        if case.get("url") == "generated":  # a generated table: the fake model takes it for a public dataset
            name = "Kaggle %s dataset" % case.get("domain", "tabular")
        guesses = [{"name": name, "confidence": 70}, {"name": "Some other benchmark", "confidence": 20}]
    else:
        guesses = [{"name": "Unknown tabular benchmark", "confidence": 10}]
    text = json.dumps({"guesses": guesses})
    return text, {"in": len(PROBE_SYSTEM + user) // 4, "out": len(text) // 4}, "stop"


# ============================================================ running
def run_all(tasks: List[Tuple[Callable[[], Any], str, str]]) -> List[Any]:
    """Runs (function, tag, model) tasks -- the APIs WORKERS at a time, the local model one at a time, both at once; a
    failed task is logged and gives None."""
    out: List[Any] = [None] * len(tasks)

    def one(i: int) -> Any:
        fn, tag, m = tasks[i]
        try:
            res = fn()
            if res and not res.get("from_cache"):
                with _lock:
                    STATE["ok"][m] = True
            return res
        except LocalDown as e:
            disable(m, str(e))
        except common.ApiError as e:
            text = str(e).lower()
            with _lock:
                STATE["bad400"][m] = STATE["bad400"].get(m, 0) + (e.code == 400)
                repeated = STATE["bad400"][m] >= 3 and not STATE["ok"].get(m)
            if m == "local" and e.code in (401, 403, 404):
                disable(m, "HTTP %d from LM Studio: check LOCAL_MODEL (%s) against the model id LM Studio shows, and "
                           "that the model is loaded" % (e.code, model_id(m)))
            elif is_open(m) and e.code == 404:
                disable(m, "HTTP 404 from OpenRouter for %s: the id is wrong, or no provider fits the filters (%s, "
                           "and your OpenRouter privacy settings) -- check OPEN_MODELS, or loosen OPEN_QUANTIZATIONS"
                        % (model_id(m), "/".join(OPEN_QUANTIZATIONS or ["any quantization"])))
            elif is_open(m) and e.code == 402:
                disable(m, "HTTP 402 from OpenRouter: out of credit -- add a few dollars at openrouter.ai, then press "
                           "Run again (finished answers are kept)")
            elif e.code in (401, 402, 403, 404) or "insufficient_quota" in text or "credit balance" in text:
                disable(m, "HTTP %d: check %s, its credit, and the model id (%s)" % (e.code, key_name(m), model_id(m)))
            elif repeated:
                disable(m, "HTTP 400 three times without a success: check the model id and settings at the top")
            log("  %s: API error: %s" % (tag, " ".join(str(e).split())[:400]))
        except Exception as e:  # one case failing must not stop the run
            log("  %s: ERROR %s: %s" % (tag, e.__class__.__name__, " ".join(str(e).split())[:400]))
        return None

    if WORKERS <= 1 or len(tasks) <= 1:
        for i in range(len(tasks)):
            out[i] = one(i)
        return out
    groups: Dict[str, List[int]] = {}
    for i, t in enumerate(tasks):
        g = t[2] if t[2] in PROVIDER_WORKERS else (t[2] if is_open(t[2]) else "")  # each open model: its own pool
        groups.setdefault(g, []).append(i)
    pools = {g: ThreadPoolExecutor(max_workers=PROVIDER_WORKERS.get(g, int(OPEN_WORKERS if is_open(g) else WORKERS)))
             for g in groups}
    try:
        futures = {pools[g].submit(one, i): i for g, idx in groups.items() for i in idx}
        for f in as_completed(futures):
            out[futures[f]] = f.result()
    finally:
        for p in pools.values():
            p.shutdown(wait=True)
    return out


def dry_run(infos: List[Dict[str, Any]]) -> None:
    print("\nDRY RUN -- no API calls. System prompt (the same for every audit call):\n")
    print(SYSTEM_PROMPT)
    est: Dict[str, Dict[str, float]] = {}

    def add(m: str, kind: str, tin: float = 0.0, tout: float = 0.0) -> None:
        e = est.setdefault(m, {"calls": 0, "in": 0.0, "out": 0.0, "cached": 0})
        if kind == "cached":
            e["cached"] += 1
        else:
            e["calls"] += 1
            e["in"] += tin
            e["out"] += tout

    def cached_ok(path: str, phash: str) -> bool:
        c = common.load_json(path)
        return isinstance(c, dict) and c.get("prompt_hash") == phash

    shown = set()
    probe_shown = False
    for info in infos:
        n = len(info["columns"])
        rw, placeholder = None, False
        if needs_paraphrase():
            rw = get_paraphrase(info, calls_allowed=False)
            if rw is None:
                rw, placeholder = mock_paraphrase(info), True
                add(PARAPHRASE_MODEL, "call", len(PARAPHRASE_SYSTEM + paraphrase_user(info)) / CHARS_PER_TOKEN,
                    150 + 12 * n)
            else:
                add(PARAPHRASE_MODEL, "cached")
        dz, dz_placeholder = None, False
        if needs_disguise():
            dz = get_disguise(info, calls_allowed=False)
            if dz is None:
                dz, dz_placeholder = mock_disguise(info), True
                n_labels = sum(len(st.get("labels") or []) for st in info["dz"].values())
                add(DISGUISE_MODEL, "call", len(DISGUISE_SYSTEM + writer_user(info)) / CHARS_PER_TOKEN,
                    200 + 12 * n + 8 * n_labels)
            else:
                add(DISGUISE_MODEL, "cached")
        for cond in CONDITIONS:
            p = condition_prompt(info, cond, rw, dz)
            if p is None:
                continue
            ph = dz_placeholder if cond == "disguised" else placeholder
            style = info["case"].get("naming_style")
            if (cond, style) not in shown:
                shown.add((cond, style))
                if cond == "disguised" and dz_placeholder:
                    note = (" -- OFFLINE PLACEHOLDER rewrites (names m01_..., labels level_A..., generic task text); "
                            "the real ones come from the writer, %s" % DISGUISE_MODEL)
                elif ph and cond != "real":
                    note = " -- names and task text are offline placeholders until the paraphrase call runs"
                else:
                    note = ""
                print("\n" + "=" * 100 + "\nFirst prompt for condition '%s'%s (case %s)%s:\n"
                      % (cond, (", %s names" % style) if style else "", info["id"], note))
                print(p["user"])
            for m in expand(MODELS):
                phash = common.text_hash(model_id(m), SYSTEM_PROMPT, p["user"])
                if not ph and cached_ok(cache_path(m, cond, info["id"]), phash):
                    add(m, "cached")
                else:
                    think = OPEN_REASONING_TOKENS_EST if is_open(m) and OPEN_REASONING else 0
                    add(m, "call", len(SYSTEM_PROMPT + p["user"]) / CHARS_PER_TOKEN,
                        40 + OUT_TOKENS_PER_COLUMN * n + think)
        for cond in probe_conditions():
            u = probe_user(info, cond, dz)
            if u is None:
                continue
            ph = dz_placeholder if cond == "disguised" else False
            if not probe_shown:
                probe_shown = True
                print("\n" + "=" * 100 + "\nRecognition probes: one short call per model on the %s table "
                      "description (system prompt: %r). Each sends the same table description as the audit prompt "
                      "of that condition, followed by:\n\n%s"
                      % (" and on the ".join(probe_conditions()), PROBE_SYSTEM, PROBE_QUESTION))
            for m in probe_models(expand(MODELS)):
                phash = common.text_hash(model_id(m), PROBE_SYSTEM, u)
                path = common.path("llm_cache", label(m), "probe_" + cond, info["id"] + ".json")
                if not ph and cached_ok(path, phash):
                    add(m, "cached")
                else:
                    add(m, "call", len(PROBE_SYSTEM + u) / CHARS_PER_TOKEN, PROBE_OUT_TOKENS)
    extras = []
    if needs_paraphrase():
        extras.append("one paraphrase call (%s)" % PARAPHRASE_MODEL)
    if needs_disguise():
        extras.append("one disguise-writer call (%s)" % DISGUISE_MODEL)
    if probe_conditions():
        left_out = (["local"] if "local" in MODELS and not PROBES_LOCAL else []) + \
            (["open models"] if "open" in MODELS and not PROBES_OPEN else [])
        extras.append("%d probe(s) per model%s" % (len(probe_conditions()),
                                                   (" (not %s)" % " or ".join(left_out)) if left_out else ""))
    if "local" in MODELS:
        print("\n" + "=" * 100 + "\nLocal model: the same system prompt and the same prompts as above go to LM Studio, "
              "one call at a time, as\nPOST %s" % LOCAL_URL)
        demo_local: Dict[str, Any] = {"model": LOCAL_MODEL, "messages": [
            {"role": "system", "content": "<the system prompt above>"}, {"role": "user", "content": "<the prompt>"}],
            "temperature": LOCAL_TEMPERATURE, "max_tokens": LOCAL_MAX_TOKENS, "stream": False}
        if LOCAL_REASONING_EFFORT:
            demo_local["reasoning_effort"] = LOCAL_REASONING_EFFORT
        print(json.dumps(demo_local, indent=1))
        print("JSON mode %s; the answer is read after any <think>...</think> block; %s."
              % ("on (response_format json_schema)" if LOCAL_JSON_MODE else "off",
                 "recognition probes too" if PROBES_LOCAL else "no recognition probes (PROBES_LOCAL = False)"))
    if "open" in MODELS:
        print("\n" + "=" * 100 + "\nOpen-weight models: the same system prompt and the same prompts as above go to "
              "OpenRouter, as\nPOST %s" % OPEN_URL)
        demo: Dict[str, Any] = {"model": "<one of: %s>" % ", ".join(open_keys().values()), "messages": [
            {"role": "system", "content": "<the system prompt above>"}, {"role": "user", "content": "<the prompt>"}],
            "max_tokens": OPEN_MAX_TOKENS, "usage": {"include": True}}
        if OPEN_TEMPERATURE is not None:
            demo["temperature"] = OPEN_TEMPERATURE
        if OPEN_TOP_P is not None:
            demo["top_p"] = OPEN_TOP_P
        if OPEN_REASONING:
            demo["reasoning"] = {"enabled": True}
        demo["provider"] = {"allow_fallbacks": True, "quantizations": list(OPEN_QUANTIZATIONS or [])}
        print(json.dumps(demo, indent=1))
        print("Labels: %s; %s." % (", ".join(open_keys()), "recognition probes too" if PROBES_OPEN else
                                   "no recognition probes (PROBES_OPEN = False)"))
    print("\n" + "=" * 100)
    print("Estimate for %d case(s) x %d condition(s) x %d model(s)%s (tokens ~ characters / %.1f; output ~ %d tokens "
          "per column%s; a retry, if needed, costs about one more call):"
          % (len(infos), len(CONDITIONS), len(expand(MODELS)), (", plus per case " + ", ".join(extras)) if extras
             else "", CHARS_PER_TOKEN, OUT_TOKENS_PER_COLUMN,
             (", plus about %d thinking tokens per open-model call" % OPEN_REASONING_TOKENS_EST)
             if "open" in MODELS and OPEN_REASONING else ""))
    rows, total = [], 0.0
    for m, e in est.items():
        c = cost_of(m, {"in": int(e["in"]), "out": int(e["out"])})
        total += c
        roles = [r for r, on in (("paraphrase", needs_paraphrase() and m == PARAPHRASE_MODEL),
                                 ("disguise writer", needs_disguise() and m == DISGUISE_MODEL)) if on]
        rows.append([m + (" (+ %s)" % ", ".join(roles) if roles else ""), model_id(m), int(e["calls"]),
                     "%.0f" % e["in"], "%.0f" % e["out"], "$%.3f" % c if price(m) else "? (no price in PRICE_PER_M)",
                     int(e["cached"])])
    print(common.format_table(["model", "model id", "calls", "input tokens", "output tokens", "est. cost",
                               "already cached"], rows))
    print("Total estimated cost: $%.2f%s" % (total, " (GPT reasoning tokens not included)" if "gpt" in
                                              needed_models() else ""))
    loc = est.get("local")
    if loc and loc["calls"]:
        secs = loc["in"] / float(LOCAL_PROMPT_TOKENS_PER_S) + loc["out"] / float(LOCAL_TOKENS_PER_S)
        print("Local model time: about %.0f minutes for %d calls, at %s output tokens/s and %s prompt tokens/s "
              "(LOCAL_TOKENS_PER_S, LOCAL_PROMPT_TOKENS_PER_S); a model that thinks before answering takes 2-4 times "
              "longer." % (secs / 60.0, loc["calls"], LOCAL_TOKENS_PER_S, LOCAL_PROMPT_TOKENS_PER_S))
    missing = list(dict.fromkeys(key_name(m) for m in needed_models() if not has_key(m)))
    print("Keys (and LOCAL_MODEL) still to paste: %s" % (", ".join(missing) if missing else "none"))
    print("Next: set DRY_RUN = False and press Run again.")


def job_fn(j: Tuple[Any, ...]) -> Callable[[], Any]:
    if j[0] == "audit":
        return lambda: audit(j[1], j[2], j[3], j[4])
    return lambda: probe(j[1], j[2], j[3], j[4])


def main() -> None:
    for k in STATE:
        STATE[k] = {}
    problems = check_settings()
    if problems:
        print("Fix these settings at the top of step3_llm_audit.py:\n  " + "\n  ".join(problems))
        return
    mode = "MOCK -- fake offline LLM" if MOCK else ("DRY RUN" if DRY_RUN else "LIVE")
    print("Step 3 -- LLM leak audit [%s]; models: %s; conditions: %s; recognition probes: %s"
          % (mode, ", ".join(expand(MODELS)), ", ".join(CONDITIONS), ", ".join(probe_conditions()) or "off"))
    infos = []
    cases = common.load_cases(quiet=True)
    if os.path.exists(common.path(REAL_CASES_FILE)):
        ids = {c["id"] for c in cases}
        cases += [c for c in common.load_cases(quiet=True, file=REAL_CASES_FILE) if c["id"] not in ids]
    for case in cases:
        if not common.has_data(case["id"]):
            print("  %s: no data -- skipped (run step 1)" % case["id"])
            continue
        try:
            infos.append(prepare_case(case))
        except Exception as e:
            print("  %s: cannot read its data (%s: %s) -- skipped" % (case["id"], e.__class__.__name__, e))
    if not infos:
        print("Nothing to audit -- run step 1 first.")
        return
    if "local" in MODELS and not MOCK and has_key("local"):
        local_check()
    if DRY_RUN and not MOCK:
        dry_run(infos)
        return
    if not MOCK:
        for m in needed_models():
            if not has_key(m):
                disable(m, ("LOCAL_MODEL not set: paste the model id LM Studio shows at the top" if m == "local" else
                            "no key: paste it into %s at the top" % key_name(m)) + " (cached answers are still used)")
    models = expand(MODELS)

    rws: Dict[str, Any] = {}
    dzs: Dict[str, Any] = {}
    prep_tasks = []
    if needs_paraphrase():
        prep_tasks += [((lambda i=i: get_paraphrase(i)), "paraphrase / " + i["id"], PARAPHRASE_MODEL) for i in infos]
    if needs_disguise():
        prep_tasks += [((lambda i=i: get_disguise(i)), "disguise / " + i["id"], DISGUISE_MODEL) for i in infos]
    if prep_tasks:
        who = []
        if needs_paraphrase():
            who.append("reworded: " + ("offline mock stand-in" if MOCK else PARAPHRASE_MODEL))
        if needs_disguise():
            who.append("disguised: " + ("offline mock stand-in" if MOCK else DISGUISE_MODEL))
        print("\nRewritten names and task texts (%s):" % "; ".join(who))
        prep = run_all(prep_tasks)
        k = 0
        if needs_paraphrase():
            rws = {i["id"]: r for i, r in zip(infos, prep[:len(infos)])}
            k = len(infos)
        if needs_disguise():
            dzs = {i["id"]: r for i, r in zip(infos, prep[k:k + len(infos)])}

    print("\nAudits%s:" % (" and recognition probes" if probe_conditions() else ""))
    jobs: List[Tuple[Any, ...]] = []
    for info in infos:
        cid = info["id"]
        for cond in CONDITIONS:
            p = condition_prompt(info, cond, rws.get(cid), dzs.get(cid))
            if p is None:
                log("  %s / %s: skipped (no %s names and text for this case)"
                    % (cond, cid, "disguised" if cond == "disguised" else "reworded"))
                continue
            for m in models:
                jobs.append(("audit", info, cond, m, p))
        for cond in probe_conditions():
            u = probe_user(info, cond, dzs.get(cid))
            if u is None:
                log("  probe_%s / %s: skipped (no disguised names and text for this case)" % (cond, cid))
                continue
            for m in probe_models(models):
                jobs.append(("probe", info, cond, m, u))
    recs = run_all([(job_fn(j), "%s / %s%s / %s" % (label(j[3]), "probe_" if j[0] == "probe" else "", j[2],
                                                    j[1]["id"]), j[3]) for j in jobs])
    for m, n in STATE["skipped"].items():
        log("  %s: %d call(s) skipped -- %s" % (m, n, STATE["disabled"].get(m, "")))
    rows, prows, held = cached_outputs(infos, rws, dzs)
    if not rows and not prows:
        print("\nNo LLM results yet -- see the messages above (and step3_log.txt). %s left unchanged." % OUT_FILE)
        return
    if rows:
        pd.DataFrame(rows, columns=FIELDS).to_csv(common.path(OUT_FILE), index=False)
    if prows:
        pd.DataFrame(prows, columns=PROBE_FIELDS).to_csv(common.path(PROBE_FILE), index=False)
    summarize(jobs, recs, rws, dzs, rows, prows, models, len(infos), held)


def cached_outputs(infos: List[Dict[str, Any]], rws: Dict[str, Any],
                   dzs: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, int]]:
    """The rows of scores_llm.csv and probes.csv, rebuilt from every cached answer that matches the current prompt --
    for every model, not only those in MODELS, so a run with fewer models never drops the others' results. Mock and
    real answers never mix. Also returns the number of (table, condition) audits held per model label."""
    rows: List[Dict[str, Any]] = []
    prows: List[Dict[str, Any]] = []
    held: Dict[str, int] = {}
    other_local: Dict[str, int] = {}  # cached local answers from a model other than LOCAL_MODEL
    for info in infos:
        cid = info["id"]
        for cond in CONDITIONS:
            p = condition_prompt(info, cond, rws.get(cid), dzs.get(cid))
            if p is None:
                continue
            for m in all_models():
                rec = common.load_json(cache_path(m, cond, cid))
                if not (isinstance(rec, dict) and rec.get("parsed")
                        and rec.get("prompt_hash") == common.text_hash(model_id(m), SYSTEM_PROMPT, p["user"])):
                    if (m == "local" and isinstance(rec, dict) and rec.get("parsed") and not MOCK
                            and str(rec.get("model_id") or "") not in ("", str(model_id(m)))):
                        other_local[str(rec["model_id"])] = other_local.get(str(rec["model_id"]), 0) + 1
                    continue
                parsed = rec["parsed"]
                held[label(m)] = held.get(label(m), 0) + 1
                for c in info["columns"]:
                    e = parsed["columns"].get(c)
                    rows.append({"case_id": cid, "column": c, "model": label(m), "condition": cond,
                                 "leak_risk": e["leak_risk"] if e else float("nan"),
                                 "category": e["category"] if e else "",
                                 "reason": e["reason"] if e else "(missing from the model's answer)",
                                 "dataset_guess": parsed.get("dataset_guess") or ""})
        for cond in ["real"] + (["disguised"] if needs_disguise() else []):
            u = probe_user(info, cond, dzs.get(cid))
            if u is None:
                continue
            for m in all_models():
                rec = common.load_json(common.path("llm_cache", label(m), "probe_" + cond, cid + ".json"))
                if not (isinstance(rec, dict) and isinstance((rec.get("parsed") or {}).get("guesses"), list)
                        and rec.get("prompt_hash") == common.text_hash(model_id(m), PROBE_SYSTEM, u)):
                    continue
                g = rec["parsed"]["guesses"]
                row: Dict[str, Any] = {"case_id": cid, "model": label(m), "condition": cond}
                for k in range(3):
                    row["guess%d" % (k + 1)] = g[k]["name"] if k < len(g) else ""
                    row["conf%d" % (k + 1)] = g[k]["confidence"] if k < len(g) else float("nan")
                prows.append(row)
    for mid, k in other_local.items():
        say("\nNOTE: llm_cache/%s holds %d answer(s) from %r, but LOCAL_MODEL is %r, so they are left out of %s. "
            "To keep them, set LOCAL_MODEL = %r at the top and press Run again (nothing is re-asked)."
            % (label("local"), k, mid, model_id("local"), OUT_FILE, mid))
    return rows, prows, held


def summarize(jobs: List[Any], recs: List[Any], rws: Dict[str, Any], dzs: Dict[str, Any], rows: List[Dict[str, Any]],
              prows: List[Dict[str, Any]], models: List[str], n_cases: int, held: Dict[str, int]) -> None:
    def done(kind: str, m: str, cond: str) -> List[Dict[str, Any]]:
        return [r for j, r in zip(jobs, recs)
                if j[0] == kind and j[3] == m and j[2] == cond and r and not r.get("failed")]

    print("\nAudits per model and condition:")
    table = []
    for m in models:
        for cond in CONDITIONS:
            ok = done("audit", m, cond)
            blank = sum(len(r["parsed"]["missing"]) for r in ok)
            guessed = sum(1 for r in ok if r["parsed"].get("dataset_guess"))
            table.append([label(m), cond, "%d/%d" % (len(ok), n_cases), blank, guessed])
    print(common.format_table(["model", "condition", "cases done", "blank columns", "dataset guessed"], table))
    if probe_conditions() and probe_models(models):
        print("\nRecognition probes (step 4 counts a confident guess of a public dataset as recognition):")
        table = [[label(m), cond, "%d/%d" % (len(done("probe", m, cond)), n_cases)]
                 for m in probe_models(models) for cond in probe_conditions()]
        print(common.format_table(["model", "condition", "cases done"], table))
    local = [r for j, r in zip(jobs, recs) if j[3] == "local" and r and not r.get("from_cache") and "seconds" in r]
    if local:
        print("\nLocal model: %d calls this run, %.0f minutes in all (%.0f s per call)"
              % (len(local), sum(r["seconds"] for r in local) / 60.0, sum(r["seconds"] for r in local) / len(local)))

    print("\nCost (open models: as OpenRouter reports it; the others: estimated from token counts and PRICE_PER_M%s):"
          % ("; mock tokens are pretend" if MOCK else ""))
    per: Dict[str, List[float]] = {}
    entries = ([(j[3], r) for j, r in zip(jobs, recs)] + [(PARAPHRASE_MODEL, r) for r in rws.values()]
               + [(DISGUISE_MODEL, r) for r in dzs.values()])
    for m, r in entries:
        if not r or r.get("mock"):  # the offline mock paraphrase / writer is not a call
            continue
        e = per.setdefault(m, [0, 0.0, 0, 0.0])
        if r.get("from_cache"):
            e[2] += 1
            e[3] += float(r.get("cost") or 0)
        else:
            e[0] += 1
            e[1] += float(r.get("cost") or 0)
    table = [[label(m), int(e[0]), "$%.4f" % e[1], int(e[2]), "$%.4f" % e[3]] for m, e in per.items()]
    print(common.format_table(["model", "calls this run", "cost this run", "cached", "cost of cached (earlier runs)"],
                              table))
    print("Total: $%.4f this run, $%.4f including earlier runs."
          % (sum(e[1] for e in per.values()), sum(e[1] + e[3] for e in per.values())))
    print("\n%s now holds every cached answer: %s." % (OUT_FILE, ", ".join(
        "%s %d table(s)" % (m, k) for m, k in sorted(held.items())) or "none"))
    print("%d rows -> %s%s. Next: train4_compare.py (GUIDE.md)"
          % (len(rows), OUT_FILE, ("; %d probe rows -> %s" % (len(prows), PROBE_FILE)) if prows else ""))


if __name__ == "__main__":
    main()
