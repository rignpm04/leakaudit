# t1_get_data.py -- downloads and prepares the public tables of run 3, the same way leak real test 2's step 1 did:
#   cases_distill.json  about 300 Rdatasets tables the two teacher models rate (training data)
#   cases_test3.json    real test 3, the new test set (never used in training)
# Each file is downloaded into data/raw/<id>/ and written as data/<id>.csv.gz + data/<id>.meta.json (target renamed
# "target", Rdatasets' rownames dropped, at most 50,000 rows). Python 3.9; press Run in PyCharm. No keys. Tables
# already prepared are skipped, so running it again only does what is missing. Needs internet (GitHub).

CASES_FILES = ["cases_distill.json", "cases_test3.json"]
FORCE = False                # True: download and prepare every table again

# ============================================================ internals
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_get_data as s1g  # noqa: E402


def changed(case: dict) -> bool:
    """The table in data/ was prepared for an earlier version of this case (another url, target, task, answer key, or
    a column that is now dropped), so it must be prepared again."""
    m = common.read_meta(case["id"])
    if not m:
        return False
    cols = set(m.get("columns") or {})
    return (m.get("url") != case["url"] or m.get("target_original") != case["target"] or m.get("task") != case["task"]
            or list(m.get("leak_columns") or []) != case["leak_columns"]
            or list(m.get("probable_leak_columns") or []) != case["probable_leak_columns"]
            or any(c in cols for c in case["drop_columns"]))


def main() -> None:
    s1g.FORCE = FORCE
    t0 = time.time()
    done = []
    test3_ready = None   # None: no cases_test3.json here yet (part A); True / False: all of real test 3 ready or not
    for fname in CASES_FILES:
        if not os.path.exists(common.path(fname)):
            print("%s: not in this folder yet -- skipped" % fname)
            continue
        cases = common.load_cases(file=fname)
        again = [c["id"] for c in cases if not FORCE and common.has_data(c["id"]) and changed(c)]
        for cid in again:   # an updated cases file: these tables are prepared again (the download is kept)
            s1g.remove_outputs(cid)
        if again:
            print("%s: %d table(s) changed since they were prepared, prepared again: %s"
                  % (fname, len(again), ", ".join(again[:12])))
        todo = [c for c in cases if FORCE or not common.has_data(c["id"])]
        print("\n%s: %d tables, %d to prepare" % (fname, len(cases), len(todo)))
        rows = s1g.prepare(cases)
        bad = [r for r in rows if r[3] not in ("ok", "ready")]
        if bad:
            print("\nSkipped in %s:" % fname)
            print(common.format_table(["case", "problem"], [[r[0], r[10]] for r in bad]))
        ok = len(rows) - len(bad)
        done.append("%s: %d of %d tables ready" % (fname, ok, len(rows)))
        if fname == "cases_test3.json":
            test3_ready = ok == len(rows)
    print("\n" + "\n".join(done) if done else "\nNo cases files here yet.")
    if test3_ready is None:
        nxt = "t2_teachers.py (DRY_RUN = True first)."
    elif test3_ready:
        nxt = "t3_make_training.py (real test 3 is ready)."
    else:
        nxt = "send Claude this output: every real test 3 table must be ready before t3_make_training.py."
    print("(%.0f s) Next: %s" % (time.time() - t0, nxt))


if __name__ == "__main__":
    main()
