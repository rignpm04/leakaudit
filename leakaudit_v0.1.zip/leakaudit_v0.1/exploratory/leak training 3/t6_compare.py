# t6_compare.py -- the before/after comparison and verdict of fine-tune run 3. Python 3.9; press Run in PyCharm after
# t5_import_gpu.py. No calls.
#
# Scores the models' own ratings (no column check, no data checks) on four groups:
#   training domains   the 24 generated test tables of the 4 domains the generated training tables come from
#   held-out domains   the 12 generated test tables of lending and hospital, never used in training
#   trap tables        the 6 generated trap tables (legitimate columns built to look late)
#   real test 3        the new public tables with documented leaks (and clean ones), none of them used in training;
#                      debatable columns (probable_leak_columns) count neither way
# A model's ratings of a table are the union of its answers to the table's run 3 prompts (at most 10 columns each).
# Only answers to today's exact prompts count; a prompt with no readable answer leaves its columns unflagged (the rule
# fixed on Oct 20), and the coverage is shown.
# Models: run 3's untrained (gpu3-qwen3.5-9b) and trained (gpu3-leakaudit3-...) answers, any other model answering the
# run 3 prompts (e.g. the teachers on real test 3, if t2's TEST3_REFERENCE was used after the verdict), and, for the
# generated groups only, every earlier whole-table answer (DeepSeek, Claude, GPT, open and local models, run 1 and run
# 2's RunPod models), marked "(whole-table)": those saw all columns in one prompt, the old answer format.
# Two settings, as in every earlier test:
#   within budget  each model at its best risk threshold with at most 1 false flag per table, per group (the verdict)
#   fixed          a column is flagged at risk >= 50, for every model and group
# VERDICT (rule fixed before the run), within budget: PASS if the trained model's macro recall beats the untrained
# model's by at least MIN_GAIN on BOTH the held-out domains and real test 3; PARTIAL on the held-out domains only;
# FAIL otherwise. Output: results_training_run3.txt (also printed).

TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]
HOLDOUT_DOMAINS = ["lending", "hospital"]
BASE_LABEL = "gpu3-qwen3.5-9b"      # the untrained model, run 3 prompts
TRAINED_PREFIX = "gpu3-leakaudit"   # trained models of run 3; only these get a verdict
FIXED_T = 50
BUDGET_PER_TABLE = 1.0
MIN_GAIN = 0.10
OUT_FILE = "results_training_run3.txt"

# ============================================================ internals
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402

TEST3_FILE = "cases_test3.json"
GROUPS = ["training domains", "held-out domains", "trap tables", "real test 3"]
GENERATED_GROUPS = GROUPS[:3]
WHOLE = " (whole-table)"
GRID = [float(t) for t in range(0, 101, 5)]
LINES: List[str] = []


def out(s: str = "") -> None:
    print(s)
    LINES.append(s)


def load_groups() -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, Dict[str, Any]]]:
    gen = [c for c in common.load_cases(quiet=True) if c.get("url") == "generated"]
    test3 = common.load_cases(quiet=True, file=TEST3_FILE) if os.path.exists(common.path(TEST3_FILE)) else []
    groups: Dict[str, List[Dict[str, Any]]] = {g: [] for g in GROUPS}
    for c in gen:
        if c.get("trap_columns"):
            groups["trap tables"].append(c)
        elif c.get("domain") in TRAIN_DOMAINS:
            groups["training domains"].append(c)
        elif c.get("domain") in HOLDOUT_DOMAINS:
            groups["held-out domains"].append(c)
    groups["real test 3"] = list(test3)
    info: Dict[str, Dict[str, Any]] = {}
    for g, cases in groups.items():
        keep = []
        for c in cases:
            if not common.has_data(c["id"]):
                print("  %s: no data here -- left out (run t0_import.py / t1_get_data.py)" % c["id"])
                continue
            i = s3.chunk_info(c)
            info[c["id"]] = {"case": c, "group": g, "columns": i["columns"], "chunks": s3.chunk_prompts(i),
                             "whole": s3.condition_prompt(i, "real", None, None)["user"] if g in GENERATED_GROUPS
                             else None}
            keep.append(c)
        groups[g] = keep
    return groups, info


def as_risk(v: Any) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return float("nan")
    return x if np.isfinite(x) else float("nan")


def load_answers(info: Dict[str, Dict[str, Any]]
                 ) -> Tuple[Dict[str, Dict[str, Dict[str, float]]], Dict[str, Dict[str, Any]], Dict[str, int]]:
    """{label: {table: {column: risk}}}; coverage {label: {table: (prompts answered, prompts, unreadable)}}; stale
    counts. Run 3 prompts from llm_cache/<label>/chunks/, whole-table answers from llm_cache/<label>/real/."""
    answers: Dict[str, Dict[str, Dict[str, float]]] = {}
    cover: Dict[str, Dict[str, Any]] = {}
    stale: Dict[str, int] = {}
    root = common.path("llm_cache")
    for lab in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        cdir = os.path.join(root, lab, "chunks")
        if os.path.isdir(cdir):
            for tid, x in info.items():
                got, n_ans, n_unread = {}, 0, 0
                for ch in x["chunks"]:
                    rec = common.load_json(os.path.join(cdir, ch["chunk_id"] + ".json"))
                    if not isinstance(rec, dict):
                        continue
                    if rec.get("prompt_hash") != common.text_hash(str(rec.get("model_id")), s3.SYSTEM_PROMPT,
                                                                   ch["user"]):
                        stale[lab] = stale.get(lab, 0) + 1
                        continue
                    if rec.get("unreadable") or not rec.get("parsed"):
                        n_unread += 1
                        continue
                    n_ans += 1
                    cols = rec["parsed"].get("columns") or {}
                    for c in ch["columns"]:
                        got[c] = as_risk((cols.get(c) or {}).get("leak_risk"))
                if n_ans or n_unread:
                    answers.setdefault(lab, {})[tid] = got
                    cover.setdefault(lab, {})[tid] = (n_ans, len(x["chunks"]), n_unread)
        rdir = os.path.join(root, lab, "real")
        if os.path.isdir(rdir) and not lab.startswith("mock-"):
            wl = lab + WHOLE
            for tid, x in info.items():
                if x["whole"] is None:
                    continue
                rec = common.load_json(os.path.join(rdir, tid + ".json"))
                if not (isinstance(rec, dict) and rec.get("parsed")):
                    continue
                if rec.get("prompt_hash") != common.text_hash(str(rec.get("model_id")), s3.SYSTEM_PROMPT, x["whole"]):
                    stale[wl] = stale.get(wl, 0) + 1
                    continue
                cols = rec["parsed"].get("columns") or {}
                answers.setdefault(wl, {})[tid] = {c: as_risk((cols.get(c) or {}).get("leak_risk"))
                                                   for c in x["columns"]}
                cover.setdefault(wl, {})[tid] = (1, 1, 0)
    return answers, cover, stale


def score(cases: List[Dict[str, Any]], info: Dict[str, Dict[str, Any]], risks: Dict[str, Dict[str, float]],
          t: float) -> Dict[str, Any]:
    recalls, ff, trap_hit, trap_n, leaks_hit, leaks_n = [], 0, 0, 0, 0, 0
    for c in cases:
        r = risks.get(c["id"], {})
        leaks = set(c.get("leak_columns") or [])
        skip = set(c.get("probable_leak_columns") or [])
        traps = set((c.get("trap_columns") or {}).keys())
        hit = 0
        for col in info[c["id"]]["columns"]:
            v = r.get(col, float("nan"))
            flagged = bool(np.isfinite(v) and v >= t - 1e-9)
            if col in leaks:
                hit += flagged
            elif col in skip:
                continue
            else:
                ff += flagged
                if col in traps:
                    trap_hit += flagged
                    trap_n += 1
        present = [x for x in leaks if x in info[c["id"]]["columns"]]
        if present:
            recalls.append(hit / float(len(present)))
            leaks_hit += hit
            leaks_n += len(present)
    return {"macro": float(np.mean(recalls)) if recalls else float("nan"), "ff": ff, "trap_hit": trap_hit,
            "trap_n": trap_n, "leaks_hit": leaks_hit, "leaks_n": leaks_n}


def tuned(cases: List[Dict[str, Any]], info: Dict[str, Dict[str, Any]], risks: Dict[str, Dict[str, float]]
          ) -> Tuple[Optional[float], Dict[str, Any]]:
    budget = BUDGET_PER_TABLE * len(cases)
    best: Optional[Tuple[Tuple[float, float], float, Dict[str, Any]]] = None
    for t in GRID:
        s = score(cases, info, risks, t)
        if s["ff"] <= budget + 1e-9 and np.isfinite(s["macro"]):
            key = (round(s["macro"], 6), -s["ff"])
            if best is None or key > best[0]:
                best = (key, t, s)
    return (best[1], best[2]) if best else (None, score(cases, info, risks, 101.0))


def ceiling(cases: List[Dict[str, Any]]) -> float:
    vals = []
    for c in cases:
        lt = c.get("leak_types") or {}
        n = len(c.get("leak_columns") or [])
        if n:
            vals.append(sum(1 for x in c["leak_columns"] if lt.get(x) != "overwrite_silent") / float(n))
    return float(np.mean(vals)) if vals else float("nan")


def order(labels: List[str]) -> List[str]:
    rank = {"deepseek": 0, "claude": 1, "gpt": 2}
    run3 = sorted([x for x in labels if x.startswith("gpu3-")], key=lambda x: (x != BASE_LABEL, x))
    chunked = sorted([x for x in labels if not x.endswith(WHOLE) and x not in run3],
                     key=lambda x: (rank.get(x.replace("mock-", ""), 9), x))
    whole = [x for x in labels if x.endswith(WHOLE)]
    w_gpu = sorted([x for x in whole if x.startswith(("run2-gpu-", "run1-gpu-"))], key=lambda x: (x[:4] != "run2", x))
    w_loc = sorted([x for x in whole if x.startswith("local-")])
    w_opn = sorted([x for x in whole if x.startswith("open-")])
    w_front = sorted([x for x in whole if x[:-len(WHOLE)] in rank], key=lambda x: rank[x[:-len(WHOLE)]])
    w_rest = sorted([x for x in whole if x not in w_gpu + w_loc + w_opn + w_front])
    return run3 + chunked + w_gpu + w_loc + w_opn + w_front + w_rest


def main() -> None:
    groups, info = load_groups()
    answers, cover, stale = load_answers(info)
    labels = order(list(answers))
    out("Fine-tune run 3 comparison -- the models' own ratings, no checks (%s)" % common.stamp())
    out("Groups: " + "; ".join("%s %d tables (%d with leaks)" % (g, len(cs), sum(1 for c in cs if c.get("leak_columns")))
                               for g, cs in groups.items()))
    out("Generated training tables came from: %s; held out: %s. Untrained model: %s. Prompts: at most %d rated "
        "columns each." % (", ".join(TRAIN_DOMAINS), ", ".join(HOLDOUT_DOMAINS), BASE_LABEL, s3.CHUNK_SIZE))
    if not labels:
        out("\nNo answers found in llm_cache/ -- run t5_import_gpu.py first.")
        return

    def has_any(lab: str, g: str) -> bool:
        return any(c["id"] in answers[lab] for c in groups[g])

    def coverage(lab: str, g: str) -> str:
        cs = groups[g]
        n_tab = sum(1 for c in cs if c["id"] in answers[lab])
        got = sum(cover[lab].get(c["id"], (0, 0, 0))[0] for c in cs)
        need = sum(len(info[c["id"]]["chunks"]) for c in cs) if not lab.endswith(WHOLE) else len(cs)
        if lab.endswith(WHOLE):
            return "" if n_tab == len(cs) else " (%d/%d answered)" % (n_tab, len(cs))
        return "" if got == need else " (%d/%d prompts)" % (got, need)

    results: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
    for setting in ("budget", "fixed"):
        out("")
        if setting == "budget":
            out("WITHIN BUDGET: each model at its best threshold with <= %.0f false flag per table, per group (the "
                "verdict uses this)" % BUDGET_PER_TABLE)
        else:
            out("FIXED: a column is flagged at risk >= %d, for every model and group (nothing tuned)" % FIXED_T)
        head = ["model"] + ["%s: macro / false flags" % g if g != "trap tables" else
                            "trap tables: leaks / trap columns / other false flags" for g in GROUPS]
        rows = []
        for lab in labels:
            row = [lab]
            for g in GROUPS:
                if not groups[g] or not has_any(lab, g):
                    row.append("-")
                    continue
                if setting == "fixed" or g == "trap tables":
                    t, s = FIXED_T, score(groups[g], info, answers[lab], FIXED_T)
                else:
                    t, s = tuned(groups[g], info, answers[lab])
                results[(setting, lab, g)] = s
                if g == "trap tables":
                    txt = "%d/%d / %d/%d / %d" % (s["leaks_hit"], s["leaks_n"], s["trap_hit"], s["trap_n"],
                                                  s["ff"] - s["trap_hit"])
                else:
                    txt = "%.2f / %d" % (s["macro"], s["ff"])
                    if setting == "budget":
                        txt += " (T %s)" % ("none fits" if t is None else "%.0f" % t)
                    b = results.get((setting, BASE_LABEL, g))
                    if lab.startswith(TRAINED_PREFIX) and b:
                        txt += " %+.2f" % (s["macro"] - b["macro"])
                row.append(txt + coverage(lab, g))
            rows.append(row)
        out(common.format_table(head, rows))
    out("(trap tables: always at risk >= %d)" % FIXED_T)
    out("")
    out("Best possible macro recall on the generated groups (everything but the silently overwritten fields, which no "
        "method can see): training domains %.2f, held-out domains %.2f."
        % (ceiling(groups["training domains"]), ceiling(groups["held-out domains"])))

    out("")
    out("HELD-OUT DOMAINS BY NAMING STYLE (fixed setting, macro recall; tables in brackets)")
    styles = ["clear", "abbreviated", "cryptic"]
    rows = []
    for lab in labels:
        row = [lab]
        for st in styles:
            cs = [c for c in groups["held-out domains"] if c.get("naming_style") == st and c.get("leak_columns")]
            ok = cs and any(c["id"] in answers[lab] for c in cs)
            row.append("%.2f (%d)" % (score(cs, info, answers[lab], FIXED_T)["macro"], len(cs)) if ok else "-")
        rows.append(row)
    out(common.format_table(["model"] + styles, rows))

    out("")
    out("REAL TEST 3 BY TABLE (fixed setting, flag at risk >= %d): leaks found / leaks, and false flags" % FIXED_T)
    show = [lab for lab in labels if lab == BASE_LABEL or lab.startswith(TRAINED_PREFIX)]
    rows = []
    for c in groups["real test 3"]:
        row = [c["id"], str(len([x for x in (c.get("leak_columns") or []) if x in info[c["id"]]["columns"]])),
               str(len(info[c["id"]]["chunks"]))]
        for lab in show:
            if c["id"] not in answers.get(lab, {}):
                row.append("-")
                continue
            s = score([c], info, answers[lab], FIXED_T)
            n_ans, n_ch, n_unr = cover[lab][c["id"]]
            row.append("%d / %d%s" % (s["leaks_hit"], s["ff"], "" if n_ans == n_ch else " (%d/%d prompts)"
                                      % (n_ans, n_ch)))
        rows.append(row)
    if show and rows:
        out(common.format_table(["table", "leaks", "prompts"] + ["%s: found / false flags" % lab for lab in show],
                                rows))

    out("")
    out("VERDICT (rule fixed before the run; within budget): PASS = beats %s by >= %.2f macro recall on both the "
        "held-out domains and real test 3" % (BASE_LABEL, MIN_GAIN))
    need = ["held-out domains", "real test 3"]

    def complete(lab: str, g: str) -> bool:
        """Every prompt of every table in g has an answer on file (readable or stored as unreadable)."""
        return bool(groups[g]) and all(lab in cover and c["id"] in cover[lab] and
                                       cover[lab][c["id"]][0] + cover[lab][c["id"]][2] == cover[lab][c["id"]][1]
                                       for c in groups[g])

    trained = [lab for lab in labels if lab.startswith(TRAINED_PREFIX)]
    if not all(complete(BASE_LABEL, g) for g in need + ["training domains"]):
        out("  not yet: %s needs an answer to every prompt of the generated and real test 3 tables (t5_import_gpu.py)"
            % BASE_LABEL)
        trained = []
    elif not trained:
        out("  not yet: no trained model's answers (t5_import_gpu.py)")
    for lab in trained:
        if not all(complete(lab, g) for g in need + ["training domains"]):
            out("  %s: not every prompt answered yet" % lab)
            continue
        ok, parts = {}, []
        for g in need:
            b, t = results[("budget", BASE_LABEL, g)], results[("budget", lab, g)]
            gain = t["macro"] - b["macro"]
            ok[g] = gain >= MIN_GAIN - 1e-9
            parts.append("%s %.2f -> %.2f (%+.2f): %s" % (g, b["macro"], t["macro"], gain, "yes" if ok[g] else "no"))
        verdict = "PASS" if all(ok.values()) else ("PARTIAL (held-out domains only)" if ok[need[0]] else "FAIL")
        out("  %s: %s" % (lab, "; ".join(parts)))
        out("  -> %s: %s" % (lab, verdict))
    unread = {lab: sum(v[2] for v in cover.get(lab, {}).values()) for lab in labels if not lab.endswith(WHOLE)}
    if any(unread.values()):
        out("  Unreadable answers (counted as nothing flagged): " +
            "; ".join("%s %d" % kv for kv in unread.items() if kv[1]))
    out("")
    held = []
    for lab in labels:
        if lab.endswith(WHOLE):
            n = sum(1 for g in GENERATED_GROUPS for c in groups[g] if c["id"] in answers[lab])
            held.append("%s %d/%d tables" % (lab, n, sum(len(groups[g]) for g in GENERATED_GROUPS)))
        else:
            got = sum(v[0] for v in cover.get(lab, {}).values())
            need_n = sum(len(x["chunks"]) for x in info.values())
            held.append("%s %d/%d prompts" % (lab, got, need_n))
    out("Answers used: " + "; ".join(held))
    if stale:
        out("Left out because the prompt no longer matches (data or prompt changed): " +
            "; ".join("%s %d" % kv for kv in stale.items()))
    with open(common.path(OUT_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(LINES) + "\n")
    print("\n-> %s. Send it to Claude, with train_run3.json." % OUT_FILE)


if __name__ == "__main__":
    main()
