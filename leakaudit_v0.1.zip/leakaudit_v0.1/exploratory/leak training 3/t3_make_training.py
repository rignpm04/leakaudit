# t3_make_training.py -- makes the training files of fine-tune run 3. Python 3.9; press Run in PyCharm after
# t2_teachers.py has every answer. No keys, no downloads, no calls.
#
# Every training example is one chunk prompt (fix 2: at most 10 rated columns, the same prompt the test uses) followed
# by its answer: a short reason, a category and a risk for each of the chunk's columns. Three kinds of table:
#   1. Public training tables (cases_distill.json, about 300): the answer is the two teachers' ratings (fix 1),
#      averaged and rounded to 5, so risks are graded, not just 5 or 95 (fix 3). Each table goes in DISTILL_VARIANTS
#      times: as is (its prompts are exactly the ones the teachers answered), then with the columns shuffled and a
#      random 60-95% of the rows (so the chunks, summaries and example values change).
#   2. Development tables (the first 27 public datasets and leak real test 2's 47, whose leaks are documented): the
#      teachers' average, kept on the right side of the answer key -- a documented leak gets at least 80, a debatable
#      column 20-80, any other column at most 20. DEV_VARIANTS times each.
#   3. Generated tables (GEN_TABLES_PER_DOMAIN per training domain, as in run 2 but fewer): leaks 95, everything else
#      5, by construction; the held-out domains (lending, hospital) are never used.
# Real test 3 (cases_test3.json) and the 42 generated test tables are never used here; the checks below stop if any of
# them, or a near copy, would get in.
# Output: train.jsonl and val.jsonl (one example per line, chat format) and train_manifest.json.

# ============================================================ settings (edit here)
TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]
HOLDOUT_DOMAINS = ["lending", "hospital"]
GEN_TABLES_PER_DOMAIN = 60    # 4 x 60 = 240 generated tables (about a quarter of the examples)
TRAP_SHARE = 0.15             # share of generated tables built as trap tables
VAL_SHARE = 0.05              # share of tables kept apart for the validation loss (whole tables)
DISTILL_VARIANTS = 3          # each public training table goes in this many times
DEV_VARIANTS = 3              # each development table goes in this many times
ROW_SHARE = (0.60, 0.95)      # variants after the first keep this share of the rows
SEED = 20261021
TEACHERS = ["claude", "gpt"]  # must match t2_teachers.py
MOCK_TEACHERS = False         # True: read the mock teachers' answers (pipeline test only)

TRAIN_FILE = "train.jsonl"
VAL_FILE = "val.jsonl"
MANIFEST_FILE = "train_manifest.json"
DISTILL_FILE = "cases_distill.json"
DEV_FILES = ["cases_dev.json", "cases_dev2.json"]
TEST3_FILE = "cases_test3.json"

# DEV_CATEGORY (below the imports): run 2's category for each documented leak of the first 27 development tables,
# used when both teachers called such a column fine.

# ============================================================ internals
import csv
import gzip
import hashlib
import io
import json
import math
import os
import sys
import time
import zlib
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_generate as s1  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

DEV_CATEGORY = {
    "bank_marketing": {"duration": "post_outcome"},
    "titanic3": {"boat": "post_outcome", "body": "post_outcome"},
    "hotel_bookings": {"reservation_status": "post_outcome", "reservation_status_date": "post_outcome",
                       "assigned_room_type": "post_outcome", "booking_changes": "future_aggregate",
                       "country": "post_outcome", "required_car_parking_spaces": "post_outcome",
                       "adr": "post_outcome"},
    "lending_club": {"total_pymnt": "future_aggregate", "total_pymnt_inv": "future_aggregate",
                     "total_rec_prncp": "future_aggregate", "total_rec_int": "future_aggregate",
                     "total_rec_late_fee": "future_aggregate", "recoveries": "post_outcome",
                     "collection_recovery_fee": "post_outcome", "last_pymnt_d": "post_outcome",
                     "last_pymnt_amnt": "post_outcome", "last_credit_pull_d": "post_outcome",
                     "funded_amnt": "post_outcome", "funded_amnt_inv": "post_outcome", "issue_d": "post_outcome",
                     "pymnt_plan": "post_outcome", "out_prncp": "post_outcome", "out_prncp_inv": "post_outcome",
                     "next_pymnt_d": "post_outcome", "hardship_flag": "post_outcome"},
    "bike_sharing_hour": {"casual": "target_derived", "registered": "target_derived"},
    "heart_failure": {"time": "post_outcome"},
    "telco_churn_ibm": {"Churn Label": "target_derived", "Churn Reason": "post_outcome",
                        "Churn Score": "post_outcome", "CLTV": "post_outcome", "Tenure Months": "post_outcome",
                        "Total Charges": "future_aggregate"},
    "compas_two_years": {"is_recid": "target_derived", "event": "target_derived", "end": "post_outcome",
                         "violent_recid": "post_outcome", "in_custody": "post_outcome", "out_custody": "post_outcome",
                         "start": "post_outcome"},
    "diabetes_130": {"discharge_disposition_id": "post_outcome", "patient_nbr": "identifier"},
    "vgsales": {"NA_Sales": "target_derived", "EU_Sales": "target_derived", "JP_Sales": "target_derived",
                "Other_Sales": "target_derived", "Rank": "target_derived"},
    "police_stops_ri": {"stop_outcome": "target_derived", "stop_duration": "post_outcome",
                        "search_conducted": "post_outcome", "search_type": "post_outcome",
                        "drugs_related_stop": "post_outcome"},
    "rossmann": {"Customers": "post_outcome"},
    "nycflights13": {"arr_time": "post_outcome", "dep_time": "post_outcome", "dep_delay": "target_derived",
                     "air_time": "post_outcome"},
    "brazilian_houses": {"hoa (R$)": "target_derived", "rent amount (R$)": "target_derived",
                         "property tax (R$)": "target_derived", "fire insurance (R$)": "target_derived"},
    "energy_efficiency": {"Cooling Load": "post_outcome"},
    "parkinsons_telemonitoring": {"motor_UPDRS": "target_derived", "test_time": "post_outcome",
                                  "subject#": "identifier"},
    "cardiotocography": {c: "target_derived" for c in ("CLASS", "A", "B", "C", "D", "E", "AD", "DE", "LD", "FS",
                                                       "SUSP", "LBE")},
    "clean_pima": {"Glucose": "target_derived"},
}

CATEGORY = {"outcome_status": "post_outcome", "post_event_date": "post_outcome", "snapshot_state": "post_outcome",
            "outcome_only_sparse": "post_outcome", "post_aggregate": "future_aggregate",
            "target_derived": "target_derived", "identifier": "identifier",
            "target_part": "target_derived", "event_measure": "post_outcome", "assigned_during": "post_outcome",
            "followup_time": "post_outcome"}
REASON = {"post_outcome": "Recorded after the prediction moment.",
          "target_derived": "Part of or computed from the outcome.",
          "future_aggregate": "Accumulates after the prediction moment.",
          "identifier": "Row identifier; repeats let a model memorize outcomes.",
          "fine": "Known at the prediction moment."}
LEAK_CATEGORIES = ("post_outcome", "target_derived", "identifier", "future_aggregate")
RISK_LEAK, RISK_FINE = 95, 5
TRAIN_CHARS_PER_TOKEN = 2.65   # Qwen3.5's measured ratio on run 1's training texts


def teacher_labels() -> List[str]:
    return [("mock-" if MOCK_TEACHERS else "") + t for t in TEACHERS]


def csv_text(header: List[str], rows: List[List[str]]) -> str:
    """The table exactly as step 1's write_table stores it."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def summaries_of(key: str, df: pd.DataFrame, cols: List[str]) -> Dict[str, Any]:
    """What step 3's prepare_case / chunk_info compute for these columns of df (same seed rule, keyed by key)."""
    rng = np.random.RandomState((s3.SEED * 1000003 + zlib.crc32(key.encode("utf-8"))) % (2 ** 32))
    return {c: common.column_summary(df[c], s3.N_EXAMPLES, rng) for c in cols}


def info_from_df(case: Dict[str, Any], key: str, df: pd.DataFrame, cols: List[str]) -> Dict[str, Any]:
    return {"case": case, "id": key, "task": case["task"], "columns": cols, "summaries": summaries_of(key, df, cols),
            "n_rows": len(df), "real_text": {k: case.get(k) or "" for k in s3.TEXT_KEYS}}


def info_from_text(case: Dict[str, Any], text: str) -> Dict[str, Any]:
    df = pd.read_csv(io.StringIO(text), low_memory=False)
    return info_from_df(case, case["id"], df, [c for c in df.columns if c != common.TARGET])


def variants(case: Dict[str, Any], df: pd.DataFrame, n: int, rng: np.random.RandomState
             ) -> List[Tuple[int, str, Dict[str, Any]]]:
    """n (variant, key, info): the table as is (key = its id, so its prompts are exactly the teachers'), then shuffled
    columns on a random share of the rows (kept in their original order)."""
    cols = [c for c in df.columns if c != common.TARGET]
    out = [(1, case["id"], info_from_df(case, case["id"], df, cols))]
    for v in range(2, n + 1):
        key = "%s__v%d" % (case["id"], v)
        share = float(rng.uniform(*ROW_SHARE))
        size = min(len(df), max(30, int(round(share * len(df)))))
        rows = np.sort(rng.choice(len(df), size=size, replace=False))
        order = [cols[i] for i in rng.permutation(len(cols))]
        out.append((v, key, info_from_df(case, key, df.iloc[rows].reset_index(drop=True), order)))
    return out


def answer(entries: List[Tuple[str, str, str, int]]) -> str:
    """The training answer of one chunk: a reason before the risk, the names as the prompt shows them."""
    cols = [{"column": s3.shown_name(c), "reason": why, "category": cat, "leak_risk": int(risk)}
            for c, why, cat, risk in entries]
    return json.dumps({"columns": cols}, ensure_ascii=False)


def example(ch: Dict[str, Any], meta: Dict[str, Any], entries: List[Tuple[str, str, str, int]]) -> Dict[str, Any]:
    return dict(meta, id=ch["chunk_id"], messages=[{"role": "system", "content": s3.SYSTEM_PROMPT},
                                                   {"role": "user", "content": ch["user"]},
                                                   {"role": "assistant", "content": answer(entries)}])


# ============================================================ targets from the teachers (fixes 1 and 3)
def round5(x: float) -> int:
    return int(min(100, max(0, math.floor(x / 5.0 + 0.5) * 5)))


def cached_record(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The teacher's cached answer for this chunk id, whatever prompt it was made for (None if there is none)."""
    rec = common.load_json(common.path("llm_cache", lab, "chunks", ch["chunk_id"] + ".json"))
    return rec if isinstance(rec, dict) and rec.get("parsed") and rec.get("model_id") else None


def same_prompt(rec: Dict[str, Any], ch: Dict[str, Any]) -> bool:
    """The cached answer was made for exactly this prompt (text and hash)."""
    return (rec.get("prompt") == ch["user"] and
            rec.get("prompt_hash") == common.text_hash(str(rec["model_id"]), s3.SYSTEM_PROMPT, ch["user"]))


def teacher_answer(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    rec = cached_record(lab, ch)
    if rec is None or rec.get("prompt_hash") != common.text_hash(str(rec["model_id"]), s3.SYSTEM_PROMPT, ch["user"]):
        return None
    return rec


def teacher_ratings(chunks: List[Dict[str, Any]]) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """{column: {teacher label: {leak_risk, category, reason}}} from the teachers' answers to these chunk prompts
    (entries without a usable risk left out)."""
    out: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for lab in teacher_labels():
        for ch in chunks:
            rec = teacher_answer(lab, ch)
            if not rec:
                continue
            for c, e in (rec["parsed"].get("columns") or {}).items():
                r = s3.to_risk((e or {}).get("leak_risk"))
                if c in ch["columns"] and np.isfinite(r):
                    out.setdefault(c, {})[lab] = {"leak_risk": float(r),
                                                  "category": s3.norm_category((e or {}).get("category")),
                                                  "reason": " ".join(str((e or {}).get("reason") or "").split())}
    return out


def target(case: Dict[str, Any], col: str, ratings: Dict[str, Dict[str, Any]], dev: bool
           ) -> Tuple[str, str, int]:
    """(reason, category, risk) for one column of a public table (design: fix 3)."""
    labs = teacher_labels()
    m = round5(float(np.mean([e["leak_risk"] for e in ratings.values()])))
    if dev:
        if col in case["leak_columns"]:
            final = max(m, 80)
        elif col in case["probable_leak_columns"]:
            final = min(max(m, 20), 80)
        else:
            final = min(m, 20)
    else:
        final = m
    order = sorted(ratings, key=lambda t: (abs(ratings[t]["leak_risk"] - final), labs.index(t)))
    closer = order[0]
    other = order[1] if len(order) > 1 else None
    if final >= 50:
        if ratings[closer]["category"] in LEAK_CATEGORIES:
            src = closer
        elif other and ratings[other]["category"] in LEAK_CATEGORIES:
            src = other
        else:
            src = None
        if src:
            cat = ratings[src]["category"]
            why = ratings[src]["reason"] or REASON[cat]
        else:
            cat = DEV_CATEGORY.get(case["id"], {}).get(col, "post_outcome") if dev else "post_outcome"
            why = REASON[cat]
    else:
        cat = "fine"
        why = (ratings[closer]["reason"] if ratings[closer]["category"] == "fine" and ratings[closer]["reason"]
               else REASON["fine"])
    return why, cat, final


def rate_generated(case: Dict[str, Any], col: str) -> Tuple[str, str, int]:
    ltype = (case.get("leak_types") or {}).get(col)
    if ltype and ltype in CATEGORY:
        return REASON[CATEGORY[ltype]], CATEGORY[ltype], RISK_LEAK
    return REASON["fine"], "fine", RISK_FINE   # decoys, traps, the moment column, strong predictors, overwrites


# ============================================================ checks
def file_sha256(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def csv_sha256(case_id: str) -> str:
    with gzip.open(common.data_file(case_id), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def generator_check(gen: List[Dict[str, Any]]) -> str:
    """Rebuilds all 42 generated test tables with this folder's generator and compares them with data/ byte for
    byte."""
    bad = []
    for c in gen:
        dom, tid = c["domain"], c["id"]
        traps = tid.startswith("traps_")
        k = 0 if traps else int(tid.rsplit("_", 1)[1])
        case, rows, header = s1.build(tid, dom, k, traps)
        h = hashlib.sha256(csv_text(header, rows).encode("utf-8")).hexdigest()
        if not common.has_data(tid) or h != csv_sha256(tid):
            bad.append(tid)
    if bad:
        raise SystemExit("STOP: the generator no longer rebuilds %d test table(s) exactly: %s. Tell Claude."
                         % (len(bad), ", ".join(bad)))
    return "ok (all %d generated test tables rebuild byte for byte)" % len(gen)


def generated_prompt_check(gen: List[Dict[str, Any]]) -> str:
    """Two generated test tables built in memory, the way training tables are built, must give exactly the chunk
    prompts built from data/."""
    by_id = {c["id"]: c for c in gen}
    done = []
    for cid, dom, k in (("claims_01", "claims", 1), ("orders_03", "orders", 3)):
        if cid not in by_id:
            continue
        case, rows, header = s1.build(cid, dom, k)
        mine = [ch["user"] for ch in s3.chunk_prompts(info_from_text(case, csv_text(header, rows)))]
        theirs = [ch["user"] for ch in s3.chunk_prompts(s3.chunk_info(by_id[cid]))]
        if mine != theirs:
            raise SystemExit("STOP: the chunk prompts built here for %s differ from those built from data/. Tell "
                             "Claude." % cid)
        done.append(cid)
    return ", ".join(done)


def columns_of(case_id: str) -> set:
    """The file's column names, the original target included, compared case- and punctuation-blind (so the same data
    under another target, or a copy with renamed case, still counts as the same columns)."""
    m = common.read_meta(case_id)
    names = set((m.get("columns") or {}).keys()) | ({str(m["target_original"])} if m.get("target_original") else set())
    return {common.norm_text(x) for x in names} - {""}


def norm_url(u: Any) -> str:
    return str(u or "").strip().lower().rstrip("/")


def raw_hashes(case_id: str) -> set:
    """sha256 of each downloaded source file in data/raw/<id>/ (empty if that folder is not here)."""
    d = common.raw_dir(case_id)
    out = set()
    if os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            p = os.path.join(d, fn)
            if os.path.isfile(p):
                out.add(file_sha256(p))
    return out


def check_inputs() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    for f in [common.CASES_FILE, DISTILL_FILE, TEST3_FILE] + DEV_FILES:
        if not os.path.exists(common.path(f)):
            raise SystemExit("%s is missing: run t0_import.py and t1_get_data.py first (Claude sends the cases files)."
                             % f)
    gen = [c for c in common.load_cases(quiet=True) if c.get("url") == "generated"]
    distill = common.load_cases(quiet=True, file=DISTILL_FILE)
    dev = []
    for f in DEV_FILES:
        dev += common.load_cases(quiet=True, file=f)
    test3 = common.load_cases(quiet=True, file=TEST3_FILE)
    sets = {"generated test": gen, "distill": distill, "development": dev, "real test 3": test3}
    seen: Dict[str, str] = {}
    for name, cs in sets.items():
        for c in cs:
            if c["id"] in seen:
                raise SystemExit("STOP: table id %s is in both %s and %s. Tell Claude." % (c["id"], seen[c["id"]], name))
            seen[c["id"]] = name
    no_data = [c["id"] for c in gen + dev + test3 if not common.has_data(c["id"])]
    if no_data:
        raise SystemExit("No data for %d table(s): %s -- run t0_import.py / t1_get_data.py first."
                         % (len(no_data), ", ".join(no_data[:15])))
    missing_distill = [c["id"] for c in distill if not common.has_data(c["id"])]
    if missing_distill:
        print("  note: %d distill table(s) have no data and are left out: %s"
              % (len(missing_distill), ", ".join(missing_distill[:15])))
    distill = [c for c in distill if common.has_data(c["id"])]
    t3_hash = {csv_sha256(c["id"]): c["id"] for c in test3}
    for c in distill + dev:
        h = csv_sha256(c["id"])
        if h in t3_hash:
            raise SystemExit("STOP: training table %s is the same file as real test 3 table %s. Tell Claude."
                             % (c["id"], t3_hash[h]))
    t3_url = {norm_url(c.get("url")): c["id"] for c in test3}
    t3_raw = {h: c["id"] for c in test3 for h in raw_hashes(c["id"])}
    for c in distill + dev:
        if norm_url(c.get("url")) in t3_url:
            raise SystemExit("STOP: training table %s comes from the same file (url) as real test 3 table %s. Tell "
                             "Claude." % (c["id"], t3_url[norm_url(c.get("url"))]))
        same = [t3_raw[h] for h in raw_hashes(c["id"]) if h in t3_raw]
        if same:
            raise SystemExit("STOP: training table %s was downloaded as the same file as real test 3 table %s. Tell "
                             "Claude." % (c["id"], same[0]))
    t3_cols = {c["id"]: columns_of(c["id"]) for c in test3}
    for c in distill + dev:
        cols = columns_of(c["id"])
        for tid, tcols in t3_cols.items():
            if cols and tcols and len(cols & tcols) / float(len(cols | tcols)) > 0.8:
                raise SystemExit("STOP: real test 3 table %s has nearly the same columns as training table %s. Tell "
                                 "Claude." % (tid, c["id"]))
    unknown = [cid for cid in DEV_CATEGORY if cid not in {c["id"] for c in dev}]
    if unknown:
        print("  note: DEV_CATEGORY names tables that are not development tables here: %s" % ", ".join(unknown))
    return gen, distill, dev, test3


# ============================================================ main
def main() -> None:
    t0 = time.time()
    bad = [d for d in TRAIN_DOMAINS if d not in s1.DOMAINS] + [d for d in TRAIN_DOMAINS if d in HOLDOUT_DOMAINS]
    if bad:
        raise SystemExit("Fix TRAIN_DOMAINS / HOLDOUT_DOMAINS: %s" % bad)
    gen_test, distill, dev, test3 = check_inputs()
    print("Training data for fine-tune run 3: %d public training tables x %d, %d development tables x %d, %d generated "
          "tables (%s; held out: %s). Teachers: %s."
          % (len(distill), DISTILL_VARIANTS, len(dev), DEV_VARIANTS, len(TRAIN_DOMAINS) * GEN_TABLES_PER_DOMAIN,
             ", ".join(TRAIN_DOMAINS), ", ".join(HOLDOUT_DOMAINS), ", ".join(teacher_labels())))
    print("Generator check: " + generator_check(gen_test))
    print("Same-prompt check (generated): ok (%s: the chunk prompts built in memory equal those from data/)"
          % generated_prompt_check(gen_test))
    test_hashes = {csv_sha256(c["id"]): c["id"] for c in gen_test}

    counts: Dict[str, Any] = {"examples": {}, "tables": {}, "train": 0, "val": 0, "columns_rated": {},
                              "by_variant": {}, "risk_histogram": {}, "leaks_by_type": {}, "chars": 0,
                              "max_chars": 0, "max_example": "", "teacher_coverage": {}}
    left_out: List[Dict[str, Any]] = []
    val_rng = np.random.RandomState(SEED + 1)
    rng = np.random.RandomState(SEED)
    same_prompt_done: Dict[str, List[str]] = {"distill": [], "development": []}
    stale: List[str] = []
    for p in (TRAIN_FILE, VAL_FILE, MANIFEST_FILE):   # a stopped run must never leave an older file that looks finished
        if os.path.exists(common.path(p)):
            os.remove(common.path(p))
    tmp_tr, tmp_va = common.path(TRAIN_FILE + ".tmp"), common.path(VAL_FILE + ".tmp")

    def put(ex: Dict[str, Any], val: bool, f_tr: Any, f_va: Any) -> None:
        (f_va if val else f_tr).write(json.dumps(ex, ensure_ascii=False) + "\n")
        src = ex["source"]
        counts["examples"][src] = counts["examples"].get(src, 0) + 1
        counts["val" if val else "train"] += 1
        vk = "%s v%d" % (src, ex["variant"])
        counts["by_variant"][vk] = counts["by_variant"].get(vk, 0) + 1
        n = sum(len(m["content"]) for m in ex["messages"])
        counts["chars"] += n
        if n > counts["max_chars"]:
            counts["max_chars"], counts["max_example"] = n, ex["id"]
        for e in json.loads(ex["messages"][2]["content"])["columns"]:
            counts["columns_rated"][src] = counts["columns_rated"].get(src, 0) + 1
            h = counts["risk_histogram"].setdefault(src, {})
            h[str(e["leak_risk"])] = h.get(str(e["leak_risk"]), 0) + 1

    with open(tmp_tr, "w", encoding="utf-8") as f_tr, open(tmp_va, "w", encoding="utf-8") as f_va:
        # 1-2. public tables: the teachers' ratings (development tables kept on the key's side)
        for source, cases, n_var in (("distill", distill, DISTILL_VARIANTS), ("development", dev, DEV_VARIANTS)):
            used = 0
            for case in cases:
                val = bool(val_rng.uniform() < VAL_SHARE)
                df = common.read_data(case["id"])
                vs = variants(case, df, n_var, rng)
                v1_chunks = s3.chunk_prompts(vs[0][2])
                # same-prompt check, on every table: an answer cached for one of these chunk ids must have been made
                # for exactly the prompt built here (otherwise the data or the prompt code changed after t2 ran)
                recs = [(lab, ch, cached_record(lab, ch)) for lab in teacher_labels() for ch in v1_chunks]
                drift = ["%s / %s" % (lab, ch["chunk_id"]) for lab, ch, rec in recs if rec and not same_prompt(rec, ch)]
                if drift:
                    stale.append("%s (%d answers, e.g. %s)" % (case["id"], len(drift), drift[0]))
                    continue
                if len(same_prompt_done[source]) < 2 and any(rec for _, _, rec in recs):
                    same_prompt_done[source].append(case["id"])
                ratings = teacher_ratings(v1_chunks)
                cols = vs[0][2]["columns"]
                unrated = [c for c in cols if c not in ratings]
                if unrated:
                    left_out.append({"table": case["id"], "source": source,
                                     "why": "%d of %d columns have no teacher rating" % (len(unrated), len(cols))})
                    continue
                for c in cols:
                    k = "+".join(sorted(ratings[c]))
                    counts["teacher_coverage"][k] = counts["teacher_coverage"].get(k, 0) + 1
                tg = {c: target(case, c, ratings[c], source == "development") for c in cols}
                for v, key, info in vs:
                    for ch in s3.chunk_prompts(info):
                        meta = {"table": case["id"], "source": source, "variant": v}
                        put(example(ch, meta, [(c,) + tg[c] for c in ch["columns"]]), val, f_tr, f_va)
                counts["tables"][source] = counts["tables"].get(source, 0) + 1
                used += 1
            print("  %s: %d of %d tables used (%d variants each)" % (source, used, len(cases), n_var))
        if stale:
            raise SystemExit("STOP: for %d table(s) the teachers' saved answers were made for other prompts than the "
                             "ones built here -- the data or the prompt code changed after t2_teachers.py ran: %s. "
                             "No training file was written. Tell Claude." % (len(stale), "; ".join(stale[:5])))
        for source, cases in (("distill", distill), ("development", dev)):
            if cases and not counts["tables"].get(source):
                raise SystemExit("STOP: no %s table has a teacher rating for every column (run t2_teachers.py until "
                                 "it says every prompt is answered). No training file was written." % source)
            if len(same_prompt_done[source]) < min(2, counts["tables"].get(source, 0)):
                raise SystemExit("STOP: the same-prompt check could not run for %s. Tell Claude." % source)
        # 3. generated tables
        plan = []
        plan_rng = np.random.RandomState(SEED + 2)   # its own draws, so the generated tables never depend on the others
        for dom in TRAIN_DOMAINS:
            for i in range(GEN_TABLES_PER_DOMAIN):
                traps = bool(plan_rng.uniform() < TRAP_SHARE)
                k = 0 if traps else int(plan_rng.randint(1, 7))      # 1-2 clear, 3-4 abbreviated, 5 cryptic, 6 clean
                plan.append(("trn3_%s_%04d" % (dom, i + 1), dom, k, traps, bool(plan_rng.uniform() < VAL_SHARE)))
        for n, (tid, dom, k, traps, val) in enumerate(plan, 1):
            case, rows, header = s1.build(tid, dom, k, traps, v2=True)
            text = csv_text(header, rows)
            h = hashlib.sha256(text.encode("utf-8")).hexdigest()
            if h in test_hashes:
                raise SystemExit("STOP: %s reproduces test table %s. Tell Claude." % (tid, test_hashes[h]))
            for ch in s3.chunk_prompts(info_from_text(case, text)):
                meta = {"table": tid, "source": "generated", "variant": 1, "domain": dom,
                        "style": case["naming_style"], "trap_table": bool(traps)}
                put(example(ch, meta, [(c,) + rate_generated(case, c) for c in ch["columns"]]), val, f_tr, f_va)
            counts["tables"]["generated"] = counts["tables"].get("generated", 0) + 1
            for t in (case.get("leak_types") or {}).values():
                counts["leaks_by_type"][t] = counts["leaks_by_type"].get(t, 0) + 1
            if n % 100 == 0 or n == len(plan):
                el = time.time() - t0
                print("  generated: %d / %d tables (%.0f s)" % (n, len(plan), el))
    os.replace(tmp_tr, common.path(TRAIN_FILE))   # only now: every check above has passed
    os.replace(tmp_va, common.path(VAL_FILE))
    est_tokens = counts["chars"] / TRAIN_CHARS_PER_TOKEN
    hist = {src: {str(r): h.get(str(r), 0) for r in range(0, 101, 5) if h.get(str(r))}
            for src, h in counts["risk_histogram"].items()}
    manifest = {"created": common.stamp(), "examples": counts["examples"], "tables": counts["tables"],
                "train": counts["train"], "val": counts["val"], "by_variant": counts["by_variant"],
                "columns_rated": counts["columns_rated"], "risk_histogram": hist,
                "leaks_by_type_generated": dict(sorted(counts["leaks_by_type"].items())),
                "est_tokens": int(est_tokens), "longest_example": {"id": counts["max_example"],
                                                                   "est_tokens": int(counts["max_chars"] /
                                                                                     TRAIN_CHARS_PER_TOKEN)},
                "tables_left_out": left_out, "teachers": teacher_labels(), "same_prompt_checked": same_prompt_done,
                "teacher_coverage": counts["teacher_coverage"],
                "settings": {"train_domains": TRAIN_DOMAINS, "holdout_domains": HOLDOUT_DOMAINS,
                             "gen_tables_per_domain": GEN_TABLES_PER_DOMAIN, "trap_share": TRAP_SHARE,
                             "val_share": VAL_SHARE, "distill_variants": DISTILL_VARIANTS,
                             "dev_variants": DEV_VARIANTS, "row_share": list(ROW_SHARE), "seed": SEED,
                             "chunk_size": s3.CHUNK_SIZE, "generator_seed": s1.SEED, "generator_options": "v2"},
                "test3_tables": [c["id"] for c in test3],
                "files": {TRAIN_FILE: file_sha256(common.path(TRAIN_FILE)),
                          VAL_FILE: file_sha256(common.path(VAL_FILE))}}
    common.write_json(common.path(MANIFEST_FILE), manifest)
    print("\n%d examples -> %s (%d) and %s (%d)" % (counts["train"] + counts["val"], TRAIN_FILE, counts["train"],
                                                   VAL_FILE, counts["val"]))
    print("Examples by source: %s; tables used: %s" % (counts["examples"], counts["tables"]))
    print("Public table columns by the teachers that rated them: %s" % ", ".join(
        "%s %d" % kv for kv in sorted(counts["teacher_coverage"].items())))
    for src, h in hist.items():
        graded = sum(v for r, v in h.items() if r not in ("5", "95"))
        print("Target risks, %s: %s (%d of %d not 5 or 95)" % (src, ", ".join("%s: %d" % kv for kv in h.items()),
                                                              graded, sum(h.values())))
    if left_out:
        print("Left out (%d tables): %s" % (len(left_out), "; ".join("%s (%s)" % (x["table"], x["why"])
                                                                      for x in left_out[:10])))
    print("About %.1f million tokens per pass; longest example about %d tokens (%s; the notebook allows 8,192 and "
          "prints the exact counts)." % (est_tokens / 1e6, counts["max_chars"] / TRAIN_CHARS_PER_TOKEN,
                                         counts["max_example"]))
    print("None of the %d generated test tables was reproduced; no real test 3 table (%d) is in the training data or "
          "nearly the same as a training table. %.0f s in all." % (len(test_hashes), len(test3), time.time() - t0))
    print("Next: t4_make_test_prompts.py")


if __name__ == "__main__":
    main()
