# t2_teachers.py -- the teachers of fine-tune run 3 (fix 1): Claude and GPT rate every column of every public training
# table, a few columns per prompt (fix 2: the same chunked prompts the small model will get). Their ratings become the
# small model's training answers in t3_make_training.py. Python 3.9; press Run in PyCharm.
#
# Tables rated: cases_distill.json (268 Rdatasets tables), cases_dev.json (the first 27 public datasets) and
# cases_dev2.json (leak real test 2's 47). Real test 3 is NOT rated (it is the test), unless TEST3_REFERENCE is set
# after the run-3 verdict, for reference rows only.
#
# How to run:
#   1. DRY_RUN = True (as shipped): prints the number of prompts, the first prompt and a cost / time estimate. No calls.
#   2. Paste your two keys below (only here, on your Mac; never into a chat, never send this file with keys in it),
#      set DRY_RUN = False, press Run. It shows progress; you can stop it any time.
#   3. Press Run again until it says every prompt is answered: each answer is saved in llm_cache/<claude|gpt>/chunks/
#      as soon as it arrives, so a stopped run resumes where it left off and a finished one costs nothing to re-run.
# At the end it writes teacher_summary.txt: answers per teacher, cost, how often the two teachers agree, and each
# teacher's recall and false flags on the 74 development tables (whose leaks are documented) as a sanity check.

ANTHROPIC_API_KEY = "REDACTED_KEY"
OPENAI_API_KEY = "REDACTED_KEY"

DRY_RUN = False                 # True: estimate only, no calls. False: call the teachers.
TEACHERS = ["claude", "gpt"]
CLAUDE_MODEL = "claude-sonnet-5-5"
GPT_MODEL = "gpt-6.1-sol"
WORKERS = 4                    # calls running at the same time, per teacher
MAX_TOKENS = 8000              # cap on one answer
TEST3_REFERENCE = True        # True ONLY after the run-3 verdict: also rate real test 3 (reference rows in t6)
MOCK = False                   # True: fake offline teachers (pipeline test only; labels mock-claude, mock-gpt)

TRAIN_FILES = ["cases_distill.json", "cases_dev.json", "cases_dev2.json"]
TEST3_FILE = "cases_test3.json"
OUT_TOKENS_PER_COLUMN = 45     # cost estimate only: answer tokens per rated column
REASONING_TOKENS_EST = 300     # cost estimate only: GPT's hidden reasoning tokens per call
SECONDS_PER_CALL_EST = 15      # time estimate only

# ============================================================ internals
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402

SUMMARY_FILE = "teacher_summary.txt"
LOG_FILE = "t2_log.txt"
DEV_FILES = ["cases_dev.json", "cases_dev2.json"]
_lock = threading.Lock()
DISABLED: Dict[str, str] = {}
LINES: List[str] = []


def setup() -> None:
    s3.ANTHROPIC_API_KEY = ANTHROPIC_API_KEY
    s3.OPENAI_API_KEY = OPENAI_API_KEY
    s3.CLAUDE_MODEL = CLAUDE_MODEL
    s3.GPT_MODEL = GPT_MODEL
    s3.MAX_TOKENS = MAX_TOKENS
    s3.MOCK = MOCK


def label(m: str) -> str:
    return ("mock-" if MOCK else "") + m


def used_model_id(m: str) -> str:
    """The model id stamped on each answer (and inside its prompt hash)."""
    return ("mock:" if MOCK else "") + s3.model_id(m)


def prompt_hash(model_id: str, user: str) -> str:
    return common.text_hash(model_id, s3.SYSTEM_PROMPT, user)


def cache_path(lab: str, chunk_id: str) -> str:
    return common.path("llm_cache", lab, "chunks", chunk_id + ".json")


def load_chunk_answer(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The cached answer of one teacher to one chunk prompt, if it answers exactly today's prompt."""
    rec = common.load_json(cache_path(lab, ch["chunk_id"]))
    if not (isinstance(rec, dict) and rec.get("parsed") and rec.get("model_id")):
        return None
    if rec.get("prompt_hash") != prompt_hash(str(rec["model_id"]), ch["user"]):
        return None
    return rec


def out(s: str = "") -> None:
    with _lock:
        print(s)
        LINES.append(s)


def log(msg: str) -> None:
    with _lock:
        print(msg)
        try:
            with open(common.path(LOG_FILE), "a", encoding="utf-8") as f:
                f.write("%s  %s%s\n" % (common.stamp(), "[mock] " if MOCK else "", " ".join(msg.split())))
        except OSError:
            pass


def disable(m: str, why: str) -> None:
    with _lock:
        first = m not in DISABLED
        DISABLED[m] = why
    if first:
        log("  %s: no more calls this run -- %s" % (m, why))


# ============================================================ the tables and their chunk prompts
def load_tables(files: List[str]) -> List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]]:
    """(file, case, chunks) for every case with data, in file order."""
    out_: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]] = []
    seen: Dict[str, str] = {}
    for fname in files:
        if not os.path.exists(common.path(fname)):
            print("  %s: not in this folder -- skipped" % fname)
            continue
        cases = common.load_cases(quiet=True, file=fname)
        no_data = []
        for c in cases:
            if c["id"] in seen:
                raise SystemExit("STOP: table %s is in both %s and %s. Tell Claude." % (c["id"], seen[c["id"]], fname))
            seen[c["id"]] = fname
            if not common.has_data(c["id"]):
                no_data.append(c["id"])
                continue
            out_.append((fname, c, s3.chunk_prompts(s3.chunk_info(c))))
        if no_data:
            print("  %s: %d table(s) have no data yet (run t1_get_data.py): %s"
                  % (fname, len(no_data), ", ".join(no_data[:12]) + (" ..." if len(no_data) > 12 else "")))
    return out_


# ============================================================ one teacher answer (with one retry)
def ask(m: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    lab = label(m)
    cols = ch["columns"]
    t0 = time.time()
    text1, u1, stop1 = s3.call_model(m, s3.SYSTEM_PROMPT, ch["user"])
    usage = dict(u1)
    p1 = s3.parse_answer(s3.strip_think(text1), cols)
    found = dict(p1["entries"]) if p1 else {}
    unknown = list(p1["unknown"]) if p1 else []
    missing = [c for c in cols if c not in found]
    text2, stop2 = None, None
    if p1 is None or missing:   # unreadable, or any column left out: ask once more
        why = "answer not readable" if p1 is None else "%d of %d columns missing" % (len(missing), len(cols))
        log("  %s / %s: %s (stop: %s) -- asking once more" % (lab, ch["chunk_id"], why, stop1 or "?"))
        reminder = s3.chunk_reminder(cols, None if p1 is None else [s3.shown_name(c) for c in missing])
        text2, u2, stop2 = s3.call_model(m, s3.SYSTEM_PROMPT, ch["user"] + "\n\n" + reminder)
        usage = s3.add_usage(usage, u2)
        p2 = s3.parse_answer(s3.strip_think(text2), cols)
        if p2:
            for c, e in p2["entries"].items():
                found.setdefault(c, e)
            unknown += p2["unknown"]
    cost = 0.0 if MOCK else s3.cost_of(m, usage)
    if not found:
        cut = any(w in str(stop2 or stop1).lower() for w in ("length", "max_tokens", "max_output_tokens"))
        log("  %s / %s: no usable answer after one retry -- not saved; press Run again later.%s It began: %r"
            % (lab, ch["chunk_id"], " The answer was cut off: raise MAX_TOKENS." if cut else "",
               (text2 if text2 is not None else text1)[:300]))
        return {"failed": True, "cost": cost}
    left_out = [c for c in cols if c not in found]
    if left_out:
        log("  %s / %s: no answer for %d column(s): %s" % (lab, ch["chunk_id"], len(left_out), ", ".join(left_out)))
    mid = used_model_id(m)
    rec = {"case_id": ch["table"], "chunk_id": ch["chunk_id"], "model": lab, "model_id": mid,
           "prompt_hash": prompt_hash(mid, ch["user"]), "timestamp": common.stamp(), "prompt": ch["user"],
           "raw": text1, "raw_retry": text2, "stop": [stop1, stop2],
           "parsed": {"columns": found, "missing": left_out, "unknown_names": unknown},
           "usage": usage, "cost": round(cost, 6), "seconds": round(time.time() - t0, 1)}
    common.write_json(cache_path(lab, ch["chunk_id"]), rec)
    return rec


def run_teacher(m: str, todo: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Asks one teacher every chunk in todo, WORKERS at a time; progress every 25 answers."""
    st = {"done": 0, "failed": 0, "cost": 0.0, "fails_in_a_row": 0}
    if not todo:
        return st
    t0 = time.time()

    def one(ch: Dict[str, Any]) -> None:
        if m in DISABLED:
            return
        try:
            rec = ask(m, ch)
        except common.ApiError as e:
            text = str(e).lower()
            if e.code in (401, 402, 403, 404) or "insufficient_quota" in text or "credit balance" in text:
                disable(m, "HTTP %d: check the key at the top, its credit, and the model id (%s)"
                        % (e.code, s3.model_id(m)))
            log("  %s / %s: API error: %s" % (label(m), ch["chunk_id"], " ".join(str(e).split())[:400]))
            rec = {"failed": True, "cost": 0.0}
        except Exception as e:  # one prompt failing must not stop the run
            log("  %s / %s: ERROR %s: %s" % (label(m), ch["chunk_id"], e.__class__.__name__,
                                              " ".join(str(e).split())[:400]))
            rec = {"failed": True, "cost": 0.0}
        with _lock:
            st["cost"] += float(rec.get("cost") or 0.0) if rec else 0.0
            if rec and rec.get("failed"):
                st["failed"] += 1
                st["fails_in_a_row"] += 1
            else:
                st["done"] += 1
                st["fails_in_a_row"] = 0
            n = st["done"] + st["failed"]
            stop_now = st["fails_in_a_row"] >= 10
        if stop_now:
            disable(m, "10 prompts in a row failed -- see %s, then press Run again" % LOG_FILE)
        if n % 25 == 0 or n == len(todo):
            el = time.time() - t0
            print("  %s: %d / %d prompts (%d failed), %.0f min, about %.0f min left, $%.2f so far"
                  % (label(m), n, len(todo), st["failed"], el / 60, el / max(n, 1) * (len(todo) - n) / 60, st["cost"]))

    with ThreadPoolExecutor(max_workers=max(1, int(WORKERS))) as pool:
        futures = [pool.submit(one, ch) for ch in todo]
        for f in as_completed(futures):
            f.result()
    return st


# ============================================================ estimate and summary
def estimate(tables: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]], teachers: List[str]) -> None:
    by_file: Dict[str, List[int]] = {}
    for fname, _, chunks in tables:
        v = by_file.setdefault(fname, [0, 0, 0])
        v[0] += 1
        v[1] += len(chunks)
        v[2] += sum(len(ch["columns"]) for ch in chunks)
    rows = [[f, v[0], v[1], v[2]] for f, v in by_file.items()]
    rows.append(["all", sum(r[1] for r in rows), sum(r[2] for r in rows), sum(r[3] for r in rows)])
    print(common.format_table(["file", "tables", "prompts", "columns"], rows))
    if tables:
        ch = tables[0][2][0]
        print("\nThe first prompt (%s), exactly as sent (system prompt first):\n%s\n%s\n%s\n%s"
              % (ch["chunk_id"], "-" * 100, s3.SYSTEM_PROMPT, ch["user"], "-" * 100))
    total_cost, total_min = 0.0, 0.0
    for m in teachers:
        lab = label(m)
        todo = [ch for _, _, chunks in tables for ch in chunks if load_chunk_answer(lab, ch) is None]
        tin = sum(len(s3.SYSTEM_PROMPT) + len(ch["user"]) for ch in todo) / s3.CHARS_PER_TOKEN
        tout = sum(len(ch["columns"]) for ch in todo) * OUT_TOKENS_PER_COLUMN + \
            (REASONING_TOKENS_EST * len(todo) if m == "gpt" else 0)
        p = s3.PRICE_PER_M.get(s3.model_id(m)) or s3.PRICE_PER_M.get(m) or (0.0, 0.0)
        cost = (tin * p[0] + tout * p[1]) / 1e6
        minutes = len(todo) * SECONDS_PER_CALL_EST / max(1, WORKERS) / 60.0
        total_cost += cost
        total_min = max(total_min, minutes)
        print("%-6s %s: %d of %d prompts still to ask; about %.1fM tokens in, %.2fM out -> about $%.2f "
              "(at $%.2f / $%.2f per million), about %.0f min with WORKERS = %d"
              % (m, s3.model_id(m), len(todo), sum(len(c) for _, _, c in tables), tin / 1e6, tout / 1e6, cost, p[0],
                 p[1], minutes, WORKERS))
    print("\nEstimate for both teachers: about $%.2f, about %.0f min (they run side by side). Check the providers' "
          "current prices; the estimate uses step3_llm_audit.py's PRICE_PER_M." % (total_cost, total_min))


def merged(lab: str, chunks: List[Dict[str, Any]]) -> Dict[str, float]:
    """{column: risk} from one teacher's cached answers to a table's chunks (missing columns left out)."""
    risk: Dict[str, float] = {}
    for ch in chunks:
        rec = load_chunk_answer(lab, ch)
        if rec:
            for c, e in (rec["parsed"].get("columns") or {}).items():
                v = s3.to_risk((e or {}).get("leak_risk"))
                if np.isfinite(v):
                    risk[c] = v
    return risk


def summary(tables: List[Tuple[str, Dict[str, Any], List[Dict[str, Any]]]], teachers: List[str],
            stats: Dict[str, Dict[str, Any]]) -> None:
    out("Teachers of fine-tune run 3 -- summary (%s)%s" % (common.stamp(), " [MOCK]" if MOCK else ""))
    n_chunks = sum(len(c) for _, _, c in tables)
    n_cols = sum(len(ch["columns"]) for _, _, c in tables for ch in c)
    out("Tables: %d; prompts: %d; columns: %d" % (len(tables), n_chunks, n_cols))
    rows = []
    risks: Dict[str, Dict[str, Dict[str, float]]] = {}
    for m in teachers:
        lab = label(m)
        answered, cost, cols = 0, 0.0, 0
        for _, case, chunks in tables:
            for ch in chunks:
                rec = load_chunk_answer(lab, ch)
                if rec:
                    answered += 1
                    cost += float(rec.get("cost") or 0.0)
            r = merged(lab, chunks)
            risks.setdefault(lab, {})[case["id"]] = r
            cols += len(r)
        st = stats.get(m, {})
        rows.append([lab, "%d / %d" % (answered, n_chunks), "%d / %d" % (cols, n_cols),
                     "%d asked, %d failed" % (st.get("done", 0) + st.get("failed", 0), st.get("failed", 0)),
                     "$%.2f" % cost, DISABLED.get(m, "")])
    out(common.format_table(["teacher", "prompts answered", "columns rated", "this run", "cost (all answers)",
                             "stopped because"], rows))
    labs = [label(m) for m in teachers]
    if len(labs) == 2:
        agree, diffs = 0, []
        for _, case, _ in tables:
            a, b = risks[labs[0]].get(case["id"], {}), risks[labs[1]].get(case["id"], {})
            for c in set(a) & set(b):
                agree += (a[c] >= 50) == (b[c] >= 50)
                diffs.append(abs(a[c] - b[c]))
        if diffs:
            out("Agreement: on %d columns both rated, they agree on flag / no flag at risk 50 for %.1f%%; mean "
                "difference %.1f points." % (len(diffs), 100.0 * agree / len(diffs), float(np.mean(diffs))))
    dev = [(f, c) for f, c, _ in tables if f in DEV_FILES]
    if dev:
        out("Sanity check on the development tables (documented leaks; flag at risk >= 50):")
        rows = []
        for lab in labs:
            for fname in DEV_FILES:
                cases = [c for f, c in dev if f == fname]
                if not cases:
                    continue
                rec, ff, answered = [], 0, 0
                for c in cases:
                    r = risks[lab].get(c["id"], {})
                    if not r:
                        continue
                    answered += 1
                    leaks, skip = set(c["leak_columns"]), set(c["probable_leak_columns"])
                    flagged = {k for k, v in r.items() if v >= 50}
                    ff += len(flagged - leaks - skip)
                    if leaks:
                        rec.append(len(flagged & leaks) / float(len(leaks)))
                rows.append([lab, fname, "%d / %d" % (answered, len(cases)),
                             "%.2f" % float(np.mean(rec)) if rec else "-", ff])
        out(common.format_table(["teacher", "tables", "answered", "macro recall", "false flags"], rows))
    with open(common.path(SUMMARY_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(LINES) + "\n")


# ============================================================ main
def main() -> None:
    setup()
    bad = [m for m in TEACHERS if m not in ("claude", "gpt")]
    if bad:
        raise SystemExit("TEACHERS may only name 'claude' and 'gpt' (got %s)." % bad)
    mode = "MOCK -- fake offline teachers" if MOCK else ("DRY RUN" if DRY_RUN else "LIVE")
    files = list(TRAIN_FILES) + ([TEST3_FILE] if TEST3_REFERENCE else [])
    print("Teachers of run 3 [%s]: %s; tables from %s" % (mode, ", ".join("%s (%s)" % (m, s3.model_id(m))
                                                                        for m in TEACHERS), ", ".join(files)))
    t0 = time.time()
    tables = load_tables(files)
    if not tables:
        raise SystemExit("No tables with data -- run t0_import.py and t1_get_data.py first.")
    print("Built %d prompts for %d tables (%.0f s)." % (sum(len(c) for _, _, c in tables), len(tables), time.time() - t0))
    if DRY_RUN and not MOCK:
        estimate(tables, TEACHERS)
        print("\nNext: paste the two keys at the top, set DRY_RUN = False, press Run.")
        return
    if not MOCK:
        for m in TEACHERS:
            k = {"claude": ANTHROPIC_API_KEY, "gpt": OPENAI_API_KEY}[m].strip()
            if not k or k.startswith("PASTE_"):
                raise SystemExit("Paste your %s key at the top (%s), then press Run again."
                                 % ("Anthropic" if m == "claude" else "OpenAI",
                                    "ANTHROPIC_API_KEY" if m == "claude" else "OPENAI_API_KEY"))
    stats: Dict[str, Dict[str, Any]] = {}
    todo = {m: [ch for _, _, chunks in tables for ch in chunks if load_chunk_answer(label(m), ch) is None]
            for m in TEACHERS}
    for m in TEACHERS:
        print("%s: %d prompts to ask (%d already answered)"
              % (label(m), len(todo[m]), sum(len(c) for _, _, c in tables) - len(todo[m])))
    threads = []
    for m in TEACHERS:   # the two teachers run side by side, each with its own WORKERS
        th = threading.Thread(target=lambda m=m: stats.__setitem__(m, run_teacher(m, todo[m])))
        th.start()
        threads.append(th)
    for th in threads:
        th.join()
    print("")
    summary(tables, TEACHERS, stats)
    left = sum(1 for m in TEACHERS for _, _, chunks in tables for ch in chunks
               if load_chunk_answer(label(m), ch) is None)
    print("\n-> %s." % SUMMARY_FILE)
    if left:
        print("%d prompt answers are still missing: press Run again (only those are asked). If the same ones keep "
              "failing, send Claude %s and %s." % (left, SUMMARY_FILE, LOG_FILE))
    else:
        print("Every prompt is answered by every teacher. Send Claude %s (the next step needs real test 3)." % SUMMARY_FILE)


if __name__ == "__main__":
    main()
