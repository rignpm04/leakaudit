# Fine-tune run 3 ("leak training 3") -- design, fixed before any run-3 result

## The question and the rule
Does training Qwen3.5 9B on frontier-teacher ratings of many real tables (fix 1), with prompts that rate at most 10
columns at a time (fix 2) and graded scores (fix 3), make it find more leaks in real tables it never saw?

Rule (same form as runs 1-2): within budget (each model at its best risk threshold on the 0..100 grid in steps of 5,
<= 1 false flag per table on average, per group), PASS = the trained model beats the untrained one by >= 0.10 macro
recall on BOTH the held-out generated domains (lending, hospital) AND "real test 3" (a new curated set of public tables,
documented leaks, none used in training). PARTIAL = held-out domains only. FAIL = anything else. Debatable columns
(probable_leak_columns) count neither way. An answer still unreadable after the retry counts as nothing flagged (rule
fixed 2026-10-20). Untrained and trained answer the same run-3 prompts, thinking off, sampling T 0.6 / top_p 0.95 /
top_k 20.

## Folder on Patrick's Mac: `leak training 3` (PyCharm project root /Users/patrigney/PycharmProjects/pythonProject)
Conventions (Patrick's standing preferences): Python 3.9 (no match, no `X | Y` types, typing module generics), pandas +
numpy + stdlib only (urllib for HTTP), every script runs from PyCharm's Run button with NO CLI args and NO env vars,
settings and keys as constants at the top, files read/written in the script's own folder (common.path), plain terse
printed messages, a clear "Next:" line at the end. Keys only in t2_teachers.py, as PASTE_..._HERE placeholders.

Files in the kit:
- `common.py`, `step1_generate.py` -- unchanged copies from run 2.
- `step3_llm_audit.py` -- run 2's copy plus the chunked prompt (below). Everything existing stays byte-identical in
  behavior (the old whole-table prompts must still be rebuilt exactly, for reference answers).
- `step1_get_data.py` -- leak real test 2's downloader, plus a constant CASES_FILES so one run prepares every case of
  cases_distill.json and cases_test3.json (same standardization; rownames via drop_columns).
- `t0_import.py` -- from `leak training 2` (constant RUN2_FOLDER =
  "/Users/patrigney/PycharmProjects/pythonProject/leak training 2"): cases.json + data/ (42 generated test tables),
  cases_dev.json + data/ (the first 27 public datasets) and cases_real.json saved here as cases_dev2.json + data/ (the
  47 of leak real test 2: development data from now on), plus every cached answer in its llm_cache/ for the 42
  generated tables (labels kept; run 2's gpu answers renamed run2-gpu-...). Copy rule as eval0's put().
- `t1_get_data.py` -- thin wrapper: runs step1_get_data's process() for every case in cases_distill.json and
  cases_test3.json not yet in data/; prints "<n> of <m> tables ready" per file; skipped cases listed with reasons.
- `t2_teachers.py` -- the teachers (fix 1), below.
- `t3_make_training.py` -- train.jsonl, val.jsonl, train_manifest.json (fixes 1-3), below.
- `t4_make_test_prompts.py` -- test_prompts.jsonl (chunked), below.
- `train2_runpod_run3.ipynb` -- the GPU notebook, below.
- `t5_import_gpu.py` -- stores the notebook's answers per chunk, below.
- `t6_compare.py` -- scores and the verdict, below.
- `GUIDE.md` -- written by the main session later (not the fork).

## Fix 2: the chunked prompt (step3_llm_audit.py additions)
CHUNK_SIZE = 10. A table's rated columns are all columns except the target, in the table's column order. With N
columns, k = ceil(N / CHUNK_SIZE) chunks of consecutive columns, sizes as equal as possible (larger parts first; e.g.
23 -> 8, 8, 7). Chunk id: "<table id>__c<j>of<k>" (j from 1).
Summaries: exactly prepare_case's (same seed rule keyed by the table id, computed over all columns in table order), so
a chunk's lines are identical to the whole-table prompt's lines for those columns. For training variants the key is
the variant key, as run 2's info_from_df did.
User prompt (exact layout; names in the list are whitespace-collapsed like column_line does):
```
Unit of observation: <unit or "(not given)">
Target (<binary classification|regression>): <target_description or "(not given)">
Prediction moment: <prediction_time or "(not given)">

The table has <N> columns besides the target (values from <M> rows). All of them: <name1>, <name2>, ..., <nameN>

Rate these <K> columns (part <j> of <k>) -- name | type | missing | distinct values | examples:
<K column_line()s>

Return only a json object, with no other text:
{"columns": [{"column": "<name>", "reason": "<one short sentence>", "category": "post_outcome|target_derived|identifier|future_aggregate|fine", "leak_risk": <0-100>}]}
Rate exactly the <K> columns listed with values above, each once, using the names exactly as given. Keep each reason under 15 words.
```
System prompt: step 3's SYSTEM_PROMPT, unchanged. The reason comes before the risk on purpose (a short reason written
before the score). Reading answers: step 3's parse_answer(strip_think(text), chunk columns) (keys are order-free; no
dataset_guess). Retry rule everywhere (teachers and notebook): if the answer is unreadable or any of the chunk's
columns is missing, ask once more with the prompt + "\n\n" + a reminder (all K columns again if unreadable;
else just the missing names, step 3's REMINDER_MISSING wording) and fill in what the retry adds.
API: `chunk_prompts(info) -> List[dict(chunk_id, part, parts, columns, user)]` and `CHUNK_SIZE`, plus a helper that
builds info for a case like prepare_case.

## Fix 1: teachers (t2_teachers.py)
Claude (`claude-sonnet-5-5`) and GPT (`gpt-6.1-sol`), via step 3's call_claude / call_gpt (t2 sets step 3's key and
model constants from its own constants; MAX_TOKENS 8000; TIMEOUT 300; retries as common.http_post). Every chunk of
every training real table: cases_distill.json (about 300 Rdatasets tables), cases_dev.json (27), cases_dev2.json (47).
Cache: llm_cache/<claude|gpt>/chunks/<chunk id>.json with case_id, chunk_id, model, model_id, prompt_hash =
common.text_hash(model_id, SYSTEM_PROMPT, user), prompt, raw (+ raw_retry), parsed {columns: {col: {leak_risk,
category, reason}}, missing, unknown_names}, usage {in, out}, cost, seconds, timestamp. A cached answer with the same
hash is reused (resume; a second run costs nothing). WORKERS = 4 per provider (thread pool), progress every 25 chunks.
DRY_RUN = True first: prints the number of tables / chunks / columns per file, the first prompt, and a cost estimate
per teacher (input chars / 3.5 tokens; output 45 tokens per rated column, and for GPT add REASONING_TOKENS_EST per call
= 300; prices from step 3's PRICE_PER_M; also time estimate). MOCK = True: a fake teacher (deterministic from a hash,
plausible json) for pipeline tests, labels mock-claude / mock-gpt, ignores DRY_RUN.
Optional flag TEST3_REFERENCE = False: when True (only after the run-3 verdict) it also rates the test-3 tables'
chunks, for reference rows in t6.
End of run: per teacher chunks answered / failed, columns rated, cost; agreement between the two teachers (share of
columns where both are >= 50 or both < 50; mean absolute difference); on the 27 + 47 (curated keys), each teacher's
recall and false flags at risk >= 50 as a sanity check. Write teacher_summary.txt.

## Fix 3: graded targets (t3_make_training.py)
Per column, from the two teachers' cached answers to the variant-1 (as-is) chunk prompts:
m = mean of the teachers' leak_risk (only one teacher has it -> that value), rounded to the nearest 5, clipped 0..100.
- Distill tables: final risk = m.
- Development tables (27 + 47, curated keys): leak_columns -> max(m, 80); probable_leak_columns -> min(max(m, 20), 80);
  every other column -> min(m, 20).
- Category and reason: from the teacher whose risk is closer to the final risk (tie -> claude). If final >= 50: category
  = that teacher's if not "fine", else the other teacher's if not "fine", else "post_outcome" (development tables: run
  2's DEV_CATEGORY entry if listed); reason = the chosen category's teacher reason if that teacher's category is not
  "fine", else run 2's template REASON[category]. If final < 50: category "fine"; reason = the closer teacher's reason
  if its category is "fine", else REASON["fine"].
- A real table is used only if every column has at least one teacher rating; tables left out are listed.
- Generated tables: run 2's rule (leak types -> 95 with CATEGORY by type; everything else 5 "fine"; template reasons).
Answer json for a chunk (reason first, risk last, ints): {"columns": [{"column", "reason", "category", "leak_risk"}]}
for the chunk's columns in prompt order, ensure_ascii=False.

## Training mix (t3_make_training.py)
- Distill tables: DISTILL_VARIANTS = 3 (v1 = as is: its chunk prompts are exactly the teacher prompts; v2 = columns
  shuffled + 60-95% of rows, run 2's dev_variants recipe, then chunked in the shuffled order).
- Development 27 + 47: DEV_VARIANTS = 3 (v1 as is + 2 shuffled/subsampled).
- Generated: GEN_TABLES_PER_DOMAIN = 60 for claims, orders, saas, shipments (240), step1_generate build(..., v2=True),
  ids trn3_<domain>_NNNN, TRAP_SHARE 0.15, k drawn as run 2; each table as is, chunked.
- Validation: VAL_SHARE = 0.05 of tables (whole table with all its variants and chunks), drawn per table with SEED.
- Each example: {"id": "<chunk id>", "table": "<table id>", "source": "distill|development|generated", "variant": v,
  "messages": [system, user, assistant]}.
- Checks that STOP: all 42 generated test tables rebuild byte for byte (run 2's generator_check); no training table's
  CSV equals a generated test table; no training id or CSV hash equals a real test 3 table; no real test 3 table has
  column-set Jaccard > 0.8 with any distill or development table; same-prompt check: for 2 distill and 2 development
  tables, the v1 chunk prompts equal the cached teacher prompts (hash), and for 2 generated test tables built in memory
  the chunk prompts equal those built from data/. Manifest: counts by source / variant / group, columns rated, risk
  histogram of targets (0-100 in steps of 5) by source, estimated tokens (2.65 chars per token), longest example,
  files' sha256, tables left out.

## Test prompts (t4_make_test_prompts.py)
The 42 generated test tables (cases.json) + real test 3 (cases_test3.json), every chunk. Refuses any distill or
development table. Line: {"id": chunk id, "table": table id, "group": "training domains|held-out domains|trap
tables|real test 3", "system", "user", "columns": chunk columns, "leak_columns": [in chunk], "probable_leak_columns":
[in chunk]}. Prints tables and chunks per group and the file's sha256; writes test_manifest.json {chunks, tables,
sha256}.

## Notebook (train2_runpod_run3.ipynb)
Run 2's notebook, changed only where needed:
- File names: answers_base_run3.jsonl, answers_trained_run3.jsonl, train_run3.json, OUTPUT_NAME leakaudit3-qwen3.5-9b.
- TEST_ROWS are chunk prompts; the check cell asserts every table's chunks are all present (j = 1..k) and prints the
  counts (no hard-coded 89).
- EVAL_MAX_NEW_TOKENS = 2048 (a chunk answer is about 500 tokens).
- answer_all: the answer file is NEVER opened in append mode. All answers are kept in a dict and the whole file is
  rewritten after each answer: write to <file>.tmp, flush + os.fsync, os.replace. read_done strips "\x00" and skips
  lines that do not parse (printing how many). (Run 2's trained file came back with 5,242,761 leading NUL bytes on
  RunPod's /workspace volume after append-mode writes.) After a stage, verify the file has no NUL byte and every line
  parses, then hash it.
- The retry rule above (missing > 10% of the chunk's columns, or unreadable) with the reminder text; record attempts.
- Preview: per group, merge each table's chunks, flag at risk >= 50, macro recall and false flags.
- Everything else as run 2: settings (EPOCHS 1, LR 5e-5, LoRA r16, batch 4 x 4, TRAIN_MAX_TOKENS 8192, MAX_SEQ_LENGTH
  16384, seed 3407, UNSLOTH_EXPERIMENTAL_HYBRID_PACKING=0, padding_free False), install cell, prompt/training-token
  prefix check, train_on_responses_only with the same markers, masking asserts, GGUF q4_k_m export and rename, run
  record (now also "examples by source" from the train rows, and the test manifest sha256).

## Import (t5_import_gpu.py)
answers_base_run3.jsonl -> llm_cache/gpu3-qwen3.5-9b/chunks/<chunk id>.json (untrained, run 3 prompts),
answers_trained_run3.jsonl -> llm_cache/gpu3-leakaudit3-qwen3.5-9b/chunks/<chunk id>.json. Strips NUL bytes (reports
how many), parses with parse_answer against the chunk's columns, stamps prompt_hash = text_hash(model_id,
SYSTEM_PROMPT, user). Prints per file: chunks stored / total, unreadable chunks, columns left unanswered, tables
complete.

## Compare (t6_compare.py)
Groups: training domains (generated, 4 trained domains), held-out domains, trap tables, real test 3. A model's risk
map for a table = the union of its chunk answers that match today's chunk prompt hash; a missing chunk leaves its
columns unflagged (coverage shown). Models: every label with chunk answers (gpu3-..., later claude/gpt if
TEST3_REFERENCE was run) plus, as references on the generated groups only, every label with old whole-table answers
in llm_cache/<label>/real/ that match the old prompt hash (frontier, open, local, run1-gpu-..., run2-gpu-...), shown as
"<label> (whole-table)". Within-budget and fixed (risk >= 50) tables, held-out by naming style, real test 3 by table
(untrained vs trained), the verdict (BASE_LABEL gpu3-qwen3.5-9b, TRAINED_PREFIX gpu3-leakaudit), answers used,
unreadable counts. Output results_training_run3.txt.

## Mock test (sandbox, before shipping)
End to end with MOCK teachers and a fake GPU model: t0 from a mock `leak training 2` (42 generated tables rebuilt with
step1_generate; the 27 and 47 downloaded with step1_get_data from their cases files), t1 on a few distill + test-3
stand-in cases, t2 (MOCK), t3, t4, the notebook's code cells with a fake model (resume, atomic writes, NUL-free check,
prefix check on a tiny tokenizer stand-in where possible), t5, t6. Also a NUL-byte test of t5 and of read_done.

## Amendments (Oct 21, before any run-3 result)
- Retry on ANY missing column (was: more than 10%), for the teachers and the notebook alike.
- Training mix: DISTILL_VARIANTS 3 (was 2), GEN_TABLES_PER_DOMAIN 60 (was 125), so generated tables are about a
  quarter of the examples instead of about half.
- The distill set is 268 tables (cases_distill.json; 284 specs written, 16 cross-batch duplicates dropped).
- Training answers use the column names as the prompt shows them (whitespace collapsed); unreadable notebook answers
  are imported as marker records (counted as nothing flagged); t5 clears a label's chunk folder before importing;
  the generated-table plan has its own random stream (SEED + 2). (Build notes.)
- Real test 3 (cases_test3.json), fixed before any model saw it: 55 public tables, 43 with documented leaks (189 leak
  columns) and 12 clean, 36 debatable columns. Built by 5 searches (recorded after the outcome 11, parts/recodings
  of the target 13, follow-up and later measurements 12, leaks named in docs 7, clean 12) that excluded the 27, the 47
  and the whole 440-item training pool; 4 independent checkers reviewed every column, quote, target and task sentence
  (31 KEEP, 24 KEEP_WITH_CHANGES, 0 DROP) and a hint reviewer read every task sentence; 35 tables changed from the
  candidates (mostly neutral moments, and keys tightened with exact data checks). Record: test3_review.json. 238 test
  prompts in all (42 generated tables 127, real test 3 111).
- Code review (independent agent) before shipping Part B: t3 now STOPs if any teacher answer was made for a different
  prompt (data or code changed after t2) or a source ends with no tables, writes its files only after every check, and
  also refuses training tables with the same url or raw file as a test-3 table (column overlap now case-blind and
  target-inclusive); t5 STOPs if test_prompts.jsonl changed since the pod run; t1 re-prepares a case whose entry
  changed; t4 STOPs if a key column is missing from the data; the notebook drops trained answers from an earlier
  training session, rewrites an answer file that held NUL bytes or broken lines, writes ASCII-only lines, matches
  column names like step 3's reader, and checks masking with prompt-only markers.
