# t5_import_gpu.py -- stores the answers the RunPod notebook wrote (answers_base_run3.jsonl and
# answers_trained_run3.jsonl, both downloaded into this folder), one file per prompt, so t6_compare.py scores them.
# Python 3.9; press Run in PyCharm. No calls, no keys. Needs test_prompts.jsonl (made by t4_make_test_prompts.py).
#
#   answers_base_run3.jsonl     -> llm_cache/gpu3-qwen3.5-9b/chunks/<prompt id>.json            (untrained)
#   answers_trained_run3.jsonl  -> llm_cache/gpu3-leakaudit3-qwen3.5-9b/chunks/<prompt id>.json  (trained, run 3)
# Each answer is read with step 3's own reader and stamped with the hash of the exact prompt it answers. An answer
# that cannot be read is stored as unreadable: it counts as nothing flagged (the rule fixed on Oct 20). Any NUL bytes
# in a file (run 2's trained file came back with 5 MB of them in front) are removed first and reported.

FILES = {"answers_base_run3.jsonl": ("gpu3-qwen3.5-9b", "runpod/qwen3.5-9b (untrained, run 3 prompts)"),
         "answers_trained_run3.jsonl": ("gpu3-leakaudit3-qwen3.5-9b", "runpod/leakaudit3-qwen3.5-9b (trained, run 3)")}
TEST_FILE = "test_prompts.jsonl"
RUN_FILE = "train_run3.json"   # the notebook's run record: holds the sha256 of the test_prompts.jsonl the pod answered

# ============================================================ internals
import hashlib
import json
import os
import shutil
import sys
from typing import Any, Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402


def read_lines(p: str) -> Tuple[List[Dict[str, Any]], int, int]:
    """The answer rows of a notebook file, its NUL byte count, and how many lines did not parse."""
    with open(p, "rb") as f:
        raw = f.read()
    nul = raw.count(b"\x00")
    rows, bad = [], 0
    # split on "\n" only: str.splitlines() also breaks at U+2028 / U+0085, which json.dumps leaves inside strings
    for line in raw.replace(b"\x00", b"").decode("utf-8", "replace").split("\n"):
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except ValueError:
            bad += 1
            continue
        if isinstance(r, dict) and r.get("id"):
            rows.append(r)
        else:
            bad += 1
    return rows, nul, bad


def main() -> None:
    if not os.path.exists(common.path(TEST_FILE)):
        raise SystemExit("%s is missing: run t4_make_test_prompts.py first." % TEST_FILE)
    with open(common.path(TEST_FILE), "rb") as f:
        digest = hashlib.sha256(f.read()).hexdigest()
    run = common.load_json(common.path(RUN_FILE)) or {}
    pod = ((run.get("files") or {}).get(TEST_FILE)) if isinstance(run, dict) else None
    if pod and pod != digest:   # each answer is stamped with the hash of the prompt in today's file: it must be that file
        raise SystemExit("STOP: %s here (sha256 %s...) is not the file the pod answered (%s says %s...). Put back the "
                         "file you uploaded, or tell Claude." % (TEST_FILE, digest[:16], RUN_FILE, pod[:16]))
    if not pod:
        print("note: %s is not here, so it cannot be checked that %s is the file the pod answered -- download it too"
              % (RUN_FILE, TEST_FILE))
    with open(common.path(TEST_FILE), encoding="utf-8") as f:
        tests: Dict[str, Dict[str, Any]] = {r["id"]: r for r in (json.loads(x) for x in f if x.strip())}
    tables: Dict[str, List[str]] = {}
    for cid, t in tests.items():
        tables.setdefault(t["table"], []).append(cid)
    found_any = False
    for fn, (lab, model_id) in FILES.items():
        p = common.path(fn)
        if not os.path.exists(p):
            print("%s: not here yet -- download it from RunPod into this folder" % fn)
            continue
        rows, nul, bad = read_lines(p)
        if rows:
            found_any = True
        else:
            print("%s: holds no answers -- download it again from RunPod" % fn)
        if nul:
            print("%s: %d NUL bytes removed before reading (the answers themselves are intact)" % (fn, nul))
        if bad:
            print("%s: %d line(s) could not be read at all (left out)" % (fn, bad))
        old = common.path("llm_cache", lab, "chunks")
        if os.path.isdir(old):   # a fresh import: no stale answer from an earlier file may survive
            shutil.rmtree(old)
        stored, unreadable, missing_cols, unknown_ids = 0, [], 0, []
        for r in rows:
            t = tests.get(r.get("id"))
            if t is None:
                unknown_ids.append(str(r.get("id")))
                continue
            parsed = s3.parse_answer(s3.strip_think(r.get("text") or ""), t["columns"])
            if r.get("text_retry"):   # the notebook asked once more: fill in what the second answer adds
                p2 = s3.parse_answer(s3.strip_think(r.get("text_retry") or ""), t["columns"])
                if p2 and parsed:
                    for c, e in p2["entries"].items():
                        parsed["entries"].setdefault(c, e)
                    parsed["unknown"] += p2["unknown"]
                elif p2:
                    parsed = p2
            phash = common.text_hash(model_id, t["system"], t["user"])
            rec = {"case_id": t["table"], "chunk_id": t["id"], "model": lab, "model_id": model_id,
                   "prompt_hash": phash, "timestamp": common.stamp(), "prompt": t["user"], "raw": r.get("text"),
                   "raw_retry": r.get("text_retry"), "attempts": r.get("attempts"), "usage": {"out": r.get("tokens")}, "cost": 0.0,
                   "seconds": r.get("seconds"), "source": "RunPod notebook (%s)" % fn}
            if parsed:
                left_out = [c for c in t["columns"] if c not in parsed["entries"]]
                missing_cols += len(left_out)
                rec["parsed"] = {"columns": parsed["entries"], "missing": left_out, "unknown_names": parsed["unknown"]}
                stored += 1
            else:
                rec["parsed"] = None
                rec["unreadable"] = True
                unreadable.append(t["id"])
            common.write_json(common.path("llm_cache", lab, "chunks", t["id"] + ".json"), rec)
        have = {r.get("id") for r in rows if r.get("id") in tests}
        complete = sum(1 for ids in tables.values() if all(i in have for i in ids))
        print("%s -> llm_cache/%s/chunks/: %d of %d prompts read; %d unreadable%s; %d columns left unanswered; %d of %d "
              "tables have every prompt answered"
              % (fn, lab, stored, len(tests), len(unreadable),
                 (" (%s)" % ", ".join(unreadable[:10])) if unreadable else "", missing_cols, complete, len(tables)))
        if unknown_ids:
            print("  note: %d answer(s) are for prompts not in %s (left out): %s"
                  % (len(unknown_ids), TEST_FILE, ", ".join(unknown_ids[:10])))
    if found_any:
        print("Next: t6_compare.py")


if __name__ == "__main__":
    main()
