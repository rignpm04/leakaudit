# t0_import.py -- brings what fine-tune run 3 needs from your run 2 folder ("leak training 2") into this folder.
# Python 3.9; press Run in PyCharm. No keys, no calls. Running it again is safe (it only adds what is new).
#
# From RUN2_FOLDER:
#   cases.json and data/ for the 42 generated test tables (byte for byte the tables every model saw), and every cached
#   answer for them in llm_cache/ (DeepSeek, Claude, GPT, open and local models, run 1's run1-gpu-... models), for
#   reference rows; run 2's own RunPod models are renamed run2-gpu-... so they never mix with run 3's;
#   cases_dev.json and data/ for the first test's 27 public datasets (development data, as in run 2);
#   cases_real.json, saved here as cases_dev2.json, and data/ for leak real test 2's 47 public datasets: their results
#   were read for run 2's verdict, so from run 3 on they are development data too (trained on, never tested).
# Nothing in RUN2_FOLDER is changed. A file already here is kept, unless the one there is newer and different.
#
# Path: in PyCharm, right-click the folder > Copy Path/Reference > Absolute Path, and paste it between the quotes.

RUN2_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leak training 2"

# ============================================================ internals
import filecmp
import json
import os
import shutil
import sys
from typing import Any, Dict, List, Set

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

DEV_CASES_FILE = "cases_dev.json"
DEV2_CASES_FILE = "cases_dev2.json"
RUN2_RENAME = {"gpu-qwen3.5-9b": "run2-gpu-qwen3.5-9b", "gpu-leakaudit2-qwen3.5-9b": "run2-gpu-leakaudit2-qwen3.5-9b"}
STATS: Dict[str, int] = {"copied": 0, "updated": 0, "kept": 0}


def folder(p: str) -> str:
    p = os.path.expanduser(str(p or "").strip().strip("'\""))
    if not p or p.startswith("PASTE_"):
        raise SystemExit("Paste the full path of your leak training 2 folder at the top of t0_import.py (RUN2_FOLDER).")
    p = os.path.normpath(p)
    if not os.path.isdir(p):
        raise SystemExit("RUN2_FOLDER does not exist: %s" % p)
    if os.path.samefile(p, HERE):
        raise SystemExit("RUN2_FOLDER points at this folder -- it must be your leak training 2 folder.")
    return p


def put(src: str, dst: str) -> None:
    """Copy src to dst unless dst exists; replace dst only if src is newer and different."""
    if os.path.exists(dst):
        if filecmp.cmp(src, dst, shallow=False) or os.path.getmtime(src) <= os.path.getmtime(dst):
            STATS["kept"] += 1
            return
        STATS["updated"] += 1
    else:
        STATS["copied"] += 1
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def read_cases(p: str) -> List[Dict[str, Any]]:
    if not os.path.exists(p):
        raise SystemExit("Not found: %s" % p)
    with open(p, encoding="utf-8-sig") as f:
        raw = json.load(f)
    return raw.get("cases", []) if isinstance(raw, dict) else raw


def copy_data(src_dir: str, ids: List[str], what: str) -> List[str]:
    missing = []
    for cid in ids:
        f = os.path.join(src_dir, "data", cid + ".csv.gz")
        if not os.path.exists(f):
            missing.append(cid)
            continue
        put(f, common.data_file(cid))
        m = os.path.join(src_dir, "data", cid + ".meta.json")
        if os.path.exists(m):
            put(m, common.meta_file(cid))
    if missing:
        print("  %s: no data for %d table(s) there: %s" % (what, len(missing), ", ".join(missing)))
    return missing


def copy_answers(src_dir: str, ids: Set[str]) -> Dict[str, int]:
    """Cached whole-table ('real') answers for these tables, for every model label (run 2's gpu labels renamed)."""
    got: Dict[str, int] = {}
    root = os.path.join(src_dir, "llm_cache")
    if not os.path.isdir(root):
        return got
    for lab in sorted(os.listdir(root)):
        d = os.path.join(root, lab, "real")
        if lab.startswith("mock-") or not os.path.isdir(d):
            continue
        dest_lab = RUN2_RENAME.get(lab, lab)
        for fn in sorted(os.listdir(d)):
            cid = fn[:-5] if fn.endswith(".json") else None
            if cid not in ids:
                continue
            put(os.path.join(d, fn), common.path("llm_cache", dest_lab, "real", fn))
            got[dest_lab] = got.get(dest_lab, 0) + 1
    return got


def main() -> None:
    src = folder(RUN2_FOLDER)
    print("From %s" % src)

    print("1. The 42 generated test tables")
    gen = [c for c in read_cases(os.path.join(src, "cases.json")) if c.get("url") == "generated"]
    if len(gen) != 42:
        print("  note: found %d generated tables in its cases.json (expected 42)" % len(gen))
    put(os.path.join(src, "cases.json"), common.path("cases.json"))
    if os.path.exists(os.path.join(src, "generated_checksums.txt")):
        put(os.path.join(src, "generated_checksums.txt"), common.path("generated_checksums.txt"))
    gen_ids = [c["id"] for c in gen]
    miss_gen = copy_data(src, gen_ids, "generated")
    answers = copy_answers(src, set(gen_ids))

    print("2. Development tables: the first test's 27 public datasets")
    dev = read_cases(os.path.join(src, DEV_CASES_FILE))
    put(os.path.join(src, DEV_CASES_FILE), common.path(DEV_CASES_FILE))
    dev_ids = [c["id"] for c in dev]
    miss_dev = copy_data(src, dev_ids, "development (27)")

    print("3. Development tables: leak real test 2's 47 public datasets (saved here as %s)" % DEV2_CASES_FILE)
    real_src = os.path.join(src, "cases_real.json")
    dev2 = read_cases(real_src)
    dev2_ids = [c["id"] for c in dev2]
    both = sorted((set(dev2_ids) & set(dev_ids)) | (set(dev2_ids) & set(gen_ids)) | (set(dev_ids) & set(gen_ids)))
    if both:
        raise SystemExit("STOP: these ids are in two sets: %s. Tell Claude." % ", ".join(both))
    put(real_src, common.path(DEV2_CASES_FILE))
    miss_dev2 = copy_data(src, dev2_ids, "development (47)")

    print("\nFiles: %d copied, %d updated, %d already here." % (STATS["copied"], STATS["updated"], STATS["kept"]))
    if answers:
        rows = [[lab, "%d / %d" % (n, len(gen_ids))] for lab, n in sorted(answers.items())]
        print(common.format_table(["whole-table answers (reference rows)", "generated tables"], rows))
    missing = miss_gen + miss_dev + miss_dev2
    if missing:
        print("STOP: %d table(s) have no data in RUN2_FOLDER (listed above). Tell Claude." % len(missing))
        return
    print("Tables here: %d generated, %d development (27), %d development (47). Next: t1_get_data.py"
          % (len(gen_ids), len(dev_ids), len(dev2_ids)))


if __name__ == "__main__":
    main()
