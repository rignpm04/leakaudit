# train4_compare.py -- the before/after comparison for fine-tune run 2. Python 3.9; press Run in PyCharm. No calls.
#
# Reads every cached answer in llm_cache/ -- the RunPod answers (gpu-qwen3.5-9b untrained, gpu-leakaudit2-... trained,
# stored by eval2_import_gpu.py), and for reference run 1's RunPod models (run1-gpu-..., generated tables only),
# local-..., deepseek, claude, gpt, open-... -- keeps only answers to today's exact prompt, and scores the LLM's own
# ratings -- no column check, no data checks -- on four groups:
#   training domains   the 20 generated test tables (+4 clean) of the 4 domains the model was trained on; it never saw
#                      these tables, but it saw many others from the same generator and domains
#   held-out domains   the generated test tables of the 2 domains it never saw at all (lending, hospital)
#   trap tables        the 6 trap tables: legitimate columns built to look late
#   public datasets    leak real test 2's 47 new real datasets (35 with documented leaks, 12 clean), none of them
#                      seen in training; debatable columns (probable_leak_columns) count neither way
# Two settings:
#   within budget  each model at its best risk threshold with at most 1 false flag per table, per group -- the rule
#                  every method followed in the earlier tests; a model is not punished for an odd risk scale alone
#   fixed          a column is flagged at risk >= 50, for every model and group (nothing tuned; shown for reference)
# A table a model has no answer for counts as nothing flagged (as in step 6); the "answered" note shows coverage.
#
# VERDICT (rule fixed before the run), within budget: a trained model PASSES if its macro recall beats the untrained
# model's by at least MIN_GAIN on BOTH the held-out domains and the public datasets. PARTIAL: it does so on the
# held-out domains only (it learned this generator's tables, not real ones). FAIL: anything else.
# Output: results_training.txt (also printed).

TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]
HOLDOUT_DOMAINS = ["lending", "hospital"]
BASE_LABEL = "gpu-qwen3.5-9b"      # the untrained model (RunPod, thinking off); trained models show their change to it
TRAINED_PREFIX = "gpu-leakaudit"    # trained models (RunPod answers); only these get a verdict
FIXED_T = 50
BUDGET_PER_TABLE = 1.0
MIN_GAIN = 0.10
OUT_FILE = "results_training_run2.txt"

# ============================================================ internals
import os
import sys
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402

REAL_CASES_FILE = "cases_real.json"
GRID = [float(t) for t in range(0, 101, 5)]
LINES: List[str] = []


def out(s: str = "") -> None:
    print(s)
    LINES.append(s)


def load_groups() -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, Dict[str, Any]]]:
    gen = common.load_cases(quiet=True)
    real = common.load_cases(quiet=True, file=REAL_CASES_FILE) if os.path.exists(common.path(REAL_CASES_FILE)) else []
    groups: Dict[str, List[Dict[str, Any]]] = {"training domains": [], "held-out domains": [], "trap tables": [],
                                               "public datasets": []}
    for c in gen:
        if c.get("trap_columns"):
            groups["trap tables"].append(c)
        elif c.get("domain") in TRAIN_DOMAINS:
            groups["training domains"].append(c)
        elif c.get("domain") in HOLDOUT_DOMAINS:
            groups["held-out domains"].append(c)
    groups["public datasets"] = list(real)
    info = {}
    for g, cases in groups.items():
        keep = []
        for c in cases:
            if not common.has_data(c["id"]):
                print("  %s: no data here -- left out (run eval0_import.py)" % c["id"])
                continue
            i = s3.prepare_case(c)
            info[c["id"]] = {"case": c, "columns": i["columns"],
                             "prompt": s3.condition_prompt(i, "real", None, None)["user"]}
            keep.append(c)
        groups[g] = keep
    return groups, info


def load_answers(info: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, Dict[str, Dict[str, float]]], Dict[str, int]]:
    """{label: {case id: {column: risk}}} for answers whose prompt hash matches today's prompt."""
    answers: Dict[str, Dict[str, Dict[str, float]]] = {}
    stale: Dict[str, int] = {}
    root = common.path("llm_cache")
    for lab in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        if lab.startswith("mock-") or not os.path.isdir(os.path.join(root, lab, "real")):
            continue
        for cid, x in info.items():
            rec = common.load_json(os.path.join(root, lab, "real", cid + ".json"))
            if not (isinstance(rec, dict) and rec.get("parsed")):
                continue
            if rec.get("prompt_hash") != common.text_hash(str(rec.get("model_id")), s3.SYSTEM_PROMPT, x["prompt"]):
                stale[lab] = stale.get(lab, 0) + 1
                continue
            cols = rec["parsed"].get("columns") or {}
            answers.setdefault(lab, {})[cid] = {c: as_risk((cols.get(c) or {}).get("leak_risk")) for c in x["columns"]}
    return answers, stale


def as_risk(v: Any) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return float("nan")
    return x if np.isfinite(x) else float("nan")


def score(cases: List[Dict[str, Any]], info: Dict[str, Dict[str, Any]], risks: Dict[str, Dict[str, float]],
          t: float) -> Dict[str, Any]:
    recalls, ff, trap_hit, trap_n, leaks_hit, leaks_n = [], 0, 0, 0, 0, 0
    for c in cases:
        r = risks.get(c["id"], {})
        leaks = set(c.get("leak_columns") or [])
        skip = set(c.get("probable_leak_columns") or [])
        traps = set((c.get("trap_columns") or {}).keys())
        hit = 0
        for col in info[c["id"]]["columns"]:
            v = r.get(col, float("nan"))
            flagged = bool(np.isfinite(v) and v >= t - 1e-9)
            if col in leaks:
                hit += flagged
            elif col in skip:
                continue
            else:
                ff += flagged
                if col in traps:
                    trap_hit += flagged
                    trap_n += 1
        present = [x for x in leaks if x in info[c["id"]]["columns"]]
        if present:
            recalls.append(hit / float(len(present)))
            leaks_hit += hit
            leaks_n += len(present)
    return {"macro": float(np.mean(recalls)) if recalls else float("nan"), "ff": ff, "trap_hit": trap_hit,
            "trap_n": trap_n, "leaks_hit": leaks_hit, "leaks_n": leaks_n}


def tuned(cases: List[Dict[str, Any]], info: Dict[str, Dict[str, Any]], risks: Dict[str, Dict[str, float]]
          ) -> Tuple[Optional[float], Dict[str, Any]]:
    budget = BUDGET_PER_TABLE * len(cases)
    best: Optional[Tuple[Tuple[float, float], float, Dict[str, Any]]] = None
    for t in GRID:
        s = score(cases, info, risks, t)
        if s["ff"] <= budget + 1e-9 and np.isfinite(s["macro"]):
            key = (round(s["macro"], 6), -s["ff"])
            if best is None or key > best[0]:
                best = (key, t, s)
    return (best[1], best[2]) if best else (None, score(cases, info, risks, 101.0))


def ceiling(cases: List[Dict[str, Any]]) -> float:
    vals = []
    for c in cases:
        lt = c.get("leak_types") or {}
        n = len(c.get("leak_columns") or [])
        if n:
            vals.append(sum(1 for x in c["leak_columns"] if lt.get(x) != "overwrite_silent") / float(n))
    return float(np.mean(vals)) if vals else float("nan")


def order(labels: List[str]) -> List[str]:
    rank = {"deepseek": 0, "claude": 1, "gpt": 2}
    gpu = sorted([x for x in labels if x.startswith("gpu-")], key=lambda x: (x != BASE_LABEL, x))
    gpu += sorted([x for x in labels if x.startswith("run1-gpu-")])
    loc = sorted([x for x in labels if x.startswith("local-")])
    opn = sorted([x for x in labels if x.startswith("open-")])
    front = sorted([x for x in labels if x in rank], key=lambda x: rank[x])
    rest = sorted([x for x in labels if x not in gpu + loc + opn + front])
    return gpu + loc + opn + front + rest


def main() -> None:
    groups, info = load_groups()
    answers, stale = load_answers(info)
    labels = order(list(answers))
    out("Fine-tune comparison -- the LLM's own ratings, no checks (%s)" % common.stamp())
    out("Groups: " + "; ".join("%s %d tables (%d with leaks)" % (g, len(cs), sum(1 for c in cs if c.get("leak_columns")))
                               for g, cs in groups.items()))
    out("Trained on: %s; held out: %s. Untrained model: %s."
        % (", ".join(TRAIN_DOMAINS), ", ".join(HOLDOUT_DOMAINS), BASE_LABEL))
    if not labels:
        out("\nNo answers found in llm_cache/ -- run eval0_import.py and eval2_import_gpu.py first.")
        return
    gnames = list(groups)

    def has_any(lab: str, g: str) -> bool:
        return any(c["id"] in answers[lab] for c in groups[g])

    def cover(lab: str, g: str) -> str:
        n = sum(1 for c in groups[g] if c["id"] in answers[lab])
        return "" if n == len(groups[g]) else " (%d/%d answered)" % (n, len(groups[g]))

    results: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
    for setting in ("budget", "fixed"):
        out("")
        if setting == "budget":
            out("WITHIN BUDGET: each model at its best threshold with <= %.0f false flag per table, per group (the "
                "verdict uses this)" % BUDGET_PER_TABLE)
        else:
            out("FIXED: a column is flagged at risk >= %d, for every model and group (nothing tuned)" % FIXED_T)
        head = ["model"] + ["%s: macro / false flags" % g if g != "trap tables" else
                            "trap tables: leaks / trap columns / other false flags" for g in gnames]
        rows = []
        for lab in labels:
            row = [lab]
            for g in gnames:
                if not groups[g] or not has_any(lab, g):
                    row.append("-")
                    continue
                if setting == "fixed" or g == "trap tables":
                    t, s = FIXED_T, score(groups[g], info, answers[lab], FIXED_T)
                else:
                    t, s = tuned(groups[g], info, answers[lab])
                results[(setting, lab, g)] = s
                if g == "trap tables":
                    txt = "%d/%d / %d/%d / %d" % (s["leaks_hit"], s["leaks_n"], s["trap_hit"], s["trap_n"],
                                                  s["ff"] - s["trap_hit"])
                else:
                    txt = "%.2f / %d" % (s["macro"], s["ff"])
                    if setting == "budget":
                        txt += " (T %s)" % ("none fits" if t is None else "%.0f" % t)
                    b = results.get((setting, BASE_LABEL, g))
                    if lab.startswith(TRAINED_PREFIX) and b:
                        txt += " %+.2f" % (s["macro"] - b["macro"])
                row.append(txt + cover(lab, g))
            rows.append(row)
        out(common.format_table(head, rows))
    out("(trap tables: always at risk >= %d)" % FIXED_T)
    out("")
    out("Best possible macro recall on the generated groups (everything but the silently overwritten fields, which no "
        "method can see): training domains %.2f, held-out domains %.2f."
        % (ceiling(groups["training domains"]), ceiling(groups["held-out domains"])))

    out("")
    out("HELD-OUT DOMAINS BY NAMING STYLE (fixed setting, macro recall; tables in brackets)")
    styles = ["clear", "abbreviated", "cryptic"]
    rows = []
    for lab in labels:
        row = [lab]
        for st in styles:
            cs = [c for c in groups["held-out domains"] if c.get("naming_style") == st and c.get("leak_columns")]
            ok = cs and any(c["id"] in answers[lab] for c in cs)
            row.append("%.2f (%d)" % (score(cs, info, answers[lab], FIXED_T)["macro"], len(cs)) if ok else "-")
        rows.append(row)
    out(common.format_table(["model"] + styles, rows))

    out("")
    out("PUBLIC DATASETS BY TABLE (fixed setting, flag at risk >= %d): leaks found / leaks, and false flags" % FIXED_T)
    show = [lab for lab in labels if lab == BASE_LABEL or lab.startswith(TRAINED_PREFIX)]
    rows = []
    for c in groups["public datasets"]:
        row = [c["id"], str(len([x for x in (c.get("leak_columns") or []) if x in info[c["id"]]["columns"]]))]
        for lab in show:
            if c["id"] not in answers.get(lab, {}):
                row.append("-")
                continue
            s = score([c], info, answers[lab], FIXED_T)
            row.append("%d / %d" % (s["leaks_hit"], s["ff"]))
        rows.append(row)
    if show:
        out(common.format_table(["table", "leaks"] + ["%s: found / false flags" % lab for lab in show], rows))

    out("")
    out("VERDICT (rule fixed before the run; within budget): PASS = beats %s by >= %.2f macro recall on both the "
        "held-out domains and the public datasets" % (BASE_LABEL, MIN_GAIN))
    need = ["held-out domains", "public datasets"]

    def full(lab: str, g: str) -> bool:
        return bool(groups[g]) and all(c["id"] in answers.get(lab, {}) for c in groups[g])

    trained = [lab for lab in labels if lab.startswith(TRAINED_PREFIX)]
    if not all(full(BASE_LABEL, g) for g in need + ["training domains"]):
        out("  not yet: %s needs answers for every generated and public table (eval2_import_gpu.py)" % BASE_LABEL)
        trained = []
    elif not trained:
        out("  not yet: no trained model's answers (eval2_import_gpu.py)")
    for lab in trained:
        if not all(full(lab, g) for g in need + ["training domains"]):
            out("  %s: not every table answered yet" % lab)
            continue
        ok, parts = {}, []
        for g in need:
            b, t = results[("budget", BASE_LABEL, g)], results[("budget", lab, g)]
            gain = t["macro"] - b["macro"]
            ok[g] = gain >= MIN_GAIN - 1e-9
            parts.append("%s %.2f -> %.2f (%+.2f): %s" % (g, b["macro"], t["macro"], gain, "yes" if ok[g] else "no"))
        verdict = "PASS" if all(ok.values()) else ("PARTIAL (held-out domains only)" if ok[need[0]] else "FAIL")
        out("  %s: %s" % (lab, "; ".join(parts)))
        out("  -> %s: %s" % (lab, verdict))
    out("")
    held = {lab: (sum(1 for g in gnames for c in groups[g] if c["id"] in answers[lab]),
                  sum(len(groups[g]) for g in gnames)) for lab in labels}
    out("Answers used: " + "; ".join("%s %d/%d" % (lab, a, b) for lab, (a, b) in held.items()))
    if stale:
        out("Left out because the prompt no longer matches (data or prompt changed): " +
            "; ".join("%s %d" % kv for kv in stale.items()))
    with open(common.path(OUT_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(LINES) + "\n")
    print("\n-> %s. Send it to Claude, with train_run2.json." % OUT_FILE)


if __name__ == "__main__":
    main()
