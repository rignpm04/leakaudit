# eval0_import.py -- brings what fine-tune run 2 needs into this folder from two earlier folders. Python 3.9; press Run
# in PyCharm. No keys, no calls. Running it again later is safe (it only adds what is new), e.g. after you run step 3
# in leak real test 2.
#
# From RUN1_FOLDER (your "leak training" folder from run 1):
#   cases.json and data/ for the 42 generated test tables (byte for byte the tables every model saw), and every cached
#   answer for them in llm_cache/ -- DeepSeek, Claude, GPT, the open and local models', and run 1's two RunPod models,
#   which are renamed here run1-gpu-... so they never mix with run 2's answers;
#   cases_real.json (saved here as cases_dev.json) and data/ for the first test's 27 public datasets: in run 2 they
#   are development data, used for training, never for testing.
# From REAL_TEST_FOLDER (your "leak real test 2" folder): cases.json (saved here as cases_real.json) and data/ for the
#   47 new public datasets, the test; and the frontier models' cached answers for them, if you have run its step 3.
# Nothing in those folders is changed. A file already here is kept, unless the one there is newer and different.
#
# Paths: in PyCharm, right-click the folder > Copy Path/Reference > Absolute Path, and paste it between the quotes.

RUN1_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/new fresh leak folder"
REAL_TEST_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leak real test 2"

# ============================================================ internals
import filecmp
import json
import os
import shutil
import sys
from typing import Any, Dict, List, Optional, Set

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402

DEV_CASES_FILE = "cases_dev.json"
REAL_CASES_FILE = "cases_real.json"
RUN1_RENAME = {"gpu-qwen3.5-9b": "run1-gpu-qwen3.5-9b", "gpu-leakaudit-qwen3.5-9b": "run1-gpu-leakaudit-qwen3.5-9b"}
STATS: Dict[str, int] = {"copied": 0, "updated": 0, "kept": 0}


def folder(p: str, name: str) -> str:
    p = os.path.expanduser(str(p or "").strip().strip("'\""))
    if not p or p.startswith("PASTE_"):
        raise SystemExit("Paste the full path of your %s folder at the top of eval0_import.py (%s)."
                         % ("leak training (run 1)" if name == "RUN1_FOLDER" else "leak real test 2", name))
    p = os.path.normpath(p)
    if not os.path.isdir(p):
        raise SystemExit("%s does not exist: %s" % (name, p))
    if os.path.samefile(p, HERE):
        raise SystemExit("%s points at this folder -- it must be your earlier folder." % name)
    return p


def put(src: str, dst: str) -> None:
    """Copy src to dst unless dst exists; replace dst only if src is newer and different."""
    if os.path.exists(dst):
        if filecmp.cmp(src, dst, shallow=False) or os.path.getmtime(src) <= os.path.getmtime(dst):
            STATS["kept"] += 1
            return
        STATS["updated"] += 1
    else:
        STATS["copied"] += 1
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def read_cases(p: str) -> List[Dict[str, Any]]:
    if not os.path.exists(p):
        raise SystemExit("Not found: %s" % p)
    with open(p, encoding="utf-8-sig") as f:
        raw = json.load(f)
    return raw.get("cases", []) if isinstance(raw, dict) else raw


def copy_data(src_dir: str, ids: List[str], what: str) -> List[str]:
    missing = []
    for cid in ids:
        f = os.path.join(src_dir, "data", cid + ".csv.gz")
        if not os.path.exists(f):
            missing.append(cid)
            continue
        put(f, common.data_file(cid))
        m = os.path.join(src_dir, "data", cid + ".meta.json")
        if os.path.exists(m):
            put(m, common.meta_file(cid))
    if missing:
        print("  %s: no data for %d table(s): %s" % (what, len(missing), ", ".join(missing)))
    return missing


def copy_answers(src_dir: str, ids: Set[str], rename: Optional[Dict[str, str]] = None) -> Dict[str, int]:
    """Cached 'real' answers for these tables, for every model label (renamed where rename says so)."""
    got: Dict[str, int] = {}
    root = os.path.join(src_dir, "llm_cache")
    if not os.path.isdir(root):
        return got
    for lab in sorted(os.listdir(root)):
        d = os.path.join(root, lab, "real")
        if lab.startswith("mock-") or not os.path.isdir(d):
            continue
        dest_lab = (rename or {}).get(lab, lab)
        for fn in sorted(os.listdir(d)):
            cid = fn[:-5] if fn.endswith(".json") else None
            if cid not in ids:
                continue
            put(os.path.join(d, fn), common.path("llm_cache", dest_lab, "real", fn))
            got[dest_lab] = got.get(dest_lab, 0) + 1
    return got


def main() -> None:
    run1 = folder(RUN1_FOLDER, "RUN1_FOLDER")
    real_dir = folder(REAL_TEST_FOLDER, "REAL_TEST_FOLDER")

    print("\n1. Generated test tables, from %s" % run1)
    gen = [c for c in read_cases(os.path.join(run1, "cases.json")) if c.get("url") == "generated"]
    if len(gen) != 42:
        print("  note: found %d generated tables in its cases.json (expected 42)" % len(gen))
    put(os.path.join(run1, "cases.json"), common.path("cases.json"))
    if os.path.exists(os.path.join(run1, "generated_checksums.txt")):
        put(os.path.join(run1, "generated_checksums.txt"), common.path("generated_checksums.txt"))
    gen_ids = [c["id"] for c in gen]
    copy_data(run1, gen_ids, "generated")
    answers = copy_answers(run1, set(gen_ids), rename=RUN1_RENAME)

    print("2. Development tables (the first test's 27 public datasets), from %s" % run1)
    dc = os.path.join(run1, REAL_CASES_FILE)
    dev = read_cases(dc)
    put(dc, common.path(DEV_CASES_FILE))
    dev_ids = [c["id"] for c in dev]
    copy_data(run1, dev_ids, "development tables")

    print("3. Test datasets (the 47 new public datasets), from %s" % real_dir)
    if not os.path.exists(os.path.join(real_dir, "task_text_changes.json")):
        raise SystemExit("STOP: %s still has the first version of the task sentences (they gave answers away). Copy "
                         "the files from leak_real_test_2_update.zip into it first, then run this again." % real_dir)
    rc = os.path.join(real_dir, "cases.json")
    real = read_cases(rc)
    real_ids = [c["id"] for c in real]
    both = sorted(set(real_ids) & set(dev_ids))
    if both:
        raise SystemExit("STOP: these tables are in both the development and the test set: %s" % ", ".join(both))
    put(rc, common.path(REAL_CASES_FILE))
    missing = copy_data(real_dir, real_ids, "test datasets")
    if missing:
        print("  -> run step1_get_data.py in %s first (it must print '47 of 47 cases ready')" % real_dir)
    real_answers = copy_answers(real_dir, set(real_ids))

    print("\nFiles: %d copied, %d updated, %d already here." % (STATS["copied"], STATS["updated"], STATS["kept"]))
    have = {}
    root = common.path("llm_cache")
    for lab in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        d = os.path.join(root, lab, "real")
        if os.path.isdir(d) and not lab.startswith("mock-"):
            names = {fn[:-5] for fn in os.listdir(d) if fn.endswith(".json")}
            have[lab] = (len(names & set(gen_ids)), len(names & set(real_ids)))
    rows = [[lab, "%d / %d" % (g, len(gen_ids)), "%d / %d" % (r, len(real_ids))] for lab, (g, r) in have.items()]
    if rows:
        print(common.format_table(["answers held here", "generated tables", "new public datasets"], rows))
    if not real_answers:
        print("No frontier answers for the 47 new datasets yet. Optional: run step 3 in leak real test 2 (about $5), "
              "then run this again.")
    print("Tables here: %d generated, %d development, %d test datasets. Next: train1_make_data.py (GUIDE.md, part A)."
          % (len(gen_ids), len(dev_ids), len(real_ids)))
    del answers


if __name__ == "__main__":
    main()
