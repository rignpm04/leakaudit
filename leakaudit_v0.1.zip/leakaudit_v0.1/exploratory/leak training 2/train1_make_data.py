# train1_make_data.py -- makes the training file for fine-tune run 2. Python 3.9; press Run in PyCharm. No keys, no
# downloads. Needs step1_generate.py, step3_llm_audit.py, common.py, and what eval0_import.py brought in (cases.json,
# cases_dev.json, cases_real.json and data/).
#
# Two kinds of training example, each one table, in the exact prompt step 3 sends (same summaries, same wording, same
# instruction), answered with the correct rating of every column in the json form step 3 asks for -- the answer only,
# no reasoning note (run 1's note became a template the model filled in instead of reasoning):
#   1. Generated tables (2,000), from the same generator as the test, for the TRAIN_DOMAINS only and under new table
#      ids (new random draws), built with the generator's run 2 options (step1_generate.py, v2=True): wider name pools
#      (some names without the usual cue words), decoys that use leak words but are known at the moment, and four new
#      leak types (parts of the target, measurements taken during or after the event, codes assigned during the
#      process, follow-up times). None of the 42 test tables is ever produced; the held-out domains are never used.
#   2. Development tables: the first test's 27 public datasets (cases_dev.json), now training data because run 1's
#      mistakes on them were studied. Each goes in DEV_VARIANTS times: once as is, then with the columns shuffled and a
#      random share of the rows (so the summaries and example values change). The 47 new public datasets
#      (cases_real.json) are the test and are never used here.
# Output: train.jsonl and val.jsonl (one example per line, chat format) and train_manifest.json (what is in them).
#
# How the answer key becomes ratings (the same plain reasons for every table):
#   leaks                    risk 95; category: recorded after the moment -> post_outcome; totals that build after it
#                            -> future_aggregate; computed from or part of the outcome -> target_derived; row ids ->
#                            identifier (the development tables' categories are set by hand, in DEV_CATEGORY)
#   debatable columns        risk 50 (development tables only: probable_leak_columns)
#   everything else          risk 5, fine -- decoys, trap columns and silently overwritten fields included (nothing
#                            in the table shows an overwrite, so a "leak" label would only teach names)

import csv
import gzip
import hashlib
import io
import json
import os
import sys
import time
import zlib
from typing import Any, Dict, List, Tuple

# ============================================================ settings (edit here)
TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]   # tables are generated for these domains only
HOLDOUT_DOMAINS = ["lending", "hospital"]                   # never used here: the test of whether training carries over
TABLES_PER_DOMAIN = 500       # 4 x 500 = 2,000 generated examples
TRAP_SHARE = 0.15             # share of generated tables built as trap tables (legitimate columns that look late)
VAL_SHARE = 0.05              # share of generated tables kept apart for the validation loss
DEV_VARIANTS = 8              # each development table goes in this many times (27 x 8 = 216 examples)
DEV_ROW_SHARE = (0.60, 0.95)  # variants after the first keep this share of the rows (drawn per variant)
SEED = 20261020               # picks each table's kind and the development variants; tables' own draws come from ids

TRAIN_FILE = "train.jsonl"
VAL_FILE = "val.jsonl"
MANIFEST_FILE = "train_manifest.json"
DEV_CASES_FILE = "cases_dev.json"
REAL_CASES_FILE = "cases_real.json"

# Development tables: the category of each leak (risk 95) and debatable column (risk 50). Any column not listed here
# that the case marks as a leak or debatable gets post_outcome.
DEV_CATEGORY: Dict[str, Dict[str, str]] = {
    "bank_marketing": {"duration": "post_outcome"},
    "titanic3": {"boat": "post_outcome", "body": "post_outcome"},
    "hotel_bookings": {"reservation_status": "post_outcome", "reservation_status_date": "post_outcome",
                       "assigned_room_type": "post_outcome", "booking_changes": "future_aggregate",
                       "country": "post_outcome", "required_car_parking_spaces": "post_outcome",
                       "adr": "post_outcome"},
    "lending_club": {"total_pymnt": "future_aggregate", "total_pymnt_inv": "future_aggregate",
                     "total_rec_prncp": "future_aggregate", "total_rec_int": "future_aggregate",
                     "total_rec_late_fee": "future_aggregate", "recoveries": "post_outcome",
                     "collection_recovery_fee": "post_outcome", "last_pymnt_d": "post_outcome",
                     "last_pymnt_amnt": "post_outcome", "last_credit_pull_d": "post_outcome",
                     "funded_amnt": "post_outcome", "funded_amnt_inv": "post_outcome", "issue_d": "post_outcome",
                     "pymnt_plan": "post_outcome", "out_prncp": "post_outcome", "out_prncp_inv": "post_outcome",
                     "next_pymnt_d": "post_outcome", "hardship_flag": "post_outcome"},
    "bike_sharing_hour": {"casual": "target_derived", "registered": "target_derived"},
    "heart_failure": {"time": "post_outcome"},
    "telco_churn_ibm": {"Churn Label": "target_derived", "Churn Reason": "post_outcome",
                        "Churn Score": "post_outcome", "CLTV": "post_outcome", "Tenure Months": "post_outcome",
                        "Total Charges": "future_aggregate"},
    "compas_two_years": {"is_recid": "target_derived", "event": "target_derived", "end": "post_outcome",
                         "violent_recid": "post_outcome", "in_custody": "post_outcome", "out_custody": "post_outcome",
                         "start": "post_outcome"},
    "diabetes_130": {"discharge_disposition_id": "post_outcome", "patient_nbr": "identifier"},
    "vgsales": {"NA_Sales": "target_derived", "EU_Sales": "target_derived", "JP_Sales": "target_derived",
                "Other_Sales": "target_derived", "Rank": "target_derived"},
    "police_stops_ri": {"stop_outcome": "target_derived", "stop_duration": "post_outcome",
                        "search_conducted": "post_outcome", "search_type": "post_outcome",
                        "drugs_related_stop": "post_outcome"},
    "rossmann": {"Customers": "post_outcome"},
    "nycflights13": {"arr_time": "post_outcome", "dep_time": "post_outcome", "dep_delay": "target_derived",
                     "air_time": "post_outcome"},
    "brazilian_houses": {"hoa (R$)": "target_derived", "rent amount (R$)": "target_derived",
                         "property tax (R$)": "target_derived", "fire insurance (R$)": "target_derived"},
    "energy_efficiency": {"Cooling Load": "post_outcome"},
    "parkinsons_telemonitoring": {"motor_UPDRS": "target_derived", "test_time": "post_outcome",
                                  "subject#": "identifier"},
    "cardiotocography": {c: "target_derived" for c in ("CLASS", "A", "B", "C", "D", "E", "AD", "DE", "LD", "FS",
                                                       "SUSP", "LBE")},
    "clean_pima": {"Glucose": "target_derived"},
}

# ============================================================ internals
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_generate as s1  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

CATEGORY = {"outcome_status": "post_outcome", "post_event_date": "post_outcome", "snapshot_state": "post_outcome",
            "outcome_only_sparse": "post_outcome", "post_aggregate": "future_aggregate",
            "target_derived": "target_derived", "identifier": "identifier",
            "target_part": "target_derived", "event_measure": "post_outcome", "assigned_during": "post_outcome",
            "followup_time": "post_outcome"}
REASON = {"post_outcome": "Recorded after the prediction moment.",
          "target_derived": "Part of or computed from the outcome.",
          "future_aggregate": "Accumulates after the prediction moment.",
          "identifier": "Row identifier; repeats let a model memorize outcomes.",
          "fine": "Known at the prediction moment.",
          "debatable": "Unclear whether it is known at the prediction moment."}
RISK_LEAK, RISK_DEBATABLE, RISK_FINE = 95, 50, 5
TRAIN_CHARS_PER_TOKEN = 2.65   # Qwen3.5's real ratio on run 1's training texts (5.24 million tokens counted on the GPU)


def csv_text(header: List[str], rows: List[List[str]]) -> str:
    """The table exactly as step 1's write_table stores it."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def summaries_of(case_id: str, df: pd.DataFrame, cols: List[str]) -> Dict[str, Any]:
    """What step 3's prepare_case computes for these columns of df (same seed rule, keyed by case_id)."""
    rng = np.random.RandomState((s3.SEED * 1000003 + zlib.crc32(case_id.encode("utf-8"))) % (2 ** 32))
    return {c: common.column_summary(df[c], s3.N_EXAMPLES, rng) for c in cols}


def info_from_df(case: Dict[str, Any], key: str, df: pd.DataFrame, cols: List[str]) -> Dict[str, Any]:
    return {"case": case, "id": key, "task": case["task"], "columns": cols, "summaries": summaries_of(key, df, cols),
            "n_rows": len(df), "real_text": {k: case.get(k) or "" for k in s3.TEXT_KEYS}}


def info_from_text(case: Dict[str, Any], text: str) -> Dict[str, Any]:
    """What step 3's prepare_case builds, from the CSV text instead of data/<id>.csv.gz (same parse, same seed)."""
    df = pd.read_csv(io.StringIO(text), low_memory=False)
    cols = [c for c in df.columns if c != common.TARGET]
    return info_from_df(case, case["id"], df, cols)


def rate_generated(case: Dict[str, Any], col: str) -> Tuple[int, str]:
    ltype = (case.get("leak_types") or {}).get(col)
    if ltype and ltype in CATEGORY:
        return RISK_LEAK, CATEGORY[ltype]
    return RISK_FINE, "fine"   # decoys, traps, the moment column, strong predictors, silently overwritten fields


def rate_dev(case: Dict[str, Any], col: str) -> Tuple[int, str, str]:
    cats = DEV_CATEGORY.get(case["id"], {})
    if col in (case.get("leak_columns") or []):
        cat = cats.get(col, "post_outcome")
        return RISK_LEAK, cat, REASON[cat]
    if col in (case.get("probable_leak_columns") or []):
        return RISK_DEBATABLE, cats.get(col, "post_outcome"), REASON["debatable"]
    return RISK_FINE, "fine", REASON["fine"]


def answer(entries: List[Tuple[str, int, str, str]]) -> str:
    cols = [{"column": c, "leak_risk": risk, "category": cat, "reason": why} for c, risk, cat, why in entries]
    return json.dumps({"dataset_guess": None, "columns": cols}, ensure_ascii=False)


def example(key: str, meta: Dict[str, Any], info: Dict[str, Any], entries: List[Tuple[str, int, str, str]]
            ) -> Dict[str, Any]:
    p = s3.condition_prompt(info, "real", None, None)
    return dict(meta, id=key, messages=[{"role": "system", "content": s3.SYSTEM_PROMPT},
                                        {"role": "user", "content": p["user"]},
                                        {"role": "assistant", "content": answer(entries)}])


def generated_example(case: Dict[str, Any], info: Dict[str, Any]) -> Dict[str, Any]:
    entries = []
    for c in info["columns"]:
        risk, cat = rate_generated(case, c)
        entries.append((c, risk, cat, REASON[cat]))
    meta = {"source": "generated", "domain": case["domain"], "style": case["naming_style"], "kind": case["kind"],
            "trap_table": bool(case.get("trap_columns"))}
    return example(case["id"], meta, info, entries)


def dev_variants(case: Dict[str, Any], df: pd.DataFrame, rng: np.random.RandomState
                 ) -> List[Tuple[str, Dict[str, Any]]]:
    """DEV_VARIANTS (key, info) pairs: the table as is (key = its id, so its prompt is exactly step 3's), then
    shuffled columns on a random share of the rows (kept in their original order)."""
    cols = [c for c in df.columns if c != common.TARGET]
    out = [(case["id"], info_from_df(case, case["id"], df, cols))]
    for v in range(2, DEV_VARIANTS + 1):
        key = "%s__v%d" % (case["id"], v)
        share = float(rng.uniform(*DEV_ROW_SHARE))
        rows = np.sort(rng.choice(len(df), size=max(30, int(round(share * len(df)))), replace=False))
        order = [cols[i] for i in rng.permutation(len(cols))]
        sub = df.iloc[rows].reset_index(drop=True)
        out.append((key, info_from_df(case, key, sub, order)))
    return out


def file_sha256(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def csv_sha256(case_id: str) -> str:
    with gzip.open(common.data_file(case_id), "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def test_table_hashes() -> Dict[str, str]:
    """sha256 of the CSV text of every generated test table in data/ (cases.json), to prove none is reproduced."""
    return {csv_sha256(c["id"]): c["id"] for c in common.load_cases(quiet=True) if common.has_data(c["id"])}


def generator_check() -> str:
    """Rebuilds all 42 generated test tables with this folder's generator (run 1 settings) and compares them with
    data/ byte for byte: the run 2 options must not have changed a single test table."""
    cases = [c for c in common.load_cases(quiet=True) if c.get("url") == "generated"]
    bad = []
    for c in cases:
        dom, tid = c["domain"], c["id"]
        traps = tid.startswith("traps_")
        k = 0 if traps else int(tid.rsplit("_", 1)[1])
        case, rows, header = s1.build(tid, dom, k, traps)
        h = hashlib.sha256(csv_text(header, rows).encode("utf-8")).hexdigest()
        if not common.has_data(tid) or h != csv_sha256(tid):
            bad.append(tid)
    if bad:
        raise SystemExit("STOP: the generator no longer rebuilds %d test table(s) exactly: %s. Tell Claude."
                         % (len(bad), ", ".join(bad)))
    return "ok (all %d generated test tables rebuild byte for byte)" % len(cases)


def same_prompt_check() -> str:
    """One generated test table built in memory, the way training tables are built, must give exactly the prompt step
    3 builds from data/; and one development table's first variant must give exactly step 3's prompt for it."""
    cases = {c["id"]: c for c in common.load_cases(quiet=True)}
    done = []
    for cid, dom, k in (("claims_01", "claims", 1), ("orders_03", "orders", 3)):
        case, rows, header = s1.build(cid, dom, k)
        mine = s3.condition_prompt(info_from_text(case, csv_text(header, rows)), "real", None, None)["user"]
        theirs = s3.condition_prompt(s3.prepare_case(cases[cid]), "real", None, None)["user"]
        if mine != theirs:
            raise SystemExit("STOP: the prompt built here for %s differs from step 3's. Tell Claude." % cid)
        done.append(cid)
    dev = common.load_cases(quiet=True, file=DEV_CASES_FILE)
    for case in dev[:2]:
        df = common.read_data(case["id"])
        key, info = dev_variants(case, df, np.random.RandomState(0))[0]
        mine = s3.condition_prompt(info, "real", None, None)["user"]
        theirs = s3.condition_prompt(s3.prepare_case(case), "real", None, None)["user"]
        if mine != theirs:
            raise SystemExit("STOP: the prompt built here for %s differs from step 3's. Tell Claude." % case["id"])
        done.append(case["id"])
    return "ok (%s: the prompts built here are identical to step 3's)" % ", ".join(done)


def check_inputs() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    for f in (common.CASES_FILE, DEV_CASES_FILE, REAL_CASES_FILE):
        if not os.path.exists(common.path(f)):
            raise SystemExit("%s is missing: run eval0_import.py first." % f)
    gen = common.load_cases(quiet=True)
    dev = common.load_cases(quiet=True, file=DEV_CASES_FILE)
    real = common.load_cases(quiet=True, file=REAL_CASES_FILE)
    missing = [c["id"] for c in gen + dev + real if not common.has_data(c["id"])]
    if missing:
        raise SystemExit("No data for %d table(s): %s -- run eval0_import.py first." % (len(missing), ", ".join(missing)))
    ids_gen, ids_dev, ids_real = {c["id"] for c in gen}, {c["id"] for c in dev}, {c["id"] for c in real}
    overlap = (ids_dev & ids_real) | (ids_dev & ids_gen)
    if overlap:
        raise SystemExit("STOP: development tables also appear in the test: %s. Tell Claude." % ", ".join(sorted(overlap)))
    dev_hash = {csv_sha256(c["id"]): c["id"] for c in dev}
    same = [(dev_hash[csv_sha256(c["id"])], c["id"]) for c in real if csv_sha256(c["id"]) in dev_hash]
    if same:
        raise SystemExit("STOP: a development table is the same file as a test table: %s. Tell Claude." % same)
    for c in real:   # a test table with nearly the same columns as a development table would not be a fair test
        cols = set(common.read_meta(c["id"]).get("columns") or {})
        for d in dev:
            dcols = set(common.read_meta(d["id"]).get("columns") or {})
            if cols and dcols and len(cols & dcols) / float(len(cols | dcols)) > 0.8:
                raise SystemExit("STOP: test table %s has nearly the same columns as development table %s. Tell "
                                 "Claude." % (c["id"], d["id"]))
    unknown = [cid for cid in DEV_CATEGORY if cid not in ids_dev]
    if unknown:
        print("  note: DEV_CATEGORY names tables that are not in %s: %s" % (DEV_CASES_FILE, ", ".join(unknown)))
    return dev, real


def main() -> None:
    t0 = time.time()
    bad = [d for d in TRAIN_DOMAINS if d not in s1.DOMAINS] + [d for d in TRAIN_DOMAINS if d in HOLDOUT_DOMAINS]
    if bad:
        raise SystemExit("Fix TRAIN_DOMAINS / HOLDOUT_DOMAINS: %s" % bad)
    dev, real = check_inputs()
    print("Training data for fine-tune run 2: %d generated tables (%s; held out: %s) and %d development tables x %d"
          % (len(TRAIN_DOMAINS) * TABLES_PER_DOMAIN, ", ".join(TRAIN_DOMAINS), ", ".join(HOLDOUT_DOMAINS), len(dev),
             DEV_VARIANTS))
    print("Generator check: " + generator_check())
    print("Same-prompt check: " + same_prompt_check())
    test_hashes = test_table_hashes()
    rng = np.random.RandomState(SEED)
    plan = []
    for dom in TRAIN_DOMAINS:
        for i in range(TABLES_PER_DOMAIN):
            traps = bool(rng.uniform() < TRAP_SHARE)
            k = 0 if traps else int(rng.randint(1, 7))      # 1-2 clear, 3-4 abbreviated, 5 cryptic, 6 clean
            plan.append(("trn2_%s_%04d" % (dom, i + 1), dom, k, traps, bool(rng.uniform() < VAL_SHARE)))
    counts: Dict[str, Any] = {"generated": 0, "development": 0, "train": 0, "val": 0, "by_domain": {}, "by_style": {},
                              "by_kind": {}, "trap_tables": 0, "leaks_by_type": {}, "dev_tables": len(dev),
                              "dev_variants": DEV_VARIANTS, "columns": 0, "chars": 0, "max_chars": 0}
    seen_ids = set()

    def count_chars(ex: Dict[str, Any]) -> None:
        n = sum(len(m["content"]) for m in ex["messages"])
        counts["chars"] += n
        counts["max_chars"] = max(counts["max_chars"], n)

    with open(common.path(TRAIN_FILE), "w", encoding="utf-8") as ftr, \
            open(common.path(VAL_FILE), "w", encoding="utf-8") as fva:
        for n, (tid, dom, k, traps, val) in enumerate(plan, 1):
            case, rows, header = s1.build(tid, dom, k, traps, v2=True)
            text = csv_text(header, rows)
            h = hashlib.sha256(text.encode("utf-8")).hexdigest()
            if h in test_hashes:
                raise SystemExit("STOP: %s reproduces test table %s. Tell Claude." % (tid, test_hashes[h]))
            if tid in seen_ids:
                raise SystemExit("STOP: duplicate training id %s" % tid)
            seen_ids.add(tid)
            ex = generated_example(case, info_from_text(case, text))
            (fva if val else ftr).write(json.dumps(ex, ensure_ascii=False) + "\n")
            counts["generated"] += 1
            counts["val" if val else "train"] += 1
            counts["by_domain"][dom] = counts["by_domain"].get(dom, 0) + 1
            counts["by_style"][case["naming_style"]] = counts["by_style"].get(case["naming_style"], 0) + 1
            counts["by_kind"][case["kind"]] = counts["by_kind"].get(case["kind"], 0) + 1
            counts["trap_tables"] += int(traps)
            for t in (case.get("leak_types") or {}).values():
                counts["leaks_by_type"][t] = counts["leaks_by_type"].get(t, 0) + 1
            counts["columns"] += len(header) - 1
            count_chars(ex)
            if n % 250 == 0 or n == len(plan):
                el = time.time() - t0
                print("  %4d / %d generated tables  (%.0f s, about %.0f s left)"
                      % (n, len(plan), el, el / n * (len(plan) - n)))
        for case in dev:
            df = common.read_data(case["id"])
            for key, info in dev_variants(case, df, rng):
                entries = [(c,) + rate_dev(case, c) for c in info["columns"]]
                meta = {"source": "development", "domain": "public", "style": "real", "kind": case["kind"],
                        "trap_table": False}
                ex = example(key, meta, info, entries)
                ftr.write(json.dumps(ex, ensure_ascii=False) + "\n")
                counts["development"] += 1
                counts["train"] += 1
                counts["columns"] += len(info["columns"])
                count_chars(ex)
        print("  %d development examples (%d tables x %d)" % (counts["development"], len(dev), DEV_VARIANTS))
    est_tokens = counts["chars"] / TRAIN_CHARS_PER_TOKEN
    manifest = dict(counts, settings={"train_domains": TRAIN_DOMAINS, "holdout_domains": HOLDOUT_DOMAINS,
                                      "tables_per_domain": TABLES_PER_DOMAIN, "trap_share": TRAP_SHARE,
                                      "val_share": VAL_SHARE, "dev_variants": DEV_VARIANTS,
                                      "dev_row_share": list(DEV_ROW_SHARE), "seed": SEED,
                                      "generator_seed": s1.SEED, "generator_options": "v2"},
                    est_tokens=int(est_tokens), created=common.stamp(),
                    dev_tables=[c["id"] for c in dev], test_real_tables=[c["id"] for c in real],
                    files={TRAIN_FILE: file_sha256(common.path(TRAIN_FILE)),
                           VAL_FILE: file_sha256(common.path(VAL_FILE))})
    common.write_json(common.path(MANIFEST_FILE), manifest)
    print("\n%d examples -> %s (%d) and %s (%d); %d columns rated"
          % (counts["generated"] + counts["development"], TRAIN_FILE, counts["train"], VAL_FILE, counts["val"],
             counts["columns"]))
    print("Generated: by domain %s; by naming style %s; trap tables %d; clean tables %d"
          % (counts["by_domain"], counts["by_style"], counts["trap_tables"], counts["by_kind"].get("clean", 0)))
    print("Leak columns by type: %s" % dict(sorted(counts["leaks_by_type"].items())))
    print("About %.1f million tokens per pass; longest example about %d tokens (the notebook allows 8,192 and prints "
          "the exact counts)." % (est_tokens / 1e6, counts["max_chars"] / TRAIN_CHARS_PER_TOKEN))
    print("None of the %d generated test tables was reproduced, and none of the %d test datasets is among the %d "
          "development tables. %.0f s in all." % (len(test_hashes), len(real), len(dev), time.time() - t0))
    print("Next: eval1_make_prompts.py, then RunPod (GUIDE.md, part B).")


if __name__ == "__main__":
    main()
