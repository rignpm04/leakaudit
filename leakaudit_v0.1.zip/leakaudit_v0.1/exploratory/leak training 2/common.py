# common.py -- shared helpers for the leakage-auditor quick test. The step scripts import it from this folder;
# nothing here needs editing. Python 3.9: pandas, numpy and the standard library.

import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request
import warnings
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# ============================================================ settings
CASES_FILE = "cases.json"   # in this folder (an absolute path also works)
TARGET = "target"           # name of the standardized target column in data/<id>.csv.gz
NUMERIC_SHARE = 0.95        # a text column counts as numeric if more than this share of its values converts
DATE_SHARE = 0.90           # ... and as a date if more than this share parses as a date
HTTP_TIMEOUT_S = 300
HTTP_MAX_RETRIES = 5
RETRY_BASE_S = 3.0          # wait 3 s, 6 s, 9 s ... between tries (longer if the server sends retry-after)

HERE = os.path.dirname(os.path.abspath(__file__))
CERT_HINT = ("Python cannot verify HTTPS certificates. On a Mac with the python.org installer, double-click "
             "'Install Certificates.command' in Applications > Python 3.9, then press Run again.")


# ============================================================ paths
def path(*parts: str) -> str:
    return os.path.join(HERE, *parts)


def raw_dir(case_id: str) -> str:
    return path("data", "raw", case_id)


def data_file(case_id: str) -> str:
    return path("data", case_id + ".csv.gz")


def meta_file(case_id: str) -> str:
    return path("data", case_id + ".meta.json")


def has_data(case_id: str) -> bool:
    return os.path.exists(data_file(case_id)) and os.path.exists(meta_file(case_id))


def load_json(p: str) -> Any:
    """The file's JSON, or None if it is missing or unreadable."""
    try:
        with open(p, encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def write_json(p: str, obj: Any) -> None:
    """Writes via a temporary file, so an interrupted run never leaves half a file."""
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False, default=_json_default)
    os.replace(tmp, p)


def _json_default(x: Any) -> Any:
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return None if np.isnan(x) else float(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    return str(x)


# ============================================================ cases.json
CASE_DEFAULTS = {"format": None, "sample_rows": None, "positive_values": None, "unit": "", "prediction_time": "",
                 "target_description": "", "drop_columns": [], "leak_columns": [], "probable_leak_columns": [],
                 "docs": "", "canonical_source": "", "notes": "", "aliases": []}
FORMAT_DEFAULTS = {"sep": ",", "encoding": "utf-8", "compression": None, "zip_member": None}
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")


def load_cases(quiet: bool = False, file: Optional[str] = None) -> List[Dict[str, Any]]:
    """The cases in cases.json (or in file), with defaults filled in. A malformed entry is reported and left out."""
    src = path(file or CASES_FILE)
    try:
        with open(src, encoding="utf-8-sig") as f:
            raw = json.load(f)
    except OSError as e:
        raise SystemExit("Cannot open %s: %s" % (src, e))
    except ValueError as e:
        raise SystemExit("%s is not valid JSON: %s" % (src, e))
    if isinstance(raw, dict):
        raw = raw.get("cases") or []
    cases: List[Dict[str, Any]] = []
    seen = set()
    for i, c in enumerate(raw):
        if not isinstance(c, dict):
            print("  cases.json entry %d is not an object -- left out" % (i + 1))
            continue
        cid = str(c.get("id") or "").strip()
        problems = []
        if not ID_RE.match(cid):
            problems.append("id must be letters, digits, '_', '.' or '-' (got %r)" % cid)
        elif cid in seen:
            problems.append("duplicate id")
        for k in ("url", "target"):
            if not str(c.get(k) or "").strip():
                problems.append("no %s" % k)
        kind = str(c.get("kind") or "").strip().lower()
        task = str(c.get("task") or "").strip().lower()
        if kind not in ("leak", "clean"):
            problems.append("kind must be 'leak' or 'clean'")
        if task not in ("binary", "regression"):
            problems.append("task must be 'binary' or 'regression'")
        if c.get("format") is not None and not isinstance(c.get("format"), dict):
            problems.append("format must be an object")
        if problems:
            print("  cases.json entry %d (%s): %s -- left out" % (i + 1, cid or "?", "; ".join(problems)))
            continue
        case = dict(CASE_DEFAULTS)
        case.update(c)
        fmt = dict(FORMAT_DEFAULTS)
        fmt.update(c.get("format") or {})
        case["format"] = fmt
        for k in ("drop_columns", "leak_columns", "probable_leak_columns"):
            v = case.get(k) or []
            if isinstance(v, str):
                v = [v]
            case[k] = [str(x).strip() for x in v]
        pv = case.get("positive_values")
        if pv is not None and not isinstance(pv, list):
            case["positive_values"] = [pv]
        al = case.get("aliases") or []
        case["aliases"] = [str(x).strip() for x in ([al] if isinstance(al, str) else al) if str(x).strip()]
        for k in ("unit", "prediction_time", "target_description", "name"):
            case[k] = str(case.get(k) or "").strip()
        case.update(id=cid, kind=kind, task=task, target=str(case["target"]).strip())
        if not case["name"]:
            case["name"] = cid
        if not quiet:
            both = set(case["leak_columns"]) & set(case["probable_leak_columns"])
            if both:
                print("  note: %s lists %s as both leak and probable -- counted as leak" % (cid, sorted(both)))
            if kind == "leak" and not case["leak_columns"]:
                print("  note: %s is kind 'leak' but lists no leak_columns" % cid)
            if kind == "clean" and case["leak_columns"]:
                print("  note: %s is kind 'clean' but lists leak_columns" % cid)
        case["probable_leak_columns"] = [x for x in case["probable_leak_columns"] if x not in case["leak_columns"]]
        cases.append(case)
        seen.add(cid)
    return cases


def norm_value(v: Any) -> str:
    """Comparable form of a target value: 1, 1.0 and "1" match; text is compared case-blind."""
    if isinstance(v, (bool, np.bool_)):
        return "true" if v else "false"
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    if isinstance(v, (float, np.floating)):
        if np.isfinite(v) and float(v).is_integer():
            return str(int(v))
        return repr(float(v))
    s = str(v).strip().lower()
    try:
        f = float(s)
        if np.isfinite(f) and f.is_integer() and re.match(r"^[+-]?\d+(\.0*)?$", s):
            return str(int(f))
    except ValueError:
        pass
    return s


# ============================================================ standardized data
def read_data(case_id: str) -> pd.DataFrame:
    return pd.read_csv(data_file(case_id), low_memory=False)


def read_meta(case_id: str) -> Dict[str, Any]:
    return load_json(meta_file(case_id)) or {}


def sample_index(y: pd.Series, n: int, seed: int, stratify: bool) -> pd.Index:
    """Index labels of an n-row random sample, in the original row order. With stratify (0/1 target) the share of
    positives is kept."""
    if n >= len(y):
        return y.index
    rng = np.random.RandomState(seed)
    if not stratify:
        picks = rng.choice(len(y), size=n, replace=False)
    else:
        yv = np.asarray(y)
        pos = np.flatnonzero(yv == 1)
        neg = np.flatnonzero(yv != 1)
        n_pos = int(round(n * len(pos) / float(len(y))))
        n_pos = min(len(pos), max(1 if len(pos) else 0, n_pos))
        n_neg = min(len(neg), n - n_pos)
        picks = np.concatenate([rng.choice(pos, n_pos, replace=False), rng.choice(neg, n_neg, replace=False)])
    return y.index[np.sort(picks)]


# ============================================================ column types
_NUM_JUNK = re.compile(r"[,$%\s]")
_MONTH = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
_TIME = (r"(?:[ T]\d{1,2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:\s*[ap]m)?)?"
         r"(?:\s*(?:z|utc|gmt|[+-]\d{2}:?\d{2}))?")
DATE_LIKE = re.compile(
    r"^\s*(?:"
    r"\d{4}[-/.]\d{1,2}(?:[-/.]\d{1,2})?" + _TIME +              # 2015-07-01, 2015/7/1, 2015-07, + time
    r"|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}" + _TIME +                 # 07/01/2015, 1.7.15
    r"|\d{1,2}[- ]" + _MONTH + r"[- ,]*\d{2,4}" + _TIME +         # 01-Jul-2015, 1 July 2015
    r"|" + _MONTH + r"[- ]\d{1,2},?[- ]\d{4}" + _TIME +           # Jul 1, 2015
    r"|" + _MONTH + r"[- ]\d{2,4}"                                # Dec-2011, Dec-11, July 2015
    r")\s*$", re.IGNORECASE)
DATE_FORMATS = ["%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d", "%Y-%m",
                "%m/%d/%Y", "%d/%m/%Y", "%m/%d/%y", "%d/%m/%y", "%m/%d/%Y %H:%M", "%m/%d/%Y %H:%M:%S", "%d.%m.%Y",
                "%m-%d-%Y", "%d-%m-%Y", "%b-%Y", "%b-%y", "%d-%b-%Y", "%d-%b-%y", "%b %Y", "%B %Y", "%d %b %Y",
                "%d %B %Y", "%b %d, %Y", "%B %d, %Y"]


def as_float(s: pd.Series) -> Tuple[pd.Series, float]:
    """s as floats, and the share of its non-missing values that converted ('1,234', '$5', '13.5%' convert)."""
    if pd.api.types.is_bool_dtype(s) or pd.api.types.is_numeric_dtype(s):
        out = pd.to_numeric(s, errors="coerce").astype(float)
        return out.replace([np.inf, -np.inf], np.nan), 1.0
    mask = s.notna()
    n = int(mask.sum())
    out = pd.Series(np.nan, index=s.index, dtype=float)
    if n == 0:
        return out, 0.0
    num = pd.to_numeric(s[mask].astype(str).str.replace(_NUM_JUNK, "", regex=True), errors="coerce")
    num = num.astype(float).replace([np.inf, -np.inf], np.nan)
    out[mask] = num
    return out, float(num.notna().sum()) / n


def _to_dt(values: pd.Series, fmt: Optional[str]) -> pd.Series:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if fmt is None:
                out = pd.to_datetime(values, errors="coerce", utc=True)
            else:
                out = pd.to_datetime(values, format=fmt, errors="coerce", utc=True)
        return out.dt.tz_convert(None)
    except (ValueError, TypeError, OverflowError, AttributeError):
        return pd.Series(pd.NaT, index=values.index, dtype="datetime64[ns]")


def as_dates(s: pd.Series) -> Tuple[Optional[pd.Series], float]:
    """s as datetimes and the share of non-missing values that parsed; (None, share) if it does not look like dates.
    Values must look like dates (digits and separators, or a month name with a year), so 'July' or 'Room 12' do not."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return s, 1.0
    if pd.api.types.is_bool_dtype(s) or pd.api.types.is_numeric_dtype(s):
        return None, 0.0
    mask = s.notna()
    n = int(mask.sum())
    if n == 0:
        return None, 0.0
    txt = s[mask].astype(str).str.strip()
    sample = txt if n <= 2000 else txt.sample(2000, random_state=0)
    like = float(sample.str.match(DATE_LIKE).mean())
    if like <= DATE_SHARE:
        return None, like
    best_fmt, best_ok = None, -1.0
    for fmt in DATE_FORMATS:
        ok = float(_to_dt(sample, fmt).notna().mean())
        if ok > best_ok:
            best_fmt, best_ok = fmt, ok
        if ok >= 0.999:
            break
    parsed = _to_dt(txt, best_fmt if best_ok > DATE_SHARE else None)
    if float(parsed.notna().mean()) <= DATE_SHARE:
        mixed = _to_dt(txt, "mixed")  # pandas 2: parse each value on its own
        if float(mixed.notna().mean()) > float(parsed.notna().mean()):
            parsed = mixed
    out = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    out[mask] = parsed
    return out, float(parsed.notna().sum()) / n


def days_since_epoch(dt: pd.Series) -> pd.Series:
    return (dt - pd.Timestamp("1970-01-01")) / pd.Timedelta(days=1)


def looks_like_text(s: pd.Series) -> bool:
    """Free text (names, descriptions) rather than a category: mostly distinct values that are long or wordy."""
    txt = s.dropna().astype(str)
    if len(txt) == 0:
        return False
    n_unique = txt.nunique()
    if n_unique < 50 or n_unique < 0.5 * len(txt):
        return False
    return float(txt.str.len().mean()) >= 25 or float(txt.str.split().str.len().mean()) >= 4


def analyze_column(s: pd.Series) -> Tuple[str, Optional[pd.Series]]:
    """(type, values): 'numeric' with floats, 'date' with datetimes, or 'category' / 'text' with None.
    Shares are of the non-missing values: numeric if more than NUMERIC_SHARE converts, date if more than DATE_SHARE
    parses."""
    if pd.api.types.is_bool_dtype(s):
        return "category", None
    if pd.api.types.is_datetime64_any_dtype(s):
        return "date", s
    if pd.api.types.is_numeric_dtype(s):
        return "numeric", as_float(s)[0]
    if int(s.notna().sum()) == 0:
        return "category", None
    num, share = as_float(s)
    if share > NUMERIC_SHARE:
        return "numeric", num
    dt, share = as_dates(s)
    if dt is not None and share > DATE_SHARE:
        return "date", dt
    return ("text" if looks_like_text(s) else "category"), None


def infer_type(s: pd.Series) -> str:
    return analyze_column(s)[0]


# ============================================================ column summaries (for prompts)
def fmt_num(x: Any) -> str:
    try:
        x = float(x)
    except (TypeError, ValueError):
        return str(x)
    if not np.isfinite(x):
        return "nan"
    if x.is_integer() and abs(x) < 1e15:
        return str(int(x))
    return "%.6g" % x


def quote(v: Any, width: int = 40) -> str:
    t = " ".join(str(v).split())
    if len(t) > width:
        t = t[:width - 3] + "..."
    return json.dumps(t, ensure_ascii=False)


def _fmt_date(d: pd.Timestamp) -> str:
    return d.strftime("%Y-%m-%d") if (d.hour, d.minute, d.second) == (0, 0, 0) else d.strftime("%Y-%m-%d %H:%M")


def _pct(share: float) -> str:
    p = 100.0 * share
    return "<1%" if 0 < p < 0.5 else "%.0f%%" % p


def random_values(values: pd.Series, k: int, rng: np.random.RandomState) -> List[Any]:
    """Up to k values from random rows, without repeating a value."""
    if k <= 0 or len(values) == 0:
        return []
    out, seen = [], set()
    for i in rng.choice(len(values), size=min(len(values), 3 * k + 3), replace=False):
        v = values.iloc[i]
        if str(v) not in seen:
            seen.add(str(v))
            out.append(v)
            if len(out) == k:
                break
    return out


def column_summary(s: pd.Series, n_examples: int, rng: np.random.RandomState) -> Dict[str, Any]:
    """Type, missing %, distinct count and example values of one column.
    Categories: the most frequent values; numbers: min, median, max and random values; dates: min, max and random
    values (as written in the file); text: random values."""
    col_type, values = analyze_column(s)
    n = len(s)
    nonnull = s.dropna()
    missing_pct = 100.0 * (1.0 - len(nonnull) / float(n)) if n else 0.0
    n_unique = int(nonnull.nunique())
    ex = ""
    if len(nonnull) and n_examples > 0:
        if col_type == "numeric":
            v = values.dropna()
            if len(v):
                ex = "min %s, median %s, max %s" % (fmt_num(v.min()), fmt_num(v.median()), fmt_num(v.max()))
                picks = random_values(v, n_examples - 3, rng)
                if picks:
                    ex += "; e.g. " + ", ".join(fmt_num(x) for x in picks)
        elif col_type == "date":
            d = values.dropna()
            if len(d):
                ex = "min %s, max %s" % (_fmt_date(d.min()), _fmt_date(d.max()))
                picks = random_values(nonnull, max(1, n_examples - 2), rng)
                ex += "; e.g. " + ", ".join(quote(x) for x in picks)
        else:
            txt = nonnull.astype(str)
            counts = txt.value_counts()
            if col_type == "text" or int(counts.iloc[0]) == 1:
                picks = random_values(txt, n_examples, rng)
                ex = "e.g. " + ", ".join(quote(x, 60 if col_type == "text" else 40) for x in picks)
            else:
                top = counts.iloc[:n_examples]
                ex = "top: " + ", ".join("%s %s" % (quote(k), _pct(c / float(len(txt)))) for k, c in top.items())
    return {"type": col_type, "missing_pct": missing_pct, "n_unique": n_unique, "examples": ex}


def column_line(name: str, summary: Dict[str, Any]) -> str:
    """One prompt line: name | type | missing | distinct values | examples."""
    return "- %s | %s | %.1f%% missing | %d distinct | %s" % (
        " ".join(str(name).split()), summary["type"], summary["missing_pct"], summary["n_unique"],
        summary["examples"] or "(no values)")


# ============================================================ HTTP (urllib only)
class ApiError(Exception):
    """An answer that retrying cannot fix (bad key, model id or setting), or no answer after all retries."""

    def __init__(self, message: str, code: int = 0) -> None:
        super().__init__(message)
        self.code = code


def http_post(url: str, headers: Dict[str, str], body: Dict[str, Any], timeout: Optional[float] = None,
              max_retries: Optional[int] = None) -> Dict[str, Any]:
    """One POST with retries on rate limits, overload and network errors. A bad key, model id or setting raises
    ApiError with the API's message (retrying cannot fix it)."""
    data = json.dumps(body).encode("utf-8")
    tries = int(max_retries or HTTP_MAX_RETRIES)
    last = ""
    for attempt in range(tries):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        wait = RETRY_BASE_S * (attempt + 1)
        try:
            with urllib.request.urlopen(req, timeout=timeout or HTTP_TIMEOUT_S) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:800]
            if e.code in (400, 401, 402, 403, 404, 413, 422) or (e.code == 429 and "insufficient_quota" in detail):
                raise ApiError("HTTP %s from %s -- check the key, model id and settings at the top.\n%s"
                               % (e.code, url, detail), e.code)
            last = "HTTP %s: %s" % (e.code, detail[:200])
            try:
                wait = max(wait, float(e.headers.get("retry-after") or 0))
            except (TypeError, ValueError):
                pass
        except Exception as e:  # timeouts, connection resets, a garbled answer
            if "CERTIFICATE_VERIFY_FAILED" in str(e):
                raise ApiError(CERT_HINT)
            last = str(e) or e.__class__.__name__
        if attempt + 1 < tries:
            print("  %s -- retrying in %.0f s" % (last, min(wait, 120.0)))
            time.sleep(min(wait, 120.0))
    raise ApiError("No answer from %s after %d tries (%s). Check your connection and press Run again."
                   % (url, tries, last))


def num(x: Any) -> int:
    try:
        return int(x or 0)
    except (TypeError, ValueError):
        return 0


# ============================================================ lenient JSON
_TRAILING_COMMA = re.compile(r",\s*([}\]])")


def _block_end(t: str, start: int) -> Optional[int]:
    """Index of the bracket closing the one at t[start], skipping brackets inside strings; None if unclosed."""
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "{[":
            depth += 1
        elif ch in "}]":
            depth -= 1
            if depth == 0:
                return i
    return None


def loads_lenient(chunk: str) -> Any:
    """json.loads that also accepts trailing commas."""
    for cand in (chunk, _TRAILING_COMMA.sub(r"\1", chunk)):
        try:
            return json.loads(cand)
        except ValueError:
            pass
    raise ValueError("not JSON")


def extract_json(text: Any) -> Any:
    """The first {...} or [...] block in text that parses (code fences, prose around it and trailing commas are
    tolerated); None if there is none."""
    if not isinstance(text, str) or not text.strip():
        return None
    t = text.strip()
    try:
        return loads_lenient(t)
    except ValueError:
        pass
    for count, m in enumerate(re.finditer(r"[\[{]", t)):
        if count >= 200:
            break
        end = _block_end(t, m.start())
        if end is None:
            continue
        try:
            return loads_lenient(t[m.start():end + 1])
        except ValueError:
            continue
    return None


# ============================================================ small helpers
def text_hash(*parts: str) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(str(p).encode("utf-8"))
        h.update(b"\x00")
    return h.hexdigest()[:20]


def norm_text(s: Any) -> str:
    """Lowercase letters and digits only (for loose name matching)."""
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def stamp() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def format_table(headers: List[str], rows: List[List[Any]]) -> str:
    cells = [[str(h) for h in headers]] + [["" if v is None else str(v) for v in r] for r in rows]
    widths = [max(len(r[i]) for r in cells) for i in range(len(headers))]
    lines = ["  ".join(c.ljust(w) for c, w in zip(r, widths)).rstrip() for r in cells]
    lines.insert(1, "  ".join("-" * w for w in widths))
    return "\n".join(lines)


# ============================================================ dataset identity (disguise check, recognition)
# Words that carry no identity and may stay in a disguised task text even when a dataset's name contains them.
GENERIC_WORDS = {
    "the", "and", "for", "with", "from", "one", "two", "data", "dataset", "datasets", "copy", "version", "release",
    "extended", "subset", "sample", "scrape", "named", "name", "column", "columns", "sheet", "raw", "csv", "xlsx",
    "train", "test", "list", "record", "records", "clinical", "project", "open", "full", "additional", "example",
    "year", "years", "hour", "hourly", "score", "scores", "customer", "personal", "machine", "learning", "semantic",
    "demand", "loan", "loans", "clean", "whether", "when", "before", "after"}


def word_tokens(text: Any) -> List[str]:
    return re.findall(r"[a-z0-9]+", str(text or "").lower())


def _stem(w: str) -> str:
    return w[:-1] if len(w) > 4 and w.endswith("s") else w


def identity_words(case: Dict[str, Any]) -> List[str]:
    """Words that would give a dataset away: the words of its name and aliases, plus capitalized words inside its
    task texts (places, organizations, products). Generic words and words under 3 letters are left out."""
    words = set()
    for s in [case.get("name") or ""] + list(case.get("aliases") or []):
        words.update(word_tokens(s))
    for k in ("unit", "target_description", "prediction_time"):
        for sentence in re.split(r"(?<=[.!?;:])\s+", str(case.get(k) or "")):
            ws = re.findall(r"[A-Za-z][A-Za-z0-9']*", sentence)
            for w in ws[1:]:  # the first word of a sentence is capitalized anyway
                if w[0].isupper():
                    words.update(word_tokens(re.sub(r"'s$", "", w)))
    return sorted(w for w in words if len(w) >= 3 and w not in GENERIC_WORDS)


def identity_hits(text: Any, words: List[str]) -> List[str]:
    """The identity words that occur in text. Plurals and short endings count ('bank' also catches 'banks',
    'banking'); words of 3 letters must match exactly."""
    banned = {_stem(w): w for w in words}
    found = set()
    for t in set(word_tokens(text)):
        st = _stem(t)
        for b, orig in banned.items():
            if st == b or (len(b) >= 4 and st.startswith(b) and len(st) - len(b) <= 3):
                found.add(orig)
    return sorted(found)


def guess_matches(guess: Any, case: Dict[str, Any]) -> bool:
    """Does a dataset guess name this case? Letters and digits only, lowercased: the guess contains the case's name,
    id or an alias, or one of those contains the guess (when the guess has at least 4 characters)."""
    g = norm_text(guess)
    if not g:
        return False
    for ref in [case.get("name"), case.get("id")] + list(case.get("aliases") or []):
        r = norm_text(ref)
        if r and (r in g or (len(g) >= 4 and g in r)):
            return True
    return False
