import os, json
P = os.path.expanduser("~/Downloads/answers_trained_run2.jsonl")
b = open(P, "rb").read()
print("bytes:", len(b))
print("first 80 bytes:", b[:80])
print("null bytes:", b.count(b"\x00"))
clean = b.replace(b"\x00", b"")
print("bytes without nulls:", len(clean))
rows = [json.loads(x) for x in clean.decode("utf-8").splitlines() if x.strip()]
print("rows:", len(rows), "unique ids:", len({r["id"] for r in rows}))
print("other odd bytes:", sorted({c for c in clean if c < 9 or 13 < c < 32}))