# leakaudit: exploratory record of runs 1-4 (v0.1)

leakaudit is a research project on auditing tabular machine-learning data for leakage before any model is trained.
Given what a row is, what is predicted and the moment of prediction, a model rates each column's risk of being
unavailable at that moment or derived from the outcome, with a reason. It needs no outcome labels.

This release is the exploratory record of the first four fine-tuning runs and the tests around them (October 17-23,
2026). The confirmatory experiment, run 5, will be pre-registered separately before it runs.

**Status: exploratory.** Each run's pass/fail rule was written before the run, but only in private files. The public
evidence for this record is a SHA-256 commitment to every file, published on Zenodo before this release
([doi:10.5281/zenodo.23608855](https://doi.org/10.5281/zenodo.23608855)). Every file under `exploratory/` matches that commitment's manifest (see Verify).

## Contents

| Folder (under `exploratory/`) | What it is | Dates (2026) | Pre-set rule |
|---|---|---|---|
| `leaktest` | Quick test on 27 public datasets (16 with documented leaks, 11 clean): DeepSeek, Claude and GPT on real, reworded, scrambled and disguised columns | Oct 17 | v1 GO; v2 NO GO: the models recognized 92-100% of the datasets even when disguised |
| `fresh test` | 36 generated tables with known availability times (139 planted leaks of 8 types, decoys, legitimate strong predictors, three naming styles); then the auditor test: 6 trap tables, label-free data checks and a local Qwen2.5-7B | Oct 17-18 | fresh test GO; auditor test NO GO (local model 0.73, 0.75 required) |
| `fresh test open` | Four open-weight models via OpenRouter on the generated tables | Oct 18 | NO GO on the checks rule; all four reached 0.78 or more |
| `new fresh leak folder` | Fine-tune run 1: Qwen3.5 9B with LoRA on 2,000 generated tables | Oct 18-19 | PARTIAL: held-out domains +0.33, public datasets -0.23 |
| `leak real test 2` | Real test 2: 47 new public tables (35 with documented leaks, 12 clean), each checked by three independent checkers; statistical column check | Oct 19-20 | test set for run 2 |
| `leak training 2` | Fine-tune run 2: generated and development tables | Oct 20-21 | PARTIAL: held-out domains +0.34, real test 2 +0.06 |
| `leak training 3` | Fine-tune run 3: distillation from Claude and GPT, development and generated tables; real test 3 (55 tables) | Oct 21-22 | FAIL: real test 3 +0.13, held-out domains -0.07 |
| `leak training 4` | Fine-tune run 4: 5,415 training examples (distillation 2,164, development 870, generated 2,381); real test 4 (56 tables, 208 leak columns) | Oct 22-23 | PASS: real test 4 0.79 -> 0.90 (+0.12), held-out domains 0.56 -> 0.67 (+0.11) |

Scores are macro recall over the leak tables at no more than one false flag per table; changes are the trained model
minus the same model untrained. The results file in each folder has the full tables. The base model in runs 1-4 is
Qwen3.5 9B.

## Run 5's test set (sealed)

`SEAL_test5_public.txt` holds the SHA-256 of the sealed test set of run 5: the answer key and documentation of 68 real
tables whose rows were first made public on or after 1 July 2026. It was fixed on 26 October 2026, before run 5's
training. The sealed file itself is published with run 5's results, and anyone can check it against this hash.

## Not included, and why

This release holds 2,744 files. 16,986 files of the timestamped folders are left out:

- **Third-party tables.** They are never re-hosted. Each folder keeps its download scripts (`step1_get_data.py` or
  `t1_get_data.py`) and the case files with source URLs and labels.
- **Outputs of third-party models** (Claude, GPT, DeepSeek and the open-weight models run through OpenRouter), the
  training files built from them, and model-written rewrites of tables: withheld pending a review of the providers'
  terms. The prompts, the scoring code and the scores in the results files are included.
- **Model weights** (LoRA adapters and GGUF files), other archives, and files over 25 MB.
- The author's private working notes.

The manifest lists the SHA-256 of every withheld file, so anything released later can be checked against the same
commitment.

## Verify

`timestamp/` holds the commitment (`COMMITMENT_2026-10-23_2314.txt`), the full manifest (`MANIFEST_2026-10-23_2314.txt`) and `verify.py`. Run
`python timestamp/verify.py`. It checks that the manifest's SHA-256 equals the line in the commitment published on
Zenodo, and that every file under `exploratory/` appears in the manifest. API keys were replaced by `REDACTED_KEY`
before the files were hashed.

## Reproduce

Python 3.9 with pandas and numpy. The scripts in each folder run in the order of their numbers; runs 3 and 4 have a
`DESIGN` file. Fine-tuning ran on rented RunPod GPUs with the notebook in each training folder. Running the teacher models
again needs your own API keys.

## License

Code: Apache License 2.0 (`LICENSE`). Labels, documentation and results: CC BY 4.0 (`LICENSE-DATA.md`). Third-party
datasets keep their own licenses.

## Citation

See `CITATION.cff`. Author: Patrick Rigney, Azalea Intelligence LLC.
