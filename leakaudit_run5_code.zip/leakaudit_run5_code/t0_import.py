# t0_import.py -- brings what fine-tune run 5 needs into this folder ("leak training 5"). Python 3.9; press Run in
# PyCharm. No keys, no calls. Running it again is safe (it only adds what is new).
#
# From RUN4_FOLDER ("leak training 4"):
#   cases.json and data/ for the 42 generated test tables (the guard against forgetting what they teach);
#   the development tables with data/: cases_dev.json (27), cases_dev2.json (47), cases_dev3.json (55), and real
#   test 4's 56 (cases_test4.json, saved here as cases_dev4.json: its results were read for run 4's verdict, so from
#   run 5 on they are training data, never test data);
#   the public training tables with data/: cases_distill.json (268) and cases_distill2.json (433);
#   the generated training tables with data/: cases_gen.json (800);
#   the teachers' saved answers (llm_cache/claude/chunks/, llm_cache/gpt/chunks/), so t2_teachers.py only asks what is
#   new, and GPT's saved disguises (disguised/), so none is written twice.
# From TEST5_FOLDER ("leak test 5"): the frozen copies of test 5's batch-2 tables (data/raw/<id>/), each checked
#   against the SHA-256 in cases_test5_blind.json. Batch 1 is downloaded by t1_get_data.py.
# Nothing in either folder is changed. A file already here is kept, unless the one there is newer and different.
#
# Paths: in PyCharm, right-click the folder > Copy Path/Reference > Absolute Path, and paste it between the quotes.

RUN4_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leak training 4"
TEST5_FOLDER = "/Users/patrigney/PycharmProjects/pythonProject/leak test 5"

# ============================================================ internals
import filecmp
import hashlib
import json
import os
import shutil
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_get_data as s1g  # noqa: E402

DEV_FILES = {"cases_dev.json": "cases_dev.json", "cases_dev2.json": "cases_dev2.json",
             "cases_dev3.json": "cases_dev3.json", "cases_test4.json": "cases_dev4.json"}
DISTILL_FILES = ["cases_distill.json", "cases_distill2.json"]
GEN_FILE = "cases_gen.json"
TEST5_FILE = "cases_test5_blind.json"
TEACHER_LABELS = ["claude", "gpt", "mock-claude", "mock-gpt"]   # the mock labels exist only in a pipeline test
STATS: Dict[str, int] = {"copied": 0, "updated": 0, "kept": 0}


def folder(p: str, what: str) -> str:
    p = os.path.normpath(os.path.expanduser(str(p or "").strip().strip("'\"")))
    if not os.path.isdir(p):
        raise SystemExit("%s does not exist: %s -- fix the path at the top of t0_import.py." % (what, p))
    if os.path.samefile(p, HERE):
        raise SystemExit("%s points at this folder." % what)
    return p


def put(src: str, dst: str) -> None:
    """Copy src to dst unless dst exists; replace dst only if src is newer and different."""
    if os.path.exists(dst):
        if filecmp.cmp(src, dst, shallow=False) or os.path.getmtime(src) <= os.path.getmtime(dst):
            STATS["kept"] += 1
            return
        STATS["updated"] += 1
    else:
        STATS["copied"] += 1
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(src, dst)


def read_cases(p: str) -> List[Dict[str, Any]]:
    if not os.path.exists(p):
        raise SystemExit("Not found: %s" % p)
    with open(p, encoding="utf-8-sig") as f:
        raw = json.load(f)
    return raw.get("cases", []) if isinstance(raw, dict) else raw


def copy_data(src_dir: str, ids: List[str], what: str) -> List[str]:
    """data/<id>.csv.gz and .meta.json, and the downloaded source files (data/raw/<id>/), which t3 compares with test
    5's so no copy of a test table can get into training."""
    missing = []
    for cid in ids:
        f = os.path.join(src_dir, "data", cid + ".csv.gz")
        if not os.path.exists(f):
            missing.append(cid)
            continue
        put(f, common.data_file(cid))
        m = os.path.join(src_dir, "data", cid + ".meta.json")
        if os.path.exists(m):
            put(m, common.meta_file(cid))
        rd = os.path.join(src_dir, "data", "raw", cid)
        if os.path.isdir(rd):
            for fn in sorted(os.listdir(rd)):
                if os.path.isfile(os.path.join(rd, fn)) and not fn.endswith(".part"):
                    put(os.path.join(rd, fn), os.path.join(common.raw_dir(cid), fn))
    if missing:
        print("  %s: no data for %d table(s) there: %s" % (what, len(missing), ", ".join(missing[:15])))
    return missing


def copy_dir_files(src: str, dst: str, suffix: str = ".json") -> int:
    n = 0
    if os.path.isdir(src):
        for fn in sorted(os.listdir(src)):
            if fn.endswith(suffix) and os.path.isfile(os.path.join(src, fn)):
                put(os.path.join(src, fn), os.path.join(dst, fn))
                n += 1
    return n


def sha256_file(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    src = folder(RUN4_FOLDER, "RUN4_FOLDER (your leak training 4 folder)")
    t5 = folder(TEST5_FOLDER, "TEST5_FOLDER (your leak test 5 folder)")
    if not os.path.exists(common.path(TEST5_FILE)):
        raise SystemExit("%s is not here: it comes with the run 5 kit." % TEST5_FILE)
    print("From %s" % src)
    sets: Dict[str, List[str]] = {}
    missing: List[str] = []

    print("1. The 42 generated test tables")
    gen_test = [c for c in read_cases(os.path.join(src, "cases.json")) if c.get("url") == "generated"]
    put(os.path.join(src, "cases.json"), common.path("cases.json"))
    if os.path.exists(os.path.join(src, "generated_checksums.txt")):
        put(os.path.join(src, "generated_checksums.txt"), common.path("generated_checksums.txt"))
    sets["generated test"] = [c["id"] for c in gen_test]
    missing += copy_data(src, sets["generated test"], "generated test")

    print("2. Development tables (documented keys): the 27, the 47, real test 3's 55 and real test 4's 56")
    for src_name, dst_name in DEV_FILES.items():
        p = os.path.join(src, src_name)
        sets[dst_name] = [c["id"] for c in read_cases(p)]
        put(p, common.path(dst_name))
        missing += copy_data(src, sets[dst_name], dst_name)

    print("3. Public training tables and the generated training tables")
    no_data: List[str] = []
    for name in DISTILL_FILES + [GEN_FILE]:
        p = os.path.join(src, name)
        sets[name] = [c["id"] for c in read_cases(p)]
        put(p, common.path(name))
        lost = copy_data(src, sets[name], name)
        (missing if name == GEN_FILE else no_data).extend(lost)   # a public table without data is left out by t3

    print("4. The teachers' saved answers and GPT's saved disguises")
    teachers = {lab: copy_dir_files(os.path.join(src, "llm_cache", lab, "chunks"),
                                    common.path("llm_cache", lab, "chunks")) for lab in TEACHER_LABELS}
    n_dis = copy_dir_files(os.path.join(src, "disguised"), common.path("disguised"))

    print("5. Test 5's frozen batch-2 files, from %s" % t5)
    test5 = common.load_cases(quiet=True, file=TEST5_FILE)
    sets[TEST5_FILE] = [c["id"] for c in test5]
    bad, n_frozen = [], 0
    for c in test5:
        if c.get("batch") != 2:
            continue
        name = s1g.file_name(c["url"])
        p = os.path.join(t5, "data", "raw", c["id"], name)
        if not os.path.exists(p):
            bad.append("%s (not in leak test 5)" % c["id"])
            continue
        if sha256_file(p) != c.get("raw_sha256"):
            bad.append("%s (not the frozen file)" % c["id"])
            continue
        put(p, os.path.join(common.raw_dir(c["id"]), name))
        n_frozen += 1

    seen: Dict[str, str] = {}
    for name, ids in sets.items():
        for cid in ids:
            if cid in seen:
                raise SystemExit("STOP: table %s is in both %s and %s. Tell Claude." % (cid, seen[cid], name))
            seen[cid] = name

    print("\nFiles: %d copied, %d updated, %d already here." % (STATS["copied"], STATS["updated"], STATS["kept"]))
    print(common.format_table(["brought in", "files"],
                              [["%s answers" % lab, n] for lab, n in teachers.items() if n] +
                              [["GPT disguises", n_dis], ["frozen test 5 files", n_frozen]]))
    if bad:
        raise SystemExit("STOP: %d frozen test 5 file(s) are missing or changed: %s. Check TEST5_FOLDER; tell Claude "
                         "if this stays." % (len(bad), "; ".join(bad[:8])))
    if missing:
        raise SystemExit("STOP: %d generated or development table(s) have no data in RUN4_FOLDER (listed above). "
                         "Tell Claude." % len(missing))
    if not teachers.get("claude") or not teachers.get("gpt"):
        print("note: no saved answers of one teacher -- t2_teachers.py would ask for all of them (check RUN4_FOLDER)")
    print("Tables here: %d generated test; development %s; public training %d%s; generated training %d; test 5: %d "
          "(%d frozen here, %d to download)."
          % (len(sets["generated test"]), " + ".join(str(len(sets[d])) for d in DEV_FILES.values()),
             sum(len(sets[d]) for d in DISTILL_FILES) - len(no_data),
             " (%d without data left out)" % len(no_data) if no_data else "", len(sets[GEN_FILE]), len(test5),
             n_frozen, sum(1 for c in test5 if c.get("batch") == 1)))
    print("Next: t1_get_data.py")


if __name__ == "__main__":
    main()
