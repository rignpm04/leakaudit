# t3_make_training.py -- makes the training files of fine-tune run 5. Python 3.9; press Run in PyCharm after
# t2_teachers.py has every answer. No keys, no downloads, no calls.
#
# Every training example is one chunk prompt (at most 10 rated columns, the same prompt format the test uses) followed
# by its answer: a short reason, a category and a risk for each of the chunk's columns. Three kinds of table:
#   1. Public training tables (cases_distill.json: 268; cases_distill2.json: 433): the answer is the two teachers'
#      ratings, averaged and rounded to 5. Each table goes in twice: as is (exactly the prompts the teachers answered),
#      then disguised (GPT's new column names, labels and task text; numbers rounded, dates shifted, columns shuffled --
#      the same disguise test 5 gets).
#   2. Development tables (the first 27 public datasets, leak real test 2's 47, real test 3's 55 and real test 4's 56,
#      whose leaks are documented): the teachers' average, kept on the right side of the answer key -- a documented leak
#      gets at least 80, a debatable column 20-80, any other column at most 20. Three times each: as is, disguised, and
#      with the columns shuffled and a random 60-95% of the rows.
#   3. Generated tables (cases_gen.json), as stored: the generator's key sets the risk (a planted leak 95, every other
#      column 5); the reason and category are GPT's when GPT agrees with the key, else a short template.
# A table without a usable disguise gets the shuffled copy in its place. In a disguised copy the answer uses the
# disguised names; a reason that would give the real table away (a real column name, label, year or identifying word
# left after renaming) is replaced by the short reason of its category.
# Never used here: real test 5 (cases_test5_blind.json) and the 42 generated test tables. The checks below stop if a
# test table is in a training file, and leave out any training table that comes from the same file (url, download or
# data) as a test 5 table or has nearly the same columns (listed in train_manifest.json).
# Output: train.jsonl and val.jsonl (one example per line, chat format) and train_manifest.json.

# ============================================================ settings (edit here)
TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]
HOLDOUT_DOMAINS = ["lending", "hospital"]
VAL_SHARE = 0.05              # share of tables kept apart for the validation loss (whole tables, every source)
DISTILL_VARIANTS = ["real", "disguised"]
DEV_VARIANTS = ["real", "disguised", "shuffled"]
ROW_SHARE = (0.60, 0.95)      # a shuffled copy keeps this share of the rows
SEED = 20261027
TEACHERS = ["claude", "gpt"]  # must match t2_teachers.py
REASON_TEACHER = "gpt"        # the teacher whose reasons the generated tables use (t2's REASON_TEACHERS)
MOCK_TEACHERS = False         # True: read the mock teachers' answers (pipeline test only)
NEAR_COPY_JACCARD = 0.8       # a training table sharing more than this share of its columns with a test 5 table is out

TRAIN_FILE = "train.jsonl"
VAL_FILE = "val.jsonl"
MANIFEST_FILE = "train_manifest.json"
DISTILL_FILES = {"distill": "cases_distill.json", "distill2": "cases_distill2.json"}
DEV_FILES = ["cases_dev.json", "cases_dev2.json", "cases_dev3.json", "cases_dev4.json"]
GEN_FILE = "cases_gen.json"
TEST5_FILE = "cases_test5_blind.json"

# DEV_CATEGORY (below the imports): run 2's category for each documented leak of the first 27 development tables,
# used when both teachers called such a column fine.

# ============================================================ internals
import csv
import gzip
import hashlib
import io
import json
import math
import os
import re
import sys
import time
import zlib
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import r5_common as r5  # noqa: E402
import step1_generate as s1  # noqa: E402
import step3_llm_audit as s3  # noqa: E402
import t2_teachers as t2  # noqa: E402  (only its model settings: the disguises were written with them)

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

DEV_CATEGORY = {
    "bank_marketing": {"duration": "post_outcome"},
    "titanic3": {"boat": "post_outcome", "body": "post_outcome"},
    "hotel_bookings": {"reservation_status": "post_outcome", "reservation_status_date": "post_outcome",
                       "assigned_room_type": "post_outcome", "booking_changes": "future_aggregate",
                       "country": "post_outcome", "required_car_parking_spaces": "post_outcome",
                       "adr": "post_outcome"},
    "lending_club": {"total_pymnt": "future_aggregate", "total_pymnt_inv": "future_aggregate",
                     "total_rec_prncp": "future_aggregate", "total_rec_int": "future_aggregate",
                     "total_rec_late_fee": "future_aggregate", "recoveries": "post_outcome",
                     "collection_recovery_fee": "post_outcome", "last_pymnt_d": "post_outcome",
                     "last_pymnt_amnt": "post_outcome", "last_credit_pull_d": "post_outcome",
                     "funded_amnt": "post_outcome", "funded_amnt_inv": "post_outcome", "issue_d": "post_outcome",
                     "pymnt_plan": "post_outcome", "out_prncp": "post_outcome", "out_prncp_inv": "post_outcome",
                     "next_pymnt_d": "post_outcome", "hardship_flag": "post_outcome"},
    "bike_sharing_hour": {"casual": "target_derived", "registered": "target_derived"},
    "heart_failure": {"time": "post_outcome"},
    "telco_churn_ibm": {"Churn Label": "target_derived", "Churn Reason": "post_outcome",
                        "Churn Score": "post_outcome", "CLTV": "post_outcome", "Tenure Months": "post_outcome",
                        "Total Charges": "future_aggregate"},
    "compas_two_years": {"is_recid": "target_derived", "event": "target_derived", "end": "post_outcome",
                         "violent_recid": "post_outcome", "in_custody": "post_outcome", "out_custody": "post_outcome",
                         "start": "post_outcome"},
    "diabetes_130": {"discharge_disposition_id": "post_outcome", "patient_nbr": "identifier"},
    "vgsales": {"NA_Sales": "target_derived", "EU_Sales": "target_derived", "JP_Sales": "target_derived",
                "Other_Sales": "target_derived", "Rank": "target_derived"},
    "police_stops_ri": {"stop_outcome": "target_derived", "stop_duration": "post_outcome",
                        "search_conducted": "post_outcome", "search_type": "post_outcome",
                        "drugs_related_stop": "post_outcome"},
    "rossmann": {"Customers": "post_outcome"},
    "nycflights13": {"arr_time": "post_outcome", "dep_time": "post_outcome", "dep_delay": "target_derived",
                     "air_time": "post_outcome"},
    "brazilian_houses": {"hoa (R$)": "target_derived", "rent amount (R$)": "target_derived",
                         "property tax (R$)": "target_derived", "fire insurance (R$)": "target_derived"},
    "energy_efficiency": {"Cooling Load": "post_outcome"},
    "parkinsons_telemonitoring": {"motor_UPDRS": "target_derived", "test_time": "post_outcome",
                                  "subject#": "identifier"},
    "cardiotocography": {c: "target_derived" for c in ("CLASS", "A", "B", "C", "D", "E", "AD", "DE", "LD", "FS",
                                                       "SUSP", "LBE")},
    "clean_pima": {"Glucose": "target_derived"},
}

CATEGORY = {"outcome_status": "post_outcome", "post_event_date": "post_outcome", "snapshot_state": "post_outcome",
            "outcome_only_sparse": "post_outcome", "post_aggregate": "future_aggregate",
            "target_derived": "target_derived", "identifier": "identifier",
            "target_part": "target_derived", "event_measure": "post_outcome", "assigned_during": "post_outcome",
            "followup_time": "post_outcome"}
REASON = {"post_outcome": "Recorded after the prediction moment.",
          "target_derived": "Part of or computed from the outcome.",
          "future_aggregate": "Accumulates after the prediction moment.",
          "identifier": "Row identifier; repeats let a model memorize outcomes.",
          "fine": "Known at the prediction moment."}
TEMPLATE = {"outcome_status": "A status that reflects the outcome, set after the prediction moment.",
            "post_event_date": "A date that is only filled in after the prediction moment.",
            "snapshot_state": "A current value taken when the data were pulled, after the prediction moment.",
            "outcome_only_sparse": "Filled in only when the outcome happens.",
            "post_aggregate": "A total that keeps growing after the prediction moment.",
            "target_derived": "Computed from the outcome itself.",
            "identifier": "An id that repeats across rows and lets a model memorize outcomes.",
            "target_part": "Part of the outcome being predicted.",
            "event_measure": "Measured during or after the event, not before the moment.",
            "assigned_during": "Assigned during the process, after the prediction moment.",
            "followup_time": "A follow-up time, known only after the outcome period."}
TEMPLATE_FINE_NAME = "Known at the prediction moment, despite how its name sounds."   # decoys and trap columns
LEAK_CATEGORIES = ("post_outcome", "target_derived", "identifier", "future_aggregate")
RISK_LEAK, RISK_FINE = 95, 5
TRAIN_CHARS_PER_TOKEN = 2.65   # Qwen3.5's measured ratio on run 1's training texts
VARIANT_NAMES = ("real", "disguised", "shuffled")
YEAR = re.compile(r"\b(1[5-9]\d\d|20\d\d)\b")


def teacher_labels() -> List[str]:
    return [("mock-" if MOCK_TEACHERS else "") + t for t in TEACHERS]


def reason_label() -> str:
    return ("mock-" if MOCK_TEACHERS else "") + REASON_TEACHER


def table_rng(kind: str, case_id: str) -> np.random.RandomState:
    """A random stream of its own for each table (so leaving one table out changes nothing for the others)."""
    return np.random.RandomState((SEED * 1000003 + zlib.crc32(("%s:%s" % (kind, case_id)).encode("utf-8"))) % (2 ** 32))


def is_val(case_id: str) -> bool:
    return bool(table_rng("val", case_id).uniform() < VAL_SHARE)


def csv_text(header: List[str], rows: List[List[str]]) -> str:
    """The table exactly as step 1's write_table stores it."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(header)
    w.writerows(rows)
    return buf.getvalue()


def summaries_of(key: str, df: pd.DataFrame, cols: List[str]) -> Dict[str, Any]:
    """What step 3's prepare_case / chunk_info compute for these columns of df (same seed rule, keyed by key)."""
    rng = np.random.RandomState((s3.SEED * 1000003 + zlib.crc32(key.encode("utf-8"))) % (2 ** 32))
    return {c: common.column_summary(df[c], s3.N_EXAMPLES, rng) for c in cols}


def info_from_df(case: Dict[str, Any], key: str, df: pd.DataFrame, cols: List[str]) -> Dict[str, Any]:
    return {"case": case, "id": key, "task": case["task"], "columns": cols, "summaries": summaries_of(key, df, cols),
            "n_rows": len(df), "real_text": {k: case.get(k) or "" for k in s3.TEXT_KEYS}}


def info_from_text(case: Dict[str, Any], text: str) -> Dict[str, Any]:
    df = pd.read_csv(io.StringIO(text), low_memory=False)
    return info_from_df(case, case["id"], df, [c for c in df.columns if c != common.TARGET])


def full_info(case: Dict[str, Any], df: pd.DataFrame) -> Dict[str, Any]:
    """What step 3's prepare_case builds (the real table and its disguise statistics), from df already read."""
    cols = [c for c in df.columns if c != common.TARGET]
    info = info_from_df(case, case["id"], df, cols)
    info["dz"] = s3.disguise_stats(df, cols, info["summaries"])
    return info


def shuffled_info(case: Dict[str, Any], df: pd.DataFrame, v: int) -> Dict[str, Any]:
    """Copy v of the table: the columns shuffled, a random 60-95% of the rows (kept in their order)."""
    rng = table_rng("shuffled:%d" % v, case["id"])
    cols = [c for c in df.columns if c != common.TARGET]
    share = float(rng.uniform(*ROW_SHARE))
    size = min(len(df), max(30, int(round(share * len(df)))))
    rows = np.sort(rng.choice(len(df), size=size, replace=False))
    order = [cols[i] for i in rng.permutation(len(cols))]
    return info_from_df(case, "%s__v%d" % (case["id"], v), df.iloc[rows].reset_index(drop=True), order)


def answer(entries: List[Tuple[str, str, str, int]]) -> str:
    """The training answer of one chunk: a reason before the risk, the names as the prompt shows them."""
    cols = [{"column": s3.shown_name(c), "reason": why, "category": cat, "leak_risk": int(risk)}
            for c, why, cat, risk in entries]
    return json.dumps({"columns": cols}, ensure_ascii=False)


def example(ch: Dict[str, Any], meta: Dict[str, Any], entries: List[Tuple[str, str, str, int]]) -> Dict[str, Any]:
    return dict(meta, id=ch["chunk_id"], messages=[{"role": "system", "content": s3.SYSTEM_PROMPT},
                                                   {"role": "user", "content": ch["user"]},
                                                   {"role": "assistant", "content": answer(entries)}])


# ============================================================ targets from the teachers
def round5(x: float) -> int:
    return int(min(100, max(0, math.floor(x / 5.0 + 0.5) * 5)))


def cached_record(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The teacher's cached answer for this chunk id, whatever prompt it was made for (None if there is none)."""
    rec = common.load_json(common.path("llm_cache", lab, "chunks", ch["chunk_id"] + ".json"))
    return rec if isinstance(rec, dict) and rec.get("parsed") and rec.get("model_id") else None


def same_prompt(rec: Dict[str, Any], ch: Dict[str, Any]) -> bool:
    """The cached answer was made for exactly this prompt (text and hash)."""
    return (rec.get("prompt") == ch["user"] and
            rec.get("prompt_hash") == common.text_hash(str(rec["model_id"]), s3.SYSTEM_PROMPT, ch["user"]))


def teacher_answer(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    rec = cached_record(lab, ch)
    if rec is None or rec.get("prompt_hash") != common.text_hash(str(rec["model_id"]), s3.SYSTEM_PROMPT, ch["user"]):
        return None
    return rec


def teacher_ratings(chunks: List[Dict[str, Any]], labs: List[str]) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """{column: {teacher label: {leak_risk, category, reason}}} from these teachers' answers to these chunk prompts
    (entries without a usable risk left out)."""
    out: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for lab in labs:
        for ch in chunks:
            rec = teacher_answer(lab, ch)
            if not rec:
                continue
            for c, e in (rec["parsed"].get("columns") or {}).items():
                r = s3.to_risk((e or {}).get("leak_risk"))
                if c in ch["columns"] and np.isfinite(r):
                    out.setdefault(c, {})[lab] = {"leak_risk": float(r),
                                                  "category": s3.norm_category((e or {}).get("category")),
                                                  "reason": " ".join(str((e or {}).get("reason") or "").split())}
    return out


def target(case: Dict[str, Any], col: str, ratings: Dict[str, Dict[str, Any]], dev: bool
           ) -> Tuple[str, str, int]:
    """(reason, category, risk) for one column of a public table."""
    labs = teacher_labels()
    m = round5(float(np.mean([e["leak_risk"] for e in ratings.values()])))
    if dev:
        if col in case["leak_columns"]:
            final = max(m, 80)
        elif col in case["probable_leak_columns"]:
            final = min(max(m, 20), 80)
        else:
            final = min(m, 20)
    else:
        final = m
    order = sorted(ratings, key=lambda t: (abs(ratings[t]["leak_risk"] - final), labs.index(t)))
    closer = order[0]
    other = order[1] if len(order) > 1 else None
    if final >= 50:
        if ratings[closer]["category"] in LEAK_CATEGORIES:
            src = closer
        elif other and ratings[other]["category"] in LEAK_CATEGORIES:
            src = other
        else:
            src = None
        if src:
            cat = ratings[src]["category"]
            why = ratings[src]["reason"] or REASON[cat]
        else:
            cat = DEV_CATEGORY.get(case["id"], {}).get(col, "post_outcome") if dev else "post_outcome"
            why = REASON[cat]
    else:
        cat = "fine"
        why = (ratings[closer]["reason"] if ratings[closer]["category"] == "fine" and ratings[closer]["reason"]
               else REASON["fine"])
    return why, cat, final


def generated_target(case: Dict[str, Any], col: str, gpt: Optional[Dict[str, Any]]
                     ) -> Tuple[str, str, int, str, str]:
    """(reason, category, risk, where the reason came from, kind of column) for one column of a generated table: the
    key sets the risk; when GPT agrees with the key, GPT's own reason and category are used (so the two always fit
    together), else a template reason with the key's category."""
    ltype = (case.get("leak_types") or {}).get(col)
    if ltype in CATEGORY:
        agrees = bool(gpt and gpt["leak_risk"] >= 50 and gpt["category"] in LEAK_CATEGORIES and gpt["reason"])
        if agrees:
            return gpt["reason"], gpt["category"], RISK_LEAK, "gpt", ltype
        return TEMPLATE[ltype], CATEGORY[ltype], RISK_LEAK, "template", ltype
    if ltype:
        kind = "%s (fine)" % ltype   # a silently overwritten field: no method can see it, so it is trained as fine
    elif col in (case.get("decoy_columns") or []) or col in (case.get("trap_columns") or {}):
        kind = "decoy or trap (fine)"
    else:
        kind = "other fine"
    agrees = bool(gpt and gpt["leak_risk"] < 50 and gpt["category"] == "fine" and gpt["reason"])
    if agrees:
        return gpt["reason"], "fine", RISK_FINE, "gpt", kind
    return (TEMPLATE_FINE_NAME if kind == "decoy or trap (fine)" else REASON["fine"]), "fine", RISK_FINE, \
        "template", kind


# ============================================================ disguised copies
GENERIC_LABELS = {"none", "null", "true", "false", "unknown", "other", "others", "missing", "male", "female", "total",
                  "n/a", "not applicable", "not available", "nan"}


def name_key(text: str) -> str:
    return re.sub(r"[_ ]+", " ", " ".join(str(text).split()).lower())


def name_regex(names: List[str]) -> Optional["re.Pattern"]:
    """One pattern for these column names as whole words (any case; '_' and ' ' interchangeable), longest first."""
    alts = []
    for n in sorted(set(names), key=lambda x: -len(x)):
        parts = [re.escape(p) for p in re.split(r"[_ ]+", " ".join(str(n).split())) if p]
        if parts:
            alts.append(r"[_ ]+".join(parts))
    if not alts:
        return None
    return re.compile(r"(?<![A-Za-z0-9])(?:" + "|".join(alts) + r")(?![A-Za-z0-9])", re.I)


def code_like(name: str) -> bool:
    """A name that reads as a column name rather than an English word: '_', a digit, inner capitals, punctuation, or
    several words."""
    t = " ".join(str(name).split())
    return bool(re.search(r"[_0-9]|[a-z][A-Z]|[^A-Za-z ]| ", t))


def disguise_tools(info: Dict[str, Any], dz: Dict[str, Any]) -> Dict[str, Any]:
    """What disguised_reason needs for one table: the renaming of the real column names that read as names, and the
    giveaways (those names, the real labels, identifying words)."""
    named = [c for c in info["columns"] if len(" ".join(str(c).split())) >= 3 and code_like(c)]
    to_new: Dict[str, str] = {}
    for c in sorted(named, key=lambda x: -len(str(x))):
        to_new.setdefault(name_key(c), dz["names"][c])
    labels = set()
    for c in info["columns"]:
        for lab in info["dz"][c].get("labels") or []:
            t = " ".join(str(lab).split())
            if len(t) >= 4 and t.lower() not in GENERIC_LABELS and not re.fullmatch(r"[-+.,0-9 %/:]+", t):
                labels.add(t)
    return {"rename": name_regex(named), "to_new": to_new, "labels": name_regex(sorted(labels)),
            "words": s3.banned_words(info["case"]), "disguised": sorted(set(dz["names"].values()), key=len,
                                                                        reverse=True)}


def disguised_reason(why: str, cat: str, tools: Dict[str, Any]) -> Tuple[str, str]:
    """(reason, how): the reason with the real column names replaced by the disguised ones (in one pass); the
    category's short reason if a real name, label, year or identifying word would still give the table away."""
    new = why
    if tools["rename"] is not None:
        new = tools["rename"].sub(lambda m: tools["to_new"].get(name_key(m.group(0)), m.group(0)), why)
    check = new
    for d in tools["disguised"]:   # the disguised names themselves are allowed
        check = check.replace(d, " ")
    if (YEAR.search(check) or (tools["rename"] is not None and tools["rename"].search(check)) or
            (tools["labels"] is not None and tools["labels"].search(check)) or
            common.identity_hits(check, tools["words"])):
        return REASON[cat], "template"
    return new, ("renamed" if new != why else "kept")


# ============================================================ checks
def file_sha256(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def csv_sha256(case_id: str) -> str:
    h = hashlib.sha256()
    with gzip.open(common.data_file(case_id), "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def generator_check(gen: List[Dict[str, Any]]) -> str:
    """Rebuilds all 42 generated test tables with this folder's generator and compares them with data/ byte for
    byte."""
    bad = []
    for c in gen:
        dom, tid = c["domain"], c["id"]
        traps = tid.startswith("traps_")
        k = 0 if traps else int(tid.rsplit("_", 1)[1])
        case, rows, header = s1.build(tid, dom, k, traps)
        h = hashlib.sha256(csv_text(header, rows).encode("utf-8")).hexdigest()
        if not common.has_data(tid) or h != csv_sha256(tid):
            bad.append(tid)
    if bad:
        raise SystemExit("STOP: the generator no longer rebuilds %d test table(s) exactly: %s. Tell Claude."
                         % (len(bad), ", ".join(bad)))
    return "ok (all %d generated test tables rebuild byte for byte)" % len(gen)


def generated_prompt_check(gen: List[Dict[str, Any]], gen_train: List[Dict[str, Any]]) -> str:
    """Generated tables built in memory must give exactly the chunk prompts built from data/: two test tables and the
    first training table of two domains (rebuilt from their plan in cases_gen.json)."""
    by_id = {c["id"]: c for c in gen}
    jobs = [(by_id[cid], dom, k, False) for cid, dom, k in (("claims_01", "claims", 1), ("orders_03", "orders", 3))
            if cid in by_id]
    doms = []
    for c in gen_train:
        if c["domain"] not in doms and len(doms) < 2:
            doms.append(c["domain"])
            gp = c.get("gen_plan") or {}
            jobs.append((c, c["domain"], int(gp.get("k", 0)), bool(gp.get("traps"))))
    done = []
    for c, dom, k, traps in jobs:
        case, rows, header = s1.build(c["id"], dom, k, traps, v2=c["id"] not in by_id)
        mine = [ch["user"] for ch in s3.chunk_prompts(info_from_text(case, csv_text(header, rows)))]
        theirs = [ch["user"] for ch in s3.chunk_prompts(s3.chunk_info(c))]
        if mine != theirs:
            raise SystemExit("STOP: the chunk prompts built here for %s differ from those built from data/. Tell "
                             "Claude." % c["id"])
        done.append(c["id"])
    return ", ".join(done)


def columns_of(case_id: str) -> set:
    """The file's column names, the original target included, compared case- and punctuation-blind (so the same data
    under another target, or a copy with renamed case, still counts as the same columns)."""
    m = common.read_meta(case_id)
    names = set((m.get("columns") or {}).keys()) | ({str(m["target_original"])} if m.get("target_original") else set())
    return {common.norm_text(x) for x in names} - {""}


def norm_url(u: Any) -> str:
    return str(u or "").strip().lower().rstrip("/")


def raw_hashes(case_id: str) -> set:
    """sha256 of each downloaded source file in data/raw/<id>/ (empty if that folder is not here)."""
    d = common.raw_dir(case_id)
    out = set()
    if os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            p = os.path.join(d, fn)
            if os.path.isfile(p) and not fn.endswith(".part"):
                out.add(file_sha256(p))
    return out


def check_inputs() -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]]:
    """Every set, after the checks that need no prompt, and the training tables left out as near copies of test 5."""
    need = [common.CASES_FILE] + list(DISTILL_FILES.values()) + DEV_FILES + [GEN_FILE, TEST5_FILE]
    for f in need:
        if not os.path.exists(common.path(f)):
            raise SystemExit("%s is missing: run t0_import.py and t1_get_data.py first." % f)
    sets: Dict[str, List[Dict[str, Any]]] = {"generated test": [c for c in common.load_cases(quiet=True)
                                                                if c.get("url") == "generated"]}
    for src, f in DISTILL_FILES.items():
        sets[src] = [dict(c, _file=f) for c in common.load_cases(quiet=True, file=f)]
    sets["development"] = []
    for f in DEV_FILES:
        sets["development"] += [dict(c, _file=f) for c in common.load_cases(quiet=True, file=f)]
    sets["generated"] = [dict(c, _file=GEN_FILE) for c in common.load_cases(quiet=True, file=GEN_FILE)]
    sets["real test 5"] = common.load_cases(quiet=True, file=TEST5_FILE)
    if any(c["kind"] != "blind" for c in sets["real test 5"]):
        raise SystemExit("STOP: %s is not the blind file of the run 5 kit. Tell Claude." % TEST5_FILE)
    seen: Dict[str, str] = {}
    for name, cs in sets.items():
        for c in cs:
            where = c.get("_file") or name
            if c["id"] in seen:
                raise SystemExit("STOP: table id %s is in both %s and %s. Tell Claude." % (c["id"], seen[c["id"]], where))
            seen[c["id"]] = where
    no_data = [c["id"] for name in ("generated test", "development", "generated", "real test 5") for c in sets[name]
               if not common.has_data(c["id"])]
    if no_data:
        raise SystemExit("No data for %d table(s): %s -- run t0_import.py / t1_get_data.py first."
                         % (len(no_data), ", ".join(no_data[:15])))
    for src in DISTILL_FILES:
        missing = [c["id"] for c in sets[src] if not common.has_data(c["id"])]
        if missing:
            print("  note: %d %s table(s) have no data and are left out: %s"
                  % (len(missing), src, ", ".join(missing[:15])))
        sets[src] = [c for c in sets[src] if common.has_data(c["id"])]
    bad_dom = sorted({c.get("domain") for c in sets["generated"] if c.get("domain") not in TRAIN_DOMAINS})
    if bad_dom:
        raise SystemExit("STOP: %s holds tables of domains that are not training domains: %s. Tell Claude."
                         % (GEN_FILE, bad_dom))
    gen_ids = {c["id"] for c in sets["generated"]}
    gen_test_hash = {csv_sha256(c["id"]): c["id"] for c in sets["generated test"]}
    for c in sets["generated"]:
        h = csv_sha256(c["id"])
        if h in gen_test_hash:
            raise SystemExit("STOP: training table %s is the same file as generated test table %s. Tell Claude."
                             % (c["id"], gen_test_hash[h]))
        if h != c.get("csv_sha256"):
            raise SystemExit("STOP: data/%s.csv.gz is not the table %s describes. Tell Claude." % (c["id"], GEN_FILE))
        cols = set(common.read_meta(c["id"]).get("columns") or {})   # the key must fit the stored table
        keyed = set(c["leak_columns"]) | set(c.get("decoy_columns") or []) | set((c.get("trap_columns") or {}).keys())
        if not cols or keyed - cols:
            raise SystemExit("STOP: generated table %s lists columns that are not in its data: %s. Tell Claude."
                             % (c["id"], ", ".join(sorted(keyed - cols)[:5])))
    # test 5: no training table may come from the same file or have nearly the same columns
    test5 = sets["real test 5"]
    t5_url = {norm_url(c.get("url")): c["id"] for c in test5}
    t5_raw = {c["raw_sha256"]: c["id"] for c in test5 if c.get("raw_sha256")}
    for c in test5:
        for h in raw_hashes(c["id"]):
            t5_raw.setdefault(h, c["id"])
    t5_csv = {csv_sha256(c["id"]): c["id"] for c in test5}
    t5_cols = {c["id"]: columns_of(c["id"]) for c in test5}
    out_: List[Dict[str, Any]] = []
    for src in list(DISTILL_FILES) + ["development"]:
        keep = []
        for c in sets[src]:
            why, which = None, None
            h = csv_sha256(c["id"])
            if norm_url(c.get("url")) in t5_url:
                why, which = "same url", t5_url[norm_url(c.get("url"))]
            elif h in t5_csv:
                why, which = "same data", t5_csv[h]
            else:
                same = [t5_raw[x] for x in raw_hashes(c["id"]) if x in t5_raw]
                if same:
                    why, which = "same downloaded file", same[0]
                else:
                    cols = columns_of(c["id"])
                    for tid, tcols in t5_cols.items():
                        if cols and tcols and len(cols & tcols) / float(len(cols | tcols)) > NEAR_COPY_JACCARD:
                            why, which = "nearly the same columns (%.0f%%)" % (
                                100.0 * len(cols & tcols) / len(cols | tcols)), tid
                            break
            if why:
                out_.append({"table": c["id"], "file": c.get("_file"), "test5_table": which, "why": why})
            else:
                keep.append(c)
        sets[src] = keep
    for c in sets["generated"]:
        cols = columns_of(c["id"])
        for tid, tcols in t5_cols.items():
            if cols and tcols and len(cols & tcols) / float(len(cols | tcols)) > NEAR_COPY_JACCARD:
                raise SystemExit("STOP: generated training table %s has nearly the same columns as test 5 table %s. "
                                 "Tell Claude." % (c["id"], tid))
    unknown = [cid for cid in DEV_CATEGORY if cid not in {c["id"] for c in sets["development"]}]
    if unknown:
        print("  note: DEV_CATEGORY names tables that are not development tables here: %s" % ", ".join(unknown))
    return sets, out_


# ============================================================ main
def main() -> None:
    t0 = time.time()
    bad = [d for d in TRAIN_DOMAINS if d not in s1.DOMAINS] + [d for d in TRAIN_DOMAINS if d in HOLDOUT_DOMAINS]
    if bad:
        raise SystemExit("Fix TRAIN_DOMAINS / HOLDOUT_DOMAINS: %s" % bad)
    if REASON_TEACHER not in TEACHERS:
        raise SystemExit("REASON_TEACHER must be one of TEACHERS.")
    if (DISTILL_VARIANTS[:1] != ["real"] or DEV_VARIANTS[:1] != ["real"] or
            any(v not in VARIANT_NAMES for v in DISTILL_VARIANTS + DEV_VARIANTS)):
        raise SystemExit("DISTILL_VARIANTS and DEV_VARIANTS start with 'real' and name only %s." % (VARIANT_NAMES,))
    s3.MOCK = MOCK_TEACHERS   # the disguises are read from disguised/ (in a pipeline test: the mock writer's)
    s3.CLAUDE_MODEL, s3.GPT_MODEL, s3.DISGUISE_MODEL = t2.CLAUDE_MODEL, t2.GPT_MODEL, t2.DISGUISE_WRITER
    sets, near = check_inputs()
    gen_test, dev, gen, test5 = sets["generated test"], sets["development"], sets["generated"], sets["real test 5"]
    print("Training data for fine-tune run 5: %s (%s), %d development tables (%s), %d generated tables (%s; held "
          "out: %s). Teachers: %s; generated reasons from %s."
          % (" + ".join("%d %s" % (len(sets[s]), s) for s in DISTILL_FILES), ", ".join(DISTILL_VARIANTS), len(dev),
             ", ".join(DEV_VARIANTS), len(gen), ", ".join(TRAIN_DOMAINS), ", ".join(HOLDOUT_DOMAINS),
             ", ".join(teacher_labels()), reason_label()))
    if near:
        print("Left out as near copies of a test 5 table (%d): %s"
              % (len(near), "; ".join("%s (%s, %s)" % (x["table"], x["why"], x["test5_table"]) for x in near[:10])))
    print("Generator check: " + generator_check(gen_test))
    print("Same-prompt check (generated): ok (%s: the chunk prompts built in memory equal those from data/)"
          % generated_prompt_check(gen_test, gen))

    counts: Dict[str, Any] = {"examples": {}, "tables": {}, "tables_by_file": {}, "train": 0, "val": 0,
                              "val_tables": {}, "columns_rated": {}, "by_variant": {}, "risk_histogram": {},
                              "leaks_by_type": {}, "chars": 0, "chars_by_source": {}, "max_chars": 0,
                              "max_example": "", "teacher_coverage": {}, "reason_sources": {},
                              "disguised_reasons": {"kept": 0, "renamed": 0, "template": 0},
                              "disguise": {"used": 0, "missing": []}}
    left_out: List[Dict[str, Any]] = []
    info_checked: List[str] = []
    same_prompt_done: Dict[str, List[str]] = {s: [] for s in list(DISTILL_FILES) + ["development", "generated"]}
    stale: List[str] = []
    gpt_prompts = [0, 0]   # generated prompts with a GPT answer, generated prompts
    for p in (TRAIN_FILE, VAL_FILE, MANIFEST_FILE):   # a stopped run must never leave an older file that looks finished
        if os.path.exists(common.path(p)):
            os.remove(common.path(p))
    tmp_tr, tmp_va = common.path(TRAIN_FILE + ".tmp"), common.path(VAL_FILE + ".tmp")

    def put(ex: Dict[str, Any], val: bool, f_tr: Any, f_va: Any) -> None:
        (f_va if val else f_tr).write(json.dumps(ex, ensure_ascii=False) + "\n")
        src = ex["source"]
        counts["examples"][src] = counts["examples"].get(src, 0) + 1
        counts["val" if val else "train"] += 1
        vk = "%s %s" % (src, ex["variant_kind"])
        counts["by_variant"][vk] = counts["by_variant"].get(vk, 0) + 1
        n = sum(len(m["content"]) for m in ex["messages"])
        counts["chars"] += n
        counts["chars_by_source"][src] = counts["chars_by_source"].get(src, 0) + n
        if n > counts["max_chars"]:
            counts["max_chars"], counts["max_example"] = n, ex["id"]
        for e in json.loads(ex["messages"][2]["content"])["columns"]:
            counts["columns_rated"][src] = counts["columns_rated"].get(src, 0) + 1
            h = counts["risk_histogram"].setdefault(src, {})
            h[str(e["leak_risk"])] = h.get(str(e["leak_risk"]), 0) + 1

    def drifted(source: str, case: Dict[str, Any], chunks: List[Dict[str, Any]], labs: List[str]) -> bool:
        """Teacher-prompt drift: an answer cached for one of these chunk ids must have been made for exactly the
        prompt built here (otherwise the data or the prompt code changed after t2 ran)."""
        recs = [(lab, ch, cached_record(lab, ch)) for lab in labs for ch in chunks]
        drift = ["%s / %s" % (lab, ch["chunk_id"]) for lab, ch, rec in recs if rec and not same_prompt(rec, ch)]
        if drift:
            stale.append("%s (%d answers, e.g. %s)" % (case["id"], len(drift), drift[0]))
            return True
        if len(same_prompt_done[source]) < 2 and any(rec for _, _, rec in recs):
            same_prompt_done[source].append(case["id"])
        return False

    def used(source: str, case: Dict[str, Any], val: bool) -> None:
        counts["tables"][source] = counts["tables"].get(source, 0) + 1
        f = case.get("_file") or "?"
        counts["tables_by_file"][f] = counts["tables_by_file"].get(f, 0) + 1
        if val:
            counts["val_tables"][source] = counts["val_tables"].get(source, 0) + 1

    with open(tmp_tr, "w", encoding="utf-8") as f_tr, open(tmp_va, "w", encoding="utf-8") as f_va:
        # 1-2. public tables: the teachers' ratings (development tables kept on the key's side)
        jobs = [(s, sets[s], DISTILL_VARIANTS) for s in DISTILL_FILES] + [("development", dev, DEV_VARIANTS)]
        for source, cases, kinds in jobs:
            n_used = 0
            for n, case in enumerate(cases, 1):
                val = is_val(case["id"])
                df = common.read_data(case["id"])
                info = full_info(case, df)          # the real table (the teachers' prompts) and its disguise stats
                if source not in info_checked:      # once per source: exactly what step 3 builds (t2 used that)
                    if s3.writer_user(info) != s3.writer_user(s3.prepare_case(case)):
                        raise SystemExit("STOP: the table built here for %s differs from step 3's. Tell Claude."
                                         % case["id"])
                    info_checked.append(source)
                v1_chunks = s3.chunk_prompts(info)
                if drifted(source, case, v1_chunks, teacher_labels()):
                    continue
                ratings = teacher_ratings(v1_chunks, teacher_labels())
                cols = info["columns"]
                unrated = [c for c in cols if c not in ratings]
                if unrated:
                    left_out.append({"table": case["id"], "source": source,
                                     "why": "%d of %d columns have no teacher rating" % (len(unrated), len(cols))})
                    continue
                for c in cols:
                    k = "+".join(sorted(ratings[c]))
                    counts["teacher_coverage"][k] = counts["teacher_coverage"].get(k, 0) + 1
                tg = {c: target(case, c, ratings[c], source == "development") for c in cols}
                dz = r5.load_disguise(info) if "disguised" in kinds else None
                tools = disguise_tools(info, dz) if dz else None
                for v, kind in enumerate(kinds, 1):
                    meta = {"table": case["id"], "source": source, "variant": v, "variant_kind": kind}
                    if kind == "real":
                        for ch in v1_chunks:
                            put(example(ch, meta, [(c,) + tg[c] for c in ch["columns"]]), val, f_tr, f_va)
                    elif kind == "disguised" and dz:
                        for ch in r5.disguised_chunks(info, dz):
                            entries = []
                            for shown in ch["columns"]:
                                why, cat, risk = tg[ch["original"][shown]]
                                why2, how = disguised_reason(why, cat, tools)
                                counts["disguised_reasons"][how] += 1
                                entries.append((shown, why2, cat, risk))
                            put(example(ch, meta, entries), val, f_tr, f_va)
                    else:   # shuffled, and the stand-in for a missing disguise
                        if kind == "disguised":
                            meta["variant_kind"] = "shuffled (no disguise)"
                        for ch in s3.chunk_prompts(shuffled_info(case, df, v)):
                            put(example(ch, meta, [(c,) + tg[c] for c in ch["columns"]]), val, f_tr, f_va)
                if "disguised" in kinds:
                    if dz:
                        counts["disguise"]["used"] += 1
                    else:
                        counts["disguise"]["missing"].append(case["id"])
                used(source, case, val)
                n_used += 1
                if n % 200 == 0:
                    print("  %s: %d / %d tables (%.0f s)" % (source, n, len(cases), time.time() - t0))
            print("  %s: %d of %d tables used (%s)" % (source, n_used, len(cases), ", ".join(kinds)))
        # 3. generated tables, as stored: the prompts GPT answered
        n_used = 0
        for n, case in enumerate(gen, 1):
            val = is_val(case["id"])
            chunks = s3.chunk_prompts(s3.chunk_info(case))
            if drifted("generated", case, chunks, teacher_labels()):
                continue
            gpt = teacher_ratings(chunks, [reason_label()])
            gpt_prompts[0] += sum(1 for ch in chunks if teacher_answer(reason_label(), ch))
            gpt_prompts[1] += len(chunks)
            for ch in chunks:
                entries = []
                for c in ch["columns"]:
                    why, cat, risk, where, kind = generated_target(case, c, gpt.get(c, {}).get(reason_label()))
                    entries.append((c, why, cat, risk))
                    rs = counts["reason_sources"].setdefault(kind, {"gpt": 0, "template": 0})
                    rs[where] += 1
                meta = {"table": case["id"], "source": "generated", "variant": 1, "variant_kind": "real",
                        "domain": case.get("domain"), "style": case.get("naming_style"),
                        "trap_table": bool(case.get("trap_columns"))}
                put(example(ch, meta, entries), val, f_tr, f_va)
            for t in (case.get("leak_types") or {}).values():
                counts["leaks_by_type"][t] = counts["leaks_by_type"].get(t, 0) + 1
            used("generated", case, val)
            n_used += 1
            if n % 200 == 0 or n == len(gen):
                print("  generated: %d / %d tables (%.0f s)" % (n, len(gen), time.time() - t0))
        print("  generated: %d of %d tables used (as stored, 1 variant)" % (n_used, len(gen)))
        if stale:
            raise SystemExit("STOP: for %d table(s) the teachers' saved answers were made for other prompts than the "
                             "ones built here -- the data or the prompt code changed after t2_teachers.py ran: %s. "
                             "No training file was written. Tell Claude." % (len(stale), "; ".join(stale[:5])))
        for source in list(DISTILL_FILES) + ["development", "generated"]:
            if sets[source] and not counts["tables"].get(source):
                raise SystemExit("STOP: no %s table has a teacher rating for every column (run t2_teachers.py until "
                                 "it says everything is answered). No training file was written." % source)
            if source != "generated" and len(same_prompt_done[source]) < min(2, counts["tables"].get(source, 0)):
                raise SystemExit("STOP: the same-prompt check could not run for %s. Tell Claude." % source)
        if gen and not gpt_prompts[0]:
            raise SystemExit("STOP: %s has not rated the generated tables (%s) yet: run t2_teachers.py until it says "
                             "everything is answered. No training file was written." % (reason_label(), GEN_FILE))
        if not counts["disguise"]["used"]:
            raise SystemExit("STOP: no training table has a disguise (disguised/): run t2_teachers.py until it says "
                             "everything is answered. No training file was written.")
    os.replace(tmp_tr, common.path(TRAIN_FILE))   # only now: every check above has passed
    os.replace(tmp_va, common.path(VAL_FILE))
    est_tokens = counts["chars"] / TRAIN_CHARS_PER_TOKEN
    hist = {src: {str(r): h.get(str(r), 0) for r in range(0, 101, 5) if h.get(str(r))}
            for src, h in counts["risk_histogram"].items()}
    rs = counts["reason_sources"]
    manifest = {"created": common.stamp(), "run": 5, "examples": counts["examples"], "tables": counts["tables"],
                "tables_by_file": counts["tables_by_file"], "train": counts["train"], "val": counts["val"],
                "val_tables": counts["val_tables"], "by_variant": counts["by_variant"],
                "columns_rated": counts["columns_rated"], "risk_histogram": hist,
                "leaks_by_type_generated": dict(sorted(counts["leaks_by_type"].items())),
                "reason_sources_generated": {k: rs[k] for k in sorted(rs)},
                "generated_prompts_with_gpt_answer": {"answered": gpt_prompts[0], "prompts": gpt_prompts[1]},
                "disguised_copies": {"tables": counts["disguise"]["used"],
                                     "without_disguise": counts["disguise"]["missing"],
                                     "reasons": counts["disguised_reasons"]},
                "left_out_near_test5": near,
                "est_tokens": int(est_tokens),
                "est_tokens_by_source": {s: int(n / TRAIN_CHARS_PER_TOKEN) for s, n in counts["chars_by_source"].items()},
                "longest_example": {"id": counts["max_example"],
                                    "est_tokens": int(counts["max_chars"] / TRAIN_CHARS_PER_TOKEN)},
                "tables_left_out": left_out, "teachers": teacher_labels(), "reason_teacher": reason_label(),
                "same_prompt_checked": same_prompt_done, "teacher_coverage": counts["teacher_coverage"],
                "settings": {"train_domains": TRAIN_DOMAINS, "holdout_domains": HOLDOUT_DOMAINS,
                             "val_share": VAL_SHARE, "distill_variants": DISTILL_VARIANTS,
                             "dev_variants": DEV_VARIANTS, "row_share": list(ROW_SHARE), "seed": SEED,
                             "chunk_size": s3.CHUNK_SIZE, "generator_seed": s1.SEED, "generator_options": "v2",
                             "risk_leak": RISK_LEAK, "risk_fine": RISK_FINE, "near_copy_jaccard": NEAR_COPY_JACCARD},
                "test5_tables": [c["id"] for c in test5],
                "files": {TRAIN_FILE: file_sha256(common.path(TRAIN_FILE)),
                          VAL_FILE: file_sha256(common.path(VAL_FILE))}}
    common.write_json(common.path(MANIFEST_FILE), manifest)
    print("\n%d examples -> %s (%d) and %s (%d)" % (counts["train"] + counts["val"], TRAIN_FILE, counts["train"],
                                                   VAL_FILE, counts["val"]))
    print("Examples by source: %s; tables used: %s; validation tables: %s"
          % (counts["examples"], counts["tables"], counts["val_tables"]))
    print("Examples by copy: %s" % ", ".join("%s %d" % kv for kv in sorted(counts["by_variant"].items())))
    dr = counts["disguised_reasons"]
    print("Disguised copies: %d tables (%d without a usable disguise got a shuffled copy instead); reasons: %d kept, "
          "%d with the names changed, %d replaced by the short reason"
          % (counts["disguise"]["used"], len(counts["disguise"]["missing"]), dr["kept"], dr["renamed"], dr["template"]))
    print("Public table columns by the teachers that rated them: %s" % ", ".join(
        "%s %d" % kv for kv in sorted(counts["teacher_coverage"].items())))
    for src, h in hist.items():
        graded = sum(v for r, v in h.items() if r not in ("5", "95"))
        print("Target risks, %s: %s (%d of %d not 5 or 95)" % (src, ", ".join("%s: %d" % kv for kv in h.items()),
                                                              graded, sum(h.values())))
    n_gpt, n_tpl = sum(v["gpt"] for v in rs.values()), sum(v["template"] for v in rs.values())
    print("Generated reasons: %d from %s, %d templates (%d of %d generated prompts have a %s answer)."
          % (n_gpt, reason_label(), n_tpl, gpt_prompts[0], gpt_prompts[1], reason_label()))
    if left_out:
        print("Left out (%d tables): %s" % (len(left_out), "; ".join("%s (%s)" % (x["table"], x["why"])
                                                                      for x in left_out[:10])))
    print("About %.1f million tokens per pass (%s); longest example about %d tokens (%s; the notebook allows 8,192 and "
          "prints the exact counts)." % (est_tokens / 1e6, ", ".join("%s %.1fM" % (s, n / TRAIN_CHARS_PER_TOKEN / 1e6)
                                                                     for s, n in counts["chars_by_source"].items()),
                                         counts["max_chars"] / TRAIN_CHARS_PER_TOKEN, counts["max_example"]))
    print("None of the %d generated test tables was reproduced; no test 5 table (%d) is in the training data, and %d "
          "training table(s) were left out as near copies. %.0f s in all."
          % (len(gen_test), len(test5), len(near), time.time() - t0))
    print("Next: t4_make_test_prompts.py")


if __name__ == "__main__":
    main()
