# t7_label_review.py -- the hand labels of test 5 against its sealed answer key, BEFORE any model answer is scored.
# Python 3.9; press Run in PyCharm. Reads only the sealed key and the returned labeling workbooks: no model answer.
#
# Put each returned workbook (leak_labeling_test5_15_tables.xlsx, one per labeler, any file name) into the folder
# labels/, and test5_sealed_2026-10-26.zip into this folder (out of leak_private_keep.zip), then press Run.
# It checks each workbook (every shown cell as built; every label "leak" or "fine"), then lists every column where a
# labeler and the key disagree. Those are the only candidates for a key correction under the rule fixed at sealing:
#   a label changes only if (1) a labeler of the 15 tables disagrees, (2) an independent re-check finds documentation
#   or an exact data relation that supports the labeler, and (3) before any run 5 answer on test 5 is scored or opened.
# The re-check writes key_corrections.json (every change listed, with its evidence); t8_score.py applies it and also
# reports the results on the sealed key.
# Output: label_review_run5.txt and label_review_run5.json (send both to Claude).

LABELS_DIR = "labels"
OUT_FILE = "label_review_run5.txt"
OUT_JSON = "label_review_run5.json"

# ============================================================ internals
import glob
import os
import sys
from typing import Any, Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import r5_common as r5  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

FIRST_ROW = 9            # the first column row of each T.. sheet (row 8 holds the headers)
LINES: List[str] = []


def out(s: str = "") -> None:
    print(s)
    LINES.append(s)


def read_workbook(path: str, codes: Dict[str, str]) -> Dict[str, Any]:
    """{name, tables: {code: [(column, label, note, shown cells)]}, problems}"""
    cells = r5.read_xlsx(path)
    name = str((cells.get("Start here") or {}).get("B3") or "").strip() or os.path.splitext(os.path.basename(path))[0]
    tables: Dict[str, List[Tuple[str, str, str, List[Any]]]] = {}
    problems: List[str] = []
    for code in codes:
        sh = cells.get(code)
        if sh is None:
            problems.append("%s: no sheet" % code)
            continue
        rows = []
        r = FIRST_ROW
        while sh.get("A%d" % r) is not None:
            col = str(sh.get("B%d" % r))
            lab = str(sh.get("G%d" % r) or "").strip().lower()
            note = str(sh.get("H%d" % r) or "").strip()
            shown = [sh.get("%s%d" % (k, r)) for k in "ABCDEF"]
            rows.append((col, lab if lab in ("leak", "fine") else ("" if not lab else "?" + lab), note, shown))
            r += 1
        tables[code] = rows
    return {"file": os.path.basename(path), "name": name, "tables": tables, "problems": problems,
            "sentences": {code: [(cells.get(code) or {}).get("C%d" % k) for k in (3, 4, 5, 6)] for code in codes}}


def key_label(case: Dict[str, Any], col: str) -> str:
    if col in case["leak_columns"]:
        return "leak"
    if col in case["probable_leak_columns"]:
        return "probable"
    return "fine"


def kappa(a: List[str], b: List[str]) -> float:
    n = len(a)
    if not n:
        return float("nan")
    po = sum(1 for x, y in zip(a, b) if x == y) / float(n)
    cats = set(a) | set(b)
    pe = sum((a.count(c) / float(n)) * (b.count(c) / float(n)) for c in cats)
    return (po - pe) / (1 - pe) if pe < 1 else float("nan")


def main() -> None:
    sealed = r5.read_sealed(common.path(r5.SEALED_ZIP))
    cases = {c["id"]: c for c in sealed["cases"]}
    for c in cases.values():
        c.setdefault("probable_leak_columns", [])
    codes: Dict[str, str] = sealed["codes"]["codes"]
    files = sorted(glob.glob(os.path.join(common.path(LABELS_DIR), "*.xlsx")))
    files = [f for f in files if not os.path.basename(f).startswith("~$")]
    if not files:
        raise SystemExit("No workbook in %s/: put each returned labeling workbook there, then press Run again." % LABELS_DIR)
    out("Test 5 hand labels against the sealed key (%s) -- no model answer read" % common.stamp())
    books = [read_workbook(f, codes) for f in files]
    blind = {c["id"]: c for c in common.load_cases(quiet=True, file=r5.TEST5_FILE)}
    disagreements: List[Dict[str, Any]] = []
    stats = []
    for b in books:
        n_lab, n_blank, n_odd, view_bad, view_ties = 0, 0, 0, 0, 0
        agree = {"leak": [0, 0], "fine": [0, 0], "probable": [0, 0]}   # [labeler said leak, labeled]
        for code, rows in b["tables"].items():
            cid = codes[code]
            case = cases[cid]
            if common.has_data(cid):   # the shown cells must be what the model sees (rebuilt from data/ here)
                info = s3.chunk_info(blind[cid])
                want = [[k + 1, c, info["summaries"][c]["type"], "%.1f%%" % info["summaries"][c]["missing_pct"],
                         info["summaries"][c]["n_unique"], info["summaries"][c]["examples"] or "(no values)"]
                        for k, c in enumerate(info["columns"])]
                got = [list(x[3]) for x in rows]
                for w, g in zip(want, got):
                    if w[:5] == g[:5] and w[5] != g[5] and r5.ties_only(w[5], g[5]):
                        view_ties += 1      # only equally frequent categories listed in another order or choice
                    elif w != g:
                        view_bad += 1
                view_bad += abs(len(want) - len(got))
            for col, lab, note, _ in rows:
                kl = key_label(case, col)
                if lab in ("leak", "fine"):
                    n_lab += 1
                    agree[kl][1] += 1
                    agree[kl][0] += lab == "leak"
                    if (lab == "leak") != (kl == "leak") and kl != "probable":
                        disagreements.append({"labeler": b["name"], "code": code, "table": cid, "column": col,
                                              "labeler_label": lab, "key": kl, "note": note})
                    elif kl == "probable":
                        disagreements.append({"labeler": b["name"], "code": code, "table": cid, "column": col,
                                              "labeler_label": lab, "key": kl, "note": note, "info_only": True})
                elif lab == "":
                    n_blank += 1
                else:
                    n_odd += 1
        stats.append([b["name"], b["file"], n_lab, n_blank, n_odd,
                      "%d / %d" % tuple(agree["leak"]), "%d / %d" % tuple(agree["fine"]),
                      "%d / %d" % tuple(agree["probable"]), view_bad, view_ties, "; ".join(b["problems"]) or "-"])
    out(common.format_table(["labeler", "file", "labeled", "blank", "not leak/fine", "key leak: said leak",
                             "key fine: said leak", "key probable: said leak", "cells not as the model sees them",
                             "ties listed otherwise", "problems"], stats))
    out("(ties listed otherwise: example lists that differ only in which equally frequent categories are shown, or in "
        "their order; the workbook was built with another pandas version than the prompts)")
    if len(books) >= 2:
        out("Agreement between labelers (Cohen's kappa on the columns both labeled):")
        for i in range(len(books)):
            for j in range(i + 1, len(books)):
                a, bb = [], []
                for code in codes:
                    la = {c: l for c, l, _, _ in books[i]["tables"].get(code, []) if l in ("leak", "fine")}
                    lb = {c: l for c, l, _, _ in books[j]["tables"].get(code, []) if l in ("leak", "fine")}
                    for c in set(la) & set(lb):
                        a.append(la[c])
                        bb.append(lb[c])
                out("  %s vs %s: %d columns, kappa %.2f" % (books[i]["name"], books[j]["name"], len(a), kappa(a, bb)))
    real = [d for d in disagreements if not d.get("info_only")]
    out("")
    out("DISAGREEMENTS WITH THE KEY (%d; the only candidates for a correction):" % len(real))
    for d in sorted(real, key=lambda x: (x["code"], x["column"], x["labeler"])):
        out("  %s %s / %s: %s says %s, key %s%s" % (d["code"], d["table"], d["column"], d["labeler"], d["labeler_label"],
                                                    d["key"], (" -- note: " + d["note"]) if d["note"] else ""))
    info = [d for d in disagreements if d.get("info_only")]
    if info:
        out("")
        out("Debatable columns in the key (count neither way; listed for information): %d labels" % len(info))
    with open(common.path(OUT_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(LINES) + "\n")
    common.write_json(common.path(OUT_JSON), {"created": common.stamp(), "workbooks": [b["file"] for b in books],
                                             "labelers": [b["name"] for b in books], "disagreements": disagreements})
    print("\n-> %s and %s. Send both to Claude: the re-check of each disagreement comes next (key_corrections.json)."
          % (OUT_FILE, OUT_JSON))


if __name__ == "__main__":
    main()
