# t4_make_test_prompts.py -- writes test_prompts.jsonl: every prompt the models of fine-tune run 5 answer on the pod,
# in five groups. Python 3.9; press Run in PyCharm after t3_make_training.py. No calls.
#
#   training domains / held-out domains / trap tables   the 42 generated test tables (cases.json), as in run 4
#   real test 5                                          the 68 tables of test 5 (cases_test5_blind.json), as is
#   real test 5 disguised                                the same tables in GPT's disguise (disguised/<id>.json)
# The prompts are exactly the ones Claude and GPT answered in t2_teachers.py (checked below). The file holds no answer
# key: each line has the prompt, the names it shows, and for the disguised prompts the map back to the real columns.
# No training table (cases_distill*.json, cases_dev*.json, cases_gen*.json) is ever written here.
# Also writes test_manifest.json (prompts and tables per group, and the file's SHA-256): send it to Claude. Keep
# test_prompts.jsonl private (it is test 5) until the results are out.

TRAIN_DOMAINS = ["claims", "orders", "saas", "shipments"]   # must match t3_make_training.py
HOLDOUT_DOMAINS = ["lending", "hospital"]
MOCK = False                                                  # True: pipeline test only (mock disguises and answers)
TEST_FILE = "test_prompts.jsonl"
TEST_MANIFEST = "test_manifest.json"

# ============================================================ internals
import fnmatch
import json
import os
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import r5_common as r5  # noqa: E402
import step1_get_data as s1g  # noqa: E402
import step3_llm_audit as s3  # noqa: E402
import t2_teachers as t2  # noqa: E402  (only its model settings: the disguises were written with them)

TRAINING_PATTERNS = ["cases_distill*.json", "cases_dev*.json", "cases_gen*.json"]
EXPECTED = {"generated": 42, "test5": 68}


def group_of(case: Dict[str, Any]) -> str:
    if case.get("kind") == "blind":
        return r5.TEST5_REAL
    if case.get("trap_columns"):
        return "trap tables"
    if case.get("domain") in TRAIN_DOMAINS:
        return "training domains"
    if case.get("domain") in HOLDOUT_DOMAINS:
        return "held-out domains"
    return "other"


def answered(lab: str, ch: Dict[str, Any]) -> bool:
    rec = common.load_json(common.path("llm_cache", lab, "chunks", ch["chunk_id"] + ".json"))
    return bool(isinstance(rec, dict) and rec.get("parsed") and rec.get("model_id") and
                rec.get("prompt_hash") == common.text_hash(str(rec["model_id"]), s3.SYSTEM_PROMPT, ch["user"]))


def main() -> None:
    s3.MOCK = MOCK
    s3.CLAUDE_MODEL, s3.GPT_MODEL, s3.DISGUISE_MODEL = t2.CLAUDE_MODEL, t2.GPT_MODEL, t2.DISGUISE_WRITER
    if not os.path.exists(common.path(r5.TEST5_FILE)):
        raise SystemExit("%s is missing: it comes with the run 5 kit." % r5.TEST5_FILE)
    gen = [c for c in common.load_cases(quiet=True) if c.get("url") == "generated"]
    test5 = common.load_cases(quiet=True, file=r5.TEST5_FILE)
    if any(c["kind"] != "blind" or c.get("leak_columns") or c.get("probable_leak_columns") for c in test5):
        raise SystemExit("STOP: %s holds answer-key fields. Tell Claude." % r5.TEST5_FILE)
    training_ids: Dict[str, str] = {}
    for fn in sorted(os.listdir(HERE)):
        if any(fnmatch.fnmatch(fn, pat) for pat in TRAINING_PATTERNS):
            for c in common.load_cases(quiet=True, file=fn):
                training_ids[c["id"]] = fn
    cases: List[Dict[str, Any]] = gen + test5
    clash = sorted(c["id"] for c in cases if c["id"] in training_ids)
    if clash:
        raise SystemExit("STOP: a training table is in the test set: %s"
                         % ", ".join("%s (%s)" % (cid, training_ids[cid]) for cid in clash[:10]))
    ids = [c["id"] for c in cases]
    if len(set(ids)) != len(ids):
        raise SystemExit("STOP: a table id appears twice among the test tables.")
    missing = [c["id"] for c in cases if not common.has_data(c["id"])]
    if missing:
        raise SystemExit("No data for %d table(s): %s -- run t0_import.py / t1_get_data.py first."
                         % (len(missing), ", ".join(missing)))
    bad = []
    for c in test5:   # the prepared table must come from the frozen file
        p = os.path.join(common.raw_dir(c["id"]), s1g.file_name(c["url"]))
        m = common.read_meta(c["id"])
        if not os.path.exists(p) or r5.sha256_file(p) != c["raw_sha256"]:
            bad.append("%s (source file missing or changed)" % c["id"])
        elif m.get("url") != c["url"] or m.get("target_original") != c["target"]:
            bad.append("%s (prepared for another version of the case: run t1_get_data.py)" % c["id"])
    if bad:
        raise SystemExit("STOP: %d test 5 table(s): %s" % (len(bad), "; ".join(bad[:6])))
    other = [c["id"] for c in cases if group_of(c) == "other"]
    if other:
        raise SystemExit("STOP: generated test table(s) of no known domain: %s. Tell Claude." % ", ".join(other))
    print("Building the prompts of %d generated and %d test 5 tables ..." % (len(gen), len(test5)))
    rows: List[Dict[str, Any]] = []
    no_disguise = []
    for c in cases:
        g = group_of(c)
        if g == r5.TEST5_REAL:
            info = s3.prepare_case(c)
            chunks = r5.real_chunks(info)
            dz = r5.load_disguise(info)
            if dz:
                chunks += r5.disguised_chunks(info, dz)
            else:
                no_disguise.append(c["id"])
        else:
            chunks = r5.real_chunks(s3.chunk_info(c))
        if not chunks:
            raise SystemExit("STOP: test table %s has no columns besides the target. Tell Claude." % c["id"])
        for ch in chunks:
            grp = r5.TEST5_DISGUISED if ch["condition"] == "disguised" else g
            rows.append({"id": ch["chunk_id"], "table": c["id"], "group": grp, "condition": ch["condition"],
                         "part": ch["part"], "parts": ch["parts"], "system": s3.SYSTEM_PROMPT, "user": ch["user"],
                         "columns": ch["columns"], "original": ch["original"]})
    ids = [r["id"] for r in rows]
    if len(set(ids)) != len(ids):
        raise SystemExit("STOP: two prompts have the same id. Tell Claude.")
    tmp = common.path(TEST_FILE + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    os.replace(tmp, common.path(TEST_FILE))
    digest = r5.sha256_file(common.path(TEST_FILE))
    tables: Dict[str, set] = {}
    prompts: Dict[str, int] = {}
    for r in rows:
        tables.setdefault(r["group"], set()).add(r["table"])
        prompts[r["group"]] = prompts.get(r["group"], 0) + 1
    # the frontier models answered exactly these test 5 prompts?
    front = []
    t5rows = [r for r in rows if r["group"] in (r5.TEST5_REAL, r5.TEST5_DISGUISED)]
    for m in t2.TEACHERS:
        lab = ("mock-" if MOCK else "") + m
        n = sum(1 for r in t5rows if answered(lab, {"chunk_id": r["id"], "user": r["user"]}))
        front.append([lab, "%d / %d" % (n, len(t5rows))])
    common.write_json(common.path(TEST_MANIFEST),
                      {"run": 5, "prompts": len(rows), "tables": len(cases), "sha256": digest,
                       "by_group": {g: {"tables": len(tables.get(g, ())), "prompts": prompts.get(g, 0)}
                                    for g in r5.GROUPS},
                       "test5_without_disguise": no_disguise, "frontier_answers": dict(front),
                       "created": common.stamp()})
    print(common.format_table(["group", "tables", "prompts"],
                              [[g, len(tables.get(g, ())), prompts.get(g, 0)] for g in r5.GROUPS] +
                              [["all", len(cases), len(rows)]]))
    print("%d prompts -> %s (sha256 %s...)" % (len(rows), TEST_FILE, digest[:16]))
    if no_disguise:
        print("Test 5 tables without a usable disguise (left out of the disguised group): %s" % ", ".join(no_disguise))
    print("Test 5 prompts the frontier models answered in t2 (exactly these prompts): %s"
          % "; ".join("%s %s" % tuple(x) for x in front))
    if len(gen) != EXPECTED["generated"] or len(test5) != EXPECTED["test5"]:
        print("  note: expected %d generated and %d test 5 tables, found %d and %d: tell Claude"
              % (EXPECTED["generated"], EXPECTED["test5"], len(gen), len(test5)))
    if any(int(x[1].split(" / ")[0]) < len(t5rows) for x in front):
        print("  note: not every test 5 prompt has a frontier answer: run t2_teachers.py until it says everything is "
              "answered, then this again.")
    print("Next: t6_baselines.py.")


if __name__ == "__main__":
    main()
