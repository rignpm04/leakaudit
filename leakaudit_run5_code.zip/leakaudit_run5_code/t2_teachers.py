# t2_teachers.py -- every call to Claude and GPT that fine-tune run 5 needs, in three steps. Python 3.9; press Run in
# PyCharm after t1_get_data.py.
#
#   1. Training ratings: both teachers rate every column of the public training tables (cases_distill*.json) and the
#      development tables (cases_dev*.json, now with real test 4 as cases_dev4.json); GPT also rates the generated
#      training tables (cases_gen.json; only its reasons are used). Run 4's saved answers are reused, so this step
#      should ask (almost) nothing.
#   2. Disguises: GPT rewrites each public training and development table and each test 5 table once (new column names,
#      labels and task text; saved in disguised/). t3 trains on the disguised copies too; t4 tests every model on test
#      5's disguised copies.
#   3. Test 5, blind: both models answer test 5's prompts, real and disguised (the same prompts the small model gets),
#      the recognition question for each table (real and disguised: which public dataset is it?), and the
#      sentences-only question (from the task sentences alone, how likely is a leak?). The answers are saved, never
#      scored here: this folder has no answer key. t8_score.py scores them after the key is final.
#
# How to run:
#   1. DRY_RUN = True (as shipped): prints, per step, what is still to ask, the cost and the time. No calls.
#   2. Paste your two keys below (only here, on your Mac; never into a chat, never send this file with keys in it),
#      set DRY_RUN = False, press Run. Every answer is saved as soon as it arrives.
#   3. Press Run again until it says everything is answered (a stopped run resumes; a finished one costs nothing).
# At the end it writes teacher_summary.txt: answers per model, cost, the teachers' agreement and their recall on the
# development tables (sanity checks), the disguises written, and what test 5 has (counts only, no scores).

ANTHROPIC_API_KEY = "PASTE_ANTHROPIC_KEY_HERE"
OPENAI_API_KEY = "PASTE_OPENAI_KEY_HERE"

DRY_RUN = True                 # True: estimate only, no calls. False: call the models.
TEACHERS = ["claude", "gpt"]
REASON_TEACHERS = ["gpt"]      # the teachers asked on cases_gen.json (only their reasons are used there)
DISGUISE_WRITER = "gpt"
CLAUDE_MODEL = "claude-sonnet-5-5"
GPT_MODEL = "gpt-6.1-sol"
WORKERS = 8                    # calls running at the same time, per model
MAX_TOKENS = 8000              # cap on one answer
MOCK = False                   # True: fake offline models (pipeline test only; labels mock-claude, mock-gpt)

TRAIN_FILES = ["cases_distill.json", "cases_distill2.json", "cases_dev.json", "cases_dev2.json", "cases_dev3.json",
               "cases_dev4.json"]
GEN_FILE = "cases_gen.json"
OUT_TOKENS_PER_COLUMN = 45     # cost estimate only: answer tokens per rated column
REASONING_TOKENS_EST = 300     # cost estimate only: GPT's hidden reasoning tokens per call
SECONDS_PER_CALL_EST = 15      # time estimate only
EST_DISGUISE = 0.035           # cost estimate only: dollars per disguise written
EST_PROBE = 0.004              # cost estimate only: dollars per recognition question
EST_SENTENCES = 0.003          # cost estimate only: dollars per sentences-only question

# ============================================================ internals
import hashlib
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import r5_common as r5  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402

SUMMARY_FILE = "teacher_summary.txt"
FRONTIER_MANIFEST = "frontier_manifest.json"
LOG_FILE = "t2_log.txt"
DEV_FILES = ["cases_dev.json", "cases_dev2.json", "cases_dev3.json", "cases_dev4.json"]
KEY_LEAK_TYPES = ("outcome_status", "post_event_date", "snapshot_state", "outcome_only_sparse", "post_aggregate",
                  "target_derived", "identifier", "target_part", "event_measure", "assigned_during", "followup_time")
_lock = threading.Lock()
DISABLED: Dict[str, str] = {}
LINES: List[str] = []


def setup() -> None:
    s3.ANTHROPIC_API_KEY = ANTHROPIC_API_KEY
    s3.OPENAI_API_KEY = OPENAI_API_KEY
    s3.CLAUDE_MODEL = CLAUDE_MODEL
    s3.GPT_MODEL = GPT_MODEL
    s3.MAX_TOKENS = MAX_TOKENS
    s3.MOCK = MOCK
    s3.DISGUISE_MODEL = DISGUISE_WRITER


def label(m: str) -> str:
    return ("mock-" if MOCK else "") + m


def used_model_id(m: str) -> str:
    """The model id stamped on each answer (and inside its prompt hash)."""
    return ("mock:" if MOCK else "") + s3.model_id(m)


def prompt_hash(model_id: str, user: str, system: str = s3.SYSTEM_PROMPT) -> str:
    return common.text_hash(model_id, system, user)


def cache_path(lab: str, chunk_id: str) -> str:
    return common.path("llm_cache", lab, "chunks", chunk_id + ".json")


def load_chunk_answer(lab: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The cached answer of one model to one chunk prompt, if it answers exactly today's prompt."""
    rec = common.load_json(cache_path(lab, ch["chunk_id"]))
    if not (isinstance(rec, dict) and rec.get("parsed") and rec.get("model_id")):
        return None
    if rec.get("prompt_hash") != prompt_hash(str(rec["model_id"]), ch["user"]):
        return None
    return rec


def out(s: str = "") -> None:
    with _lock:
        print(s)
        LINES.append(s)


def log(msg: str) -> None:
    with _lock:
        print(msg)
        try:
            with open(common.path(LOG_FILE), "a", encoding="utf-8") as f:
                f.write("%s  %s%s\n" % (common.stamp(), "[mock] " if MOCK else "", " ".join(str(msg).split())))
        except OSError:
            pass


def disable(m: str, why: str) -> None:
    with _lock:
        first = m not in DISABLED
        DISABLED[m] = why
    if first:
        log("  %s: no more calls this run -- %s" % (m, why))


def teachers_for(fname: str) -> List[str]:
    if fname == GEN_FILE:
        return [m for m in TEACHERS if m in REASON_TEACHERS]
    return list(TEACHERS)


# ============================================================ the tables and their prompts
def load_tables(files: List[str], disguise_info: bool = False
                ) -> List[Tuple[str, Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]]:
    """(file, case, info, real chunk prompts) for every case with data. With disguise_info, info is step3's
    prepare_case (it holds what a disguise needs; its prompts are the same)."""
    rows: List[Tuple[str, Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]] = []
    seen: Dict[str, str] = {}
    for fname in files:
        if not os.path.exists(common.path(fname)):
            print("  %s: not in this folder -- skipped" % fname)
            continue
        cases = common.load_cases(quiet=True, file=fname)
        no_data = []
        for c in cases:
            if c["id"] in seen:
                raise SystemExit("STOP: table %s is in both %s and %s. Tell Claude." % (c["id"], seen[c["id"]], fname))
            seen[c["id"]] = fname
            if not common.has_data(c["id"]):
                no_data.append(c["id"])
                continue
            info = s3.prepare_case(c) if disguise_info else s3.chunk_info(c)
            rows.append((fname, c, info, r5.real_chunks(info)))
        if no_data:
            print("  %s: %d table(s) have no data (run t0_import.py / t1_get_data.py): %s"
                  % (fname, len(no_data), ", ".join(no_data[:12]) + (" ..." if len(no_data) > 12 else "")))
    return rows


# ============================================================ one chunk answer (with one retry)
def ask(m: str, ch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    lab = label(m)
    cols = ch["columns"]
    t0 = time.time()
    text1, u1, stop1 = s3.call_model(m, s3.SYSTEM_PROMPT, ch["user"])
    usage = dict(u1)
    p1 = s3.parse_answer(s3.strip_think(text1), cols)
    found = dict(p1["entries"]) if p1 else {}
    unknown = list(p1["unknown"]) if p1 else []
    missing = [c for c in cols if c not in found]
    text2, stop2 = None, None
    if p1 is None or missing:   # unreadable, or any column left out: ask once more
        why = "answer not readable" if p1 is None else "%d of %d columns missing" % (len(missing), len(cols))
        log("  %s / %s: %s (stop: %s) -- asking once more" % (lab, ch["chunk_id"], why, stop1 or "?"))
        reminder = s3.chunk_reminder(cols, None if p1 is None else [s3.shown_name(c) for c in missing])
        text2, u2, stop2 = s3.call_model(m, s3.SYSTEM_PROMPT, ch["user"] + "\n\n" + reminder)
        usage = s3.add_usage(usage, u2)
        p2 = s3.parse_answer(s3.strip_think(text2), cols)
        if p2:
            for c, e in p2["entries"].items():
                found.setdefault(c, e)
            unknown += p2["unknown"]
    cost = 0.0 if MOCK else s3.cost_of(m, usage)
    if not found:
        cut = any(w in str(stop2 or stop1).lower() for w in ("length", "max_tokens", "max_output_tokens"))
        log("  %s / %s: no usable answer after one retry -- not saved; press Run again later.%s It began: %r"
            % (lab, ch["chunk_id"], " The answer was cut off: raise MAX_TOKENS." if cut else "",
               (text2 if text2 is not None else text1)[:300]))
        return {"failed": True, "cost": cost}
    left_out = [c for c in cols if c not in found]
    if left_out:
        log("  %s / %s: no answer for %d column(s): %s" % (lab, ch["chunk_id"], len(left_out), ", ".join(left_out)))
    mid = used_model_id(m)
    rec = {"case_id": ch["table"], "chunk_id": ch["chunk_id"], "model": lab, "model_id": mid,
           "prompt_hash": prompt_hash(mid, ch["user"]), "timestamp": common.stamp(), "prompt": ch["user"],
           "raw": text1, "raw_retry": text2, "stop": [stop1, stop2],
           "parsed": {"columns": found, "missing": left_out, "unknown_names": unknown},
           "usage": usage, "cost": round(cost, 6), "seconds": round(time.time() - t0, 1)}
    common.write_json(cache_path(lab, ch["chunk_id"]), rec)
    return rec


def run_pool(m: str, todo: List[Any], fn: Any, what: str) -> Dict[str, Any]:
    """Runs fn(item) for every item, WORKERS at a time; progress every 25. fn returns a record or None/failed."""
    st = {"done": 0, "failed": 0, "cost": 0.0, "fails_in_a_row": 0}
    if not todo:
        return st
    t0 = time.time()

    def one(item: Any) -> None:
        if m in DISABLED:
            return
        try:
            rec = fn(item)
        except common.ApiError as e:
            text = str(e).lower()
            if e.code in (401, 402, 403, 404) or "insufficient_quota" in text or "credit balance" in text:
                disable(m, "HTTP %d: check the key at the top, its credit, and the model id (%s)"
                        % (e.code, s3.model_id(m)))
            log("  %s / %s: API error: %s" % (label(m), what, " ".join(str(e).split())[:400]))
            rec = {"failed": True, "cost": 0.0}
        except Exception as e:  # one call failing must not stop the run
            log("  %s / %s: ERROR %s: %s" % (label(m), what, e.__class__.__name__, " ".join(str(e).split())[:400]))
            rec = {"failed": True, "cost": 0.0}
        with _lock:
            st["cost"] += float((rec or {}).get("cost") or 0.0)
            if not rec or rec.get("failed"):
                st["failed"] += 1
                if not (rec or {}).get("content"):   # an unusable disguise is not a sign of a broken connection
                    st["fails_in_a_row"] += 1
            else:
                st["done"] += 1
                st["fails_in_a_row"] = 0
            n = st["done"] + st["failed"]
            stop_now = st["fails_in_a_row"] >= 10
        if stop_now:
            disable(m, "10 calls in a row failed -- see %s, then press Run again" % LOG_FILE)
        if n % 25 == 0 or n == len(todo):
            el = time.time() - t0
            print("  %s, %s: %d / %d (%d failed), %.0f min, about %.0f min left, $%.2f so far"
                  % (label(m), what, n, len(todo), st["failed"], el / 60, el / max(n, 1) * (len(todo) - n) / 60,
                     st["cost"]))

    with ThreadPoolExecutor(max_workers=max(1, int(WORKERS))) as pool:
        futures = [pool.submit(one, it) for it in todo]
        for f in as_completed(futures):
            f.result()
    return st


def both(jobs: Dict[str, Tuple[List[Any], Any, str]]) -> Dict[str, Dict[str, Any]]:
    """The models' job lists side by side, each with its own WORKERS."""
    stats: Dict[str, Dict[str, Any]] = {}
    threads = []
    for m, (todo, fn, what) in jobs.items():
        th = threading.Thread(target=lambda m=m, todo=todo, fn=fn, what=what:
                              stats.__setitem__(m, run_pool(m, todo, fn, what)))
        th.start()
        threads.append(th)
    for th in threads:
        th.join()
    return stats


# ============================================================ the sentences-only question (cached)
def sentences_path(lab: str, cid: str) -> str:
    return common.path("llm_cache", lab, "sentences", cid + ".json")


def load_sentences(m: str, case: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    rec = common.load_json(sentences_path(label(m), case["id"]))
    user = r5.sentences_user(case)
    if (isinstance(rec, dict) and rec.get("parsed") and
            rec.get("prompt_hash") == prompt_hash(str(rec.get("model_id")), user, r5.SENTENCES_SYSTEM)):
        return rec
    return None


def ask_sentences(m: str, case: Dict[str, Any]) -> Dict[str, Any]:
    user = r5.sentences_user(case)
    t0 = time.time()
    if MOCK:
        lik = 40 + (int(common.text_hash("sent", m, case["id"])[:4], 16) % 50)
        text1, usage, stop1 = '{"likelihood": %d, "reason": "mock"}' % lik, {"in": len(user) // 4, "out": 12}, "stop"
    else:
        text1, usage, stop1 = s3.call_model(m, r5.SENTENCES_SYSTEM, user, r5.SENTENCES_MAX_TOKENS)
    parsed = r5.parse_sentences(s3.strip_think(text1))
    text2 = None
    if parsed is None and not MOCK:
        text2, u2, _ = s3.call_model(m, r5.SENTENCES_SYSTEM, user + "\n\nReminder: answer with the json object only.",
                                     r5.SENTENCES_MAX_TOKENS)
        usage = s3.add_usage(usage, u2)
        parsed = r5.parse_sentences(s3.strip_think(text2))
    cost = 0.0 if MOCK else s3.cost_of(m, usage)
    if parsed is None:
        log("  %s / sentences / %s: no readable answer -- not saved" % (label(m), case["id"]))
        return {"failed": True, "cost": cost}
    mid = used_model_id(m)
    rec = {"case_id": case["id"], "model": label(m), "model_id": mid,
           "prompt_hash": prompt_hash(mid, user, r5.SENTENCES_SYSTEM), "timestamp": common.stamp(), "prompt": user,
           "raw": text1, "raw_retry": text2, "parsed": parsed, "usage": usage, "cost": round(cost, 6),
           "seconds": round(time.time() - t0, 1)}
    common.write_json(sentences_path(label(m), case["id"]), rec)
    return rec


# ============================================================ fingerprints of the test 5 answers
def frontier_manifest(chunks5: List[Dict[str, Any]], pjobs: List[Tuple[Dict[str, Any], str, str]],
                      cases5: List[Dict[str, Any]]) -> None:
    """The SHA-256 of every saved test 5 answer (prompts, recognition, sentences-only), per model, and one SHA-256
    over each model's list: published before any scoring, so nobody can change an answer afterwards unseen."""
    rec: Dict[str, Any] = {"run": 5, "created": common.stamp(), "models": {}, "files": {}}
    for m in TEACHERS:
        lab = label(m)
        paths = [cache_path(lab, ch["chunk_id"]) for ch in chunks5]
        paths += [common.path("llm_cache", s3.label(m), "probe_" + cond, info["id"] + ".json") for info, cond, _ in pjobs]
        paths += [sentences_path(lab, c["id"]) for c in cases5]
        got = []
        for p in paths:
            if os.path.exists(p):
                rel = os.path.relpath(p, HERE).replace(os.sep, "/")
                h = r5.sha256_file(p)
                rec["files"][rel] = h
                got.append("%s %s" % (rel, h))
        rec["models"][lab] = {"model_id": used_model_id(m), "files": len(got), "expected": len(paths),
                              "sha256_of_list": hashlib.sha256("\n".join(got).encode("utf-8")).hexdigest()}
    common.write_json(common.path(FRONTIER_MANIFEST), rec)


# ============================================================ estimate
def chunk_cost(m: str, todo: List[Dict[str, Any]]) -> Tuple[float, float]:
    """(dollars, minutes) to ask these chunk prompts."""
    tin = sum(len(s3.SYSTEM_PROMPT) + len(ch["user"]) for ch in todo) / s3.CHARS_PER_TOKEN
    tout = sum(len(ch["columns"]) for ch in todo) * OUT_TOKENS_PER_COLUMN + \
        (REASONING_TOKENS_EST * len(todo) if m == "gpt" else 0)
    p = s3.PRICE_PER_M.get(s3.model_id(m)) or s3.PRICE_PER_M.get(m) or (0.0, 0.0)
    return (tin * p[0] + tout * p[1]) / 1e6, len(todo) * SECONDS_PER_CALL_EST / max(1, WORKERS) / 60.0


# ============================================================ summary (training part: as in run 4)
def merged(lab: str, chunks: List[Dict[str, Any]]) -> Dict[str, Tuple[float, str]]:
    got: Dict[str, Tuple[float, str]] = {}
    for ch in chunks:
        rec = load_chunk_answer(lab, ch)
        if rec:
            for c, e in (rec["parsed"].get("columns") or {}).items():
                v = s3.to_risk((e or {}).get("leak_risk"))
                if np.isfinite(v):
                    got[c] = (v, s3.norm_category((e or {}).get("category")))
    return got


def training_summary(tables: List[Tuple[str, Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]]) -> None:
    rows = []
    risks: Dict[str, Dict[str, Dict[str, Tuple[float, str]]]] = {}
    for m in TEACHERS:
        lab = label(m)
        answered, cost, cols, n_chunks, n_cols = 0, 0.0, 0, 0, 0
        for fname, case, _, chunks in tables:
            if m not in teachers_for(fname):
                continue
            n_chunks += len(chunks)
            n_cols += sum(len(ch["columns"]) for ch in chunks)
            for ch in chunks:
                rec = load_chunk_answer(lab, ch)
                if rec:
                    answered += 1
                    cost += float(rec.get("cost") or 0.0)
            r = merged(lab, chunks)
            risks.setdefault(lab, {})[case["id"]] = r
            cols += len(r)
        rows.append([lab, "%d / %d" % (answered, n_chunks), "%d / %d" % (cols, n_cols), "$%.2f" % cost,
                     DISABLED.get(m, "")])
    out("1. Training ratings")
    out(common.format_table(["teacher", "prompts answered", "columns rated", "cost (all answers)", "stopped because"],
                            rows))
    labs = [label(m) for m in TEACHERS]
    if len(labs) == 2:
        agree, diffs = 0, []
        for _, case, _, _ in tables:
            a, b = risks[labs[0]].get(case["id"], {}), risks[labs[1]].get(case["id"], {})
            for c in set(a) & set(b):
                agree += (a[c][0] >= 50) == (b[c][0] >= 50)
                diffs.append(abs(a[c][0] - b[c][0]))
        if diffs:
            out("Agreement: on %d columns both rated, flag / no flag at risk 50 agree for %.1f%%; mean difference "
                "%.1f points." % (len(diffs), 100.0 * agree / len(diffs), float(np.mean(diffs))))
    dev = [(f, c) for f, c, _, _ in tables if f in DEV_FILES]
    if dev:
        out("Sanity check on the development tables (documented leaks; flag at risk >= 50):")
        rows = []
        for lab in labs:
            for fname in DEV_FILES:
                cases = [c for f, c in dev if f == fname]
                if not cases:
                    continue
                rec, ff, answered = [], 0, 0
                for c in cases:
                    r = risks[lab].get(c["id"], {})
                    if not r:
                        continue
                    answered += 1
                    leaks, skip = set(c["leak_columns"]), set(c["probable_leak_columns"])
                    flagged = {k for k, v in r.items() if v[0] >= 50}
                    ff += len(flagged - leaks - skip)
                    if leaks:
                        rec.append(len(flagged & leaks) / float(len(leaks)))
                rows.append([lab, fname, "%d / %d" % (answered, len(cases)),
                             "%.2f" % float(np.mean(rec)) if rec else "-", ff])
        out(common.format_table(["teacher", "tables", "answered", "macro recall", "false flags"], rows))
    gen = [c for f, c, _, _ in tables if f == GEN_FILE]
    if gen:
        for m in TEACHERS:
            if m in teachers_for(GEN_FILE):
                generated_check(label(m), [(c, risks[label(m)].get(c["id"], {})) for c in gen])


def generated_check(lab: str, gen: List[Tuple[Dict[str, Any], Dict[str, Tuple[float, str]]]]) -> None:
    """GPT on the generated training tables against the generator's key, flag at risk >= 50 (as in run 4)."""
    rec, ff, answered, dec_hit, dec_n, trap_hit, trap_n = [], 0, 0, 0, 0, 0, 0
    agree_leak, n_leak, agree_fine, n_fine = 0, 0, 0, 0
    for c, r in gen:
        if not r:
            continue
        answered += 1
        types = c.get("leak_types") or {}
        leaks = {x for x, t in types.items() if t in KEY_LEAK_TYPES}
        skip = {x for x, t in types.items() if t not in KEY_LEAK_TYPES}
        decoys, traps = set(c.get("decoy_columns") or []), set((c.get("trap_columns") or {}).keys())
        flagged = {x for x, (v, _) in r.items() if v >= 50}
        ff += len(flagged - leaks - skip)
        dec_hit += len(flagged & decoys)
        dec_n += len(decoys & set(r))
        trap_hit += len(flagged & traps)
        trap_n += len(traps & set(r))
        rated_leaks = [x for x in leaks if x in r]
        if rated_leaks:
            rec.append(len(flagged & leaks) / float(len(rated_leaks)))
        for x, (v, cat) in r.items():
            if x in leaks:
                n_leak += 1
                agree_leak += v >= 50 and cat != "fine"
            else:
                n_fine += 1
                agree_fine += v < 50 and cat == "fine"
    out("%s on the generated training tables against the generator's key:" % lab)
    out(common.format_table(["teacher", "tables answered", "macro recall", "false flags per table", "decoys flagged",
                             "trap columns flagged"],
                            [[lab, "%d / %d" % (answered, len(gen)), "%.2f" % float(np.mean(rec)) if rec else "-",
                              "%.2f" % (ff / float(max(answered, 1))), "%d / %d" % (dec_hit, dec_n),
                              "%d / %d" % (trap_hit, trap_n)]]))
    out("  reasons usable in training: %d of %d leak columns, %d of %d fine columns (the others get a template)."
        % (agree_leak, n_leak, agree_fine, n_fine))


# ============================================================ main
def main() -> None:
    setup()
    bad = [m for m in TEACHERS if m not in ("claude", "gpt")] + [m for m in REASON_TEACHERS if m not in TEACHERS]
    if bad or DISGUISE_WRITER not in ("claude", "gpt"):
        raise SystemExit("TEACHERS may only name 'claude' and 'gpt'; REASON_TEACHERS and DISGUISE_WRITER one of them.")
    mode = "MOCK -- fake offline models" if MOCK else ("DRY RUN" if DRY_RUN else "LIVE")
    print("Run 5 calls [%s]: %s; disguises by %s" % (mode, ", ".join("%s (%s)" % (m, s3.model_id(m)) for m in TEACHERS),
                                                     DISGUISE_WRITER))
    if not DRY_RUN and not MOCK:
        for m in TEACHERS:
            k = {"claude": ANTHROPIC_API_KEY, "gpt": OPENAI_API_KEY}[m].strip()
            if not k or k.startswith("PASTE_"):
                raise SystemExit("Paste your %s key at the top, then press Run again."
                                 % ("Anthropic" if m == "claude" else "OpenAI"))
    t0 = time.time()
    print("Reading the tables (a few minutes) ...")
    train = load_tables(list(TRAIN_FILES), disguise_info=True) + load_tables([GEN_FILE])
    test5 = load_tables([r5.TEST5_FILE], disguise_info=True)
    if not train or len(test5) < 60:
        raise SystemExit("Too few tables with data (training %d, test 5 %d): run t0_import.py and t1_get_data.py first."
                         % (len(train), len(test5)))
    print("  %d training tables, %d test 5 tables (%.0f s)" % (len(train), len(test5), time.time() - t0))

    # what is still to ask
    def todo_train(m: str) -> List[Dict[str, Any]]:
        return [ch for f, _, _, chunks in train if m in teachers_for(f) for ch in chunks
                if load_chunk_answer(label(m), ch) is None]
    dz_rows = [(f, c, info) for f, c, info, _ in train if f != GEN_FILE] + [(f, c, info) for f, c, info, _ in test5]
    failed_before = common.load_json(common.path(r5.DISGUISE_FAILED_FILE)) or {}
    dz_todo = [(f, c, info) for f, c, info in dz_rows
               if r5.load_disguise(info) is None and c["id"] not in failed_before]

    def test5_chunks() -> List[Dict[str, Any]]:
        chunks = []
        for _, c, info, real in test5:
            chunks += real
            dz = r5.load_disguise(info)
            if dz:
                chunks += r5.disguised_chunks(info, dz)
        return chunks

    def probe_jobs() -> List[Tuple[Dict[str, Any], str, str]]:
        jobs = []
        for _, c, info, _ in test5:
            jobs.append((info, "real", s3.probe_user(info, "real", None)))
            dz = r5.load_disguise(info)
            if dz:
                jobs.append((info, "disguised", s3.probe_user(info, "disguised", dz)))
        return jobs

    def probe_done(m: str, job: Tuple[Dict[str, Any], str, str]) -> bool:
        rec = common.load_json(common.path("llm_cache", s3.label(m), "probe_" + job[1], job[0]["id"] + ".json"))
        return bool(isinstance(rec, dict) and rec.get("prompt_hash") ==
                    common.text_hash(s3.model_id(m), s3.PROBE_SYSTEM, job[2]))

    if DRY_RUN and not MOCK:
        rows, total, step_min = [], 0.0, [0.0, 0.0, 0.0]
        for m in TEACHERS:
            tt = todo_train(m)
            cost, mins = chunk_cost(m, tt)
            total += cost
            step_min[0] = max(step_min[0], mins)
            rows.append(["1. training ratings", m, len(tt), "$%.2f" % cost, "%.0f" % mins])
        step_min[1] = len(dz_todo) * 30 / max(1, WORKERS) / 60.0
        rows.append(["2. disguises (%d tables still without one)" % len(dz_todo), DISGUISE_WRITER, len(dz_todo),
                     "$%.2f" % (len(dz_todo) * EST_DISGUISE), "%.0f" % step_min[1]])
        total += len(dz_todo) * EST_DISGUISE
        n_dis_t5 = sum(1 for _, c, _ in dz_todo if c.get("kind") == "blind")
        for m in TEACHERS:
            ch = [x for x in test5_chunks() if load_chunk_answer(label(m), x) is None]
            extra = sum(len(s3.chunk_parts(info["columns"])) for f, c, info in dz_todo if c.get("kind") == "blind")
            cost, mins = chunk_cost(m, ch)
            cost += extra * (cost / max(1, len(ch)) if ch else 0.012)
            pj = [j for j in probe_jobs() if not probe_done(m, j)] + [None] * n_dis_t5
            sj = [c for _, c, _, _ in test5 if load_sentences(m, c) is None]
            cost += len(pj) * EST_PROBE + len(sj) * EST_SENTENCES
            total += cost
            mins += (extra * SECONDS_PER_CALL_EST + (len(pj) + len(sj)) * 6) / max(1, WORKERS) / 60.0
            step_min[2] = max(step_min[2], mins)
            rows.append(["3. test 5 (blind)", m, "%d prompts, %d recognition, %d sentences" % (len(ch) + extra, len(pj),
                                                                                              len(sj)),
                         "$%.2f" % cost, "%.0f" % mins])
        print(common.format_table(["step", "model", "still to ask", "about", "minutes"], rows))
        print("\nAbout $%.0f in all, about %.0f minutes (plus about 5 minutes to read the tables). Check the providers' "
              "current prices; the estimate uses step3_llm_audit.py's PRICE_PER_M." % (max(1.0, total), sum(step_min)))
        if test5:
            ch0 = test5[0][3][0]
            print("\nThe first test 5 prompt (%s), exactly as sent (system prompt first):\n%s\n%s\n%s\n%s"
                  % (ch0["chunk_id"], "-" * 100, s3.SYSTEM_PROMPT, ch0["user"], "-" * 100))
        print("Next: paste the two keys at the top, set DRY_RUN = False, press Run.")
        return

    # 1. training ratings
    jobs = {m: (todo_train(m), lambda ch, m=m: ask(m, ch), "training prompts") for m in TEACHERS}
    for m in TEACHERS:
        print("1. %s: %d training prompts to ask" % (label(m), len(jobs[m][0])))
    both(jobs)

    # 2. disguises
    print("2. Disguises: %d to write with %s" % (len(dz_todo), DISGUISE_WRITER))
    if dz_todo:
        def write_one(row: Tuple[str, Dict[str, Any], Dict[str, Any]]) -> Dict[str, Any]:
            dz = s3.get_disguise(row[2], calls_allowed=True)
            if dz and not dz.get("failed"):
                return dz
            if isinstance(dz, dict) and dz.get("failed"):   # two answers, neither usable: not asked again
                with _lock:
                    failed_before[row[1]["id"]] = common.stamp()
                log("  disguise / %s: not usable after two tries -- left without a disguise (listed in %s)"
                    % (row[1]["id"], r5.DISGUISE_FAILED_FILE))
            return {"failed": True, "content": isinstance(dz, dict), "cost": (dz or {}).get("cost", 0.0)}
        run_pool(DISGUISE_WRITER, dz_todo, write_one, "disguises")
        common.write_json(common.path(r5.DISGUISE_FAILED_FILE), failed_before)

    # 3. test 5, blind
    chunks5 = test5_chunks()
    jobs = {m: ([ch for ch in chunks5 if load_chunk_answer(label(m), ch) is None], lambda ch, m=m: ask(m, ch),
                "test 5 prompts") for m in TEACHERS}
    for m in TEACHERS:
        print("3. %s: %d test 5 prompts to ask (real and disguised)" % (label(m), len(jobs[m][0])))
    both(jobs)
    pjobs = probe_jobs()

    def probe_one(m: str, job: Tuple[Dict[str, Any], str, str]) -> Dict[str, Any]:
        rec = s3.probe(job[0], job[1], m, job[2])
        return rec or {"failed": True}
    both({m: ([j for j in pjobs if not probe_done(m, j)], lambda j, m=m: probe_one(m, j), "recognition questions")
          for m in TEACHERS})
    both({m: ([c for _, c, _, _ in test5 if load_sentences(m, c) is None], lambda c, m=m: ask_sentences(m, c),
              "sentences-only questions") for m in TEACHERS})

    # summary
    out("Run 5 calls -- summary (%s)%s" % (common.stamp(), " [MOCK]" if MOCK else ""))
    training_summary(train)
    n_dz = sum(1 for _, _, info in dz_rows if r5.load_disguise(info))
    out("2. Disguises: %d of %d tables have one (%d test 5 tables); %d could not be disguised: %s"
        % (n_dz, len(dz_rows), sum(1 for _, _, info, _ in test5 if r5.load_disguise(info)), len(failed_before),
           ", ".join(sorted(failed_before)[:10]) or "none"))
    rows = []
    chunks5 = test5_chunks()
    for m in TEACHERS:
        lab = label(m)
        n_real = sum(1 for ch in chunks5 if ch["condition"] == "real" and load_chunk_answer(lab, ch))
        n_dis = sum(1 for ch in chunks5 if ch["condition"] == "disguised" and load_chunk_answer(lab, ch))
        rows.append([lab, "%d / %d" % (n_real, sum(1 for ch in chunks5 if ch["condition"] == "real")),
                     "%d / %d" % (n_dis, sum(1 for ch in chunks5 if ch["condition"] == "disguised")),
                     "%d / %d" % (sum(1 for j in pjobs if probe_done(m, j)), len(pjobs)),
                     "%d / %d" % (sum(1 for _, c, _, _ in test5 if load_sentences(m, c)), len(test5))])
    out("3. Test 5 (blind; answers saved, not scored):")
    out(common.format_table(["model", "real prompts", "disguised prompts", "recognition", "sentences-only"], rows))
    with open(common.path(SUMMARY_FILE), "w", encoding="utf-8") as f:
        f.write("\n".join(LINES) + "\n")
    frontier_manifest(chunks5, pjobs, [c for _, c, _, _ in test5])
    left = (sum(len(todo_train(m)) for m in TEACHERS) +
            sum(1 for m in TEACHERS for ch in chunks5 if load_chunk_answer(label(m), ch) is None) +
            sum(1 for m in TEACHERS for j in pjobs if not probe_done(m, j)) +
            sum(1 for m in TEACHERS for _, c, _, _ in test5 if load_sentences(m, c) is None))
    print("\n-> %s (%.0f min)." % (SUMMARY_FILE, (time.time() - t0) / 60))
    new_dz = [c["id"] for _, c, info in dz_rows if r5.load_disguise(info) is None and c["id"] not in failed_before]
    if left or new_dz:
        print("%d answers and %d disguises are still missing: press Run again (only those are asked). If the same ones "
              "keep failing, send Claude %s and %s." % (left, len(new_dz), SUMMARY_FILE, LOG_FILE))
    else:
        print("Everything is answered (fingerprints of the test 5 answers: %s). Next: t3_make_training.py."
              % FRONTIER_MANIFEST)


if __name__ == "__main__":
    main()
