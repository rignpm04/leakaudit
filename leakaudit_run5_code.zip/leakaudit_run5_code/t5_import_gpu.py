# t5_import_gpu.py -- brings the pod's answers into this folder: unpacks run5_results.zip (downloaded from RunPod into
# this folder), checks every fingerprint, and stores the answers one file per prompt (llm_cache/<label>/chunks/), the
# way t8_score.py reads them. Python 3.9; press Run in PyCharm. No calls, no keys, no answer key: nothing is scored.
#
#   answers_base_run5.jsonl          -> gpu5-qwen3.5-9b            (untrained; the mean of 3 samples per column)
#   answers_s3407_run5.jsonl, ...    -> gpu5-leakaudit5-s3407, ... (the three trained runs; 3 samples each)
#   answers_gguf_q4_k_m_run5.jsonl   -> gguf5-q4km                 (the laptop files: one greedy answer)
#   answers_gguf_q6_k_run5.jsonl     -> gguf5-q6k
# A column's risk is the mean over the samples that rated it (the retry fills in columns no first-round sample rated);
# its category is the most common one, its reason the first. Each answer is read with step 3's own reader and stamped
# with the hash of the exact prompt it answers. A prompt with no readable sample is stored as unreadable: it counts as
# nothing flagged.

ZIP_FILE = "run5_results.zip"
SEEDS = [3407, 3408, 3409]

# ============================================================ internals
import json
import os
import shutil
import sys
import zipfile
from typing import Any, Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import r5_common as r5  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

import numpy as np  # noqa: E402

TEST_FILE = "test_prompts.jsonl"
RUN_FILE = "train_run5.json"
MANIFEST = "answers_manifest_run5.json"
FILES: Dict[str, Tuple[str, str]] = {"answers_base_run5.jsonl": ("gpu5-qwen3.5-9b", "runpod/qwen3.5-9b (untrained, run 5)")}
for _s in SEEDS:
    FILES["answers_s%d_run5.jsonl" % _s] = ("gpu5-leakaudit5-s%d" % _s, "runpod/leakaudit5-qwen3.5-9b seed %d (run 5)" % _s)
FILES["answers_gguf_q4_k_m_run5.jsonl"] = ("gguf5-q4km", "llama.cpp/leakaudit5 Q4_K_M (run 5)")
FILES["answers_gguf_q6_k_run5.jsonl"] = ("gguf5-q6k", "llama.cpp/leakaudit5 Q6_K (run 5)")
ZIP_NAMES = set(FILES) | {RUN_FILE, MANIFEST, "batching_check_run5.json"} | {"seed_s%d_run5.json" % s for s in SEEDS}


def read_lines(p: str) -> Tuple[List[Dict[str, Any]], int, int]:
    with open(p, "rb") as f:
        raw = f.read()
    nul = raw.count(b"\x00")
    rows, bad = [], 0
    for line in raw.replace(b"\x00", b"").decode("utf-8", "replace").split("\n"):
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except ValueError:
            bad += 1
            continue
        if isinstance(r, dict) and r.get("id"):
            rows.append(r)
        else:
            bad += 1
    return rows, nul, bad


def parse(text: str, columns: List[str]) -> Optional[Dict[str, Any]]:
    return s3.parse_answer(s3.strip_think(text or ""), columns)


def finite(v: Any) -> Optional[float]:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if np.isfinite(x) else None


def combine(first: List[Optional[Dict[str, Any]]], retry: List[Optional[Dict[str, Any]]], columns: List[str]
            ) -> Optional[Dict[str, Any]]:
    """{columns: {col: {leak_risk, category, reason, samples}}, missing, unknown_names}; None if nothing is readable."""
    readable = [p for p in first if p] + [p for p in retry if p]
    if not readable:
        return None
    entries: Dict[str, Dict[str, Any]] = {}

    def numeric(ps: List[Optional[Dict[str, Any]]], c: str) -> List[Dict[str, Any]]:
        return [p["entries"][c] for p in ps if p and c in p["entries"] and finite(p["entries"][c].get("leak_risk"))
                is not None]
    for c in columns:
        rated = numeric(first, c) or numeric(retry, c)   # only a numeric risk counts as rated (as on the pod)
        if not rated:
            continue
        vals = [finite(e.get("leak_risk")) for e in rated]
        cats: Dict[str, int] = {}
        for e in rated:
            cats[e.get("category") or ""] = cats.get(e.get("category") or "", 0) + 1
        best = max(cats.values())
        category = next(e.get("category") or "" for e in rated if cats[e.get("category") or ""] == best)
        entries[c] = {"leak_risk": float(np.mean(vals)), "category": category,
                      "reason": next((e.get("reason") for e in rated if e.get("reason")), ""), "samples": len(rated)}
    unknown: List[str] = []
    for p in readable:
        unknown += [u for u in p["unknown"] if u not in unknown]
    return {"columns": entries, "missing": [c for c in columns if c not in entries], "unknown_names": unknown}


def unpack() -> None:
    p = common.path(ZIP_FILE)
    if not os.path.exists(p):
        return
    with zipfile.ZipFile(p) as z:
        names = [n for n in z.namelist() if n in ZIP_NAMES]   # only the files the notebook writes, nothing else
        for n in names:
            dst = common.path(n)
            data = z.read(n)
            if os.path.exists(dst):
                with open(dst, "rb") as f:
                    if f.read() == data:
                        continue
            with open(dst + ".tmp", "wb") as f:
                f.write(data)
            os.replace(dst + ".tmp", dst)
    print("%s: %d files unpacked or already here" % (ZIP_FILE, len(names)))


def main() -> None:
    unpack()
    for f in (TEST_FILE, RUN_FILE, MANIFEST):
        if not os.path.exists(common.path(f)):
            raise SystemExit("%s is missing: download %s from RunPod into this folder, then press Run again." % (f, ZIP_FILE))
    run = common.load_json(common.path(RUN_FILE)) or {}
    man = common.load_json(common.path(MANIFEST)) or {}
    digest = r5.sha256_file(common.path(TEST_FILE))
    if (run.get("files") or {}).get(TEST_FILE) != digest or (man.get("inputs") or {}).get(TEST_FILE) != digest:
        raise SystemExit("STOP: %s here (sha256 %s...) is not the file the pod answered. Put back the file you uploaded, "
                         "or tell Claude." % (TEST_FILE, digest[:16]))
    bad = [f for f, h in (man.get("answers") or {}).items()
           if not os.path.exists(common.path(f)) or r5.sha256_file(common.path(f)) != h]
    if bad:
        raise SystemExit("STOP: %s do not match their fingerprints in %s: unpack %s again, or tell Claude."
                         % (", ".join(bad), MANIFEST, ZIP_FILE))
    if (man.get("run_record") or {}).get(RUN_FILE) != r5.sha256_file(common.path(RUN_FILE)):
        print("note: %s is not the one %s fingerprinted (the notebook rewrote it later?) -- tell Claude" % (RUN_FILE, MANIFEST))
    tests = {r["id"]: r for r in r5.json_lines(common.path(TEST_FILE))}
    man_sha = r5.sha256_file(common.path(MANIFEST))
    for lab, _ in FILES.values():   # a fresh import: no answer of an earlier pod run may survive, under any label
        if os.path.isdir(common.path("llm_cache", lab)):
            shutil.rmtree(common.path("llm_cache", lab))
    sessions = {"answers_s%d_run5.jsonl" % s: ((run.get("seeds") or {}).get(str(s)) or {}).get("session") for s in SEEDS}
    done_any = False
    for fn, (lab, model_id) in FILES.items():
        if fn not in (man.get("answers") or {}):
            print("%s: not in %s (not made on the pod) -- skipped" % (fn, MANIFEST))
            continue
        rows, nul, nbad = read_lines(common.path(fn))
        if nul or nbad:
            raise SystemExit("STOP: %s holds %d NUL bytes and %d unreadable lines although its fingerprint matches. Tell "
                             "Claude." % (fn, nul, nbad))
        sess = {r.get("session") for r in rows}
        want = sessions.get(fn)
        if len(sess) != 1 or (want and sess != {want}):
            raise SystemExit("STOP: %s mixes answers of different models (%s). Tell Claude." % (fn, sorted(map(str, sess))))
        n_ok, unread, missing, unknown = 0, [], 0, []
        for r in rows:
            t = tests.get(r["id"])
            if t is None:
                unknown.append(r["id"])
                continue
            texts = [str(x or "") for x in (r.get("texts") or [])]
            retry = [str(x or "") for x in (r.get("texts_retry") or [])]
            first = [parse(x, t["columns"]) for x in texts]
            again = [parse(x, t["columns"]) for x in retry]
            parsed = combine(first, again, t["columns"])
            rec = {"case_id": t["table"], "chunk_id": t["id"], "model": lab, "model_id": model_id,
                   "prompt_hash": common.text_hash(model_id, t["system"], t["user"]), "timestamp": common.stamp(),
                   "prompt": t["user"], "condition": t["condition"], "group": t["group"], "raw": texts,
                   "raw_retry": retry or None, "attempts": r.get("attempts"), "usage": {"out": r.get("tokens")},
                   "cost": 0.0, "seconds": r.get("seconds"), "session": r.get("session"),
                   "source": "RunPod notebook (%s)" % fn, "answers_file": fn,
                   "answers_sha256": man["answers"][fn], "manifest_sha256": man_sha,
                   "samples": [x["entries"] if x else None for x in first],
                   "samples_retry": [x["entries"] if x else None for x in again]}
            if parsed:
                rec["parsed"] = parsed
                missing += len(parsed["missing"])
                n_ok += 1
            else:
                rec["parsed"] = None
                rec["unreadable"] = True
                unread.append(t["id"])
            common.write_json(common.path("llm_cache", lab, "chunks", t["id"] + ".json"), rec)
        done_any = True
        absent = len([i for i in tests if i not in {r["id"] for r in rows}])
        print("%-34s -> llm_cache/%s/: %d of %d prompts read, %d unreadable, %d columns unanswered%s"
              % (fn, lab, n_ok, len(tests), len(unread), missing,
                 "; %d prompts without an answer" % absent if absent else ""))
        if unknown:
            print("  note: %d answers are for prompts not in %s (left out)" % (len(unknown), TEST_FILE))
    if done_any:
        print("\nAll answers are stored; nothing was scored. The answer files' fingerprint (SHA-256 of their sorted list) "
              "is %s. Send Claude %s, to publish before the key is opened." % (r5.canonical_sha(man["answers"]), MANIFEST))


if __name__ == "__main__":
    main()
