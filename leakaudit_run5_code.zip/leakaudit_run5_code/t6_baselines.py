# t6_baselines.py -- the two simple baselines of fine-tune run 5, on real test 5. Python 3.9; press Run in PyCharm
# after t1_get_data.py (any time before scoring). No keys, no calls. Needs scikit-learn (see below).
#
#   column check   the vendor-style leak check: each column alone predicts the outcome, 5-fold out of fold, with
#                  gradient-boosted trees (scikit-learn), on at most 8,000 rows. Score 0-100: 100 x |2 AUC - 1| for a
#                  yes/no outcome, 100 x R^2 (at least 0) for a number. A column that predicts the outcome very well
#                  is suspicious. Unlike the language models, it uses the outcome values.
#   keyword rule   a column is flagged (100) when its name holds one of r5_common.py's KEYWORDS (date, status,
#                  total, ...), else 0.
# Nothing here knows which columns leak: the scores are only saved. t8_score.py scores them later, the column check at
# the vendors' default thresholds (DataRobot, H2O) and at its best threshold, like every other method.
# Output: baselines_test5.jsonl (one line per table) and baselines_manifest.json (its SHA-256): send Claude the
# manifest, keep the .jsonl.
#
# scikit-learn: if this stops with "No module named 'sklearn'", install it once in PyCharm: Settings > Project >
# Python Interpreter > + > type scikit-learn > Install Package. Then press Run again.

MAX_ROWS = 8000      # rows used per table (a random sample; yes/no outcomes keep their share of yes)
FOLDS = 5
SEED = 0
TOP_CATS = 200       # a text column keeps its 200 most frequent values; the rest count as one "other" value
MAX_ITER = 60        # boosting rounds per fold
OUT_FILE = "baselines_test5.jsonl"
MANIFEST_FILE = "baselines_manifest.json"

# ============================================================ internals
import json
import os
import sys
import time
import warnings
from typing import Any, Dict, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import r5_common as r5  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

try:
    import sklearn  # noqa: E402
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor  # noqa: E402
    from sklearn.metrics import r2_score, roc_auc_score  # noqa: E402
    from sklearn.model_selection import KFold, StratifiedKFold  # noqa: E402
except ImportError:
    raise SystemExit("scikit-learn is not installed. In PyCharm: Settings > Project > Python Interpreter > + > type "
                     "scikit-learn > Install Package. Then press Run again.")

warnings.filterwarnings("ignore")


def feature(s: pd.Series) -> Tuple[np.ndarray, bool, str]:
    """The column as one number per row: numbers as they are, dates as days, text as the code of its value."""
    typ, vals = common.analyze_column(s)
    if typ == "numeric":
        return vals.astype(float).to_numpy(), False, typ
    if typ == "date":
        return common.days_since_epoch(vals).astype(float).to_numpy(), False, typ
    txt = s.astype(str)
    vc = txt[s.notna()].value_counts()
    top = {v: i for i, v in enumerate(vc.index[:TOP_CATS])}
    codes = txt.map(lambda v: top.get(v, len(top))).astype(float)
    codes[s.isna().to_numpy()] = np.nan
    return codes.to_numpy(), True, typ


def score_column(x: np.ndarray, cat: bool, y: np.ndarray, task: str) -> float:
    ok = ~np.isnan(x)
    if ok.sum() == 0 or (np.nanstd(x) == 0 and ok.all()):
        return 0.0
    X = x.reshape(-1, 1)
    oof = np.full(len(y), np.nan)
    if task == "binary":
        cv = StratifiedKFold(FOLDS, shuffle=True, random_state=SEED)
        for tr, te in cv.split(X, y):
            if len(np.unique(y[tr])) < 2:
                continue
            m = HistGradientBoostingClassifier(max_iter=MAX_ITER, learning_rate=0.1, categorical_features=[cat],
                                               random_state=SEED)
            m.fit(X[tr], y[tr])
            oof[te] = m.predict_proba(X[te])[:, 1]
        k = ~np.isnan(oof)
        if len(np.unique(y[k])) < 2:
            return 0.0
        return abs(2 * roc_auc_score(y[k], oof[k]) - 1)
    cv = KFold(FOLDS, shuffle=True, random_state=SEED)
    for tr, te in cv.split(X):
        m = HistGradientBoostingRegressor(max_iter=MAX_ITER, learning_rate=0.1, categorical_features=[cat],
                                          random_state=SEED)
        m.fit(X[tr], y[tr])
        oof[te] = m.predict(X[te])
    return max(0.0, r2_score(y, oof))


def one_table(c: Dict[str, Any]) -> Dict[str, Any]:
    df = common.read_data(c["id"])
    y = pd.to_numeric(df[common.TARGET], errors="coerce")
    keep = y.notna()
    df, y = df[keep], y[keep]
    if c["task"] == "binary":
        y = (y == 1).astype(int)
    idx = common.sample_index(y, MAX_ROWS, SEED, stratify=c["task"] == "binary")
    df, yv = df.loc[idx], y.loc[idx].to_numpy()
    out: Dict[str, Any] = {}
    for col in [k for k in df.columns if k != common.TARGET]:
        rec: Dict[str, Any] = {"keyword": 100 if r5.keyword_flag(col) else 0}
        try:
            x, cat, typ = feature(df[col])
            v = score_column(x, cat, yv.astype(float) if c["task"] != "binary" else yv, c["task"])
            rec.update(colcheck=round(100.0 * float(v), 2), type=typ)
        except Exception as e:  # a column the check cannot score counts as score 0
            rec.update(colcheck=0.0, type="error", error=" ".join(str(e).split())[:200])
        out[col] = rec
    return {"table": c["id"], "task": c["task"], "rows_used": int(len(yv)), "columns": out}


def main() -> None:
    cases = common.load_cases(quiet=True, file=r5.TEST5_FILE)
    missing = [c["id"] for c in cases if not common.has_data(c["id"])]
    if missing:
        raise SystemExit("No data for %d test 5 table(s) (%s): run t1_get_data.py first."
                         % (len(missing), ", ".join(missing[:5])))
    t0 = time.time()
    tmp = common.path(OUT_FILE + ".tmp")
    n_cols, errors = 0, []
    with open(tmp, "w", encoding="utf-8") as f:
        for i, c in enumerate(cases, 1):
            rec = one_table(c)
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_cols += len(rec["columns"])
            errors += ["%s / %s" % (c["id"], k) for k, v in rec["columns"].items() if v["type"] == "error"]
            print("%2d/%d %-44s %3d columns  %.0f s" % (i, len(cases), c["id"], len(rec["columns"]), time.time() - t0))
    os.replace(tmp, common.path(OUT_FILE))
    digest = r5.sha256_file(common.path(OUT_FILE))
    common.write_json(common.path(MANIFEST_FILE),
                      {"run": 5, "file": OUT_FILE, "sha256": digest, "tables": len(cases), "columns": n_cols,
                       "columns_not_scored": errors,
                       "settings": {"max_rows": MAX_ROWS, "folds": FOLDS, "seed": SEED, "top_cats": TOP_CATS,
                                    "max_iter": MAX_ITER, "keywords": r5.KEYWORDS},
                       "versions": {"python": sys.version.split()[0], "sklearn": sklearn.__version__,
                                    "pandas": pd.__version__, "numpy": np.__version__},
                       "created": common.stamp()})
    print("\n%d tables, %d columns -> %s (sha256 %s...)%s" % (len(cases), n_cols, OUT_FILE, digest[:16],
          "; %d column(s) could not be scored (count as 0): %s" % (len(errors), ", ".join(errors[:5])) if errors
          else ""))
    print("Part A is done. Send Claude these five files: teacher_summary.txt, train_manifest.json, test_manifest.json, "
          "frontier_manifest.json and %s." % MANIFEST_FILE)


if __name__ == "__main__":
    main()
