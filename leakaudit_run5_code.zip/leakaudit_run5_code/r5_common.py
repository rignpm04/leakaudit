# r5_common.py -- helpers shared by the run 5 scripts (a library; nothing to run). Python 3.9.
# The chunk prompts are step3_llm_audit.py's own (run 3/4 format, at most 10 rated columns each). A disguised table's
# prompts are built the same way from GPT's disguise (disguised/<id>.json): new column names, labels and task text,
# numbers rounded, dates shifted, columns shuffled (step3's disguised_parts); each disguised prompt keeps the map from
# the names it shows back to the real columns, so answers can be scored against the real table's key.
import hashlib
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step3_llm_audit as s3  # noqa: E402

TEST5_FILE = "cases_test5_blind.json"
DISGUISE_FAILED_FILE = "disguise_failed.json"
GEN_GROUPS = ["training domains", "held-out domains", "trap tables"]
TEST5_REAL, TEST5_DISGUISED = "real test 5", "real test 5 disguised"
GROUPS = GEN_GROUPS + [TEST5_REAL, TEST5_DISGUISED]

# The sentences-only check: can the three task sentences alone tell a table with leaks from a clean one?
SENTENCES_SYSTEM = ("You assess prediction tasks on tables before any model is trained. Answer with one json object "
                    "only.")
SENTENCES_QUESTION = (
    "You do not see the table's columns. Based only on these three sentences, how likely is it (0-100) that the table "
    "includes at least one column that leaks: a value that would not yet be known at the prediction moment, a value "
    "computed from the outcome, or an identifier that lets a model memorize outcomes?\n"
    'Return only a json object: {"likelihood": <0-100>, "reason": "<one short sentence>"}')
SENTENCES_MAX_TOKENS = 4000   # room for a reasoning model's thinking (as step 3's PROBE_MAX_TOKENS)

# The keyword rule (a baseline): a column is flagged when its name holds one of these words (whole words, any case;
# names are split at _, -, ., spaces and camelCase). Fixed before test 5 was scored.
KEYWORDS = ["date", "dt", "time", "status", "result", "results", "outcome", "final", "total", "end", "ended", "closed",
            "close", "paid", "payment", "due", "after", "post", "later", "last", "completed", "complete", "resolved",
            "resolution", "disposition", "discharge", "death", "died", "score", "rating", "won", "win", "loss", "lost",
            "approved", "rejected", "denied", "settled", "actual", "returned"]


def sha256_file(p: str) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def name_words(name: str) -> List[str]:
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(name))
    return [w for w in re.split(r"[^A-Za-z0-9]+", s.lower()) if w]


def keyword_flag(name: str) -> bool:
    words = set(name_words(name))
    return any(k in words for k in KEYWORDS)


def real_chunks(info: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The table's chunk prompts exactly as run 4 built them, each with the identity map of its columns."""
    return [dict(ch, condition="real", original={c: c for c in ch["columns"]}) for ch in s3.chunk_prompts(info)]


def disguised_user(text: Dict[str, str], task: str, shown_all: List[str], rows: str, lines: List[str], part: int,
                   parts: int) -> str:
    """A chunk prompt in run 4's exact layout, for a disguised table (rows given as 'about N rows')."""
    kind = "binary classification" if task == "binary" else "regression"
    head = ["Unit of observation: " + (text.get("unit") or "(not given)"),
            "Target (%s): %s" % (kind, text.get("target_description") or "(not given)"),
            "Prediction moment: " + (text.get("prediction_time") or "(not given)"),
            "",
            "The table has %d columns besides the target (values from %s). All of them: %s"
            % (len(shown_all), rows, ", ".join(s3.shown_name(c) for c in shown_all)),
            "",
            "Rate these %d columns (part %d of %d) -- name | type | missing | distinct values | examples:"
            % (len(lines), part, parts)]
    return "\n".join(head + lines + ["", s3.INSTRUCTION_CHUNK % len(lines)])


def disguised_chunks(info: Dict[str, Any], dz: Dict[str, Any], key: Optional[str] = None) -> List[Dict[str, Any]]:
    """The disguised table's chunk prompts (info from step3's prepare_case, which holds the disguise statistics).
    Chunk ids '<key>__d<j>of<k>'; 'columns' are the names shown, 'original' maps them back."""
    key = key or info["id"]
    order, _ = s3.disguise_layout(info)
    text, lines_all, rows = s3.disguised_parts(info, dz)
    line_of = dict(zip(order, lines_all))
    shown_all = [dz["names"][c] for c in order]
    groups = s3.chunk_parts(order)
    out = []
    for j, g in enumerate(groups, 1):
        out.append({"chunk_id": "%s__d%dof%d" % (key, j, len(groups)), "table": info["id"], "condition": "disguised",
                    "part": j, "parts": len(groups), "columns": [dz["names"][c] for c in g],
                    "original": {dz["names"][c]: c for c in g},
                    "user": disguised_user(text, info["task"], shown_all, rows, [line_of[c] for c in g], j,
                                           len(groups))})
    return out


def sentences_user(case: Dict[str, Any]) -> str:
    kind = "binary classification" if case["task"] == "binary" else "regression"
    return "\n".join(["Unit of observation: " + (case.get("unit") or "(not given)"),
                      "Target (%s): %s" % (kind, case.get("target_description") or "(not given)"),
                      "Prediction moment: " + (case.get("prediction_time") or "(not given)"),
                      "", SENTENCES_QUESTION])


def parse_sentences(text: str) -> Optional[Dict[str, Any]]:
    obj = common.extract_json(text)
    if isinstance(obj, dict):
        v = s3.to_risk(obj.get("likelihood"))
        if v == v:
            return {"likelihood": v, "reason": " ".join(str(obj.get("reason") or "").split())[:300]}
    m = re.search(r'"likelihood"\s*:\s*(\d+(?:\.\d+)?)', text or "")
    if m:
        return {"likelihood": min(100.0, max(0.0, float(m.group(1)))), "reason": ""}
    return None


def load_disguise(info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """GPT's saved disguise of this table if it fits today's prompt, else None (no call)."""
    dz = s3.get_disguise(info, calls_allowed=False)
    return dz if dz and not dz.get("failed") else None


def json_lines(p: str) -> List[Dict[str, Any]]:
    out = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                out.append(json.loads(line))
    return out


# ============================================================ run 5 scoring helpers (t7, t8)
SEALED_ZIP = "test5_sealed_2026-10-26.zip"
SEALED_SHA256 = "853b13b2724edf2aa26d2f0cbf7ddbea09b4120c7b434dc620916e0694337588"


def read_sealed(path: str) -> Dict[str, Any]:
    """The sealed test 5 bundle: verified against its public SHA-256, then its key and labeling files."""
    import zipfile
    if not os.path.exists(path):
        raise SystemExit("%s is not in this folder: copy it out of leak_private_keep.zip (only now, at scoring)." % SEALED_ZIP)
    if sha256_file(path) != SEALED_SHA256:
        raise SystemExit("STOP: %s is not the sealed file (its SHA-256 differs from the public one). Tell Claude." % path)
    with zipfile.ZipFile(path) as z:
        cases = json.loads(z.read("cases_test5.json").decode("utf-8"))
        codes = json.loads(z.read("labeling/label_codes_test5.json").decode("utf-8"))
    return {"cases": cases, "codes": codes}


def read_xlsx(path: str) -> Dict[str, Dict[str, Any]]:
    """The cell values of every sheet of an .xlsx file, {sheet name: {"B9": value}}, with the standard library only
    (shared strings, inline strings, numbers, booleans and cached formula results)."""
    import zipfile
    import xml.etree.ElementTree as ET
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
          "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
          "pr": "http://schemas.openxmlformats.org/package/2006/relationships"}
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        shared: List[str] = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si", ns):
                shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        target = {r.get("Id"): r.get("Target") for r in rels.findall("pr:Relationship", ns)}
        out: Dict[str, Dict[str, Any]] = {}
        for sh in wb.find("m:sheets", ns).findall("m:sheet", ns):
            rid = sh.get("{%s}id" % ns["r"])
            t = target.get(rid, "")
            p = t.lstrip("/") if t.startswith("/") else "xl/" + t
            root = ET.fromstring(z.read(p))
            cells: Dict[str, Any] = {}
            for c in root.iter("{%s}c" % ns["m"]):
                kind, v = c.get("t"), c.find("m:v", ns)
                if kind == "s" and v is not None:
                    val: Any = shared[int(v.text)]
                elif kind == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter("{%s}t" % ns["m"]))
                elif kind == "b" and v is not None:
                    val = v.text == "1"
                elif v is not None and v.text is not None:
                    if kind in ("str", "e"):
                        val = v.text
                    else:
                        try:
                            f = float(v.text)
                            val = int(f) if f.is_integer() else f
                        except ValueError:
                            val = v.text
                else:
                    continue
                cells[c.get("r")] = val
            out[sh.get("name")] = cells
    return out


def guess_words(text: Any) -> List[str]:
    return re.findall(r"[a-z0-9]+", str(text or "").lower())


def names_source(guess: Any, alias: Dict[str, Any]) -> bool:
    words = guess_words(guess)
    return any(all(any(w.startswith(t.lower()) for w in words) for t in toks) for toks in alias.get("source") or [])


def names_edition(guess: Any, alias: Dict[str, Any]) -> bool:
    if not names_source(guess, alias):
        return False
    g = " " + " ".join(guess_words(guess)) + " "
    return any((" " + " ".join(guess_words(e)) + " ") in g for e in alias.get("edition") or [])


def auc(pos: List[float], neg: List[float]) -> float:
    """The chance that a random positive scores above a random negative (ties count half); nan if a side is empty."""
    if not pos or not neg:
        return float("nan")
    n = 0.0
    for p in pos:
        for q in neg:
            n += 1.0 if p > q else (0.5 if p == q else 0.0)
    return n / (len(pos) * len(neg))


_TOP_ITEM = re.compile(r'"((?:[^"\\]|\\.)*)" (<1%|\d+%)')


def ties_only(a: Any, b: Any) -> bool:
    """Two 'top:' example lists that differ only in the order or choice of equally frequent categories (pandas
    versions break ties differently): the same shares, and the same values above the lowest share."""
    a, b = str(a or ""), str(b or "")
    if not (a.startswith("top: ") and b.startswith("top: ")):
        return False
    ia, ib = _TOP_ITEM.findall(a), _TOP_ITEM.findall(b)
    if not ia or len(ia) != len(ib) or sorted(p for _, p in ia) != sorted(p for _, p in ib):
        return False

    def pct(p: str) -> float:
        return 0.4 if p == "<1%" else float(p[:-1])
    low = min(pct(p) for _, p in ia)
    return {v for v, p in ia if pct(p) > low} == {v for v, p in ib if pct(p) > low}


def canonical_sha(files: Dict[str, str]) -> str:
    """One SHA-256 for a set of fingerprinted files: over the sorted lines '<path> <sha256>' (independent of the order
    and of any time stamp in the manifest that lists them)."""
    return hashlib.sha256("\n".join("%s %s" % (k, files[k]) for k in sorted(files)).encode("utf-8")).hexdigest()
