# Fine-tune run 5: step by step

**The goal:** the first formal test of the leak finder, written down in public before any result. Run 5 trains the
same 9B model as run 4 (Qwen3.5 9B), three times with three seeds, and tests it on sealed real test 5 (68 new tables
whose answer key is sealed; its fingerprint is already public in release v0.1).

What is new since run 4:
- **Real test 4 becomes training data** (its results were read for run 4's verdict, so it can never be a test again).
- **Disguised copies in training.** GPT rewrites every public training table once (new column names, labels and task
  text). The model learns from both copies, so it has to judge columns by what they hold, not by which dataset it
  recognizes.
- **Blind testing.** Nothing on your Mac or on the pod knows test 5's answers. Claude, GPT and the small model answer
  the same prompts; the answers are fingerprinted and published before anything is scored.
- **Baselines** that need no AI: the vendor-style column check (DataRobot / H2O style) and a keyword rule.

## Part A: now, on your Mac (about 2-3 hours, mostly waiting; about $40 of API calls)

1. **Set up the folder.** Unzip `leak_training_5_kit_A.zip` into your PyCharm project. You get a folder called
   `leak training 5`. Keep `leak training 4` and `leak test 5` as they are.
2. **`t0_import.py`.** Check the two paths at the top (`RUN4_FOLDER` = your `leak training 4` folder, `TEST5_FOLDER` =
   your `leak test 5` folder), then press Run. It must end with `frozen test 5 files  46` in its table and
   `Tables here: 42 generated test; development 27 + 47 + 55 + 56; ...; test 5: 68 (46 frozen here, 22 to download).`
3. **`t1_get_data.py`** (a few minutes; downloads 22 files from GitHub). It must end with
   `cases_test5_blind.json: 68 of 68 tables ready.`
4. **`t2_teachers.py`, dry run.** Press Run as shipped (`DRY_RUN = True`). In its table, "1. training ratings" should
   be about 110-120 for each model (only real test 4 is new there). If either shows more than 300, stop and send me the
   output. The total should be about $35-50.
5. **`t2_teachers.py`, real run.** Paste your Anthropic and OpenAI keys at the top, set `DRY_RUN = False`, press Run.
   About 1.5-2 hours. If it stops or says answers are missing, press Run again: it only asks what is missing. It is
   done when it prints `Everything is answered`.
6. **`t3_make_training.py`** (about 5 minutes). It must end with `Next: t4_make_test_prompts.py`.
7. **`t4_make_test_prompts.py`** (1 minute). Its last lines must show the same two numbers for each model, e.g.
   `claude 387 / 387; gpt 387 / 387`.
8. **`t6_baselines.py`** (about 10 minutes). If it says scikit-learn is missing: PyCharm > Settings > Project > Python
   Interpreter > + > type `scikit-learn` > Install Package, then press Run again.
9. **Send me these five files** (all small, no test content): `teacher_summary.txt`, `train_manifest.json`,
   `test_manifest.json`, `frontier_manifest.json`, `baselines_manifest.json`.

## Part B: the pre-registration, then the pod (about 8-10 hours on the pod, mostly unattended)

1. **Unzip `leak_training_5_kit_B.zip` into `leak training 5`** (it adds the notebook, `t5`, `t7`, `t8`, and an
   updated `r5_common.py`; replace when asked).
2. **Publish the pre-registration first** (GitHub website, as for v0.1): upload the files of the
   `leakaudit_v1.0-prereg` folder Claude sends, then make a release called `v1.0-prereg`. Zenodo gives it a DOI;
   send it to Claude. Nothing below may start before this.
3. **RunPod:** an A100 80 GB (or an H100) pod, RunPod's PyTorch 2.8.0 template, container disk 200 GB, volume disk
   200 GB. In JupyterLab upload `train.jsonl`, `val.jsonl`, `test_prompts.jsonl` and `train5_runpod_run5.ipynb`, then
   Run > Run All Cells. You can close the tab; it keeps running. If the pod restarts: open the notebook, Run All Cells
   again (finished parts are kept).
4. **At the end:** download `run5_results.zip` (and, if you want it for LM Studio, the `...Q4_K_M.gguf` file), then
   terminate the pod.
5. **`t5_import_gpu.py`:** put `run5_results.zip` into `leak training 5` and press Run. Send Claude
   `answers_manifest_run5.json` (only fingerprints). Claude sends the small public release that dates them.

## Part C: scoring (after the hand labels are back)

1. Send Claude the returned labeling workbooks. Claude checks them against the sealed key (`t7_label_review.py`) and
   sends back `key_corrections.json`, `label_review_run5.json`, `test5_aliases.json` and `t8_score.py` (with the
   published answer fingerprint filled in).
2. Put those four files into `leak training 5`, the workbooks into a folder `labels` inside it, and copy
   `test5_sealed_2026-10-26.zip` out of `leak_private_keep.zip` into `leak training 5` (only now).
3. **`t8_score.py`:** press Run. Send Claude `results_run5.txt` and `results_run5.json`.

## Keep private

- Keys go only into `t2_teachers.py`, on your Mac. Never paste them into a chat; never send that file with keys in it.
- Test 5 stays on your Mac until the results are out: do not upload or share `cases_test5_blind.json`,
  `test_prompts.jsonl`, `baselines_test5.jsonl`, `data/`, `llm_cache/` or `disguised/`.
- Until Part C, nothing needs the sealed key: leave `leak_private_keep.zip` closed.
- Anthropic and OpenAI get task sentences and column summaries of public tables, as in every earlier run.
