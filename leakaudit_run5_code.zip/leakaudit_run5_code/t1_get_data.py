# t1_get_data.py -- prepares real test 5 (cases_test5_blind.json, 68 tables) the way every earlier test set was
# prepared: each table read with its case's format and written as data/<id>.csv.gz + data/<id>.meta.json (target
# renamed "target", at most 50,000 rows). Python 3.9; press Run in PyCharm after t0_import.py. No keys.
#
# Batch 1 (22 tables) is downloaded from GitHub, pinned to a fixed commit. Batch 2 (46 tables) is NOT downloaded: its
# frozen copies come from your "leak test 5" folder (t0_import.py puts them in data/raw/). Every file must have the
# SHA-256 the case lists, or that table stops. The cases file holds no answer key ("blind"): nothing here can score.
# Tables already prepared are skipped, so running it again only does what is missing.

CASES_FILES = ["cases_test5_blind.json"]
FORCE = False                # True: prepare every table again (the frozen and downloaded files are kept)

# ============================================================ internals
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import common  # noqa: E402
import step1_get_data as s1g  # noqa: E402

EXPECTED = 68


def changed(case: dict) -> bool:
    """The table in data/ was prepared for another version of this case (url, target, task, a column now dropped or
    renamed), or with more rows than its file had: it is prepared again (the downloaded file is kept)."""
    m = common.read_meta(case["id"])
    if not m:
        return False
    cols = set(m.get("columns") or {})
    split = isinstance(m.get("rows"), int) and isinstance(m.get("rows_in_file"), int) and m["rows"] > m["rows_in_file"]
    renamed = any(c in cols for c in (case.get("rename_columns") or {}))
    return (m.get("url") != case["url"] or m.get("target_original") != case["target"] or m.get("task") != case["task"]
            or any(c in cols for c in case["drop_columns"]) or renamed or split)


def main() -> None:
    s1g.FORCE = FORCE
    t0 = time.time()
    for fname in CASES_FILES:
        if not os.path.exists(common.path(fname)):
            raise SystemExit("%s is not in this folder: it comes with the run 5 kit." % fname)
        cases = common.load_cases(quiet=True, file=fname)
        not_blind = [c["id"] for c in cases if c["kind"] != "blind" or c.get("leak_columns")]
        if not_blind:
            raise SystemExit("STOP: %s holds answer-key fields (%s). Tell Claude." % (fname, ", ".join(not_blind[:5])))
        frozen = [c["id"] for c in cases if c.get("batch") == 2 and
                  not os.path.exists(os.path.join(common.raw_dir(c["id"]), s1g.file_name(c["url"])))]
        if frozen:
            raise SystemExit("STOP: %d frozen batch-2 file(s) are not in data/raw/ (e.g. %s): run t0_import.py first."
                             % (len(frozen), ", ".join(frozen[:5])))
        again = [c["id"] for c in cases if not FORCE and common.has_data(c["id"]) and changed(c)]
        for cid in again:
            s1g.remove_outputs(cid)
        if again:
            print("%s: %d table(s) changed since they were prepared, prepared again: %s"
                  % (fname, len(again), ", ".join(again[:12])))
        todo = [c for c in cases if FORCE or not common.has_data(c["id"])]
        print("%s: %d tables, %d to prepare" % (fname, len(cases), len(todo)))
        rows = s1g.prepare(cases)
        bad = [r for r in rows if r[3] not in ("ok", "ready")]
        if bad:
            print("\nNot ready:")
            print(common.format_table(["case", "problem"], [[r[0], r[10]] for r in bad]))
            raise SystemExit("STOP: %d of %d test 5 tables are not ready (above). Press Run again; if the same ones "
                             "stay, send Claude this output." % (len(bad), len(rows)))
        garbled = [(c["id"], common.read_meta(c["id"]).get("garbled_signatures") or 0) for c in cases]
        garbled = [g for g in garbled if g[1]]
        if garbled:
            print("Garbled-text signatures (counted, not changed): %s"
                  % ", ".join("%s %d" % g for g in garbled))
        print("\n%s: %d of %d tables ready%s. (%.0f s)" % (fname, len(rows), len(rows),
              "" if len(rows) == EXPECTED else " -- expected %d: tell Claude" % EXPECTED, time.time() - t0))
    print("Next: t2_teachers.py (DRY_RUN first).")


if __name__ == "__main__":
    main()
